# Third-party notices

This overlay is licensed under the Apache License 2.0 (see `LICENSE`). It was assembled in the junkyard chop shop
from parts pulled out of the owner's GitHub Junkyard. Donor repositories were **read only** —
no donor was modified — and only permissively licensed parts were used.

Every entry below states what was taken and in what form:

- **verbatim** — the donor's file is checked in here byte-for-byte, with its license beside it.
- **adapted** — donor code was rewritten for this runtime; the design is the donor's, the code here is not.
- **pattern** — only the approach was reused; no donor code was copied.

## Verbatim

| Part | Donor | License | Where it lives | Used for |
|---|---|---|---|---|
| `redaction.py` | `amplifier-bundle-redaction` (Microsoft) | MIT (header retained in file) | `architecture_studio/vendor/redaction.py` | secret detection and redaction primitives behind `security.scan_for_secrets` / `security.redact` |
| `text_attack_test.json`, `code_attack_test.json` | `BIPIA` (Microsoft) | MIT (`fixtures/adversarial/bipia/LICENSE`) | `fixtures/adversarial/bipia/` | 125 indirect-prompt-injection **attack** cases in the benchmark (XEVAL-02, MODEL-07, SEC-01) |
| `fp_tests.json` | `llmail-inject-challenge` (Microsoft) | MIT (`fixtures/adversarial/llmail/LICENSE`) | `fixtures/adversarial/llmail/` | 203 benign email **controls** for the injection false-positive rate (GATE-PROD-02, XOBS-03) |

## Adapted

| Part | Donor | License | Where the design shows up |
|---|---|---|---|
| envelope encryption (KEK/DEK split, provider boundary) | `custom-azure-data-encryption` (Microsoft) | MIT | `architecture_studio/crypto.py` — AES-256-GCM and an authenticated key wrap replace the donor's CBC/NUL-padding and SHA-1; the provider is a slot that fails closed |
| content-addressed version store, compare-and-swap refs, backup/restore manifests | `Project_Repository_Context_Graph` (`rcg/versionstore.py`), owner's own | MIT | `architecture_studio/store.py`, `architecture_studio/backup.py` |
| observability shape: rates that always carry a denominator, span trees per run, SLO reporting | `Project_Repository_Context_Graph` (`rcg/observability.py`) + `_YARDOFFICE/spb` observability | owner's own / no LICENSE file in `_YARDOFFICE/spb` (see note) | `architecture_studio/observability.py`, `architecture_studio/slo.py` |
| provider-slot with no default occupant; binding as a recorded human act | `Project_Repository_Context_Graph` (`rcg/bindings.py`) | MIT | `architecture_studio/generator.py` (`ProviderSlot`) |
| hard-limit composition that may only narrow | `_YARDOFFICE/spb` (`hard_limits.effective_caps`) | see note | `architecture_studio/slo.py` (`effective_ceilings`), `architecture_studio/scope.py` (`effective_permissions`) |
| fail-closed gate + preview-before-write | `Project_Embedded_Quality_Gate` | MIT (owner's own) | `architecture_studio/writes.py` |
| evidence-first record/report discipline | `Project_Trace_to_Diff` | owner's own | `architecture_studio/evidence_records.py`, `tools/build_evidence.py` |
| diagram round-trip expectation (render, parse back, compare ids) | `mxc-main` (Microsoft) | MIT | `architecture_studio/diagrams.py`, `connectors/parsers.parse_mermaid` |

## Pattern only

- Hash-chained append-only audit ledger — a standard construction; the implementation here is original.
- BM25 retrieval scoring — a published algorithm; the implementation here is original and dependency-free.
- SPDX 2.3 SBOM document shape — an open specification.

## Notes

- **`_YARDOFFICE/spb` has no LICENSE file.** It is the owner's own vendored Scoped PR Builder runtime inside
  the owner's yard office, so the owner holds the rights; nothing from it is checked in here verbatim — only
  the composition-narrows-only pattern was reused. If that code is ever redistributed, it should get an
  explicit license first.
- The generic project corpus (612 files, 66 JA21/DeepML suites) that this overlay sits on top of is the
  owner's own repository. The overlay does not modify it; it reads it as evidence.
- The ASRTD v1.4.0 prompt/workflow package is a sealed input, not a dependency. Its manifests and the two
  pinned source documents are copied under `source/` with a `SOURCE_LOCK_v1.4.0.json` recording their digests;
  the package's own validator is not vendored here and is run from the package.

## Runtime dependencies

There are **no required** third-party runtime dependencies. `cryptography` is optional; when it is absent,
Ed25519 approval signatures and at-rest encryption report themselves as unavailable rather than silently
falling back (see `architecture_studio/approvals.py` and `architecture_studio/crypto.py`).
`architecture_studio.supply_chain.policy_check()` asserts this and is part of the test suite.
