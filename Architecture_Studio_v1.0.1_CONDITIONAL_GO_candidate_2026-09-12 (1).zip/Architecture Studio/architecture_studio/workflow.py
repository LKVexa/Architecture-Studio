"""Versioned workflow state machine (IMPL-03, API-06, API-07, XSTATE-01..03, WF-12).

States and transitions are declared data. A transition that is not declared
cannot happen; every transition that does happen is recorded to the ledger
with the authority under which it occurred, so an interrupted run can be
reconstructed from the ledger alone (XSTATE-03, STORE-01).

Load-bearing properties, each proven by a test:

* Terminal states are absorbing (``COMPLETED``, ``ABSTAINED``, ``REJECTED``,
  ``ABORTED``, ``ROLLED_BACK``, ``DENIED``).
* Every path to ``APPROVED`` passes through ``AWAITING_REVIEW`` and the
  ``approve`` event, which only a human principal may raise (WF-10, XHITL-02,
  PAPER-GRD-01) — structural, not a runtime check at one call site.
* ``reject`` leads only to ``REJECTED``, from which nothing follows
  (HUMAN-04: no side effect).
* A retried step with the same idempotency key is a no-op that returns the
  state the first call produced (API-06).

Adapted from the owner's Repository Context Graph runtime (``rcg/workflow.py``).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping

from .canonical import digest_of, fmt_ts
from .ids import deterministic_id
from .schemas import validate

__all__ = ["WorkflowState", "TransitionError", "WorkflowMachine", "STATE_MACHINE_VERSION", "TRANSITIONS",
           "TERMINAL_STATES", "HUMAN_ONLY_EVENTS", "SAFE_TERMINALS"]

STATE_MACHINE_VERSION = "1.0.0"


class WorkflowState:
    CREATED = "CREATED"
    AUTHORIZED = "AUTHORIZED"            # WF-01
    PINNED = "PINNED"                    # WF-02
    COLLECTING = "COLLECTING"            # WF-03
    INDEXED = "INDEXED"                  # WF-04
    ANALYZED = "ANALYZED"                # WF-05
    GENERATED = "GENERATED"              # WF-06 / WF-07
    VERIFIED = "VERIFIED"                # WF-08
    AWAITING_REVIEW = "AWAITING_REVIEW"  # WF-09
    CLARIFYING = "CLARIFYING"            # PAPER-CAP-05
    SCOPE_NARROWED = "SCOPE_NARROWED"    # HUMAN-03
    EVIDENCE_REQUESTED = "EVIDENCE_REQUESTED"  # HUMAN-05
    EDITED = "EDITED"                    # XHITL-03 edit goals/constraints
    APPROVED = "APPROVED"                # WF-10
    EXPORTING = "EXPORTING"              # WF-11
    COMPLETED = "COMPLETED"
    ABSTAINED = "ABSTAINED"
    REJECTED = "REJECTED"
    ABORTED = "ABORTED"
    ROLLED_BACK = "ROLLED_BACK"
    DENIED = "DENIED"


_S = WorkflowState
TRANSITIONS: dict[str, dict[str, str]] = {
    _S.CREATED: {"authority_established": _S.AUTHORIZED, "policy_denied": _S.DENIED, "abort": _S.ABORTED},
    _S.AUTHORIZED: {"revisions_pinned": _S.PINNED, "policy_denied": _S.DENIED, "abort": _S.ABORTED},
    _S.PINNED: {"collect_evidence": _S.COLLECTING, "policy_denied": _S.DENIED, "abort": _S.ABORTED},
    _S.COLLECTING: {"evidence_indexed": _S.INDEXED, "abstain": _S.ABSTAINED, "tool_failure": _S.ABORTED,
                    "policy_denied": _S.DENIED, "abort": _S.ABORTED},
    _S.INDEXED: {"analysis_complete": _S.ANALYZED, "abstain": _S.ABSTAINED, "policy_denied": _S.DENIED,
                 "abort": _S.ABORTED},
    _S.ANALYZED: {"candidates_generated": _S.GENERATED, "clarification_needed": _S.CLARIFYING,
                  "abstain": _S.ABSTAINED, "tool_failure": _S.ABORTED, "policy_denied": _S.DENIED,
                  "abort": _S.ABORTED},
    _S.CLARIFYING: {"question_answered": _S.ANALYZED, "abstain": _S.ABSTAINED, "abort": _S.ABORTED},
    _S.GENERATED: {"verification_passed": _S.VERIFIED, "verification_failed": _S.ABORTED,
                   "policy_denied": _S.DENIED, "abort": _S.ABORTED},
    _S.VERIFIED: {"submit_for_review": _S.AWAITING_REVIEW, "policy_denied": _S.DENIED, "abort": _S.ABORTED},
    _S.AWAITING_REVIEW: {"approve": _S.APPROVED, "reject": _S.REJECTED, "narrow_scope": _S.SCOPE_NARROWED,
                         "request_more_evidence": _S.EVIDENCE_REQUESTED, "edit": _S.EDITED,
                         "abort": _S.ABORTED},
    _S.SCOPE_NARROWED: {"collect_evidence": _S.COLLECTING, "abort": _S.ABORTED},
    _S.EVIDENCE_REQUESTED: {"collect_evidence": _S.COLLECTING, "abort": _S.ABORTED},
    _S.EDITED: {"analysis_complete": _S.ANALYZED, "abort": _S.ABORTED},
    _S.APPROVED: {"export_case_file": _S.EXPORTING, "policy_denied": _S.DENIED, "abort": _S.ABORTED},
    _S.EXPORTING: {"export_succeeded": _S.COMPLETED, "export_failed": _S.ROLLED_BACK, "rollback": _S.ROLLED_BACK},
}

TERMINAL_STATES = frozenset({_S.COMPLETED, _S.ABSTAINED, _S.REJECTED, _S.ABORTED, _S.ROLLED_BACK, _S.DENIED})
#: Terminals a failure may legally end in (WF-12): explicit, safe, no external effect.
SAFE_TERMINALS = frozenset({_S.ABSTAINED, _S.REJECTED, _S.ABORTED, _S.ROLLED_BACK, _S.DENIED})
HUMAN_ONLY_EVENTS = frozenset({"approve", "reject", "narrow_scope", "request_more_evidence", "edit",
                               "question_answered"})


class TransitionError(RuntimeError):
    pass


@dataclass
class WorkflowMachine:
    run_id: str
    state: str = WorkflowState.CREATED
    version: str = STATE_MACHINE_VERSION
    history: list[dict[str, Any]] = None  # type: ignore[assignment]
    checkpoint: dict[str, Any] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.history is None:
            self.history = []
        if self.checkpoint is None:
            self.checkpoint = {}

    def can(self, event: str) -> bool:
        return event in TRANSITIONS.get(self.state, {})

    def allowed_events(self) -> tuple[str, ...]:
        return tuple(sorted(TRANSITIONS.get(self.state, {})))

    @property
    def terminal(self) -> bool:
        return self.state in TERMINAL_STATES

    def fire(self, event: str, *, actor: str, actor_kind: str, ledger: Any = None,
             authority_ref: str | None = None, detail: Mapping[str, Any] | None = None,
             idempotency_key: str | None = None) -> str:
        if idempotency_key:
            for entry in self.history:
                if entry.get("idempotency_key") == idempotency_key:
                    return entry["to"]
        if self.state in TERMINAL_STATES:
            raise TransitionError(f"{self.state} is terminal; event {event!r} cannot be applied")
        table = TRANSITIONS.get(self.state, {})
        if event not in table:
            raise TransitionError(f"event {event!r} is not declared from state {self.state!r}; "
                                  f"allowed: {', '.join(sorted(table)) or 'none'}")
        if event in HUMAN_ONLY_EVENTS and actor_kind != "human":
            raise TransitionError(f"event {event!r} requires a human actor, not {actor_kind!r}")
        if event in HUMAN_ONLY_EVENTS and not authority_ref:
            raise TransitionError(f"event {event!r} requires an authority reference for the human decision")
        previous, self.state = self.state, table[event]
        entry = {
            "sequence": len(self.history), "from": previous, "event": event, "to": self.state,
            "actor": actor, "actor_kind": actor_kind, "authority_ref": authority_ref,
            "at": fmt_ts(datetime.now(timezone.utc)), "idempotency_key": idempotency_key,
            "detail_digest": digest_of(dict(detail or {})),
        }
        self.history.append(entry)
        if ledger is not None:
            ledger.append("workflow.transition", actor=actor, actor_kind=actor_kind, outcome="recorded",
                          subject=f"{previous}->{self.state}", authority_ref=authority_ref,
                          detail={"transition": entry, "detail": dict(detail or {})})
        return self.state

    def set_checkpoint(self, **fields: Any) -> None:
        """STORE-01: pause/resume data the reconstruction needs (pinned set, indexed count...)."""
        self.checkpoint.update(fields)

    def snapshot(self) -> dict[str, Any]:
        doc = {
            "schema_id": "as.workflow_state/1", "version": self.version, "run_id": self.run_id,
            "state": self.state, "terminal": self.terminal, "allowed_events": list(self.allowed_events()),
            "history": list(self.history),
            "state_id": deterministic_id("run", run=self.run_id, sequence=len(self.history), state=self.state),
            "checkpoint": dict(self.checkpoint),
        }
        return validate("as.workflow_state/1", doc)

    @classmethod
    def restore(cls, snapshot: Mapping[str, Any]) -> "WorkflowMachine":
        validate("as.workflow_state/1", dict(snapshot))
        if snapshot.get("version") != STATE_MACHINE_VERSION:
            raise TransitionError(f"snapshot version {snapshot.get('version')!r} needs migration to "
                                  f"{STATE_MACHINE_VERSION}; refusing a silent upgrade")
        machine = cls(run_id=snapshot["run_id"], state=snapshot["state"], version=snapshot["version"])
        machine.history = list(snapshot.get("history", []))
        machine.checkpoint = dict(snapshot.get("checkpoint", {}))
        # Legal-state check: the restored state must be the one the history produced.
        expected = WorkflowState.CREATED
        for entry in machine.history:
            if entry["from"] != expected or TRANSITIONS.get(entry["from"], {}).get(entry["event"]) != entry["to"]:
                raise TransitionError("snapshot history is not a legal transition sequence; refusing to resume")
            expected = entry["to"]
        if expected != machine.state:
            raise TransitionError("snapshot state disagrees with its own history; refusing to resume")
        return machine

    @classmethod
    def reconstruct_from_ledger(cls, run_id: str, events: Any) -> "WorkflowMachine":
        """XSTATE-03: rebuild a run purely from ledger transitions."""
        machine = cls(run_id=run_id)
        for record in events:
            event = record["event"]
            if event["run_id"] != run_id or event["event_type"] != "workflow.transition":
                continue
            entry = record["detail"]["transition"]
            if entry["from"] != machine.state or TRANSITIONS.get(machine.state, {}).get(entry["event"]) != entry["to"]:
                raise TransitionError("ledger contains an illegal transition; reconstruction refused")
            machine.state = entry["to"]
            machine.history.append(dict(entry))
        return machine

    @staticmethod
    def reachable_without(event: str, target: str) -> bool:
        seen = {WorkflowState.CREATED}
        frontier = [WorkflowState.CREATED]
        while frontier:
            state = frontier.pop()
            for ev, nxt in TRANSITIONS.get(state, {}).items():
                if ev == event:
                    continue
                if nxt == target:
                    return True
                if nxt not in seen:
                    seen.add(nxt)
                    frontier.append(nxt)
        return False

    @staticmethod
    def successors(state: str) -> set[str]:
        return set(TRANSITIONS.get(state, {}).values())
