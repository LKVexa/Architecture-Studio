"""Protocol-v3 EXECUTION_REPORT builder (ASRTD/EXECUTION_REPORT/3).

This module writes *proposals*, not verdicts. For every task in
``APPLICATION_ORDER`` it emits one record whose fields are what actually
happened in this pass:

* ``evidence_mode`` is ``OBSERVED`` — the checks named in the record were run
  here, against this worktree, and their outputs are the evidence files.
* ``status`` is ``IMPLEMENTED`` only where the sealed checker's own rules allow
  it: the task has no hard dependency and no unclosed phase-start prerequisite.
  In this package exactly one task qualifies (``AUDIT-ADD-01``, the first task
  of P0). Every other task is ``BLOCKED`` — not because nothing was built, but
  because the protocol requires each prerequisite to be satisfied by an
  *independently VERIFIED* upstream record, and no such record exists: nothing
  in this pass has been verified by anyone but the pass itself.
* ``verifier`` is ``null`` everywhere. The runtime cannot verify its own work,
  and no human has. ``gate_verdict`` is ``NOT_EVALUATED`` everywhere, because a
  gate verdict is only expressible on a final assessment and this pass produces
  none; a P15 gate's actual state travels in its check result and its blocker.
* ``remaining_risks_or_blockers`` carries the real blocker for each record,
  named precisely — the missing verified prerequisite, plus any external
  blocker the task itself has (no bound model provider, no host identity
  provider, no KMS, unprovisioned environment, unapproved threshold, no
  independent reviewer).

The acceptance criterion ``SOURCE_DONE`` always carries the manifest's
``done_when_evidence`` text verbatim, and its result is the honest one: PASS
only where every mapped check passed, UNKNOWN where a check could not run and
says so. A criterion never claims more than its checks.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import platform
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from . import PACKAGE_VERSION_APPLIED, __version__
from .acceptance import acceptance_map
from .canonical import canonical_bytes, fmt_ts, sha256_hex
from .registry import build_registry

__all__ = ["RECORD_SCHEMA", "PACKAGE_VERSION", "TaskRow", "load_application_order", "load_phase_gates",
           "EvidenceWriter", "RecordBuilder", "worktree_manifest"]

RECORD_SCHEMA = "ASRTD/EXECUTION_REPORT/3"
DEPENDENCY_SCHEMA = "ASRTD/DEPENDENCY_EVIDENCE/3"
PACKAGE_VERSION = "1.4.0"
CLASSIFICATION = "INTERNAL"
JSON_MEDIA = "application/json"
TEXT_MEDIA = "text/plain"


# --------------------------------------------------------------------------- #
# Package manifests                                                             #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class TaskRow:
    sequence: int
    phase: str
    todo_id: str
    title: str
    priority: str
    hard_task_dependencies: tuple[str, ...]
    applicability_policy: str
    verification_class: str
    non_waivable: bool
    implement: str
    done_when_evidence: str
    contract_sha256: str


def load_application_order(root: Path) -> list[TaskRow]:
    path = Path(root) / f"manifests/APPLICATION_ORDER_v{PACKAGE_VERSION}.csv"
    rows = []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            rows.append(TaskRow(
                sequence=int(row["sequence"]), phase=row["phase"], todo_id=row["todo_id"], title=row["title"],
                priority=row["priority"],
                hard_task_dependencies=tuple(d for d in row["hard_task_dependencies"].split(";") if d),
                applicability_policy=row["applicability_policy"], verification_class=row["verification_class"],
                non_waivable=row["non_waivable"].strip().lower() == "true", implement=row["implement"],
                done_when_evidence=row["done_when_evidence"], contract_sha256=row["contract_sha256"]))
    return rows


def load_phase_gates(root: Path) -> dict[str, dict[str, Any]]:
    path = Path(root) / f"manifests/PHASE_GATES_v{PACKAGE_VERSION}.csv"
    out: dict[str, dict[str, Any]] = {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            out[row["phase"]] = {**row,
                                 "start_after": tuple(p for p in row["start_after_phase_closures"].split(";") if p),
                                 "close_after": tuple(p for p in row["close_after_phase_closures"].split(";") if p)}
    return out


def worktree_manifest(root: Path, *, exclude: Iterable[str] = (".git", "__pycache__", "evidence", ".pytest_cache")) -> tuple[str, int]:
    """SHA-256 over "<path>\\0<file sha256>\\n" for the whole worktree, excluding VCS and evidence."""
    root = Path(root)
    exclude = set(exclude)
    digest = hashlib.sha256()
    count = 0
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if any(part in exclude for part in rel.parts) or not path.is_file() or path.is_symlink():
            continue
        digest.update(f"{rel.as_posix()}\0{sha256_hex(path.read_bytes())}\n".encode("utf-8"))
        count += 1
    return digest.hexdigest(), count


# --------------------------------------------------------------------------- #
# Evidence files                                                                #
# --------------------------------------------------------------------------- #
class EvidenceWriter:
    """Writes evidence artifacts under one root and returns manifest entries.

    Identical payloads are written once and reused, so a check output shared by
    several records resolves to one hashed file (the checker requires the
    classification/media-type of a path to agree across every record).
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self._by_digest: dict[str, dict[str, Any]] = {}
        self._paths: set[str] = set()

    def write(self, relative_path: str, payload: Any, *, evidence_id: str, media_type: str = JSON_MEDIA,
              classification: str = CLASSIFICATION) -> dict[str, Any]:
        data = payload if isinstance(payload, bytes) else canonical_bytes(payload)
        digest = sha256_hex(data)
        cached = self._by_digest.get(digest)
        if cached is not None:
            return {"evidence_id": evidence_id, "path": cached["path"], "sha256": digest,
                    "classification": cached["classification"], "media_type": cached["media_type"]}
        target = self.root / relative_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        entry = {"evidence_id": evidence_id, "path": relative_path, "sha256": digest,
                 "classification": classification, "media_type": media_type}
        self._by_digest[digest] = entry
        self._paths.add(relative_path)
        return dict(entry)

    @property
    def files(self) -> int:
        return len(self._paths)


# --------------------------------------------------------------------------- #
# Record construction                                                           #
# --------------------------------------------------------------------------- #
@dataclass
class CheckResult:
    """One executed check, with its real invocation, timing and output."""

    check_id: str
    kind: str                      # COMMAND | INSPECTION
    description: str
    invocation: list[str]
    result: str                    # PASS | FAIL | UNKNOWN | NOT_RUN
    exit_code: int | None
    started_at: str
    ended_at: str
    output: Any
    reason: str | None = None
    required_for_acceptance: bool = True

    def as_record(self, evidence_refs: Sequence[str]) -> dict[str, Any]:
        return {"check_id": self.check_id, "kind": self.kind, "description": self.description,
                "invocation": list(self.invocation), "result": self.result, "exit_code": self.exit_code,
                "started_at": self.started_at if self.result != "NOT_RUN" else None,
                "ended_at": self.ended_at if self.result != "NOT_RUN" else None,
                "evidence_refs": list(evidence_refs) if self.result != "NOT_RUN" else [],
                "reason": self.reason, "required_for_acceptance": self.required_for_acceptance}


class RecordBuilder:
    def __init__(self, *, package_root: Path, worktree_root: Path, evidence_root: Path, run_id: str,
                 attempt_id: str, principal_id: str, repository_id: str, revision: str, environment_id: str,
                 recorded_at: datetime | None = None) -> None:
        self.package_root = Path(package_root)
        self.worktree_root = Path(worktree_root)
        self.writer = EvidenceWriter(evidence_root)
        self.run_id = run_id
        self.attempt_id = attempt_id
        self.principal_id = principal_id
        self.recorded_at = recorded_at or datetime.now(timezone.utc)
        self.tasks = {row.todo_id: row for row in load_application_order(self.package_root)}
        self.phases = load_phase_gates(self.package_root)
        manifest_digest, file_count = worktree_manifest(self.worktree_root)
        self.baseline = {"repository_id": repository_id, "revision": revision,
                         "worktree_manifest_sha256": manifest_digest, "environment_id": environment_id}
        self.worktree_files = file_count
        self.requirements = {r.requirement_id: r for r in build_registry()}
        self.acceptance = acceptance_map(self.requirements.values())

    # ------------------------------------------------------------ dependencies --
    def _dependency(self, dependency_type: str, dependency_id: str, *, reason: str, checked_at: str) -> dict[str, Any]:
        """An unsatisfied prerequisite: no upstream record exists, so none is referenced."""
        required = {"TASK": "VERIFIED", "PHASE_START": "CLOSED", "PHASE_CLOSE": "CLOSED", "NAMED_GATE": "PASS"}[dependency_type]
        return {"schema": DEPENDENCY_SCHEMA, "package_version": PACKAGE_VERSION, "dependency_type": dependency_type,
                "dependency_id": dependency_id, "required_state": required, "observed_state": "NOT_STARTED",
                "satisfied": False, "checked_at": checked_at, "checker": "architecture_studio.evidence_records",
                "upstream_record_sha256": None, "evidence_refs": [], "run_id": self.run_id,
                "baseline": dict(self.baseline), "evidence_manifest": [], "reason": reason}

    # ----------------------------------------------------------------- record --
    def build(self, todo_id: str, *, checks: Sequence[CheckResult], changes: Sequence[Mapping[str, Any]],
              tests: Sequence[str], schemas_changed: Sequence[str], baseline_findings: Sequence[str],
              security_note: str, rollback_note: str, extra_blockers: Sequence[Mapping[str, Any]] = (),
              status: str | None = None, applicability: str = "APPLICABLE",
              recommended_next: Sequence[str] = ()) -> dict[str, Any]:
        row = self.tasks[todo_id]
        # recorded_at is stamped when this record is written, after its checks ran: the protocol requires
        # every check timestamp to precede the record that reports it.
        recorded_at = fmt_ts(max(datetime.now(timezone.utc), self.recorded_at))
        # Every check output becomes one evidence file; the record references them by id.
        manifest: list[dict[str, Any]] = []
        check_records: list[dict[str, Any]] = []
        refs_by_check: dict[str, list[str]] = {}
        for index, check in enumerate(checks):
            refs: list[str] = []
            if check.result != "NOT_RUN":
                evidence_id = f"EV-{todo_id}-{check.check_id}"
                entry = self.writer.write(f"{todo_id}/{check.check_id}.json", check.output, evidence_id=evidence_id)
                manifest.append(entry)
                refs.append(evidence_id)
            refs_by_check[check.check_id] = refs
            check_records.append(check.as_record(refs))
        # SOURCE_DONE: the manifest's own criterion text, with the honest result.
        mapped = [c.check_id for c in checks if c.required_for_acceptance]
        results = {c.result for c in checks if c.check_id in mapped}
        if results == {"PASS"}:
            criterion_result = "PASS"
        elif "FAIL" in results:
            criterion_result = "FAIL"
        else:
            criterion_result = "UNKNOWN"
        criterion_refs = sorted({ref for cid in mapped for ref in refs_by_check.get(cid, [])})
        acceptance = [{"criterion_id": "SOURCE_DONE", "criterion_text": row.done_when_evidence,
                       "result": criterion_result, "check_ids": mapped, "evidence_refs": criterion_refs}]

        earliest_check = min((c.started_at for c in checks if c.result != "NOT_RUN"), default=recorded_at)
        dependencies = [self._dependency("TASK", dep,
                                         reason=(f"prerequisite {dep} has no independently VERIFIED record: this pass "
                                                 f"implemented it but nobody outside the pass has verified it"),
                                         checked_at=earliest_check)
                        for dep in row.hard_task_dependencies]
        phase_start = [self._dependency("PHASE_START", phase,
                                        reason=f"phase {phase} has no PASS PHASE_CLOSE record; no phase has been closed",
                                        checked_at=earliest_check)
                       for phase in self.phases[row.phase]["start_after"]]

        blockers = list(extra_blockers)
        if dependencies:
            blockers.append({"id": f"BLK-{todo_id}-DEPS", "blocking": True,
                             "description": ("hard dependencies " + ", ".join(row.hard_task_dependencies) +
                                             " are not satisfied by independently VERIFIED upstream records"),
                             "evidence_refs": []})
        if phase_start:
            blockers.append({"id": f"BLK-{todo_id}-PHASE", "blocking": True,
                             "description": ("phase-start prerequisite(s) " + ", ".join(self.phases[row.phase]["start_after"]) +
                                             " have no PASS PHASE_CLOSE record"),
                             "evidence_refs": []})
        blockers.append({"id": f"BLK-{todo_id}-VERIFY", "blocking": True,
                         "description": (f"no independent verifier has assessed this task; verification class "
                                         f"{row.verification_class} requires a verifier execution distinct from the "
                                         f"implementer, and for V3 a distinct trusted principal"),
                         "evidence_refs": []})

        resolved_status = status or ("IMPLEMENTED" if not dependencies and not phase_start else "BLOCKED")
        record = {
            "schema": RECORD_SCHEMA, "package_version": PACKAGE_VERSION, "todo_id": todo_id,
            "contract_sha256": row.contract_sha256, "run_id": self.run_id, "attempt_id": self.attempt_id,
            "recorded_at": recorded_at, "baseline": dict(self.baseline), "evidence_mode": "OBSERVED",
            "implementer": {"principal_id": self.principal_id, "execution_id": self.attempt_id},
            "status": resolved_status, "applicability": applicability,
            "applicability_decision": None, "verification_class": row.verification_class,
            "baseline_findings": list(baseline_findings), "changes_made": list(changes),
            "schemas_or_interfaces_changed": list(schemas_changed), "tests_added_or_updated": list(tests),
            "commands_or_checks_run": check_records, "acceptance_evidence": acceptance,
            "dependencies_satisfied": dependencies, "evidence_manifest": manifest,
            "security_authority_provenance_impact": security_note,
            "rollback_or_recovery_notes": rollback_note,
            "remaining_risks_or_blockers": blockers, "verifier": None, "approvals": [],
            # A gate verdict is only expressible on a final (VERIFIED/ACCEPTED) assessment. This pass produces
            # none, so every record is NOT_EVALUATED; the gate's actual state travels in its check and blocker.
            "gate_verdict": "NOT_EVALUATED", "gate_record_ref": None,
            "recommended_next_todo_ids": list(recommended_next), "phase_start_evidence": phase_start,
        }
        return record


def record_digest(record: Mapping[str, Any]) -> str:
    return sha256_hex(json.dumps(record, sort_keys=True, ensure_ascii=False, allow_nan=False,
                                 separators=(",", ":")).encode("utf-8"))
