"""Local-grounding sufficiency and conflict semantics (AUDIT-ADD-07, AUDIT-ADD-08, PAPER-GRD-03).

Grounding: every material candidate element — component, relationship,
deployment choice, trade-off claim — must resolve to at least one indexed local
record of an appropriate class. Coverage is the fraction of material elements
that do; the required source classes per element kind are declared here so the
expectation is inspectable, not judged. Elements that cite nothing resolvable
are *generic fallback* and are routed to clarification or abstention
(PAPER-GRD-03), never presented as grounded design.

Conflicts: contradictory NFR targets, superseded ADRs grounding a current
decision, catalog mismatches, security-versus-design contradictions and stale
revisions become explicit ``as.conflict/1`` records with the affected
candidates and evidence links. Nothing here resolves a conflict; the
resolution path is always ``human_decision_required`` (AUDIT-ADD-08).

Build provenance: BUILD_NEW.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping

from .canonical import fmt_ts
from .connectors.normalize import NormalizedIndex
from .ids import deterministic_id
from .schemas import validate

__all__ = ["GROUNDING_EXPECTATIONS", "GroundingReport", "evaluate_grounding", "detect_conflicts", "conflicts_for_candidate"]

#: AUDIT-ADD-07: which source classes may ground which candidate element kinds.
GROUNDING_EXPECTATIONS: dict[str, tuple[str, ...]] = {
    "component": ("service", "api_operation", "requirement", "diagram", "adr"),
    "relationship": ("api_operation", "service", "adr", "requirement", "diagram"),
    "deployment": ("deployment_standard", "service", "adr"),
    "tradeoff_claim": ("nfr", "cost_perf_constraint", "security_constraint", "adr", "requirement",
                       "deployment_standard", "api_operation", "service"),
    "security_posture": ("security_constraint", "adr"),
}


@dataclass
class GroundingReport:
    coverage: float
    material_elements: int
    grounded_elements: int
    generic_fallback: list[dict[str, Any]]
    wrong_class: list[dict[str, Any]]
    stale_refs: list[str]
    required_classes_missing: list[str]

    @property
    def sufficient(self) -> bool:
        return not self.generic_fallback and self.material_elements > 0

    def as_document(self) -> dict[str, Any]:
        return {"coverage": round(self.coverage, 4), "material_elements": self.material_elements,
                "grounded_elements": self.grounded_elements, "generic_fallback": self.generic_fallback,
                "wrong_class": self.wrong_class, "stale_refs": self.stale_refs,
                "required_classes_missing": self.required_classes_missing, "sufficient": self.sufficient}


def _resolve(index: NormalizedIndex, ref_id: str) -> dict[str, Any] | None:
    for record in index.records.values():
        if record["provenance_ref_id"] == ref_id or record["record_id"] == ref_id:
            return record
    return None


def evaluate_grounding(candidate: Mapping[str, Any], index: NormalizedIndex, *,
                       required_classes: Iterable[str] = ("requirement",)) -> GroundingReport:
    """Coverage of material elements by resolvable local evidence of an appropriate class."""
    lookup: dict[str, dict[str, Any]] = {}
    for record in index.records.values():
        lookup[record["provenance_ref_id"]] = record
        lookup[record["record_id"]] = record
    elements: list[tuple[str, str, list[str]]] = []
    for component in candidate.get("components", []):
        elements.append(("component", component["element_id"], list(component.get("evidence_refs", []))))
    for relationship in candidate.get("relationships", []):
        elements.append(("relationship", relationship["element_id"], list(relationship.get("evidence_refs", []))))
    deployment = candidate.get("deployment") or {}
    if deployment:
        elements.append(("deployment", "deployment", list(deployment.get("evidence_refs", []))))
    grounded = 0
    generic: list[dict[str, Any]] = []
    wrong: list[dict[str, Any]] = []
    stale: list[str] = []
    classes_seen: set[str] = set()
    for kind, element_id, refs in elements:
        resolved = [lookup[r] for r in refs if r in lookup]
        allowed = GROUNDING_EXPECTATIONS[kind]
        good = [r for r in resolved if r["data_class"] in allowed]
        for r in resolved:
            classes_seen.add(r["data_class"])
            if r["freshness"] == "STALE":
                stale.append(r["provenance_ref_id"])
        if good:
            grounded += 1
        elif resolved:
            wrong.append({"kind": kind, "element_id": element_id,
                          "classes": sorted({r["data_class"] for r in resolved}), "expected": list(allowed)})
        else:
            generic.append({"kind": kind, "element_id": element_id, "refs": refs,
                            "reason": "no evidence reference resolves to an indexed local record"})
    coverage = grounded / len(elements) if elements else 0.0
    missing_classes = sorted(set(required_classes) - classes_seen)
    return GroundingReport(coverage=coverage, material_elements=len(elements), grounded_elements=grounded,
                           generic_fallback=generic, wrong_class=wrong, stale_refs=sorted(set(stale)),
                           required_classes_missing=missing_classes)


# --------------------------------------------------------------------------- #
# Conflicts (AUDIT-ADD-08)                                                      #
# --------------------------------------------------------------------------- #
def _conflict(run_id: str, kind: str, artifacts: list[str], description: str, evidence: list[str],
              affected: list[str] = ()) -> dict[str, Any]:
    doc = {"schema_id": "as.conflict/1",
           "conflict_id": deterministic_id("conflict", run=run_id, conflict_kind=kind, artifacts=sorted(artifacts)),
           "run_id": run_id, "kind": kind, "artifact_ids": sorted(artifacts), "description": description,
           "affected_candidates": list(affected), "evidence_refs": sorted(set(evidence)),
           "resolution_path": "human_decision_required", "status": "open",
           "detected_at": fmt_ts(datetime.now(timezone.utc))}
    return validate("as.conflict/1", doc)


def detect_conflicts(run_id: str, index: NormalizedIndex, *, stale_artifacts: Iterable[str] = ()) -> list[dict[str, Any]]:
    """Evidence-level conflicts, independent of any candidate."""
    conflicts: list[dict[str, Any]] = []
    # NFR target conflicts: same scope + category + unit, different targets.
    groups: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for record in index.by_class("nfr"):
        p = record["payload"]
        if p.get("quantitative"):
            groups[(str(p.get("scope")), str(p.get("category")), str(p.get("unit")))].append(record)
    for (scope_name, category, unit), records in sorted(groups.items()):
        targets = {r["payload"]["target"] for r in records}
        if len(targets) > 1:
            conflicts.append(_conflict(run_id, "nfr_target_conflict", [r["record_id"] for r in records],
                                       f"NFR {category} for {scope_name} has {len(targets)} different targets "
                                       f"({sorted(targets)} {unit}) in the pinned sources",
                                       [r["provenance_ref_id"] for r in records]))
    # Superseded ADRs still present: any reliance must be flagged.
    adrs = {r["payload"].get("adr_id"): r for r in index.by_class("adr")}
    for adr_id, record in sorted(adrs.items(), key=lambda kv: str(kv[0])):
        p = record["payload"]
        if p.get("status") == "superseded" or p.get("superseded_by"):
            successor = p.get("superseded_by")
            conflicts.append(_conflict(run_id, "adr_superseded", [record["record_id"]],
                                       f"{adr_id} is superseded{(' by ' + successor) if successor else ''}; it cannot "
                                       "ground a current decision", [record["provenance_ref_id"]]))
    # Stale revisions.
    stale = set(stale_artifacts)
    if stale:
        for record in index.records.values():
            if record["artifact_id"] in stale:
                conflicts.append(_conflict(run_id, "stale_revision", [record["record_id"]],
                                           f"{record['path']} changed after pinning; its records are stale",
                                           [record["provenance_ref_id"]]))
    return conflicts


def conflicts_for_candidate(run_id: str, candidate: Mapping[str, Any], index: NormalizedIndex) -> list[dict[str, Any]]:
    """Candidate-level conflicts: catalog mismatch and security-versus-design."""
    conflicts: list[dict[str, Any]] = []
    services = {str(r["payload"].get("service")).lower() for r in index.by_class("service")}
    workspaces = {str(r["payload"].get("workspace")).lower() for r in index.by_class("service")}
    network_denied = [r for r in index.by_class("security_constraint")
                      if r["payload"].get("verb") == "deny" and "network" in str(r["payload"].get("rule"))]
    for component in candidate.get("components", []):
        ref = component.get("catalog_ref")
        if ref and ref.lower() not in services and ref.lower() not in workspaces:
            conflicts.append(_conflict(run_id, "catalog_mismatch", [component["element_id"]],
                                       f"component {component['name']} names catalog entry {ref!r}, which is not in the "
                                       "pinned infrastructure catalog", list(component.get("evidence_refs", [])),
                                       [candidate["candidate_id"]]))
        if component.get("kind") == "external" and network_denied:
            conflicts.append(_conflict(run_id, "security_vs_design", [component["element_id"]],
                                       f"component {component['name']} is external but the pinned security constraints "
                                       "deny network access by default", [r["provenance_ref_id"] for r in network_denied[:3]],
                                       [candidate["candidate_id"]]))
    return conflicts
