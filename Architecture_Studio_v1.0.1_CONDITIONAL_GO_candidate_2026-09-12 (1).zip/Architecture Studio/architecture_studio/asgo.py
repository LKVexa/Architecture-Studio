"""ASGO 150-item Production GO prompt/workflow register (ASGO-0.1..ASGO-10.12).

Pins ``Architecture_Studio_Production_GO_Prompts_and_Workflows_2026-09-12.md``.
This module is the implementer. It may ingest, classify, implement in-repo
checks, and write incomplete evidence. It may not mark ``DONE``, ``VERIFIED``,
``PASS``, ``QUALIFIED``, or ``GO``. Missing ``INDEX.csv`` and missing DOD
definitions are not inferred. Same-session chat signatures are not reviews.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Mapping

from .canonical import digest_of, now_iso, sha256_hex
from .corpus import PRODUCT_KIND, product_contract
from .evidence_io import atomic_write, confine
from .fixtures import OVERLAY_ROOT, portable_overlay_path
from .gate_evidence import IMPLEMENTER_SUBJECTS

__all__ = [
    "ASGO_VERSION",
    "EXPECTED_ITEM_COUNT",
    "EXPECTED_PACKAGE_SHA256",
    "IMPLEMENTER_PASS",
    "AsgoError",
    "AsgoAuthorityError",
    "package_pin",
    "load_items",
    "build_register",
    "register_summary",
    "export_register",
    "claim_done",
    "production_go_from_asgo",
    "test_count_contract",
    "gate_count_contract",
    "freeze_intake",
    "write_item_evidence",
    "write_declared_evidence",
    "overlay_tree_report",
    "scan_release_hygiene",
    "scan_referenced_paths",
]

ASGO_VERSION = "1.0.0"
EXPECTED_ITEM_COUNT = 150
EXPECTED_PACKAGE_SHA256 = "41209097b7b6d7fdaf905a7d52776be8557214049741ad4df5c89bf1982971b9"
PACKAGE_FILENAME = "Architecture_Studio_Production_GO_Prompts_and_Workflows_2026-09-12.md"
IMPLEMENTER_PASS = "builder:architecture-studio-asgo-2026-09-12"
ASGO_IMPLEMENTER_SUBJECTS = IMPLEMENTER_SUBJECTS + (
    IMPLEMENTER_PASS,
    "builder:architecture-studio-audit-2026-09-11",
    "builder:architecture-studio-asfw-2026-09-11",
    "asgo", "implementer",
)
HEADER_RE = re.compile(r"^### (ASGO-(\d+)\.(\d+)) — (.+)$", re.M)
INCOMPLETE_STATUSES = frozenset({"PROPOSED", "IMPLEMENTED", "AWAITING_CONFIRMATION", "ACCEPTED_RISK"})

WAVE_CLASS = {
    0: "package_reproducibility",
    1: "source_resolution",
    2: "corpus_qualification",
    3: "security_hardening",
    4: "host_binding",
    5: "environment_provisioning",
    6: "evaluation_thresholds",
    7: "independent_gate_review",
    8: "independent_asfw_review",
    9: "independent_protocol_verification",
    10: "release_promotion",
}


class AsgoError(RuntimeError):
    pass


class AsgoAuthorityError(PermissionError):
    pass


def _package_path(path: Path | None = None) -> Path:
    if path is not None:
        return Path(path)
    env = os.environ.get("ASGO_PACKAGE_PATH")
    if env:
        return Path(env)
    candidates = [
        OVERLAY_ROOT / "asgo" / "source" / PACKAGE_FILENAME,
        OVERLAY_ROOT.parent.parent / "attachments" / PACKAGE_FILENAME,
        OVERLAY_ROOT.parent / "attachments" / PACKAGE_FILENAME,
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise AsgoError(f"{PACKAGE_FILENAME} not found; ASGO register fails closed")


def package_pin(path: Path | None = None) -> dict[str, Any]:
    target = _package_path(path)
    payload = target.read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    if digest != EXPECTED_PACKAGE_SHA256:
        raise AsgoError(
            f"ASGO package digest {digest} != pinned {EXPECTED_PACKAGE_SHA256}; "
            "issue a new version rather than mutating the baseline"
        )
    return {
        "schema_id": "as.asgo_package_pin/1",
        "filename": PACKAGE_FILENAME,
        "path": portable_overlay_path(target),
        "bytes": len(payload),
        "sha256": digest,
        "item_count_declared": EXPECTED_ITEM_COUNT,
        "immutable": True,
        "expanded_source": "Architecture_Studio_Production_GO_Per_Item_Checklists_2026-09-12.md",
    }


_ITEMS_CACHE: tuple[str, tuple[dict[str, Any], ...]] | None = None


def load_items(path: Path | None = None) -> tuple[dict[str, Any], ...]:
    global _ITEMS_CACHE
    target = _package_path(path)
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    if _ITEMS_CACHE and _ITEMS_CACHE[0] == digest:
        return _ITEMS_CACHE[1]
    text = target.read_text(encoding="utf-8")
    matches = list(HEADER_RE.finditer(text))
    if len(matches) != EXPECTED_ITEM_COUNT:
        raise AsgoError(f"expected {EXPECTED_ITEM_COUNT} ASGO items, parsed {len(matches)}")
    items = []
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        block = text[match.start():end]
        head = block.split("#### Technical prompt", 1)[0]
        owner = _search(r"You are the assigned `([^`]+)` responsible", block)
        evidence = _search(r"Write evidence to: `([^`]+)`", block)
        environment = _search(r"Target environment: `([^`]+)`", block)
        mode = _search(r"Work mode: `([^`]+)`", block)
        deps = _search(r"Dependencies: ([^\n]+)", block)
        items.append({
            "item_id": match.group(1),
            "wave": int(match.group(2)),
            "seq": int(match.group(3)),
            "source_text": match.group(4).strip(),
            "source_line": text[:match.start()].count("\n") + 1,
            "owner_role": owner or "UNSET",
            "evidence_location": evidence or f"evidence/reports/asgo/{match.group(1)}.json",
            "environment": environment or "UNSET",
            "work_mode": mode or "UNSET",
            "dependencies": (deps or "none").strip(),
            "implementation_id": f"ASGO-IMPL-{int(match.group(2)):02d}.{int(match.group(3)):02d}",
        })
    frozen = tuple(items)
    _ITEMS_CACHE = (digest, frozen)
    return frozen


def _search(pattern: str, text: str) -> str:
    match = re.search(pattern, text)
    return match.group(1).strip() if match else ""


def classify(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Honest mechanical class. Never VERIFIED/DONE/GO."""
    wave = int(raw["wave"])
    iid = raw["item_id"]
    execution = WAVE_CLASS[wave]
    status = "BLOCKED"
    block = None
    in_repo = "none"
    if wave == 0:
        if iid == "ASGO-0.4":
            status, block = "BLOCKED", "NOT_APPLICABLE_PENDING_SIGNED_OVERLAY_DECISION"
            in_repo = "self-contained packaging is refused while product_kind is overlay_only"
        elif iid == "ASGO-0.8":
            status, block = "BLOCKED", "INDEX.csv ABSENT; derived index is not a substitute"
            in_repo = "absence recorded; recovery not invented"
        elif iid == "ASGO-0.7":
            status = "IMPLEMENTED"
            in_repo = ("MASTER_PROMPT_WORKFLOW_PACKAGE.md pinned at asfw/source; digest verified; "
                       "INDEX.csv still ABSENT")
        elif iid == "ASGO-0.9":
            status = "IMPLEMENTED"
            in_repo = ("gitignore + hygiene scan; pycache stripped; generated pins/manifests use "
                       "portable overlay-relative paths; historical evidence SUITE.json stdout tails remain forensic")
        elif iid == "ASGO-0.10":
            status, block = "IMPLEMENTED", None
            in_repo = ("package lookup prefers overlay-relative pins; path validity scan of declared "
                       "handoffs/source pins; Windows/production-host re-extraction UNTESTED_HERE")
        elif iid == "ASGO-0.11":
            status = "IMPLEMENTED"
            in_repo = "console entry point declared; Python 3.11/3.12 not executed in this sandbox"
        elif iid == "ASGO-0.14":
            status = "IMPLEMENTED"
            in_repo = "overlay tree_digest is portable and recomputed at recut; evidence/ excluded from tree digest"
        elif iid == "ASGO-0.15":
            status = "IMPLEMENTED"
            in_repo = "SHA256SUMS/RELEASE_MANIFEST/ledger recut after source and code changes; not a release"
        else:
            status = "IMPLEMENTED"
            in_repo = "overlay contract, pin, preflight, layout skip, or intake machinery"
    elif wave == 1:
        if iid in {"ASGO-1.13", "ASGO-1.14"}:
            status = "IMPLEMENTED"
            in_repo = "register rebuild and ambiguity checks"
        else:
            status, block = "BLOCKED", "authoritative source PDF / INDEX.csv / product-authority signature missing"
    elif wave == 2:
        status = "IMPLEMENTED"
        in_repo = "existing overlay tests cover the objective mechanically; independent review outstanding"
    elif wave == 3:
        if iid in {"ASGO-3.11", "ASGO-3.12", "ASGO-3.13", "ASGO-3.14"}:
            status, block = "BLOCKED", "human decision or independent security/privacy review required"
            in_repo = "sandbox/limitation encoded; target-acceptance and GATE-PROD-07 review are not this pass"
        else:
            status = "IMPLEMENTED"
            in_repo = "existing overlay tests cover the objective mechanically; independent review outstanding"
    elif wave in {4, 5, 6, 7, 8, 9, 10}:
        status, block = "BLOCKED", f"{execution} requires a distinct human or provisioned host"
        if iid in {"ASGO-4.3", "ASGO-7.11", "ASGO-7.14", "ASGO-8.11", "ASGO-10.12"}:
            status, block = "IMPLEMENTED", None
            in_repo = "fail-closed refusal already encoded (self-review, chat signature, ACCEPTED_RISK≠PASS, post-fail NO_GO)"
    return {
        "execution_class": execution,
        "status": status,
        "block_reason": block,
        "in_repo_action": in_repo,
    }


def item_record(raw: Mapping[str, Any]) -> dict[str, Any]:
    classification = classify(raw)
    owner = raw["owner_role"]
    reviewer = "independent_reviewer"
    if "independent" not in owner.lower():
        reviewer = "independent_reviewer (distinct from owner and implementer)"
    complete = False
    return {
        **{k: raw[k] for k in (
            "item_id", "implementation_id", "wave", "seq", "source_text", "source_line",
            "owner_role", "evidence_location", "environment", "work_mode", "dependencies",
        )},
        **classification,
        "assignment": {
            "owner_role": owner,
            "owner_person": "UNSET",
            "implementer_role": "implementer",
            "implementer_person": "UNSET",
            "independent_reviewer_role": reviewer,
            "independent_reviewer_person": "UNSET",
            "environment": raw["environment"],
            "due_date": "UNSET",
            "evidence_location": raw["evidence_location"],
        },
        "review": None,
        "completion": {
            "complete": complete,
            "reason": "IMPLEMENTED is not DONE; independent review and dependencies required",
        },
        "product_kind": PRODUCT_KIND,
    }


def build_register(*, path: Path | None = None) -> dict[str, Any]:
    pin = package_pin(path)
    items = [item_record(raw) for raw in load_items(path)]
    contract = product_contract()
    counts: dict[str, int] = {}
    classes: dict[str, int] = {}
    waves: dict[str, int] = {}
    for item in items:
        counts[item["status"]] = counts.get(item["status"], 0) + 1
        classes[item["execution_class"]] = classes.get(item["execution_class"], 0) + 1
        waves[str(item["wave"])] = waves.get(str(item["wave"]), 0) + 1
    summary = {
        "total": len(items),
        "by_status": dict(sorted(counts.items())),
        "by_execution_class": dict(sorted(classes.items())),
        "by_wave": dict(sorted(waves.items(), key=lambda kv: int(kv[0]))),
        "complete": 0,
        "verified": 0,
        "done": 0,
        "production_go": "NO_GO",
    }
    return {
        "schema_id": "as.asgo_register/1",
        "asgo_version": ASGO_VERSION,
        "package_pin": pin,
        "implementer": IMPLEMENTER_PASS,
        "implementer_cannot": ["DONE", "VERIFIED", "PASS", "QUALIFIED", "GO", "APPROVED"],
        "product_contract": contract,
        "test_count_contract": test_count_contract(),
        "gate_count_contract": gate_count_contract(),
        "intake": freeze_intake(),
        "items": items,
        "summary": summary,
        "note": "ASGO prompts authorize work; they do not grant authority. This register is not GO.",
    }


def register_summary(**kwargs: Any) -> dict[str, Any]:
    document = build_register(**kwargs)
    return {
        "asgo_version": document["asgo_version"],
        "package_sha256": document["package_pin"]["sha256"],
        "implementer": document["implementer"],
        "product_kind": document["product_contract"]["product_kind"],
        "product_contract_status": document["product_contract"]["status"],
        **document["summary"],
    }


def claim_done(item_id: str, *, actor: str) -> None:
    raise AsgoAuthorityError(f"{actor} cannot mark {item_id} DONE; independent review is required")


def production_go_from_asgo(register: Mapping[str, Any] | None = None) -> dict[str, Any]:
    document = register or build_register()
    blocking = [item["item_id"] for item in document["items"]
                if item["status"] != "VERIFIED" or not item["completion"]["complete"]]
    if document["product_contract"]["status"] != "SIGNED":
        blocking.append("PRODUCT-CONTRACT-UNSIGNED")
    return {
        "verdict": "GO" if not blocking else "NO_GO",
        "blocking_count": len(blocking),
        "blocking_preview": blocking[:12],
        "done": 0,
        "total": document["summary"]["total"],
        "note": "ASGO-10.11: stamp GO only when every item is independently complete on one digest",
    }


def test_count_contract() -> dict[str, Any]:
    """ASGO-0.12: stored 133/133 and 150/150 are not archive-without-corpus evidence."""
    return {
        "schema_id": "as.asgo_test_count_contract/1",
        "historical_claims": {
            "133/133": "pre-ASFW overlay suite; superseded",
            "150/150": "post-ASFW overlay suite WITH the sibling 612-file corpus present; not evidence that an overlay-only zip is self-contained",
            "120/150": "fresh extraction of the overlay-only archive WITHOUT the sibling corpus; corpus-dependent tests fail closed. Expected. Do not skip those tests to restore a green count.",
        },
        "rule": ("Cite the live `tests/run_all.py` report with preflight=ok. "
                 "A green count taken while the corpus is absent is invalid. "
                 "Skipping corpus-dependent tests is forbidden."),
        "preflight_required": True,
        "skipping_corpus_tests_forbidden": True,
        "current_suite": "tests/run_all.py MODULES including test_asgo; count is whatever that report says after this pass",
    }


def gate_count_contract() -> dict[str, Any]:
    """ASGO-0.13: stored 6/1/1 vs 5/2/1 is evidence-assembly, not GO."""
    return {
        "schema_id": "as.asgo_gate_count_contract/1",
        "historical_claims": {
            "6/1/1": ("typical mechanical snapshot WITH sibling corpus: "
                      "6 AWAITING_INDEPENDENT_REVIEW, 1 FAIL (GATE-PROD-02 PROPOSED thresholds), "
                      "1 NO_EVIDENCE (GATE-PROD-07 missing security review)"),
            "5/2/1": ("overlay-only archive WITHOUT sibling corpus: tests no longer all-pass, "
                      "so one additional gate FAILs or loses evidence. Difference is inputs, not a new PASS."),
        },
        "rule": "Neither snapshot is PASS. Production requires eight gates PASS, zero ACCEPTED_RISK.",
        "executable_gates": 8,
        "pdf_claim": "GATE-PROD-01-09",
        "resolution": "UNRESOLVED",
        "ninth_gate_invented": False,
    }


def freeze_intake() -> dict[str, Any]:
    """ASGO-0.1: freeze the input candidate. Reviewer remains null. Paths are portable."""
    from .corpus import EXPECTED_DIGEST, EXPECTED_FILES
    pin = package_pin()
    asfw_rel = "asfw/source/MASTER_PROMPT_WORKFLOW_PACKAGE.md"
    asfw_path = OVERLAY_ROOT / asfw_rel
    asfw_digest = hashlib.sha256(asfw_path.read_bytes()).hexdigest() if asfw_path.is_file() else None
    return {
        "schema_id": "as.asgo_intake/1",
        "item_id": "ASGO-0.1",
        "implementer": IMPLEMENTER_PASS,
        "reviewer": None,
        "complete": False,
        "unblocks_go": False,
        "input_candidates": [
            {
                "role": "original_attachment",
                "filename": "Project_Architecture_Studio_v1.0.0.zip",
                "sha256": "e087924c429973c513510f24aa039e174331f3f7be9654217958427cb0643f16",
                "bytes": 3959383,
            },
            {
                "role": "prior_no_go_candidate",
                "filename": "Architecture_Studio_v1.0.0_NO_GO_candidate_2026-09-11.zip",
                "sha256": "bc9e5f6125737c717d3ee1716a357163353d4ef2008f04851fe548dbc169ae58",
                "bytes": 3302421,
                "note": "input to the first ASGO pass; overlay-only; not a release",
            },
            {
                "role": "prior_asgo_candidate",
                "filename": "Architecture_Studio_v1.0.0_NO_GO_candidate_2026-09-12.zip",
                "sha256": "81214744aaff1db53a5eaa323642018436bdd9ec9c8040af65c8812db74ba3ff",
                "note": "previous ASGO ingest candidate; this pass recuts after remaining W0 hygiene",
            },
        ],
        "asgo_package": pin,
        "asfw_package": {
            "relative_path": asfw_rel,
            "sha256": asfw_digest,
            "expected_sha256": "c94ed9bd6f41bd034cc0136183010f9f7ddb1823fcdb25c55a7c138a026048d2",
            "verified_here": asfw_digest == "c94ed9bd6f41bd034cc0136183010f9f7ddb1823fcdb25c55a7c138a026048d2",
        },
        "corpus_contract": {
            "files": EXPECTED_FILES,
            "digest": EXPECTED_DIGEST,
            "included_in_overlay_zip": False,
        },
        "declared_layout": {
            "overlay_directory": "Architecture Studio/",
            "archive_wrappers": "_archive/",
            "corpus": "sibling parent of the overlay, never inside the overlay zip",
        },
        "note": "Intake is not independent review. SHA256SUMS for THIS pass is cut after all changes (ASGO-0.15).",
    }


def overlay_tree_report(root: Path | None = None) -> dict[str, Any]:
    """ASGO-0.14: portable overlay tree digest. evidence/ and __pycache__ are excluded."""
    from .release import tree_digest
    target = Path(root) if root is not None else OVERLAY_ROOT
    report = tree_digest(target)
    report["root"] = target.name
    report["root_portable"] = True
    return report


def scan_release_hygiene(root: Path | None = None) -> dict[str, Any]:
    """ASGO-0.9: generated bytecode out; current pins/manifests must not embed sandbox abs paths."""
    target = Path(root) if root is not None else OVERLAY_ROOT
    pycache: list[str] = []
    current_abs: list[str] = []
    current_names = {
        "asgo/PACKAGE_PIN.json", "asgo/ASGO_SUMMARY.json", "asgo/ASGO_REGISTER.json",
        "asfw/PACKAGE_PIN.json", "asfw/ASFW_SUMMARY.json",
        "RELEASE_MANIFEST.json", "CANDIDATE_README.md", "PRODUCTION_GO_TODO.json",
    }
    for path in target.rglob("*"):
        rel = path.relative_to(target)
        parts = rel.parts
        if "__pycache__" in parts or path.suffix in {".pyc", ".pyo"}:
            pycache.append(rel.as_posix())
            continue
        if not path.is_file():
            continue
        if rel.as_posix() not in current_names:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        if "/workspace/" in text or "/home/" in text:
            current_abs.append(rel.as_posix())
    return {
        "schema_id": "as.asgo_hygiene/1",
        "pycache": pycache,
        "environment_specific_absolute_paths_in_current_artifacts": current_abs,
        "ok": not pycache and not current_abs,
        "residual": ("historical evidence/*/SUITE.json stdout tails may name the sandbox; "
                     "they are forensic and were not rewritten"),
        "complete": False,
        "unblocks_go": False,
    }


FORBIDDEN_REVIEW_NAME = re.compile(r"^(GATE-PROD-\d+|GATE-PROD-\d+-security|exceptions|builder_subjects)\.json$")


def _may_write_declared(relative_path: str) -> bool:
    """Never place an implementer note on a gate-review filename the verifier must own."""
    name = Path(relative_path).name
    return FORBIDDEN_REVIEW_NAME.match(name) is None


REQUIRED_RELATIVE_PATHS = (
    "pyproject.toml",
    "architecture_studio/cli.py",
    "architecture_studio/asgo.py",
    "architecture_studio/corpus.py",
    "tests/run_all.py",
    "asgo/source/Architecture_Studio_Production_GO_Prompts_and_Workflows_2026-09-12.md",
    "asfw/source/MASTER_PROMPT_WORKFLOW_PACKAGE.md",
    "handoff/HANDOFF-ASGO.md",
    "docs/DOC-12-known-limitations.md",
    ".gitignore",
)

KNOWN_ABSENT_PATHS = {
    "INDEX.csv": "source INDEX.csv was never in the attachment set; derived index is not a substitute",
    "Architecture_Studio_Production_GO_Per_Item_Checklists_2026-09-12.md": (
        "named expanded source of the ASGO package; not shipped in this overlay"
    ),
}


def scan_referenced_paths(root: Path | None = None, *, register: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """ASGO-0.10: declared overlay paths exist after extraction; known-absent stay named, not invented."""
    target = Path(root) if root is not None else OVERLAY_ROOT
    document = register or build_register()
    missing = []
    present = []
    for rel in REQUIRED_RELATIVE_PATHS:
        if (target / rel).is_file():
            present.append(rel)
        else:
            missing.append(rel)
    declared_missing = []
    declared_present = []
    for item in document["items"]:
        rel = item["evidence_location"]
        if (target / rel).is_file():
            declared_present.append(rel)
        else:
            declared_missing.append(rel)
    known_absent = []
    for rel, reason in KNOWN_ABSENT_PATHS.items():
        known_absent.append({"path": rel, "present": (target / rel).is_file(), "reason": reason})
    invented = [row["path"] for row in known_absent if row["present"] and "INDEX.csv" in row["path"]]
    return {
        "schema_id": "as.asgo_path_validity/1",
        "required_present": present,
        "required_missing": missing,
        "declared_evidence_present": len(declared_present),
        "declared_evidence_missing": declared_missing[:12],
        "declared_evidence_missing_count": len(declared_missing),
        "known_absent": known_absent,
        "invented_index_csv": bool(invented),
        "hard_dependency_on_workspace_attachments": False,
        "windows_reextraction": "UNTESTED_HERE",
        "ok": not missing and not invented,
        "complete": False,
        "unblocks_go": False,
        "note": "Declared evidence files exist only after write_declared_evidence. Missing is not GO.",
    }


def _item_note(item: Mapping[str, Any], document: Mapping[str, Any], *,
               tree: Mapping[str, Any] | None = None,
               hygiene: Mapping[str, Any] | None = None,
               paths: Mapping[str, Any] | None = None) -> dict[str, Any]:
    record = {
        "schema_id": "as.asgo_item_evidence/1",
        "record_kind": "asgo_implementer_note",
        "item_id": item["item_id"],
        "title": item["source_text"],
        "checklist_package": PACKAGE_FILENAME,
        "package_sha256": document["package_pin"]["sha256"],
        "owner_role": item["owner_role"],
        "implementer": IMPLEMENTER_PASS,
        "independent_reviewer": None,
        "target_environment": item["environment"],
        "due_date": "UNSET",
        "status": item["status"],
        "block_reason": item["block_reason"],
        "in_repo_action": item["in_repo_action"],
        "declared_evidence_location": item["evidence_location"],
        "complete": False,
        "review": None,
        "decision": None,
        "unblocks_go": False,
        "product_kind": PRODUCT_KIND,
        "overlay_tree": tree,
        "note": ("IMPLEMENTED is not DONE. This file is an implementer note. "
                 "A same-session chat signature is not a review."),
    }
    if item["item_id"] == "ASGO-0.1":
        record["intake"] = document.get("intake") or freeze_intake()
    if item["item_id"] == "ASGO-0.9" and hygiene is not None:
        record["hygiene"] = hygiene
    if item["item_id"] == "ASGO-0.10" and paths is not None:
        record["path_validity"] = paths
    if item["item_id"] == "ASGO-0.12":
        record["test_count_contract"] = document.get("test_count_contract") or test_count_contract()
    if item["item_id"] == "ASGO-0.13":
        record["gate_count_contract"] = document.get("gate_count_contract") or gate_count_contract()
    if item["item_id"] == "ASGO-0.14" and tree is not None:
        record["overlay_tree"] = tree
    return record


def write_item_evidence(directory: Path, *, register: Mapping[str, Any] | None = None,
                        also_declared_under: Path | None = None) -> dict[str, Any]:
    """Write incomplete implementer notes. Never a review. Never GATE-PROD PASS files."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    document = register or build_register()
    tree = overlay_tree_report()
    hygiene = scan_release_hygiene()
    paths = scan_referenced_paths(register=document)
    written = []
    declared = []
    for item in document["items"]:
        record = _item_note(item, document, tree=tree, hygiene=hygiene, paths=paths)
        payload = json.dumps(record, indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8")
        path = directory / f"{item['item_id']}.json"
        atomic_write(path, payload)
        written.append({"file": path.name, "sha256": sha256_hex(payload), "bytes": len(payload)})
        if also_declared_under is not None and _may_write_declared(item["evidence_location"]):
            dest = confine(also_declared_under, item["evidence_location"])
            atomic_write(dest, payload)
            declared.append(item["evidence_location"])
    intake = freeze_intake()
    pin_bytes = json.dumps(intake, indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8")
    atomic_write(directory / "ASGO-0.1-intake.json", pin_bytes)
    written.append({"file": "ASGO-0.1-intake.json", "sha256": sha256_hex(pin_bytes), "bytes": len(pin_bytes)})
    return {"directory": str(directory), "written": len(written), "declared_written": len(declared),
            "digest": digest_of(written), "production_go": "NO_GO", "reviewer": None}


def write_declared_evidence(*, overlay: Path | None = None,
                            register: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """ASGO evidence schema: write each note to the package-declared path. Not a review."""
    overlay = Path(overlay) if overlay is not None else OVERLAY_ROOT
    document = register or build_register()
    notes_dir = overlay / "evidence" / "asgo"
    return write_item_evidence(notes_dir, register=document, also_declared_under=overlay)


def export_register(directory: Path, *, register: Mapping[str, Any] | None = None) -> dict[str, Any]:
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    document = dict(register) if register is not None else build_register()
    go = production_go_from_asgo(document)
    compact = [{k: item[k] for k in (
        "item_id", "implementation_id", "wave", "source_text", "status",
        "execution_class", "owner_role", "block_reason", "evidence_location",
    )} for item in document["items"]]
    summary = {
        "schema_id": document["schema_id"],
        "asgo_version": document["asgo_version"],
        "package_pin": document["package_pin"],
        "implementer": document["implementer"],
        "product_contract": document["product_contract"],
        "summary": document["summary"],
        "production_go_from_asgo": go,
        "items": compact,
        "exported_at": now_iso(),
    }
    written = []
    for name, payload in (
        ("ASGO_REGISTER.json", json.dumps(document, indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8")),
        ("ASGO_SUMMARY.json", json.dumps(summary, indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8")),
        ("PACKAGE_PIN.json", json.dumps(document["package_pin"], indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8")),
    ):
        atomic_write(directory / name, payload)
        written.append({"file": name, "sha256": sha256_hex(payload), "bytes": len(payload)})
    md = _markdown(document, go)
    atomic_write(directory / "ASGO_REGISTER.md", md.encode("utf-8"))
    written.append({"file": "ASGO_REGISTER.md", "sha256": sha256_hex(md.encode("utf-8")),
                    "bytes": len(md.encode("utf-8"))})
    return {"directory": str(directory), "written": written, "digest": digest_of(written),
            "production_go": go["verdict"]}


def _markdown(document: Mapping[str, Any], go: Mapping[str, Any]) -> str:
    summary = document["summary"]
    lines = [
        "# ASGO 150-item Production GO register",
        "",
        f"**Production GO from ASGO:** `{go['verdict']}`",
        "",
        "Prompts authorize work; they do not grant authority. `IMPLEMENTED` is not `DONE`.",
        "",
        f"- package sha256: `{document['package_pin']['sha256']}`",
        f"- items: {summary['total']}",
        f"- product kind: `{document['product_contract']['product_kind']}` ({document['product_contract']['status']})",
        f"- verified/done/complete: {summary['verified']}/{summary['done']}/{summary['complete']}",
        "",
        "| status | n |",
        "|---|---|",
    ]
    for key, value in summary["by_status"].items():
        lines.append(f"| {key} | {value} |")
    lines += ["", "## Items", ""]
    for item in document["items"]:
        lines.append(f"- `{item['item_id']}` [{item['status']}] {item['source_text']}")
    return "\n".join(lines) + "\n"
