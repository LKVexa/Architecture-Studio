"""Sandboxed execution of untrusted code and artifacts (XTOOL-03, ENV-05).

Deny-by-default on four axes — filesystem, network, environment, time — and
honest about what it can and cannot enforce. On a host without namespaces or
seccomp, process-level isolation is what is available: a separate interpreter,
a scrubbed environment, a working directory confined to a temporary root, a
wall-clock limit and (where the platform provides them) address-space and
file-size rlimits. :attr:`SandboxResult.enforcement` records exactly which were
applied, so evidence never claims an isolation guarantee the host did not give.
A caller needing a stronger boundary reads that field and refuses.

Build provenance: adapted from the owner's ``rcg/sandbox.py``; the deny-by-default
policy vocabulary follows ``mxc-main`` sandbox-policy via the SPB
``sandbox_backend`` (MIT).
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Sequence

__all__ = ["SandboxError", "SandboxPolicy", "SandboxResult", "Sandbox", "POLICY_VERSION"]

POLICY_VERSION = "1.0.0"
_ENV_ALLOWLIST = ("PATH", "LANG", "LC_ALL", "TZ", "PYTHONHASHSEED", "SYSTEMROOT", "SystemRoot")


class SandboxError(RuntimeError):
    pass


@dataclass(frozen=True)
class SandboxPolicy:
    timeout_seconds: int = 30
    max_output_bytes: int = 1_000_000
    max_address_space_bytes: int | None = 1 << 30
    max_file_size_bytes: int | None = 64 << 20
    allow_network: bool = False
    allow_host_env: bool = False
    read_only_inputs: bool = True
    isolation_class: str = "process-level"

    def as_document(self) -> dict[str, Any]:
        return {"policy_version": POLICY_VERSION, "timeout_seconds": self.timeout_seconds,
                "max_output_bytes": self.max_output_bytes, "max_address_space_bytes": self.max_address_space_bytes,
                "max_file_size_bytes": self.max_file_size_bytes, "allow_network": self.allow_network,
                "allow_host_env": self.allow_host_env, "read_only_inputs": self.read_only_inputs,
                "isolation_class": self.isolation_class, "default": "deny"}


@dataclass
class SandboxResult:
    exit_code: int | None
    stdout: str
    stderr: str
    timed_out: bool
    truncated: bool
    enforcement: dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.exit_code == 0 and not self.timed_out

    def as_document(self) -> dict[str, Any]:
        return {"exit_code": self.exit_code, "timed_out": self.timed_out, "truncated": self.truncated, "ok": self.ok,
                "stdout_bytes": len(self.stdout), "stderr_bytes": len(self.stderr), "enforcement": self.enforcement}


class Sandbox:
    def __init__(self, policy: SandboxPolicy | None = None) -> None:
        self.policy = policy or SandboxPolicy()

    def _environment(self) -> dict[str, str]:
        if self.policy.allow_host_env:
            return dict(os.environ)
        env = {name: os.environ[name] for name in _ENV_ALLOWLIST if name in os.environ}
        env.setdefault("PATH", "/usr/bin:/bin")
        env["PYTHONHASHSEED"] = "0"
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        if not self.policy.allow_network:
            env["no_proxy"] = env["NO_PROXY"] = "*"
            env["http_proxy"] = env["https_proxy"] = "http://127.0.0.1:9"
        return env

    def _preexec(self):
        limits: list[str] = []
        try:
            import resource
        except ImportError:  # Windows
            return None, limits
        policy = self.policy

        def apply() -> None:  # pragma: no cover - child process
            if policy.max_address_space_bytes:
                resource.setrlimit(resource.RLIMIT_AS, (policy.max_address_space_bytes, policy.max_address_space_bytes))
            if policy.max_file_size_bytes:
                resource.setrlimit(resource.RLIMIT_FSIZE, (policy.max_file_size_bytes, policy.max_file_size_bytes))
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            os.setsid()

        if policy.max_address_space_bytes:
            limits.append("rlimit_as")
        if policy.max_file_size_bytes:
            limits.append("rlimit_fsize")
        limits.extend(["rlimit_core", "new_session"])
        return apply, limits

    def run(self, command: Sequence[str], *, inputs: Mapping[str, bytes] | None = None) -> SandboxResult:
        workdir = Path(tempfile.mkdtemp(prefix="as-sandbox-"))
        try:
            for name, payload in (inputs or {}).items():
                target = (workdir / name).resolve()
                try:
                    target.relative_to(workdir.resolve())
                except ValueError:
                    raise SandboxError(f"sandbox input {name!r} escapes the sandbox root")
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(payload)
                if self.policy.read_only_inputs:
                    os.chmod(target, 0o400)
            preexec, limits = self._preexec()
            enforcement = {
                "process_isolation": True, "environment_scrubbed": not self.policy.allow_host_env,
                "network": "denied (advisory: proxy blackhole + no credentials)" if not self.policy.allow_network else "allowed",
                "filesystem_root": "temporary directory, removed after the run", "rlimits_applied": limits,
                "timeout_seconds": self.policy.timeout_seconds,
                "kernel_sandbox": "unavailable on this host; process-level isolation only",
                "isolation_class": "process-level",
            }
            try:
                completed = subprocess.run(list(command), cwd=str(workdir), env=self._environment(), capture_output=True,
                                           text=True, timeout=self.policy.timeout_seconds, preexec_fn=preexec, check=False)
            except subprocess.TimeoutExpired as exc:
                return SandboxResult(None, _text(exc.stdout), _text(exc.stderr), True, False, enforcement)
            except (OSError, ValueError) as exc:
                raise SandboxError(f"sandbox could not start the process: {exc}") from None
            cap = self.policy.max_output_bytes
            truncated = len(completed.stdout) > cap or len(completed.stderr) > cap
            return SandboxResult(completed.returncode, completed.stdout[:cap], completed.stderr[:cap], False, truncated, enforcement)
        finally:
            shutil.rmtree(workdir, ignore_errors=True)

    def run_python(self, source: str, *, inputs: Mapping[str, bytes] | None = None) -> SandboxResult:
        return self.run([sys.executable, "-I", "-S", "untrusted.py"], inputs={**(inputs or {}), "untrusted.py": source.encode("utf-8")})


def _text(value: Any) -> str:
    if value is None:
        return ""
    return value if isinstance(value, str) else value.decode("utf-8", "replace")
