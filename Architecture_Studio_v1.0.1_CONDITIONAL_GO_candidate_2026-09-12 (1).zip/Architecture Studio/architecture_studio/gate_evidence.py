"""Assemble the mechanical evidence the production gates inspect.

CLI ``gates`` and ``tools/build_evidence.py`` previously passed a *partial*
evidence document (often only the docs freshness report). That made four gates
report ``NO_EVIDENCE`` even though the runtime could produce the missing
artifacts: a write-authority scan, a verification report over a real run, an
incident drill, and a recovery exercise.

This module produces those artifacts from *this* process. It does not invent a
security/privacy review, an independent human review, an approved threshold, a
bound identity provider, a KMS, or a provisioned environment.
"""
from __future__ import annotations

import json
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .canonical import digest_of, fmt_ts
from .docs import freshness_report
from .fixtures import OVERLAY_ROOT, make_operator, make_scope, scope_document
from .gates import evaluate_gates, production_verdict
from .policy import controls_document
from .write_scan import scan_write_authority

__all__ = [
    "collect_gate_evidence",
    "evaluate_production",
    "load_external_authority",
    "IMPLEMENTER_SUBJECTS",
    "GATE_EVIDENCE_VERSION",
]

GATE_EVIDENCE_VERSION = "1.0.1"

#: Subjects that must never review or verify this overlay. Passing a review
#: file signed by one of these is ignored the same way an in-process self-review is.
IMPLEMENTER_SUBJECTS: tuple[str, ...] = (
    "architecture_studio",
    "runtime",
    "generator",
    "builder:architecture-studio-audit-2026-09-11",
    "builder:architecture-studio-asfw-2026-09-11",
    "builder:architecture-studio-asgo-2026-09-12",
)


def _read_json(path: Path) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def load_external_authority(root: Path | None = None) -> dict[str, Any]:
    """Load human-authored authority records from disk. Never invents them.

    Expected layout (all optional; missing = empty):

    * ``evidence/reviews/GATE-PROD-XX.json`` — independent gate review
    * ``evidence/reviews/GATE-PROD-07-security.json`` — security/privacy review body
    * ``evidence/reviews/exceptions.json`` — documented risk acceptances (still not PASS)
    * ``evidence/reviews/builder_subjects.json`` — extra implementer subjects to refuse
    """
    root = Path(root) if root is not None else OVERLAY_ROOT
    reviews_dir = root / "evidence" / "reviews"
    reviews: dict[str, dict[str, Any]] = {}
    security_review = None
    exceptions: dict[str, dict[str, Any]] = {}
    extra_builders: list[str] = []
    loaded_from: list[str] = []
    if reviews_dir.is_dir():
        for path in sorted(reviews_dir.glob("*.json")):
            payload = _read_json(path)
            if payload is None:
                continue
            kind = str(payload.get("record_kind") or "")
            if kind in {"principal_offer", "source_completeness_decision", "roster_proposal",
                        "asgo_implementer_note"} \
                    or str(payload.get("schema_id") or "").startswith("as.roster") \
                    or str(payload.get("schema_id") or "").startswith("as.asgo"):
                loaded_from.append(f"{path.name}:ignored_non_review")
                continue
            if path.name == "GATE-PROD-07-security.json" or kind == "security_review":
                security_review = payload
                loaded_from.append(path.name)
                continue
            if path.name == "exceptions.json":
                for gate_id, rec in payload.items():
                    if isinstance(rec, dict):
                        exceptions[str(gate_id)] = rec
                loaded_from.append(path.name)
                continue
            if path.name == "builder_subjects.json":
                extra_builders = [str(s) for s in payload.get("subjects", [])]
                loaded_from.append(path.name)
                continue
            gate_id = str(payload.get("gate_id") or path.stem)
            if gate_id.startswith("GATE-PROD-"):
                reviews[gate_id] = payload
                loaded_from.append(path.name)
    builders = tuple(dict.fromkeys([*IMPLEMENTER_SUBJECTS, *extra_builders]))
    return {
        "reviews": reviews,
        "security_review": security_review,
        "exceptions": exceptions,
        "builder_subjects": builders,
        "loaded_from": loaded_from,
        "reviews_dir": str(reviews_dir),
        "note": "absent files mean no human authority has been presented; they are not a PASS",
    }


def _now() -> str:
    return fmt_ts(datetime.now(timezone.utc))


def _run_verification() -> dict[str, Any]:
    """VERIFY-01 over a real (fixture-scoped) generation, not a synthetic stub."""
    from .assumptions import AssumptionRegistry
    from .fixtures import make_index
    from .generator import Generator
    from .ledger import Ledger
    from .retrieval import RetrievalIndex
    from .verify import verify_outputs

    with tempfile.TemporaryDirectory(prefix="as-verify-") as tmp:
        root = Path(tmp)
        scope = make_scope("RUN-GATE-VERIFY")
        index, _, _ = make_index(scope)
        retrieval = RetrievalIndex()
        retrieval.add_index(index)
        ledger = Ledger(root / "ledger.jsonl", "RUN-GATE-VERIFY")
        generator = Generator(scope=scope, index=index, retrieval=retrieval,
                              assumptions=AssumptionRegistry("RUN-GATE-VERIFY"), ledger=ledger)
        generation = generator.generate(run_id="RUN-GATE-VERIFY", iteration=1,
                                        goals=[{"text": "consolidate governance services", "derivation": "human"}],
                                        constraints=[], session_ref="S-GATE")
        report = verify_outputs(run_id="RUN-GATE-VERIFY", iteration=1, candidates=generation.candidates,
                                index=index, assumptions=generator.assumptions, ledger=ledger)
        return report.as_document()


def _run_incident_drill() -> dict[str, Any]:
    from .authority import IdentityProvider
    from .incident import FlagStore, drill
    from .ledger import Ledger
    from .policy import Verdict, evaluate

    with tempfile.TemporaryDirectory(prefix="as-drill-") as tmp:
        root = Path(tmp)
        idp = IdentityProvider()
        idp.enroll("oncall@example.test", "human", "oncall-secret")
        idp.enroll("svc-runner", "service", "svc-secret")
        operator = idp.authenticate("oncall@example.test", "oncall-secret")
        ledger = Ledger(root / "ledger.jsonl", "RUN-DRILL")
        flags = FlagStore(root / "flags.json", ledger=ledger)
        scope = make_scope("RUN-DRILL")
        provider_calls = {"n": 0}

        def probe() -> dict[str, Any]:
            decision = evaluate({"kind": "model_call", "permission": "analyze", "actor_kind": "service",
                                 "rollout": flags}, scope)
            if decision.verdict == Verdict.ALLOW:
                provider_calls["n"] += 1
            persisted = 0 if not flags.enabled else 1
            return {"provider_calls": provider_calls["n"], "persisted": persisted if flags.enabled else 0,
                    "outcome": decision.verdict}

        return drill(flags=flags, identity_provider=idp, ledger=ledger, operator=operator, run_probe=probe,
                     revoke_subject="svc-runner", revoke_secret="svc-secret")


def _run_recovery_exercise() -> dict[str, Any]:
    from .backup import exercise
    from .ledger import Ledger
    from .store import ObjectStore

    with tempfile.TemporaryDirectory(prefix="as-recovery-") as tmp:
        root = Path(tmp)
        store = ObjectStore(root / "store")
        store.commit("runs/RUN-REC/state", {"kind": "run", "n": 1}, expected_parent=None,
                     metadata={"data_class": "run_state"})
        ledger = Ledger(root / "ledger.jsonl", "RUN-REC")
        ledger.append("test.event", actor="operator@example.test", actor_kind="human", outcome="recorded",
                      detail={"n": 1})
        return exercise(store=store, ledger=ledger, flags_path=None, workdir=root / "dr", run_id="RUN-REC")


def _load_or_run_tests(tests: Mapping[str, Any] | None) -> dict[str, Any]:
    if tests:
        return dict(tests)
    report_path = OVERLAY_ROOT / "evidence" / "reports" / "run_all.json"
    if report_path.is_file():
        try:
            payload = json.loads(report_path.read_text(encoding="utf-8"))
            if "all_passed" in payload and "passed" in payload:
                return payload
        except (OSError, json.JSONDecodeError):
            pass
    # Last resort: run the suite. This is the honest evidence; a missing report
    # is not a pass.
    import subprocess
    import sys
    target = OVERLAY_ROOT / "evidence" / "reports" / "run_all.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    completed = subprocess.run([sys.executable or "python3", "tests/run_all.py", "--json", str(target)],
                               cwd=str(OVERLAY_ROOT), capture_output=True, text=True, timeout=1800)
    if target.is_file():
        payload = json.loads(target.read_text(encoding="utf-8"))
        payload["exit_code"] = completed.returncode
        return payload
    return {"all_passed": False, "passed": 0, "total": 0, "exit_code": completed.returncode,
            "stderr_tail": (completed.stderr or "")[-2000:]}


def collect_gate_evidence(*, tests: Mapping[str, Any] | None = None, benchmark: Mapping[str, Any] | None = None,
                          run_benchmark: bool = True, run_operational: bool = True,
                          authority_root: Path | None = None) -> dict[str, Any]:
    """Return the evidence mapping :func:`evaluate_gates` consumes.

    ``security_review`` is omitted unless a human-authored file already exists
    under ``evidence/reviews/``. The runtime never writes that file.
    """
    evidence: dict[str, Any] = {
        "collected_at": _now(),
        "collector": "architecture_studio.gate_evidence",
        "collector_version": GATE_EVIDENCE_VERSION,
        "controls": controls_document(),
        "docs": freshness_report(OVERLAY_ROOT / "docs"),
        "write_authority_scan": scan_write_authority(),
        "tests": _load_or_run_tests(tests),
    }
    if benchmark is not None:
        evidence["benchmark"] = dict(benchmark)
    elif run_benchmark:
        from .benchmark import run_benchmark as _run_benchmark
        evidence["benchmark"] = _run_benchmark()
    if run_operational:
        evidence["verification"] = _run_verification()
        evidence["incident_drill"] = _run_incident_drill()
        evidence["recovery_exercise"] = _run_recovery_exercise()
    authority = load_external_authority(authority_root)
    if authority["security_review"] is not None:
        evidence["security_review"] = authority["security_review"]
    evidence["evidence_digest"] = digest_of({k: evidence[k] for k in sorted(evidence) if k != "evidence_digest"})
    return evidence


def evaluate_production(*, tests: Mapping[str, Any] | None = None, benchmark: Mapping[str, Any] | None = None,
                        run_benchmark: bool = True, run_operational: bool = True,
                        reviews: Mapping[str, Mapping[str, Any]] | None = None,
                        exceptions: Mapping[str, Mapping[str, Any]] | None = None,
                        builder_subjects: tuple[str, ...] = (),
                        authority_root: Path | None = None) -> dict[str, Any]:
    authority = load_external_authority(authority_root)
    evidence = collect_gate_evidence(tests=tests, benchmark=benchmark, run_benchmark=run_benchmark,
                                     run_operational=run_operational, authority_root=authority_root)
    merged_reviews = dict(authority["reviews"])
    if reviews:
        merged_reviews.update(reviews)
    merged_exceptions = dict(authority["exceptions"])
    if exceptions:
        merged_exceptions.update(exceptions)
    builders = tuple(dict.fromkeys([*authority["builder_subjects"], *builder_subjects]))
    report = evaluate_gates(evidence, reviews=merged_reviews, exceptions=merged_exceptions,
                            builder_subjects=builders)
    verdict = production_verdict(report)
    return {"evidence": evidence,
            "evidence_keys": sorted(k for k in evidence if k not in ("collected_at", "collector", "collector_version",
                                                                     "evidence_digest")),
            "evidence_digest": evidence["evidence_digest"],
            "write_authority_scan": {"write_sites": evidence["write_authority_scan"]["write_sites"],
                                     "hidden": evidence["write_authority_scan"]["hidden_write_paths"],
                                     "verdict": evidence["write_authority_scan"]["verdict"]},
            "authority_loaded_from": authority["loaded_from"],
            "gates": report, "production_verdict": verdict,
            "boundary": ("Mechanical evidence is assembled here. PASS still requires an independent human "
                         "review record per gate. This collector is the implementer's runtime; it is not a verifier. "
                         "On-disk review files are loaded if present and still refused when the reviewer is the implementer.")}
