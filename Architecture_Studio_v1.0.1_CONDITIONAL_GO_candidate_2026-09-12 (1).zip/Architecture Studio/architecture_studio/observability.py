"""Observability, metrics, tracing and alerting (ARCH-10, XOBS-01..05, AUDIT-ADD-13, AUDIT-ADD-19).

Structured logs (one JSON object per event, secrets filtered before emission),
a metric registry whose rates always carry their denominator (a rate over zero
observations is ``INSUFFICIENT_DATA``, never ``1.0``), run-level tracing as one
span tree per run, ground-truth scoring for false-positive/false-negative rates
where truth exists, and alert rules that fire on *permission* anomalies rather
than on errors.

Metric owners and thresholds are declared in :mod:`architecture_studio.slo`;
this module measures and reports, it does not judge a threshold met unless the
threshold is APPROVED and the denominator is non-zero.

Adapted from the owner's ``rcg/observability.py`` and the SPB ``observability``
(``_rate`` names its denominator).
"""
from __future__ import annotations

import json
import time
from collections import Counter, defaultdict
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterator, Mapping, Sequence

from .canonical import digest_of, fmt_ts
from .security import redact

__all__ = ["StructuredLogger", "Metrics", "Rate", "Span", "Tracer", "AlertRule", "ALERT_RULES", "evaluate_alerts",
           "GroundTruthScorer", "Telemetry", "MEASURED", "INSUFFICIENT_DATA"]

MEASURED, INSUFFICIENT_DATA = "MEASURED", "INSUFFICIENT_DATA"
_SENSITIVE_KEYS = ("secret", "token", "password", "credential", "authorization", "api_key")


class StructuredLogger:
    """XOBS-01: one JSON object per event; sensitive fields redacted before emission."""

    def __init__(self, sink: list[str] | None = None) -> None:
        self.sink: list[str] = sink if sink is not None else []

    def emit(self, event: str, **fields: Any) -> dict[str, Any]:
        clean: dict[str, Any] = {}
        for key, value in fields.items():
            if any(word in key.lower() for word in _SENSITIVE_KEYS):
                clean[key] = "[REDACTED:field]"
            elif isinstance(value, str):
                clean[key] = redact(value)[0]
            else:
                clean[key] = value
        record = {"ts": fmt_ts(datetime.now(timezone.utc)), "event": event, **clean}
        self.sink.append(json.dumps(record, sort_keys=True, separators=(",", ":"), ensure_ascii=True))
        return record

    def transition(self, run_id: str, previous: str, event: str, current: str, **fields: Any) -> dict[str, Any]:
        return self.emit("workflow.transition", run_id=run_id, previous_state=previous, transition=event, state=current, **fields)


@dataclass(frozen=True)
class Rate:
    name: str
    numerator: int
    denominator: int
    over: str

    def __post_init__(self) -> None:
        if self.numerator < 0 or self.denominator < 0 or self.numerator > self.denominator:
            raise ValueError(f"{self.name}: {self.numerator} of {self.denominator} is impossible")

    @property
    def value(self) -> float | None:
        return round(self.numerator / self.denominator, 6) if self.denominator else None

    def as_document(self) -> dict[str, Any]:
        return {"name": self.name, "n": self.numerator, "of": self.denominator, "over": self.over, "rate": self.value,
                "state": MEASURED if self.denominator else INSUFFICIENT_DATA}


class Metrics:
    """XOBS-02: latency, cost, tool failures, abstention, approval and override rates — with denominators."""

    def __init__(self) -> None:
        self._counters: Counter[str] = Counter()
        self._timings: dict[str, list[float]] = defaultdict(list)
        self._costs: Counter[str] = Counter()

    def increment(self, name: str, amount: int = 1) -> None:
        self._counters[name] += amount

    def observe(self, name: str, milliseconds: float) -> None:
        self._timings[name].append(milliseconds)

    def add_cost(self, name: str, units: int) -> None:
        self._costs[name] += units

    def count(self, name: str) -> int:
        return self._counters.get(name, 0)

    def rate(self, numerator: str, denominator: str, *, over: str = "") -> Rate:
        total = self._counters.get(denominator, 0)
        return Rate(numerator, min(self._counters.get(numerator, 0), total), total, over or denominator)

    def percentile(self, name: str, p: float) -> float | None:
        values = sorted(self._timings.get(name, []))
        if not values:
            return None
        index = min(len(values) - 1, int(round((p / 100.0) * (len(values) - 1))))
        return round(values[index], 3)

    def snapshot(self) -> dict[str, Any]:
        return {
            "counters": dict(sorted(self._counters.items())), "costs": dict(sorted(self._costs.items())),
            "latency_ms": {name: {"count": len(values), "p50": self.percentile(name, 50), "p95": self.percentile(name, 95),
                                  "max": round(max(values), 3)} for name, values in sorted(self._timings.items()) if values},
            "rates": {
                "tool_failure": self.rate("tool.failed", "tool.calls").as_document(),
                "abstention": self.rate("model.abstained", "model.calls").as_document(),
                "approval": self.rate("review.approved", "review.decisions").as_document(),
                "override": self.rate("review.overridden", "review.decisions").as_document(),
                "denial": self.rate("policy.denied", "policy.evaluations").as_document(),
            },
        }


@dataclass
class Span:
    span_id: str
    name: str
    parent_id: str | None
    start_ms: float
    end_ms: float | None = None
    attributes: dict[str, Any] = field(default_factory=dict)
    status: str = "ok"
    sequence: int = 0

    @property
    def duration_ms(self) -> float | None:
        return None if self.end_ms is None else round(self.end_ms - self.start_ms, 3)

    def as_document(self) -> dict[str, Any]:
        return {"span_id": self.span_id, "name": self.name, "parent_id": self.parent_id, "duration_ms": self.duration_ms,
                "status": self.status, "attributes": dict(self.attributes), "sequence": self.sequence}


class Tracer:
    """XOBS-05: one span tree per run across retrieval, analyzers, model calls and approvals."""

    def __init__(self, run_id: str, *, metrics: Metrics | None = None) -> None:
        self.run_id = run_id
        self.metrics = metrics
        self.spans: list[Span] = []
        self._stack: list[str] = []

    @contextmanager
    def span(self, name: str, **attributes: Any) -> Iterator[Span]:
        span = Span(span_id=f"SP-{len(self.spans):04d}", name=name, parent_id=self._stack[-1] if self._stack else None,
                    start_ms=time.perf_counter() * 1000.0, attributes=dict(attributes), sequence=len(self.spans))
        self.spans.append(span)
        self._stack.append(span.span_id)
        try:
            yield span
        except BaseException as exc:
            span.status = f"error:{type(exc).__name__}"
            raise
        finally:
            span.end_ms = time.perf_counter() * 1000.0
            self._stack.pop()
            if self.metrics is not None and span.duration_ms is not None:
                self.metrics.observe(name, span.duration_ms)

    def order_of(self, prefix: str) -> list[int]:
        return [s.sequence for s in self.spans if s.name.startswith(prefix)]

    def as_document(self) -> dict[str, Any]:
        return {"run_id": self.run_id, "span_count": len(self.spans), "spans": [s.as_document() for s in self.spans],
                "trace_digest": digest_of([s.as_document() for s in self.spans])}


@dataclass(frozen=True)
class AlertRule:
    rule_id: str
    requirement_id: str
    description: str
    severity: str
    owner_role: str

    def as_document(self) -> dict[str, Any]:
        return {"rule_id": self.rule_id, "requirement_id": self.requirement_id, "description": self.description,
                "severity": self.severity, "owner_role": self.owner_role}


ALERT_RULES: tuple[AlertRule, ...] = (
    AlertRule("ALERT-WRITE-01", "XOBS-04", "A write was attempted without the modify permission or approval.", "critical", "security_privacy_owner"),
    AlertRule("ALERT-PERM-01", "XOBS-04", "A permission was used that this run had never used before.", "warning", "security_privacy_owner"),
    AlertRule("ALERT-DENY-01", "XOBS-04", "Policy denial rate exceeded 20% of evaluations (threshold PROPOSED).", "warning", "operations_owner"),
    AlertRule("ALERT-EXT-01", "XOBS-04", "An unauthorized external or foreign-tenant source was contacted.", "critical", "security_privacy_owner"),
    AlertRule("ALERT-SELFAPP-01", "SEC-07", "A non-human principal attempted an approval or final selection.", "critical", "human_review_policy_owner"),
    AlertRule("ALERT-KILL-01", "AUDIT-ADD-26", "The rollout switch was disabled or the store became unreadable.", "critical", "incident_response_owner"),
)


def evaluate_alerts(*, events: Sequence[Mapping[str, Any]], metrics: Metrics, baseline_permissions: Sequence[str] = ()) -> list[dict[str, Any]]:
    alerts: list[dict[str, Any]] = []
    baseline = set(baseline_permissions)
    for record in events:
        event = record.get("event", record)
        detail = record.get("detail", {}) if "event" in record else {}
        kind = event.get("event_type", "")
        outcome = event.get("outcome", "")
        permission = detail.get("permission")
        if kind in ("tool.call", "artifact.write") and outcome == "denied" and permission in ("modify", "commit"):
            alerts.append({"rule_id": "ALERT-WRITE-01", "severity": "critical", "event": kind, "detail": f"denied {permission} attempt"})
        if permission and baseline and permission not in baseline:
            alerts.append({"rule_id": "ALERT-PERM-01", "severity": "warning", "event": kind, "detail": f"permission {permission!r} not in baseline"})
        if kind == "connector.denied" and (detail.get("external") or "tenant" in str(detail.get("reason", ""))):
            alerts.append({"rule_id": "ALERT-EXT-01", "severity": "critical", "event": kind, "detail": "unauthorized source contacted"})
        if kind in ("review.decision", "approval.issued", "approval.refused") and (
                event.get("actor_kind") not in (None, "human") or detail.get("code") == "approval.not_human"):
            alerts.append({"rule_id": "ALERT-SELFAPP-01", "severity": "critical", "event": kind, "detail": "non-human approval attempt"})
        if kind == "rollout.flag_changed" and "EMERGENCY" in str(event.get("subject", "")):
            alerts.append({"rule_id": "ALERT-KILL-01", "severity": "critical", "event": kind, "detail": "emergency disable recorded"})
    denial = metrics.rate("policy.denied", "policy.evaluations")
    if denial.value is not None and denial.value > 0.20:
        alerts.append({"rule_id": "ALERT-DENY-01", "severity": "warning", "event": "policy", "detail": f"denial rate {denial.value:.0%} exceeds 20%"})
    return alerts


class GroundTruthScorer:
    """XOBS-03 / XEVAL-03: false-positive and false-negative rates where ground truth exists."""

    def __init__(self) -> None:
        self.tp = self.fp = self.tn = self.fn = 0

    def add(self, *, predicted: bool, actual: bool) -> None:
        if predicted and actual:
            self.tp += 1
        elif predicted and not actual:
            self.fp += 1
        elif not predicted and actual:
            self.fn += 1
        else:
            self.tn += 1

    def scores(self) -> dict[str, Any]:
        total = self.tp + self.fp + self.tn + self.fn

        def ratio(n: int, d: int) -> float | None:
            return None if not d else round(n / d, 6)
        return {"true_positive": self.tp, "false_positive": self.fp, "true_negative": self.tn, "false_negative": self.fn,
                "total": total, "precision": ratio(self.tp, self.tp + self.fp), "recall": ratio(self.tp, self.tp + self.fn),
                "false_positive_rate": ratio(self.fp, self.fp + self.tn), "false_negative_rate": ratio(self.fn, self.fn + self.tp),
                "accuracy": ratio(self.tp + self.tn, total), "state": MEASURED if total else INSUFFICIENT_DATA}


class Telemetry:
    """The one object a run carries: logger + metrics + tracer, exported together."""

    def __init__(self, run_id: str) -> None:
        self.run_id = run_id
        self.logger = StructuredLogger()
        self.metrics = Metrics()
        self.tracer = Tracer(run_id, metrics=self.metrics)

    def as_document(self) -> dict[str, Any]:
        return {"run_id": self.run_id, "logs": len(self.logger.sink), "metrics": self.metrics.snapshot(),
                "trace": self.tracer.as_document(), "alert_rules": [r.as_document() for r in ALERT_RULES]}
