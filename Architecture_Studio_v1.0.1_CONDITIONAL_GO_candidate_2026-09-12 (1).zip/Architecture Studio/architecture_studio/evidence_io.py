"""Strict evidence parsing, atomic writes and artifact resolution.

Every document this runtime consumes as *evidence* — a scope contract, a
connector record, a flag store, a receipt, a registry — must have exactly one
interpretation, and every artifact it references must resolve to the bytes that
were approved. The default JSON parser gives neither guarantee: it keeps the
last duplicate key, accepts ``NaN``/``Infinity``, and has no size opinion.

Rules (each has a negative test): duplicate keys refused; non-finite numbers
refused; size bounded; strict UTF-8 only; artifact references carry their digest
and are re-hashed on read; a skipped or optional check never satisfies a
mandatory one (:func:`require_coverage`).

Adapted from the owner's Repository Context Graph runtime (``rcg/evidence.py``).
"""
from __future__ import annotations

import json
import math
import os
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Mapping, Sequence

from .canonical import sha256_hex

__all__ = ["EvidenceError", "AmbiguousEvidence", "UnsafeReference", "ArtifactRef",
           "MAX_EVIDENCE_BYTES", "MAX_RELATIVE_PATH_CHARS", "MAX_ABS_PATH_CHARS",
           "load_strict", "loads_strict", "parse_ref",
           "resolve_artifact", "require_coverage", "atomic_write", "confine"]

MAX_EVIDENCE_BYTES = 4 * 1024 * 1024
#: Conservative relative-path bound: well under Windows MAX_PATH (260) and
#: far under typical Linux PATH_MAX (4096). Absolute bound is the host limit.
MAX_RELATIVE_PATH_CHARS = 240
MAX_ABS_PATH_CHARS = 4096
_WINDOWS_RESERVED = frozenset({
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
})
_UNSAFE_RELATIVE = re.compile(r"[\x00-\x1f]")


class EvidenceError(ValueError):
    """The document cannot be accepted as evidence."""


class AmbiguousEvidence(EvidenceError):
    """The document has more than one reasonable interpretation."""


class UnsafeReference(EvidenceError):
    """An artifact reference does not resolve to approved immutable bytes."""


def _no_duplicates(pairs: Sequence[tuple[str, Any]]) -> dict[str, Any]:
    seen: dict[str, Any] = {}
    for key, value in pairs:
        if key in seen:
            raise AmbiguousEvidence(f"duplicate key {key!r}: the document has two meanings")
        seen[key] = value
    return seen


def _reject_non_finite(value: Any, path: str = "$") -> None:
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            raise AmbiguousEvidence(f"non-finite number at {path}")
    elif isinstance(value, Mapping):
        for key, sub in value.items():
            _reject_non_finite(sub, f"{path}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, sub in enumerate(value):
            _reject_non_finite(sub, f"{path}[{index}]")


def _reject_constant(name: str) -> Any:
    raise AmbiguousEvidence(f"non-finite constant {name!r} is not admissible in evidence")


def loads_strict(payload: bytes | str, *, max_bytes: int = MAX_EVIDENCE_BYTES,
                 expect: type | tuple[type, ...] = dict) -> Any:
    raw = payload.encode("utf-8") if isinstance(payload, str) else payload
    if not isinstance(raw, (bytes, bytearray)):
        raise EvidenceError("evidence must be bytes or str")
    if len(raw) == 0:
        raise EvidenceError("evidence document is empty")
    if len(raw) > max_bytes:
        raise EvidenceError(f"evidence document is {len(raw)} bytes; the bound is {max_bytes}")
    try:
        text = bytes(raw).decode("utf-8")
    except UnicodeDecodeError as exc:
        raise EvidenceError(f"evidence is not strict UTF-8: {exc}") from None
    try:
        document = json.loads(text, parse_constant=_reject_constant, object_pairs_hook=_no_duplicates)
    except json.JSONDecodeError as exc:
        raise EvidenceError(f"evidence is not JSON: {exc}") from None
    _reject_non_finite(document)
    if not isinstance(document, expect):
        raise EvidenceError(f"evidence must be {expect}, not {type(document).__name__}")
    return document


def load_strict(path: str | Path, **kw: Any) -> Any:
    return loads_strict(Path(path).read_bytes(), **kw)


@dataclass(frozen=True)
class ArtifactRef:
    algorithm: str
    digest: str

    def as_uri(self) -> str:
        return f"{self.algorithm}:{self.digest}"


def parse_ref(reference: Any) -> ArtifactRef:
    if not isinstance(reference, str) or ":" not in reference:
        raise UnsafeReference(f"artifact reference {reference!r} is not algorithm:hex")
    algorithm, digest = reference.split(":", 1)
    if algorithm != "sha256" or not re.fullmatch(r"[0-9a-f]{64}", digest or ""):
        raise UnsafeReference(f"only lowercase sha256:<64 hex> references are accepted, not {reference!r}")
    return ArtifactRef(algorithm, digest)


def confine(root: str | Path, relative_path: str) -> Path:
    """Resolve ``relative_path`` under ``root`` or raise; symlinks resolved first.

    Refuses NULs, control characters, empty/absolute paths, ``..`` segments,
    Windows reserved device names, and over-long paths *before* touching the
    filesystem. Prefix-match confinement is not used: ``relative_to`` is.
    """
    if not isinstance(relative_path, str):
        raise UnsafeReference("path must be a string")
    if not relative_path or relative_path in {".", ""}:
        raise UnsafeReference("path is empty")
    if "\x00" in relative_path or _UNSAFE_RELATIVE.search(relative_path):
        raise UnsafeReference("path contains a NUL or control character")
    if len(relative_path) > MAX_RELATIVE_PATH_CHARS:
        raise UnsafeReference(f"relative path is {len(relative_path)} chars; bound is {MAX_RELATIVE_PATH_CHARS}")
    candidate = relative_path.replace("\\", "/")
    if candidate.startswith("/") or (len(candidate) >= 2 and candidate[1] == ":"):
        raise UnsafeReference("absolute paths are not admitted as relative targets")
    parts = PurePosixPath(candidate).parts
    if any(part in ("", ".", "..") for part in parts):
        # "." is refused as a *segment* after splitting; a single "." was caught above.
        if any(part == ".." or part == "" for part in parts):
            raise UnsafeReference("path contains an empty or parent-directory segment")
    for part in parts:
        stem = part.split(".")[0].upper()
        if stem in _WINDOWS_RESERVED:
            raise UnsafeReference(f"path uses a reserved device name {part!r}")
        if len(part) > 255:
            raise UnsafeReference(f"path component {part[:32]!r}… exceeds 255 characters")
    base = Path(root).resolve()
    target = (base / candidate).resolve()
    if len(str(target)) > MAX_ABS_PATH_CHARS:
        raise UnsafeReference(f"resolved path is {len(str(target))} chars; bound is {MAX_ABS_PATH_CHARS}")
    try:
        target.relative_to(base)
    except ValueError:
        raise UnsafeReference(f"path {relative_path!r} escapes the root") from None
    return target


def resolve_artifact(reference: Any, *, root: str | Path, relative_path: str) -> bytes:
    ref = parse_ref(reference)
    target = confine(root, relative_path)
    if not target.is_file():
        raise UnsafeReference(f"artifact {relative_path!r} does not exist")
    payload = target.read_bytes()
    actual = sha256_hex(payload)
    if actual != ref.digest:
        raise UnsafeReference(f"artifact {relative_path!r} hashes to {actual}, not the referenced digest")
    return payload


def require_coverage(required: Iterable[str], results: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    required = list(required)
    missing, unsatisfied = [], []
    for check in required:
        record = results.get(check)
        if record is None:
            missing.append(check)
            continue
        verdict = str(record.get("verdict", "")).upper()
        if verdict != "PASS":
            unsatisfied.append({"check": check, "verdict": verdict or "ABSENT"})
    satisfied = not missing and not unsatisfied
    return {"required": required, "satisfied": satisfied, "missing": missing,
            "unsatisfied": unsatisfied, "verdict": "PASS" if satisfied else "FAIL"}


def atomic_write(path: str | Path, payload: bytes) -> Path:
    """temp + fsync + rename; a reader never sees a partial file.

    Portable: ``os.replace`` overwrites atomically on POSIX and on Windows when
    the destination is not open. The temporary file is created in the same
    directory so the rename does not cross filesystems.
    """
    if not isinstance(payload, (bytes, bytearray)):
        raise TypeError("atomic_write requires bytes")
    target = Path(path)
    if len(str(target)) > MAX_ABS_PATH_CHARS:
        raise UnsafeReference(f"write path is {len(str(target))} chars; bound is {MAX_ABS_PATH_CHARS}")
    target.parent.mkdir(parents=True, exist_ok=True)
    handle, tmp = tempfile.mkstemp(dir=str(target.parent), prefix=".tmp-")
    try:
        with os.fdopen(handle, "wb") as fh:
            fh.write(payload)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                # Some Windows/network FS types refuse fsync; the rename still happens.
                pass
        os.replace(tmp, target)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return target
