"""The nine typed source connectors (DATA-01..09) over the corpus and the fixture set.

Each connector is a :class:`Connector` whose artifacts carry *typed records* in
``metadata["records"]``: a requirement, an NFR, an ADR, an API operation, an
infrastructure service, a diagram projection, a security constraint, a
cost/performance constraint or a deployment standard. Every record names the
pinned file and line it came from, so :mod:`normalize` can attach a full
evidence reference (XPROV-01) and the graph can answer "which source supports
this element" (COMP-02).

Missing values are surfaced as ``"unspecified"`` or ``None`` — never invented
(DATA-02: "conflicting or missing targets are surfaced rather than invented").
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Callable

from ..scope import ScopeContract, ScopeDenied
from .base import Connector, ConnectorCapabilities, ConnectorError, RawArtifact, make_raw_artifact
from .corpus import CorpusConnector, OVERLAY_DIR
from . import parsers

__all__ = ["REGISTRY", "RequirementsConnector", "NFRConnector", "ADRConnector", "APICatalogConnector",
           "InfraCatalogConnector", "DiagramConnector", "SecurityConstraintConnector", "CostPerformanceConnector",
           "DeploymentStandardConnector", "connector_for_class", "TypedConnector"]

_SUITE_NUM = re.compile(r"^(?P<num>\d+)\.\d+_")


class TypedConnector(Connector):
    """A connector that reads corpus (and optional fixture) files and emits typed records."""

    source_system: str = ""
    data_class: str = ""
    suffixes: tuple[str, ...] = ()
    fixture_glob: str | None = None
    root_files: tuple[str, ...] = ()

    def __init__(self, corpus_root: Path, *, tenant: str, project: str, fixtures_root: Path | None = None,
                 **kw: Any) -> None:
        super().__init__(**kw)
        self.corpus_root = Path(corpus_root).resolve()
        self.fixtures_root = Path(fixtures_root).resolve() if fixtures_root else None
        self.tenant = tenant
        self.project = project
        self.capabilities = ConnectorCapabilities(source_system=self.source_system, data_classes=(self.data_class,),
                                                  read=True, write=False, revision_semantics="content-hash",
                                                  pagination=True, page_size=40, supports_partial_results=True)
        self._fail_paths: set[str] = set()

    def simulate_unavailable(self, locator: str, on: bool = True) -> None:
        (self._fail_paths.add if on else self._fail_paths.discard)(locator)

    # --- discovery -----------------------------------------------------------
    def _discover(self, scope: ScopeContract) -> list[str]:
        locators: list[str] = []
        for path in sorted(self.corpus_root.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            rel = path.relative_to(self.corpus_root)
            if rel.parts and rel.parts[0] in (OVERLAY_DIR, ".git"):
                continue
            posix = rel.as_posix()
            if (path.suffix.lower() in self.suffixes and len(rel.parts) > 1) or posix in self.root_files:
                try:
                    scope.check_path(path, permission="read")
                except ScopeDenied:
                    continue
                locators.append("corpus:" + posix)
        if self.fixture_glob and self.fixtures_root and self.fixtures_root.is_dir():
            for path in sorted(self.fixtures_root.glob(self.fixture_glob)):
                if path.is_file():
                    locators.append("fixtures:" + path.relative_to(self.fixtures_root).as_posix())
        return locators

    def _resolve(self, locator: str) -> tuple[Path, str]:
        origin, _, rel = locator.partition(":")
        base = self.corpus_root if origin == "corpus" else self.fixtures_root
        if base is None or origin not in ("corpus", "fixtures"):
            raise ConnectorError("denied", f"{locator}: unknown origin")
        path = (base / rel).resolve()
        try:
            path.relative_to(base)
        except ValueError:
            raise ConnectorError("denied", f"{locator} escapes its root") from None
        return path, rel

    def _read_one(self, locator: str, scope: ScopeContract) -> RawArtifact:
        if locator in self._fail_paths:
            raise ConnectorError("unavailable", f"{locator}: source temporarily unavailable")
        path, rel = self._resolve(locator)
        if not path.is_file():
            raise ConnectorError("unavailable", f"{locator} does not exist")
        content = path.read_bytes()
        try:
            text = content.decode("utf-8")
        except UnicodeDecodeError:
            raise ConnectorError("malformed", f"{locator} is not UTF-8") from None
        try:
            records, ambiguities = self.extract(rel, text, locator)
        except (ValueError, KeyError) as exc:
            raise ConnectorError("malformed", f"{locator}: {exc}") from None
        import hashlib
        revision = "sha256:" + hashlib.sha256(content).hexdigest()
        return make_raw_artifact(
            source_system=self.source_system, data_class=self.data_class, tenant=self.tenant, project=self.project,
            path=locator, revision=revision, content=content, classification=self.classify(rel, text),
            metadata={"records": records, "ambiguities": ambiguities, "suite": _suite_of(rel),
                      "origin": locator.split(":", 1)[0]})

    # --- to implement --------------------------------------------------------
    def extract(self, rel: str, text: str, locator: str) -> tuple[list[dict[str, Any]], list[str]]:
        raise NotImplementedError

    def classify(self, rel: str, text: str) -> str:
        return "internal"


def _suite_of(rel: str) -> str:
    return rel.split("/", 1)[0] if "/" in rel else ""


def _suite_number(rel: str) -> int | None:
    name = rel.rsplit("/", 1)[-1]
    m = _SUITE_NUM.match(name)
    return int(m.group("num")) if m else None


def _record_id(data_class: str, rel: str, line: int | None, tag: str = "") -> str:
    base = f"{data_class}:{rel}#{line if line is not None else 0}"
    return base + (f":{tag}" if tag else "")


# --------------------------------------------------------------------------- #
class RequirementsConnector(TypedConnector):
    """DATA-01: canonical requirement records from suite READMEs and the module inventory."""

    source_system = "requirements"
    data_class = "requirement"
    suffixes = (".md",)
    root_files = ("ALL_SUITES_REPOSITORY_66_MODULES.md",)

    def extract(self, rel: str, text: str, locator: str) -> tuple[list[dict[str, Any]], list[str]]:
        records: list[dict[str, Any]] = []
        if rel == "ALL_SUITES_REPOSITORY_66_MODULES.md":
            for component in parsers.parse_inventory(text):
                for index, capability in enumerate(component["capabilities"], start=1):
                    records.append({
                        "requirement_id": f"REQ-S{component['number']:02d}-{index:02d}",
                        "text": f"{component['name']} provides {capability}",
                        "priority": "unspecified", "status": "stated", "suite": component["name"],
                        "relationships": [f"suite:{component['number']:02d}"],
                        "source_line": component["line"], "kind": "capability"})
            return records, []
        if not rel.endswith("README.md"):
            return [], []
        parsed = parsers.parse_readme(text)
        suite = _suite_of(rel)
        if not parsed["statements"]:
            return [], [f"{rel}: README has no requirement statements"]
        for index, statement in enumerate(parsed["statements"], start=1):
            records.append({
                "requirement_id": f"REQ-{_slug(suite)}-{index:02d}", "text": statement["text"],
                "priority": "unspecified", "status": "stated", "suite": suite,
                "relationships": [f"section:{statement['section']}"] + (
                    [f"script:{s['path']}" for s in parsed["scripts"]] if statement["kind"] == "prose" else []),
                "source_line": statement["line"], "kind": statement["kind"]})
        return records, []


class NFRConnector(TypedConnector):
    """DATA-02: NFRs with category, target, unit, scope, priority, evidence and conflict state."""

    source_system = "nfrs"
    data_class = "nfr"
    suffixes = (".jasp", ".jaops", ".md")

    def extract(self, rel: str, text: str, locator: str) -> tuple[list[dict[str, Any]], list[str]]:
        records: list[dict[str, Any]] = []
        ambiguities: list[str] = []
        suite = _suite_of(rel)
        if rel.endswith(".jasp"):
            parsed = parsers.parse_jasp(text)
            ambiguities += parsed["ambiguities"]
            quantitative = parsers.parse_nfr_lines(parsed, {})
        elif rel.endswith(".jaops"):
            parsed = parsers.parse_jaops(text)
            ambiguities += parsed["ambiguities"]
            quantitative = parsers.parse_nfr_lines({}, parsed)
        elif rel.endswith("README.md"):
            parsed = parsers.parse_readme(text)
            quantitative = []
            for statement in parsed["statements"]:
                if statement["kind"] == "design_rule":
                    records.append({"nfr_id": _record_id("nfr", rel, statement["line"]), "category": "policy",
                                    "target": statement["text"], "unit": None, "scope": suite,
                                    "priority": "unspecified", "quantitative": False, "conflict_state": "none",
                                    "source_line": statement["line"], "suite": suite})
        else:
            return [], []
        for index, nfr in enumerate(quantitative):
            if nfr["target"] is None or nfr["unit"] is None:
                ambiguities.append(f"{rel}: NFR at line {nfr.get('line')} lacks a target or unit")
                continue
            records.append({"nfr_id": _record_id("nfr", rel, nfr.get("line"), str(index)), "category": nfr["category"],
                            "target": nfr["target"], "unit": nfr["unit"], "scope": nfr["scope"] or suite,
                            "priority": "unspecified", "quantitative": True, "conflict_state": "none",
                            "source_line": nfr.get("line"), "suite": suite})
        return records, ambiguities


class ADRConnector(TypedConnector):
    """DATA-03: ADRs from MADR fixture files and the corpus's own cross-reference diagnostic."""

    source_system = "adrs"
    data_class = "adr"
    suffixes = ()
    fixture_glob = "adrs/*.md"
    root_files = ("CROSS_REFERENCE_DIAGNOSTIC.md",)

    def extract(self, rel: str, text: str, locator: str) -> tuple[list[dict[str, Any]], list[str]]:
        if rel == "CROSS_REFERENCE_DIAGNOSTIC.md":
            records = []
            for decision in parsers.parse_diagnostic(text):
                records.append({"adr_id": decision["id"], "title": decision["title"], "status": decision["status"],
                                "context": "cross-reference integrity re-run after the .dmk data-source migration",
                                "decision": decision["body"][:400], "consequences": decision["body"][:400],
                                "supersedes": None, "superseded_by": None, "owner": "repository maintainer (role)",
                                "source_line": decision["line"], "kind": decision["kind"]})
            return records, []
        parsed = parsers.parse_madr(text)
        if not parsed["adr_id"]:
            raise ValueError("ADR has no identifier")
        sections = parsed["sections"]
        record = {"adr_id": parsed["adr_id"], "title": parsed["title"], "status": (parsed["status"] or "unspecified").lower(),
                  "context": " ".join(sections.get("context", {}).get("text", [])),
                  "decision": " ".join(sections.get("decision", {}).get("text", [])),
                  "consequences": " ".join(sections.get("consequences", {}).get("text", [])),
                  "supersedes": parsed["supersedes"], "superseded_by": parsed["superseded_by"],
                  "owner": parsed["owner"] or parsed["deciders"] or "unspecified",
                  "source_line": parsed["title_line"], "kind": "adr", "date": parsed["date"]}
        return [record], list(parsed["ambiguities"])


class APICatalogConnector(TypedConnector):
    """DATA-04: service/operation identity, versions, schemas, auth, owner, lifecycle from `.jasp` contracts."""

    source_system = "api_catalog"
    data_class = "api_operation"
    suffixes = (".jasp",)

    def extract(self, rel: str, text: str, locator: str) -> tuple[list[dict[str, Any]], list[str]]:
        parsed = parsers.parse_jasp(text)
        records = []
        for service in parsed["services"]:
            for endpoint in service["endpoints"]:
                records.append({
                    "operation_id": f"{parsed['module']}.{service['name']}.{endpoint['name']}",
                    "service": service["name"], "operation": endpoint["name"], "module": parsed["module"],
                    "version": parsed["language_version"], "params": endpoint["params"], "returns": endpoint["returns"],
                    "schemas": [m["name"] for m in service["messages"]],
                    "auth_requirement": endpoint["auth_capability"] or "unspecified",
                    "deadline_seconds": endpoint["deadline_seconds"], "retry_max": endpoint["retry_max"],
                    "idempotency_key": endpoint["idempotency_key"], "owner": _suite_of(rel),
                    "lifecycle_state": "active", "network_policy": parsed["network_policy"],
                    "protocol_states": service["states"], "source_line": endpoint["line"]})
        return records, list(parsed["ambiguities"])


class InfraCatalogConnector(TypedConnector):
    """DATA-05: service identity, environments, quotas, capabilities, ownership, constraints from `.jaops`."""

    source_system = "infra_catalog"
    data_class = "service"
    suffixes = (".jaops",)

    def extract(self, rel: str, text: str, locator: str) -> tuple[list[dict[str, Any]], list[str]]:
        parsed = parsers.parse_jaops(text)
        records = []
        checks = {h["service"]: h["interval_seconds"] for h in parsed["health_checks"]}
        for service in parsed["services"]:
            records.append({
                "service_id": f"{parsed['workspace']}.{service['name']}", "workspace": parsed["workspace"],
                "service": service["name"], "replicas": service["replicas"],
                "environments": [parsed["environment"] or "unspecified"], "region": "unspecified",
                "quotas": {"cpu": parsed["cpu"], "memory_gb": parsed["memory_gb"]},
                "capabilities": {"health_check_interval_seconds": checks.get(service["name"]),
                                 "upgrade": parsed["upgrade"], "rollback_on": parsed["rollback_on"]},
                "ownership": _suite_of(rel),
                "constraints": {"network": parsed["network"], "target": parsed["target"],
                                "secret_references": [s["reference"] for s in parsed["secrets"]]},
                "source_line": service["line"]})
        return records, list(parsed["ambiguities"])


class DiagramConnector(TypedConnector):
    """DATA-06: supported diagram inputs (inventory projection, Mermaid subset) with the original retained."""

    source_system = "diagrams"
    data_class = "diagram"
    suffixes = ()
    fixture_glob = "diagrams/*.mmd"
    root_files = ("ALL_SubSuite_Language_Assignment.md",)

    def extract(self, rel: str, text: str, locator: str) -> tuple[list[dict[str, Any]], list[str]]:
        if rel == "ALL_SubSuite_Language_Assignment.md":
            # The inventory is the first part of the file; the embedded master document that follows
            # ("## 2. Purpose and Boundary" onward) is not part of the component projection.
            inventory_text = text.split("\n## 2.", 1)[0]
            components = parsers.parse_inventory(inventory_text)
            ambiguities = [f"suite {c['number']:02d} has no language" for c in components if not c["language"]]
            suite_dirs = sorted(p.name for p in self.corpus_root.iterdir()
                                if p.is_dir() and p.name not in (OVERLAY_DIR, ".git"))
            named = {c["name"].strip().lower() for c in components}
            for folder in suite_dirs:
                if folder.strip().lower() not in named:
                    ambiguities.append(f"suite folder {folder!r} has no inventory entry")
            numbers = {c["number"] for c in components}
            for missing in sorted(set(range(1, len(suite_dirs) + 1)) - numbers):
                ambiguities.append(f"inventory has no entry numbered {missing:02d}")
            record = {"diagram_id": "DIAG-suite-inventory", "notation": "suite-inventory/markdown",
                      "components": [{"id": f"S{c['number']:02d}", "label": c["name"], "kind": "suite",
                                      "language": c["language"], "line": c["line"]} for c in components],
                      "edges": [], "ambiguities": ambiguities, "source_line": 1, "original_retained": True}
            return [record], list(ambiguities)
        parsed = parsers.parse_mermaid(text)
        record = {"diagram_id": "DIAG-" + Path(rel).stem, "notation": "mermaid-flowchart/subset",
                  "components": [{"id": n["id"], "label": n["label"], "kind": "component", "line": n["line"]}
                                 for n in parsed["nodes"]],
                  "edges": [{"source": e["source"], "target": e["target"], "label": e["label"], "line": e["line"]}
                            for e in parsed["edges"]],
                  "ambiguities": parsed["ambiguities"], "source_line": 1, "original_retained": True}
        return [record], list(parsed["ambiguities"])


class SecurityConstraintConnector(TypedConnector):
    """DATA-07: typed, scoped security controls from `.jasec` policies."""

    source_system = "security_constraints"
    data_class = "security_constraint"
    suffixes = (".jasec",)

    def extract(self, rel: str, text: str, locator: str) -> tuple[list[dict[str, Any]], list[str]]:
        parsed = parsers.parse_jasec(text)
        records = []
        classifications = {r["name"]: r["classification"] for r in parsed["resources"]}
        data_class = next(iter(classifications.values()), "unspecified")
        for policy in parsed["policies"]:
            for index, rule in enumerate(policy["rules"], start=1):
                records.append({
                    "constraint_id": f"{parsed['module']}.{policy['name']}.{index:02d}",
                    "policy": policy["name"], "verb": rule["verb"], "rule": rule["rule"],
                    "trust_boundary": parsed["module"], "data_class": data_class,
                    "enforcement_status": "declared", "source_policy": rel, "network_policy": parsed["network_policy"],
                    "principal": parsed["principal"], "source_line": rule["line"], "waivable_by_model": False})
        return records, list(parsed["ambiguities"])

    def classify(self, rel: str, text: str) -> str:
        return "confidential" if "classification restricted" in text else "internal"


class CostPerformanceConnector(TypedConnector):
    """DATA-08: cost/performance constraints with metric, unit, target, scope, environment, freshness."""

    source_system = "cost_performance"
    data_class = "cost_perf_constraint"
    suffixes = (".jaops", ".jasp")

    def extract(self, rel: str, text: str, locator: str) -> tuple[list[dict[str, Any]], list[str]]:
        records = []
        ambiguities: list[str] = []
        if rel.endswith(".jaops"):
            parsed = parsers.parse_jaops(text)
            ambiguities += parsed["ambiguities"]
            if parsed["cpu"] is not None:
                records.append({"constraint_id": _record_id("costperf", rel, parsed.get("lines", {}).get("resource"), "cpu"),
                                "metric": "cpu", "unit": "vcpu", "target": parsed["cpu"], "range": None,
                                "workload_scope": parsed["workspace"], "environment": parsed["environment"],
                                "confidence": "stated", "source_line": parsed.get("lines", {}).get("resource")})
                records.append({"constraint_id": _record_id("costperf", rel, parsed.get("lines", {}).get("resource"), "mem"),
                                "metric": "memory", "unit": "GB", "target": parsed["memory_gb"], "range": None,
                                "workload_scope": parsed["workspace"], "environment": parsed["environment"],
                                "confidence": "stated", "source_line": parsed.get("lines", {}).get("resource")})
        else:
            parsed = parsers.parse_jasp(text)
            ambiguities += parsed["ambiguities"]
            for service in parsed["services"]:
                for endpoint in service["endpoints"]:
                    if endpoint["deadline_seconds"] is not None:
                        records.append({"constraint_id": _record_id("costperf", rel, endpoint["line"], "deadline"),
                                        "metric": "latency_deadline", "unit": "s", "target": endpoint["deadline_seconds"],
                                        "range": None, "workload_scope": f"{service['name']}.{endpoint['name']}",
                                        "environment": "unspecified", "confidence": "stated",
                                        "source_line": endpoint["line"]})
        return records, ambiguities


class DeploymentStandardConnector(TypedConnector):
    """DATA-09: deployment standards as versioned constraints from `.jaops` and suite manifests."""

    source_system = "deployment_standards"
    data_class = "deployment_standard"
    suffixes = (".jaops", ".json")

    def extract(self, rel: str, text: str, locator: str) -> tuple[list[dict[str, Any]], list[str]]:
        records = []
        if rel.endswith(".json"):
            if not rel.endswith("MANIFEST.json"):
                return [], []
            parsed = parsers.parse_manifest(text)
            for check in parsed["checks"]:
                records.append({"standard_id": f"manifest:{_suite_of(rel)}:{check}", "family": "release_process",
                                "rule": f"every script passes check {check}", "value": True,
                                "scope": parsed["repository"], "version": parsed["version"],
                                "failed_scripts": [s for s, name in parsed["failed_checks"] if name == check],
                                "source_line": 1})
            return records, []
        parsed = parsers.parse_jaops(text)
        lines = parsed.get("lines", {})
        for key, family in (("target", "runtime_platform"), ("environment", "environment"), ("upgrade", "release_process"),
                            ("rollback_on", "release_process"), ("package", "release_process"),
                            ("compiler_profile", "runtime_platform"), ("dependencies", "policy"), ("network", "networking")):
            if parsed.get(key) is not None:
                records.append({"standard_id": f"{parsed['module']}.{key}", "family": family, "rule": key,
                                "value": parsed[key], "scope": parsed["workspace"], "version": parsed["language_version"],
                                "failed_scripts": [], "source_line": lines.get(key, 1)})
        return records, list(parsed["ambiguities"])


def _slug(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_").upper()[:40]


REGISTRY: dict[str, type[TypedConnector]] = {c.data_class: c for c in (
    RequirementsConnector, NFRConnector, ADRConnector, APICatalogConnector, InfraCatalogConnector,
    DiagramConnector, SecurityConstraintConnector, CostPerformanceConnector, DeploymentStandardConnector)}


def connector_for_class(data_class: str, **kw: Any) -> TypedConnector:
    try:
        return REGISTRY[data_class](**kw)
    except KeyError:
        raise ConnectorError("failed", f"no connector for data class {data_class!r}") from None
