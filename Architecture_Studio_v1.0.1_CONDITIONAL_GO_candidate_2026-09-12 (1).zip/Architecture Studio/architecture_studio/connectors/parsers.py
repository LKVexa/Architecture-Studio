"""Deterministic parsers for the corpus dialects and fixture formats (DATA-01..09).

Each parser turns bytes into typed records and *keeps the line span* of what it
read, so every normalized record can point back to an exact location in a
pinned file (XPROV-01). Parsers never guess: an unparseable construct is
reported as an ambiguity, not silently dropped (DATA-06 "surface any parse
ambiguity").

Build provenance: BUILD_NEW. The yard held no ADR/MADR parser and no JA21
dialect parser outside the owner's own suites.
"""
from __future__ import annotations

import json
import re
from typing import Any

__all__ = ["parse_readme", "parse_jasp", "parse_jaops", "parse_jasec", "parse_manifest", "parse_inventory",
           "parse_diagnostic", "parse_madr", "parse_mermaid", "parse_nfr_lines"]

_HEADER = re.compile(r"^ja source (?P<version>[0-9.]+)\s*$", re.M)
_MODULE = re.compile(r"^module (?P<name>[A-Za-z0-9_.]+)\s*$", re.M)
_POLICY_LINE = re.compile(r"^policy (?P<name>[a-z_]+)\s*$", re.M)
_SERVICE_BLOCK = re.compile(r"^service (?P<name>[A-Za-z0-9_]+) \{", re.M)
_ENDPOINT = re.compile(r"^\s*endpoint (?P<name>[A-Za-z0-9_]+)\((?P<params>[^)]*)\)\s*->\s*(?P<ret>[A-Za-z0-9_<>]+)")
_AUTH = re.compile(r"^\s*auth capability (?P<cap>[A-Za-z0-9_.:]+)")
_DEADLINE = re.compile(r"^\s*deadline (?P<n>\d+)(?P<unit>ms|s|m)")
_RETRY = re.compile(r"^\s*retry max (?P<n>\d+)")
_IDEMP = re.compile(r"^\s*idempotency (?P<key>[A-Za-z0-9_.]+)")
_MESSAGE = re.compile(r"^\s*message (?P<name>[A-Za-z0-9_]+) \{")
_STATE = re.compile(r"^\s*state (?P<name>[A-Za-z0-9_]+)")
_TRANSITION = re.compile(r"^\s*transition (?P<name>[A-Za-z0-9_]+): (?P<from>[A-Za-z0-9_]+) -> (?P<to>[A-Za-z0-9_]+)")
_WORKSPACE = re.compile(r"^workspace (?P<name>[A-Za-z0-9_]+) \{", re.M)
_TARGET = re.compile(r"^\s*target (?P<target>[a-z0-9-]+)")
_ENV = re.compile(r"^\s*environment (?P<env>[a-z_]+)")
_RESOURCE = re.compile(r"^\s*resource cpu (?P<cpu>\d+) memory (?P<mem>\d+)(?P<unit>GB|MB)")
_NETWORK = re.compile(r"^\s*network (?P<state>[a-z_]+)")
_SECRET = re.compile(r"^\s*secret (?P<name>[A-Za-z0-9_]+) reference \"(?P<ref>[^\"]+)\"")
_SVC = re.compile(r"^\s*service (?P<name>[A-Za-z0-9_]+) replicas (?P<n>\d+)")
_HEALTH = re.compile(r"^\s*health_check (?P<name>[A-Za-z0-9_]+) every (?P<n>\d+)(?P<unit>ms|s|m)")
_UPGRADE = re.compile(r"^\s*upgrade (?P<mode>[a-z_]+)")
_ROLLBACK = re.compile(r"^\s*rollback on (?P<cond>[a-z_]+)")
_PACKAGE = re.compile(r"^\s*package (?P<fmt>[a-z0-9]+)")
_COMPILER = re.compile(r"^\s*compiler profile (?P<profile>[a-z]+)")
_DEPS = re.compile(r"^\s*dependencies (?P<state>[a-z]+)")
_PRINCIPAL = re.compile(r"^principal (?P<name>[A-Za-z0-9_]+)", re.M)
_ROLE = re.compile(r"^role (?P<name>[A-Za-z0-9_]+) \{", re.M)
_GRANT = re.compile(r"^\s*grant (?P<cap>[A-Za-z0-9_.:]+)")
_RESOURCE_CLASS = re.compile(r"^resource (?P<name>[A-Za-z0-9_]+) classification (?P<cls>[a-z]+)", re.M)
_POLICY_BLOCK = re.compile(r"^policy (?P<name>[A-Za-z0-9_]+) \{", re.M)
_RULE = re.compile(r"^\s*(?P<verb>deny|allow|require|audit|redact|resolve) (?P<rest>.+?)\s*$")
_ASSERT = re.compile(r"^assert (?P<expr>.+?)\s*$", re.M)
_INVENTORY_HEADER = re.compile(r"^### (?P<num>\d{2})\. (?P<name>.+?)\s*$")
_LANG = re.compile(r"^JA21 Language: (?P<lang>.+?)\s*$")


def _unit_seconds(n: str, unit: str) -> float:
    value = float(n)
    return value / 1000.0 if unit == "ms" else value * 60.0 if unit == "m" else value


def _header(text: str) -> dict[str, Any]:
    header = _HEADER.search(text)
    module = _MODULE.search(text)
    policy = _POLICY_LINE.search(text)
    return {"language_version": header.group("version") if header else None,
            "module": module.group("name") if module else None,
            "network_policy": policy.group("name") if policy else None}


# --------------------------------------------------------------------------- #
def parse_readme(text: str) -> dict[str, Any]:
    """Suite README → title, purpose statements, scripts, assignments, design bullets, with line numbers."""
    lines = text.splitlines()
    title = next((l[2:].strip() for l in lines if l.startswith("# ")), "")
    section = ""
    statements: list[dict[str, Any]] = []
    scripts: list[dict[str, Any]] = []
    profile: dict[str, str] = {}
    for number, line in enumerate(lines, start=1):
        if line.startswith("## "):
            section = line[3:].strip()
            continue
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        m = re.match(r"^\d+\.\s+`(?P<path>[^`]+)`", stripped)
        if m and section == "Scripts":
            scripts.append({"path": m.group("path"), "line": number})
            continue
        m = re.match(r"^- (?P<key>[A-Za-z][A-Za-z0-9 -]+): `(?P<val>[^`]+)`", stripped)
        if m and section == "Corpus-grounded profile":
            profile[m.group("key").strip()] = m.group("val")
            continue
        if stripped.startswith("- "):
            body = stripped[2:].strip()
            statements.append({"section": section, "text": body, "line": number,
                               "kind": "assignment" if section == "Suite assignments" else
                               "design_rule" if section == "Corpus-native design" else "statement"})
        elif section and not stripped.startswith("|") and len(stripped) > 20 and section not in ("Scripts",):
            statements.append({"section": section, "text": stripped, "line": number, "kind": "prose"})
    return {"title": title, "statements": statements, "scripts": scripts, "profile": profile}


def parse_jasp(text: str) -> dict[str, Any]:
    """`.jasp` service contract → services, endpoints (auth, deadline, retry, idempotency), messages, protocol."""
    doc = _header(text)
    services: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    endpoint: dict[str, Any] | None = None
    for number, line in enumerate(text.splitlines(), start=1):
        m = _SERVICE_BLOCK.match(line)
        if m:
            current = {"name": m.group("name"), "line": number, "endpoints": [], "messages": [], "states": [],
                       "transitions": []}
            services.append(current)
            endpoint = None
            continue
        if current is None:
            continue
        m = _MESSAGE.match(line)
        if m:
            current["messages"].append({"name": m.group("name"), "line": number})
            continue
        m = _ENDPOINT.match(line)
        if m:
            endpoint = {"name": m.group("name"), "params": m.group("params").strip(), "returns": m.group("ret"),
                        "line": number, "auth_capability": None, "deadline_seconds": None, "retry_max": None,
                        "idempotency_key": None}
            current["endpoints"].append(endpoint)
            continue
        if endpoint is not None:
            m = _AUTH.match(line)
            if m:
                endpoint["auth_capability"] = m.group("cap")
                continue
            m = _DEADLINE.match(line)
            if m:
                endpoint["deadline_seconds"] = _unit_seconds(m.group("n"), m.group("unit"))
                continue
            m = _RETRY.match(line)
            if m:
                endpoint["retry_max"] = int(m.group("n"))
                continue
            m = _IDEMP.match(line)
            if m:
                endpoint["idempotency_key"] = m.group("key")
                continue
        m = _STATE.match(line)
        if m and "protocol" not in line:
            current["states"].append(m.group("name"))
            continue
        m = _TRANSITION.match(line)
        if m:
            current["transitions"].append({"name": m.group("name"), "from": m.group("from"), "to": m.group("to")})
    doc["services"] = services
    doc["asserts"] = [a.group("expr") for a in _ASSERT.finditer(text)]
    doc["ambiguities"] = [] if services else ["no service block found"]
    return doc


def parse_jaops(text: str) -> dict[str, Any]:
    """`.jaops` workspace → deployment target, environment, resources, network, secrets, services, upgrade/rollback."""
    doc = _header(text)
    ws = _WORKSPACE.search(text)
    doc["workspace"] = ws.group("name") if ws else None
    doc.update({"target": None, "environment": None, "cpu": None, "memory_gb": None, "network": None,
                "secrets": [], "services": [], "health_checks": [], "upgrade": None, "rollback_on": None,
                "package": None, "compiler_profile": None, "dependencies": None})
    for number, line in enumerate(text.splitlines(), start=1):
        for pattern, key in ((_TARGET, "target"), (_ENV, "environment"), (_NETWORK, "network"),
                             (_UPGRADE, "upgrade"), (_PACKAGE, "package"), (_COMPILER, "compiler_profile"),
                             (_DEPS, "dependencies")):
            m = pattern.match(line)
            if m:
                doc[key] = m.group(1)
                doc.setdefault("lines", {})[key] = number
        m = _ROLLBACK.match(line)
        if m:
            doc["rollback_on"] = m.group("cond")
            doc.setdefault("lines", {})["rollback_on"] = number
        m = _RESOURCE.match(line)
        if m:
            mem = int(m.group("mem"))
            doc["cpu"] = int(m.group("cpu"))
            doc["memory_gb"] = mem if m.group("unit") == "GB" else round(mem / 1024, 3)
            doc.setdefault("lines", {})["resource"] = number
        m = _SECRET.match(line)
        if m:
            doc["secrets"].append({"name": m.group("name"), "reference": m.group("ref"), "line": number})
        m = _SVC.match(line)
        if m:
            doc["services"].append({"name": m.group("name"), "replicas": int(m.group("n")), "line": number})
        m = _HEALTH.match(line)
        if m:
            doc["health_checks"].append({"service": m.group("name"),
                                         "interval_seconds": _unit_seconds(m.group("n"), m.group("unit")),
                                         "line": number})
    doc["asserts"] = [a.group("expr") for a in _ASSERT.finditer(text)]
    doc["ambiguities"] = [] if ws else ["no workspace block found"]
    return doc


def parse_jasec(text: str) -> dict[str, Any]:
    """`.jasec` policy → principal, roles/grants, resource classifications, policy rules, asserts."""
    doc = _header(text)
    principal = _PRINCIPAL.search(text)
    doc["principal"] = principal.group("name") if principal else None
    doc["roles"] = []
    doc["resources"] = [{"name": m.group("name"), "classification": m.group("cls")} for m in _RESOURCE_CLASS.finditer(text)]
    doc["policies"] = []
    current_role: dict[str, Any] | None = None
    current_policy: dict[str, Any] | None = None
    for number, line in enumerate(text.splitlines(), start=1):
        m = _ROLE.match(line)
        if m:
            current_role = {"name": m.group("name"), "grants": [], "line": number}
            doc["roles"].append(current_role)
            current_policy = None
            continue
        m = _POLICY_BLOCK.match(line)
        if m:
            current_policy = {"name": m.group("name"), "rules": [], "line": number}
            doc["policies"].append(current_policy)
            current_role = None
            continue
        if line.strip() == "}":
            current_role = None
            current_policy = None
            continue
        if current_role is not None:
            m = _GRANT.match(line)
            if m:
                current_role["grants"].append(m.group("cap"))
        if current_policy is not None:
            m = _RULE.match(line)
            if m:
                current_policy["rules"].append({"verb": m.group("verb"), "rule": m.group("rest"), "line": number})
    doc["asserts"] = [a.group("expr") for a in _ASSERT.finditer(text)]
    doc["ambiguities"] = [] if doc["policies"] else ["no policy block found"]
    return doc


def parse_manifest(text: str) -> dict[str, Any]:
    data = json.loads(text)
    raw_scripts = data.get("scripts", {})
    if isinstance(raw_scripts, list):
        scripts = {str(entry.get("name") or entry.get("file") or entry.get("path") or i): entry
                   for i, entry in enumerate(raw_scripts) if isinstance(entry, dict)}
    elif isinstance(raw_scripts, dict):
        scripts = {k: v for k, v in raw_scripts.items() if isinstance(v, dict)}
    else:
        scripts = {}
    checks = sorted({name for entry in scripts.values() for name in (entry.get("checks") or {})})
    failed = [(script, name) for script, entry in scripts.items()
              for name, ok in (entry.get("checks") or {}).items() if ok is not True]
    return {"package": data.get("package"), "repository": data.get("repository"), "language_id": data.get("language_id"),
            "version": data.get("version"), "checks": checks, "script_count": len(scripts), "failed_checks": failed,
            "source_corpus_sha256": (data.get("source_corpus") or {}).get("sha256")}


def parse_inventory(text: str) -> list[dict[str, Any]]:
    """ALL_SubSuite_Language_Assignment.md → 66 components with language and capabilities (DATA-06 projection)."""
    components: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    for number, line in enumerate(text.splitlines(), start=1):
        m = _INVENTORY_HEADER.match(line.strip())
        if m:
            current = {"number": int(m.group("num")), "name": m.group("name").strip(), "language": None,
                       "capabilities": [], "line": number}
            components.append(current)
            continue
        if current is None:
            continue
        m = _LANG.match(line.strip())
        if m:
            current["language"] = m.group("lang")
            continue
        stripped = line.strip().rstrip(".")
        if stripped and not stripped.startswith("#"):
            current["capabilities"].append(stripped)
    return components


def parse_diagnostic(text: str) -> list[dict[str, Any]]:
    """CROSS_REFERENCE_DIAGNOSTIC.md → recorded decisions and observations (ADR-like, DATA-03)."""
    decisions: list[dict[str, Any]] = []
    lines = text.splitlines()
    for number, line in enumerate(lines, start=1):
        m = re.match(r"^\*\*(?P<num>\d+)\. (?P<title>[^*]+?)\*\*\s*(?P<body>.*)$", line.strip())
        if m:
            status = "resolved" if "RESOLVED" in m.group("title").upper() or "complete" in m.group("body").lower() else "accepted"
            decisions.append({"id": f"XREF-{int(m.group('num')):02d}", "title": m.group("title").strip().rstrip("."),
                              "status": status, "body": m.group("body").strip(), "line": number, "kind": "check"})
            continue
        m = re.match(r"^\*\*(?P<letter>[A-C])\. (?P<title>[^*]+?)\*\*\s*(?P<body>.*)$", line.strip())
        if m:
            decisions.append({"id": f"XREF-OBS-{m.group('letter')}", "title": m.group("title").strip().rstrip("."),
                              "status": "observation", "body": m.group("body").strip(), "line": number,
                              "kind": "observation"})
    return decisions


_MADR_FIELDS = ("status", "date", "deciders", "owner", "supersedes", "superseded_by")


def parse_madr(text: str) -> dict[str, Any]:
    """MADR-shaped ADR → id, title, status, context, decision, consequences, supersession, owner, with lines."""
    lines = text.splitlines()
    title_line = next(((i, l) for i, l in enumerate(lines, start=1) if l.startswith("# ")), (None, ""))
    m = re.match(r"^# (?P<id>ADR-\d{3,4})[:\s—-]+(?P<title>.+)$", title_line[1].strip()) if title_line[1] else None
    doc: dict[str, Any] = {"adr_id": m.group("id") if m else None, "title": m.group("title").strip() if m else None,
                           "title_line": title_line[0], "sections": {}, "ambiguities": []}
    for field_name in _MADR_FIELDS:
        doc[field_name] = None
    section = None
    for number, line in enumerate(lines, start=1):
        stripped = line.strip()
        fm = re.match(r"^[-*]?\s*\*?\*?(?P<key>[A-Za-z_ -]+?)\*?\*?:\s*(?P<val>.+)$", stripped)
        if fm and fm.group("key").strip().lower().replace(" ", "_").replace("-", "_") in _MADR_FIELDS and section is None:
            doc[fm.group("key").strip().lower().replace(" ", "_").replace("-", "_")] = fm.group("val").strip()
            continue
        if stripped.startswith("## "):
            section = stripped[3:].strip().lower()
            doc["sections"][section] = {"line": number, "text": []}
            continue
        if section and stripped:
            doc["sections"][section]["text"].append(stripped)
    for required in ("context", "decision", "consequences"):
        if required not in doc["sections"]:
            doc["ambiguities"].append(f"missing section: {required}")
    if not doc["adr_id"]:
        doc["ambiguities"].append("no ADR identifier in the title")
    if not doc["status"]:
        doc["ambiguities"].append("no status field")
    return doc


# Node shapes the renderer emits: [box], (round), [[queue]], [(store)], {{external}}, {policy point}.
_MERMAID_NODE = re.compile(
    r"^\s*(?P<id>[A-Za-z0-9_]+)\s*(?:"
    r"\[\[(?P<qlabel>[^\]]+)\]\]|"
    r"\[\((?P<slabel>[^)]+)\)\]|"
    r"\{\{(?P<xlabel>[^}]+)\}\}|"
    r"\{(?P<plabel>[^}]+)\}|"
    r"\[(?P<label>[^\]]+)\]|"
    r"\((?P<rlabel>[^)]+)\)"
    r")\s*$")
_MERMAID_EDGE = re.compile(r"^\s*(?P<src>[A-Za-z0-9_]+)\s*-->\s*(?:\|(?P<label>[^|]+)\|\s*)?(?P<dst>[A-Za-z0-9_]+)\s*$")


def parse_mermaid(text: str) -> dict[str, Any]:
    """Mermaid flowchart subset → components/edges; anything else is reported as an ambiguity."""
    nodes: dict[str, dict[str, Any]] = {}
    edges: list[dict[str, Any]] = []
    ambiguities: list[str] = []
    for number, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if not stripped or stripped.startswith("%%") or stripped.startswith(("flowchart", "graph")):
            continue
        m = _MERMAID_EDGE.match(stripped)
        if m:
            edges.append({"source": m.group("src"), "target": m.group("dst"), "label": (m.group("label") or "").strip(),
                          "line": number})
            for ident in (m.group("src"), m.group("dst")):
                nodes.setdefault(ident, {"id": ident, "label": ident, "line": number})
            continue
        m = _MERMAID_NODE.match(stripped)
        if m:
            label = next((m.group(g) for g in ("qlabel", "slabel", "xlabel", "plabel", "label", "rlabel") if m.group(g)), "")
            nodes[m.group("id")] = {"id": m.group("id"), "label": label.strip(), "line": number}
            continue
        ambiguities.append(f"line {number}: unsupported construct {stripped[:60]!r}")
    return {"nodes": list(nodes.values()), "edges": edges, "ambiguities": ambiguities}


def parse_nfr_lines(jasp: dict[str, Any], jaops: dict[str, Any]) -> list[dict[str, Any]]:
    """Quantitative NFRs stated in the corpus: deadlines, retries, resources, health intervals."""
    nfrs: list[dict[str, Any]] = []
    for service in jasp.get("services", []):
        for endpoint in service["endpoints"]:
            if endpoint["deadline_seconds"] is not None:
                nfrs.append({"category": "latency", "target": endpoint["deadline_seconds"], "unit": "s",
                             "scope": f"{service['name']}.{endpoint['name']}", "line": endpoint["line"]})
            if endpoint["retry_max"] is not None:
                nfrs.append({"category": "resilience", "target": endpoint["retry_max"], "unit": "retries",
                             "scope": f"{service['name']}.{endpoint['name']}", "line": endpoint["line"]})
    if jaops.get("cpu") is not None:
        nfrs.append({"category": "capacity", "target": jaops["cpu"], "unit": "vcpu", "scope": jaops.get("workspace"),
                     "line": jaops.get("lines", {}).get("resource")})
    if jaops.get("memory_gb") is not None:
        nfrs.append({"category": "capacity", "target": jaops["memory_gb"], "unit": "GB", "scope": jaops.get("workspace"),
                     "line": jaops.get("lines", {}).get("resource")})
    for hc in jaops.get("health_checks", []):
        nfrs.append({"category": "availability", "target": hc["interval_seconds"], "unit": "s",
                     "scope": hc["service"], "line": hc["line"]})
    return nfrs
