"""Normalize, validate, classify and index the evidence (WF-04, IMPL-02, XSEC-01, XPROV-01/02).

The pipeline is strict and ordered: normalize → schema-validate → classify →
attach identity/revision/freshness → index. A record that fails any step is
*quarantined* with a typed error and never indexed; nothing downstream can
retrieve it. Indexed records trace back to the raw pinned artifact through the
evidence reference they carry.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping

from ..canonical import digest_of, fmt_ts
from ..provenance import EvidenceRef
from ..schemas import SchemaError, validate
from .base import ConnectorResult, RawArtifact

__all__ = ["Normalizer", "NormalizedIndex", "QuarantineEntry", "NORMALIZE_SCHEMA_VERSION"]

NORMALIZE_SCHEMA_VERSION = "1.0.0"

_SECRET_MARKERS = ("BEGIN PRIVATE KEY", "AKIA", "ghp_", "xox")


@dataclass(frozen=True)
class QuarantineEntry:
    artifact_id: str
    path: str
    reason_code: str
    reason: str

    def as_document(self) -> dict[str, Any]:
        return {"artifact_id": self.artifact_id, "path": self.path, "reason_code": self.reason_code, "reason": self.reason}


@dataclass
class NormalizedIndex:
    """Indexed, validated records keyed by record id, with per-class and per-artifact views."""

    records: dict[str, dict[str, Any]] = field(default_factory=dict)
    quarantine: list[QuarantineEntry] = field(default_factory=list)
    evidence: dict[str, EvidenceRef] = field(default_factory=dict)

    def by_class(self, data_class: str) -> list[dict[str, Any]]:
        return [r for r in self.records.values() if r["data_class"] == data_class]

    def by_artifact(self, artifact_id: str) -> list[dict[str, Any]]:
        return [r for r in self.records.values() if r["artifact_id"] == artifact_id]

    def evidence_for(self, record_id: str) -> EvidenceRef:
        return self.evidence[self.records[record_id]["provenance_ref_id"]]

    def summary(self) -> dict[str, Any]:
        classes: dict[str, int] = {}
        for record in self.records.values():
            classes[record["data_class"]] = classes.get(record["data_class"], 0) + 1
        return {"indexed": len(self.records), "quarantined": len(self.quarantine), "by_class": dict(sorted(classes.items())),
                "index_digest": digest_of(sorted(self.records))}

    def mark_stale(self, artifact_ids: Iterable[str]) -> int:
        targets = set(artifact_ids)
        changed = 0
        for record in self.records.values():
            if record["artifact_id"] in targets and record["freshness"] != "STALE":
                record["freshness"] = "STALE"
                ref = self.evidence[record["provenance_ref_id"]]
                self.evidence[record["provenance_ref_id"]] = ref.stale()
                changed += 1
        return changed


class Normalizer:
    def __init__(self, *, ledger: Any = None, classifier: Any = None) -> None:
        self.ledger = ledger
        self.classifier = classifier

    def ingest(self, results: Iterable[ConnectorResult], *, index: NormalizedIndex | None = None,
               allowed_classes: Iterable[str] | None = None) -> NormalizedIndex:
        index = index or NormalizedIndex()
        allowed = set(allowed_classes) if allowed_classes is not None else None
        for result in results:
            for artifact in result.artifacts:
                if allowed is not None and artifact.data_class not in allowed:
                    self._quarantine(index, artifact, "CLASS_NOT_ALLOWED",
                                     f"data class {artifact.data_class} is outside the scope's allowed classes")
                    continue
                self._ingest_artifact(index, artifact)
        return index

    def _ingest_artifact(self, index: NormalizedIndex, artifact: RawArtifact) -> None:
        records = artifact.metadata.get("records") if artifact.metadata else None
        if not isinstance(records, list):
            self._quarantine(index, artifact, "NO_TYPED_RECORDS", "artifact carries no typed records")
            return
        classification = self._classify(artifact)
        if classification == "secret":
            self._quarantine(index, artifact, "SECRET_CONTENT", "artifact contains secret material; not indexed")
            return
        for position, payload in enumerate(records):
            if not isinstance(payload, dict):
                self._quarantine(index, artifact, "MALFORMED_RECORD", f"record {position} is not an object")
                continue
            line = payload.get("source_line")
            ref = EvidenceRef(artifact_id=artifact.artifact_id, source_system=artifact.source_system,
                              revision=artifact.revision, source_hash=artifact.source_hash,
                              observed_at=artifact.observed_at, derivation="source", evidence_status="current",
                              location=artifact.path, span=f"L{line}" if line else None,
                              transformation_chain=("connector:" + artifact.source_system, "normalize:" + NORMALIZE_SCHEMA_VERSION))
            record_id = str(payload.get("requirement_id") or payload.get("nfr_id") or payload.get("adr_id")
                            or payload.get("operation_id") or payload.get("service_id") or payload.get("diagram_id")
                            or payload.get("constraint_id") or payload.get("standard_id") or f"{artifact.path}#{position}")
            document = {
                "schema_id": "as.connector_record/1", "artifact_id": artifact.artifact_id,
                "source_system": artifact.source_system, "data_class": artifact.data_class, "tenant": artifact.tenant,
                "project": artifact.project, "path": artifact.path, "revision": artifact.revision,
                "source_hash": artifact.source_hash, "classification": classification, "freshness": "CURRENT",
                "observed_at": artifact.observed_at, "record_id": record_id, "payload": payload,
                "provenance": ref.as_document(), "schema_version": NORMALIZE_SCHEMA_VERSION,
            }
            try:
                validate("as.connector_record/1", document)
            except SchemaError as exc:
                self._quarantine(index, artifact, "SCHEMA_INVALID", str(exc))
                continue
            if record_id in index.records and index.records[record_id]["source_hash"] != artifact.source_hash:
                self._quarantine(index, artifact, "DUPLICATE_ID",
                                 f"record id {record_id} already indexed from a different source hash")
                continue
            document["provenance_ref_id"] = ref.ref_id
            index.evidence[ref.ref_id] = ref
            index.records[record_id] = document
        if self.ledger is not None:
            self.ledger.append("evidence.normalized", actor="normalizer", actor_kind="service", outcome="recorded",
                               subject=artifact.artifact_id,
                               detail={"path": artifact.path, "records": len(records), "classification": classification})

    def _classify(self, artifact: RawArtifact) -> str:
        if self.classifier is not None:
            return self.classifier(artifact)
        text = artifact.content.decode("utf-8", "replace") if artifact.content else ""
        if any(marker in text for marker in _SECRET_MARKERS):
            return "secret"
        return artifact.classification or "internal"

    def _quarantine(self, index: NormalizedIndex, artifact: RawArtifact, code: str, reason: str) -> None:
        index.quarantine.append(QuarantineEntry(artifact.artifact_id, artifact.path, code, reason))
        if self.ledger is not None:
            self.ledger.append("evidence.quarantined", actor="normalizer", actor_kind="service", outcome="denied",
                               subject=artifact.artifact_id, detail={"path": artifact.path, "code": code, "reason": reason})
