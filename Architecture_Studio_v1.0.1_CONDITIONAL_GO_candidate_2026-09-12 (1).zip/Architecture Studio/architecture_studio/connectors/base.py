"""Connector contract: capabilities, failure semantics, pinning (ARCH-01, AUDIT-ADD-14, IMPL-05, WF-02, WF-03).

Every connector advertises its capabilities and enforces the granted scope at
time of use: a read that is not authorized by the scope contract is a typed
``denied`` result *and* a ledger denial, never an exception swallowed in a
retry loop. Failure states are typed (``unavailable``, ``denied``, ``partial``,
``rate_limited``, ``stale``, ``malformed``) and every result carries the same
status metadata regardless of connector, which is what lets the workflow treat
connectors uniformly (AUDIT-ADD-14) and lets :func:`contract_test` prove it.

Pinning (WF-02 / IMPL-05): :func:`pin_source_set` freezes every source system
to a revision and every artifact to a content hash; :func:`verify_pins` re-reads
and reports drift as ``STALE`` with the exact artifacts that moved, so a rerun
either uses the same revisions or *explicitly reports that reproduction is
impossible* — it never silently reads newer bytes.

Structure informed by the owner's Trace-to-Diff connectors and Repository
Context Graph ``connectors/base.py``; this contract is this package's.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Iterable, Mapping, Sequence

from ..canonical import canonical_bytes, digest_of, fmt_ts, merkle_root, sha256_hex, sha256_of
from ..ids import artifact_id as make_artifact_id
from ..scope import ScopeContract, ScopeDenied

__all__ = ["ConnectorError", "ConnectorCapabilities", "Health", "RetryPolicy", "RawArtifact", "ConnectorResult",
           "Connector", "PinnedSourceSet", "pin_source_set", "verify_pins", "contract_test", "FAILURE_STATES"]

FAILURE_STATES = ("complete", "partial", "denied", "unavailable", "rate_limited", "stale", "malformed", "failed")


class ConnectorError(RuntimeError):
    def __init__(self, state: str, message: str) -> None:
        if state not in FAILURE_STATES:
            raise ValueError(f"unknown failure state {state!r}")
        self.state = state
        super().__init__(f"{state}: {message}")


@dataclass(frozen=True)
class ConnectorCapabilities:
    source_system: str
    data_classes: tuple[str, ...]
    read: bool = True
    write: bool = False
    revision_semantics: str = "content-hash"        # content-hash | vcs | snapshot
    pagination: bool = True
    page_size: int = 50
    rate_limit_per_minute: int | None = None
    supports_partial_results: bool = True
    external: bool = False

    def as_document(self) -> dict[str, Any]:
        return {"source_system": self.source_system, "data_classes": list(self.data_classes), "read": self.read,
                "write": self.write, "revision_semantics": self.revision_semantics, "pagination": self.pagination,
                "page_size": self.page_size, "rate_limit_per_minute": self.rate_limit_per_minute,
                "supports_partial_results": self.supports_partial_results, "external": self.external}


@dataclass(frozen=True)
class Health:
    status: str            # healthy | degraded | unavailable
    checked_at: str
    detail: str = ""

    def as_document(self) -> dict[str, Any]:
        return {"status": self.status, "checked_at": self.checked_at, "detail": self.detail}


@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int = 3
    base_delay_seconds: float = 0.05
    multiplier: float = 2.0
    max_delay_seconds: float = 1.0

    def delay(self, attempt: int) -> float:
        return min(self.max_delay_seconds, self.base_delay_seconds * (self.multiplier ** max(attempt - 1, 0)))


@dataclass(frozen=True)
class RawArtifact:
    artifact_id: str
    source_system: str
    data_class: str
    tenant: str
    project: str
    path: str
    revision: str
    source_hash: str
    observed_at: str
    content: bytes | None = None
    classification: str = "internal"
    tombstone: bool = False
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def as_document(self) -> dict[str, Any]:
        return {"artifact_id": self.artifact_id, "source_system": self.source_system, "data_class": self.data_class,
                "tenant": self.tenant, "project": self.project, "path": self.path, "revision": self.revision,
                "source_hash": self.source_hash, "observed_at": self.observed_at,
                "classification": self.classification, "tombstone": self.tombstone,
                "bytes": len(self.content) if self.content is not None else 0, "metadata": dict(self.metadata)}


@dataclass
class ConnectorResult:
    source_system: str
    status: str
    artifacts: list[RawArtifact] = field(default_factory=list)
    diagnostics: list[str] = field(default_factory=list)
    next_page: int | None = None
    health: Health | None = None
    denied: list[dict[str, str]] = field(default_factory=list)
    attempts: int = 1

    def __post_init__(self) -> None:
        if self.status not in FAILURE_STATES:
            raise ValueError(f"unknown status {self.status!r}")

    @property
    def ok(self) -> bool:
        return self.status == "complete"

    def as_document(self) -> dict[str, Any]:
        return {"source_system": self.source_system, "status": self.status, "artifact_count": len(self.artifacts),
                "diagnostics": list(self.diagnostics), "next_page": self.next_page,
                "health": self.health.as_document() if self.health else None, "denied": list(self.denied),
                "attempts": self.attempts}


class Connector:
    """Base class. Subclasses implement ``_discover`` and ``_read_one``; the contract lives here."""

    capabilities: ConnectorCapabilities
    connector_version = "1.0.0"

    def __init__(self, *, ledger: Any = None, retry: RetryPolicy | None = None,
                 sleep: Callable[[float], None] | None = None) -> None:
        self.ledger = ledger
        self.retry = retry or RetryPolicy()
        self._sleep = sleep or time.sleep
        self._calls_this_minute = 0
        self._minute_started = time.monotonic()

    # --- to be implemented ---------------------------------------------------
    def _discover(self, scope: ScopeContract) -> list[str]:
        raise NotImplementedError

    def _read_one(self, locator: str, scope: ScopeContract) -> RawArtifact:
        raise NotImplementedError

    def health(self) -> Health:
        return Health("healthy", fmt_ts(datetime.now(timezone.utc)))

    # --- contract ------------------------------------------------------------
    def _authorize(self, scope: ScopeContract, *, locator: str | None = None, data_class: str | None = None) -> str | None:
        try:
            scope.check("read", source_system=self.capabilities.source_system, artifact_class=data_class,
                        external_system=self.capabilities.source_system if self.capabilities.external else None,
                        tenant=scope.tenant)
        except ScopeDenied as denial:
            if self.ledger is not None:
                self.ledger.append("connector.denied", actor=self.capabilities.source_system, actor_kind="service",
                                   outcome="denied", subject=locator or self.capabilities.source_system,
                                   detail={"reason": str(denial), "data_class": data_class, "locator": locator,
                                           "external": self.capabilities.external})
            return str(denial)
        return None

    def _rate_check(self) -> None:
        limit = self.capabilities.rate_limit_per_minute
        if limit is None:
            return
        now = time.monotonic()
        if now - self._minute_started >= 60:
            self._minute_started, self._calls_this_minute = now, 0
        self._calls_this_minute += 1
        if self._calls_this_minute > limit:
            raise ConnectorError("rate_limited", f"{limit} calls/minute exceeded")

    def discover(self, scope: ScopeContract) -> ConnectorResult:
        denied = self._authorize(scope)
        if denied:
            return ConnectorResult(self.capabilities.source_system, "denied", diagnostics=[denied],
                                   denied=[{"locator": "*", "reason": denied}], health=self.health())
        try:
            locators = sorted(self._discover(scope))
        except ConnectorError as exc:
            return ConnectorResult(self.capabilities.source_system, exc.state, diagnostics=[str(exc)],
                                   health=self.health())
        result = ConnectorResult(self.capabilities.source_system, "complete", health=self.health())
        result.diagnostics.append(f"{len(locators)} locator(s) discovered")
        result.artifacts = []
        result.locators = locators  # type: ignore[attr-defined]
        return result

    def read(self, scope: ScopeContract, *, locators: Sequence[str] | None = None, page: int = 0,
             data_class: str | None = None) -> ConnectorResult:
        """Read one page of artifacts under the scope; typed status, denials logged, retries bounded."""
        source = self.capabilities.source_system
        denied = self._authorize(scope, data_class=data_class)
        if denied:
            return ConnectorResult(source, "denied", diagnostics=[denied],
                                   denied=[{"locator": "*", "reason": denied}], health=self.health())
        if locators is None:
            try:
                locators = sorted(self._discover(scope))
            except ConnectorError as exc:
                return ConnectorResult(source, exc.state, diagnostics=[str(exc)], health=self.health())
        size = self.capabilities.page_size if self.capabilities.pagination else len(locators) or 1
        start = page * size
        chunk = list(locators[start:start + size])
        next_page = page + 1 if start + size < len(locators) else None
        result = ConnectorResult(source, "complete", next_page=next_page, health=self.health())
        for locator in chunk:
            artifact, diag, denial = self._read_with_retry(locator, scope, data_class)
            if denial:
                result.denied.append({"locator": locator, "reason": denial})
                continue
            if artifact is None:
                result.diagnostics.append(diag or f"{locator}: failed")
                continue
            result.artifacts.append(artifact)
            if self.ledger is not None:
                self.ledger.append("connector.read", actor=source, actor_kind="service", outcome="allowed",
                                   subject=locator, detail={"artifact_id": artifact.artifact_id,
                                                            "source_hash": artifact.source_hash,
                                                            "revision": artifact.revision,
                                                            "data_class": artifact.data_class})
        if result.denied and not result.artifacts and not result.diagnostics:
            result.status = "denied"
        elif result.diagnostics or result.denied:
            result.status = "partial" if result.artifacts else "failed"
        return result

    def _read_with_retry(self, locator: str, scope: ScopeContract, data_class: str | None
                         ) -> tuple[RawArtifact | None, str | None, str | None]:
        last: str | None = None
        for attempt in range(1, self.retry.max_attempts + 1):
            try:
                self._rate_check()
                artifact = self._read_one(locator, scope)
                if data_class is not None and artifact.data_class != data_class:
                    return None, f"{locator}: data class {artifact.data_class} does not match request", None
                denied = self._authorize(scope, locator=locator, data_class=artifact.data_class)
                if denied:
                    return None, None, denied
                try:
                    scope.check_path(artifact.path, permission="read")
                except ScopeDenied as denial:
                    if self.ledger is not None:
                        self.ledger.append("connector.denied", actor=self.capabilities.source_system,
                                           actor_kind="service", outcome="denied", subject=locator,
                                           detail={"reason": str(denial)})
                    return None, None, str(denial)
                return artifact, None, None
            except ConnectorError as exc:
                last = str(exc)
                if exc.state in ("denied", "malformed"):
                    return None, last, None
                if attempt < self.retry.max_attempts:
                    self._sleep(self.retry.delay(attempt))
        return None, last, None

    def pin(self, scope: ScopeContract) -> dict[str, Any]:
        """Resolve every discoverable artifact to an immutable content hash and derive the system revision."""
        result = self.read(scope)
        if result.status not in ("complete", "partial"):
            raise ConnectorError(result.status, f"cannot pin {self.capabilities.source_system}: {result.diagnostics}")
        pages = [result]
        while pages[-1].next_page is not None:
            pages.append(self.read(scope, page=pages[-1].next_page))
        artifacts = [a for page in pages for a in page.artifacts]
        leaves = sorted(f"{a.path}:{a.source_hash}" for a in artifacts)
        revision = merkle_root([sha256_hex(leaf) for leaf in leaves])
        return {"source_system": self.capabilities.source_system, "revision": revision,
                "artifact_count": len(artifacts),
                "artifacts": {a.path: {"artifact_id": a.artifact_id, "source_hash": a.source_hash,
                                       "data_class": a.data_class} for a in artifacts},
                "connector_version": self.connector_version, "pinned_at": fmt_ts(datetime.now(timezone.utc))}

    def describe(self) -> dict[str, Any]:
        return {"capabilities": self.capabilities.as_document(), "connector_version": self.connector_version,
                "retry": {"max_attempts": self.retry.max_attempts, "base_delay_seconds": self.retry.base_delay_seconds,
                          "multiplier": self.retry.multiplier}, "health": self.health().as_document()}


def make_raw_artifact(*, source_system: str, data_class: str, tenant: str, project: str, path: str,
                      revision: str, content: bytes, classification: str = "internal",
                      metadata: Mapping[str, Any] | None = None) -> RawArtifact:
    source_hash = sha256_of(content)
    return RawArtifact(
        artifact_id=make_artifact_id(source_system=source_system, tenant=tenant, project=project, path=path,
                                     revision=revision),
        source_system=source_system, data_class=data_class, tenant=tenant, project=project, path=path,
        revision=revision, source_hash=source_hash, observed_at=fmt_ts(datetime.now(timezone.utc)),
        content=content, classification=classification, metadata=dict(metadata or {}))


# --------------------------------------------------------------------------- #
# Pinning (WF-02, IMPL-05)                                                      #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class PinnedSourceSet:
    run_id: str
    pins: Mapping[str, Mapping[str, Any]]
    pinned_at: str

    @property
    def digest(self) -> str:
        return sha256_of(canonical_bytes({"run_id": self.run_id, "pins": {
            s: {"revision": p["revision"], "artifacts": p["artifacts"]} for s, p in sorted(self.pins.items())}}))

    def revision_of(self, source_system: str) -> str:
        return self.pins[source_system]["revision"]

    def as_document(self) -> dict[str, Any]:
        return {"run_id": self.run_id, "pinned_at": self.pinned_at, "digest": self.digest,
                "pins": {s: dict(p) for s, p in sorted(self.pins.items())}}


def pin_source_set(run_id: str, connectors: Iterable[Connector], scope: ScopeContract) -> PinnedSourceSet:
    """Freeze the target set into the run (WF-02). Revision bounds in the scope must agree."""
    pins: dict[str, dict[str, Any]] = {}
    for connector in connectors:
        pin = connector.pin(scope)
        bound = scope.revision_bounds.get(connector.capabilities.source_system)
        if bound and bound not in ("*", pin["revision"]):
            raise ConnectorError("stale", f"{connector.capabilities.source_system}: scope pins revision {bound} "
                                          f"but the source is at {pin['revision']}; refusing to silently repin")
        pins[connector.capabilities.source_system] = pin
    return PinnedSourceSet(run_id=run_id, pins=pins, pinned_at=fmt_ts(datetime.now(timezone.utc)))


def verify_pins(pinned: PinnedSourceSet, connectors: Iterable[Connector], scope: ScopeContract) -> dict[str, Any]:
    """IMPL-05: re-read and report exactly which artifacts moved. Never repins silently."""
    report: dict[str, Any] = {"reproducible": True, "systems": {}}
    for connector in connectors:
        system = connector.capabilities.source_system
        if system not in pinned.pins:
            report["systems"][system] = {"state": "UNPINNED", "reason": "source system was not in the pinned set"}
            report["reproducible"] = False
            continue
        current = connector.pin(scope)
        before = pinned.pins[system]["artifacts"]
        after = current["artifacts"]
        changed = sorted(p for p in before if p in after and before[p]["source_hash"] != after[p]["source_hash"])
        removed = sorted(p for p in before if p not in after)
        added = sorted(p for p in after if p not in before)
        if changed or removed or added:
            report["systems"][system] = {"state": "STALE", "changed": changed, "removed": removed, "added": added,
                                         "pinned_revision": pinned.pins[system]["revision"],
                                         "current_revision": current["revision"],
                                         "reason": "reproduction from recorded inputs is impossible against the "
                                                   "current source; the pinned revision no longer exists on disk"}
            report["reproducible"] = False
        else:
            report["systems"][system] = {"state": "CURRENT", "revision": current["revision"]}
    return report


# --------------------------------------------------------------------------- #
# Common contract test (AUDIT-ADD-14)                                          #
# --------------------------------------------------------------------------- #
def contract_test(connector: Connector, scope: ScopeContract, *, denied_scope: ScopeContract | None = None) -> dict[str, Any]:
    """Exercise the contract every connector must honour; returns a typed report."""
    checks: dict[str, Any] = {}
    caps = connector.capabilities
    checks["capabilities_declared"] = bool(caps.source_system and caps.data_classes and caps.read and not caps.write)
    health = connector.health()
    checks["health_typed"] = health.status in ("healthy", "degraded", "unavailable")
    discovered = connector.discover(scope)
    checks["discover_status_typed"] = discovered.status in FAILURE_STATES
    first = connector.read(scope, page=0)
    checks["read_status_typed"] = first.status in FAILURE_STATES
    checks["artifacts_have_identity"] = all(a.artifact_id and a.source_hash.startswith("sha256:") and a.revision
                                            for a in first.artifacts)
    checks["artifacts_in_declared_classes"] = all(a.data_class in caps.data_classes for a in first.artifacts)
    checks["pagination_consistent"] = (first.next_page is None) or (first.next_page == 1 and caps.pagination)
    pin = connector.pin(scope)
    checks["pin_deterministic"] = pin["revision"] == connector.pin(scope)["revision"]
    if denied_scope is not None:
        denied = connector.read(denied_scope)
        checks["denial_typed_and_empty"] = denied.status == "denied" and not denied.artifacts
    checks["result_metadata_uniform"] = set(first.as_document()) == {
        "source_system", "status", "artifact_count", "diagnostics", "next_page", "health", "denied", "attempts"}
    return {"source_system": caps.source_system, "checks": checks, "passed": all(checks.values()),
            "artifact_count": pin["artifact_count"]}
