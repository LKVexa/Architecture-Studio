"""The local corpus as an authorized, read-only source system (ARCH-01, DATA-*, WF-02).

The car's 66-suite JA21/DeepML corpus is the studio's local evidence: suite
READMEs, `.jasp` service contracts, `.jaops` workspaces, `.jasec` policies and
the root inventories. This connector exposes those files read-only, confined to
the car root, with a content-hash revision per file and a Merkle-root revision
for the whole corpus. Nothing here can write; the corpus's byte-identity is
asserted separately by ``tools/verify_corpus.py``.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..scope import ScopeContract, ScopeDenied
from .base import Connector, ConnectorCapabilities, ConnectorError, RawArtifact, make_raw_artifact

__all__ = ["CorpusConnector", "OVERLAY_DIR", "CLASS_BY_SUFFIX"]

OVERLAY_DIR = "Architecture Studio"

#: The default data class of a corpus file by suffix; typed connectors refine it.
CLASS_BY_SUFFIX = {
    ".md": "document", ".jasp": "api_operation", ".jaops": "service", ".jasec": "security_constraint",
    ".json": "deployment_standard", ".jaui": "document", ".jaa": "document", ".jad": "document",
    ".jate": "document", ".ja": "document", ".deepml": "document", ".dmk": "document", ".ebnf": "document",
    ".txt": "document",
}

_TEXT_SUFFIXES = tuple(CLASS_BY_SUFFIX)


class CorpusConnector(Connector):
    connector_version = "1.0.0"

    def __init__(self, root: Path, *, tenant: str, project: str, source_system: str = "corpus",
                 suffixes: tuple[str, ...] = _TEXT_SUFFIXES, **kw: Any) -> None:
        super().__init__(**kw)
        self.root = Path(root).resolve()
        self.tenant = tenant
        self.project = project
        self.suffixes = suffixes
        self.capabilities = ConnectorCapabilities(
            source_system=source_system, data_classes=tuple(sorted(set(CLASS_BY_SUFFIX.values()))),
            read=True, write=False, revision_semantics="content-hash", pagination=True, page_size=100,
            rate_limit_per_minute=None, supports_partial_results=True, external=False)
        self._fail_paths: set[str] = set()      # test hook: simulate an unavailable file

    def simulate_unavailable(self, relative_path: str, on: bool = True) -> None:
        if on:
            self._fail_paths.add(relative_path)
        else:
            self._fail_paths.discard(relative_path)

    def _iter_files(self) -> list[Path]:
        out = []
        for path in sorted(self.root.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            rel = path.relative_to(self.root)
            if rel.parts and rel.parts[0] in (OVERLAY_DIR, ".git"):
                continue
            if path.suffix.lower() in self.suffixes:
                out.append(path)
        return out

    def _discover(self, scope: ScopeContract) -> list[str]:
        locators = []
        for path in self._iter_files():
            rel = path.relative_to(self.root).as_posix()
            try:
                scope.check_path(path, permission="read")
            except ScopeDenied:
                continue
            locators.append(rel)
        return locators

    def _read_one(self, locator: str, scope: ScopeContract) -> RawArtifact:
        if locator in self._fail_paths:
            raise ConnectorError("unavailable", f"{locator}: source temporarily unavailable")
        path = (self.root / locator)
        try:
            resolved = path.resolve()
            resolved.relative_to(self.root)
        except ValueError:
            raise ConnectorError("denied", f"{locator} escapes the corpus root") from None
        if not resolved.is_file():
            raise ConnectorError("unavailable", f"{locator} does not exist")
        content = resolved.read_bytes()
        if b"\x00" in content[:4096]:
            raise ConnectorError("malformed", f"{locator} is not a text artifact")
        data_class = CLASS_BY_SUFFIX.get(resolved.suffix.lower(), "document")
        return make_raw_artifact(source_system=self.capabilities.source_system, data_class=data_class,
                                 tenant=self.tenant, project=self.project, path=locator,
                                 revision="sha256:" + _short(content), content=content,
                                 classification="internal",
                                 metadata={"suite": locator.split("/", 1)[0] if "/" in locator else "",
                                           "suffix": resolved.suffix.lower()})

    def read_text(self, locator: str) -> str:
        return (self.root / locator).read_text(encoding="utf-8", errors="strict")


def _short(content: bytes) -> str:
    import hashlib
    return hashlib.sha256(content).hexdigest()
