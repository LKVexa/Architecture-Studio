"""Connector/adaptor layer for authorized source systems (ARCH-01, AUDIT-ADD-14, DATA-01..09, WF-02..04, IMPL-05)."""
from __future__ import annotations

from .base import (Connector, ConnectorCapabilities, ConnectorError, ConnectorResult, RawArtifact,
                   PinnedSourceSet, pin_source_set, verify_pins, contract_test, RetryPolicy, Health)
from .corpus import CorpusConnector
from .typed import (REGISTRY, RequirementsConnector, NFRConnector, ADRConnector, APICatalogConnector,
                    InfraCatalogConnector, DiagramConnector, SecurityConstraintConnector,
                    CostPerformanceConnector, DeploymentStandardConnector, connector_for_class)
from .normalize import Normalizer, NormalizedIndex, QuarantineEntry

__all__ = [
    "Connector", "ConnectorCapabilities", "ConnectorError", "ConnectorResult", "RawArtifact", "PinnedSourceSet",
    "pin_source_set", "verify_pins", "contract_test", "RetryPolicy", "Health", "CorpusConnector", "REGISTRY",
    "RequirementsConnector", "NFRConnector", "ADRConnector", "APICatalogConnector", "InfraCatalogConnector",
    "DiagramConnector", "SecurityConstraintConnector", "CostPerformanceConnector", "DeploymentStandardConnector",
    "connector_for_class", "Normalizer", "NormalizedIndex", "QuarantineEntry",
]
