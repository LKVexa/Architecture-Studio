"""Model orchestration and candidate generation (ARCH-06, COMP-04, PAPER-CAP-03, WF-06, WF-07, MODEL-01..05, XTOOL-06, XTOOL-07).

The orchestration layer assembles only authorized, provenance-bearing context,
invokes a *version-pinned* provider under policy, validates every structured
output against the candidate schema, and handles retries, fallback and
abstention. Three things are true by construction:

* **No provider is bound by default.** :class:`ProviderSlot` is empty; a run
  with an empty slot runs the :class:`DeterministicEvidenceGenerator`, whose
  candidates are derived from the pinned catalogs and labelled
  ``deterministic_analyzer`` — never presented as model output. Binding a live
  provider is a human act recorded through the slot (this is the MODEL-01
  blocker, stated as code, not hidden).
* **Context is source-labelled and bounded** (WF-06, MODEL-03, XTOOL-04). The
  exact context manifest is recorded and its digest travels with every output.
* **Output is schema-validated before anything downstream sees it**
  (MODEL-04); invalid output becomes a typed abstention, and a provider failure
  becomes a typed ``PROVIDER_UNAVAILABLE`` fallback (XTOOL-07), never a crash
  and never a silent generic design.

System prompts are versioned data (MODEL-02) and policy enforcement is
independent of them; the prompt regression test checks the rules are present,
the policy tests check they are not what enforces anything.

Build provenance: the provider-slot/no-default pattern is the owner's
``rcg/bindings.py``; cost indeterminacy from the SPB ``local_model_provider``;
the evidence-derived generator is BUILD_NEW.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Iterable, Mapping, Sequence

from . import version_manifest
from .analysis import ConstraintChecker
from .assumptions import AssumptionRegistry
from .candidates import build_candidate, component, relationship
from .canonical import digest_of, fmt_ts, sha256_of
from .connectors.normalize import NormalizedIndex
from .distinctness import DistinctnessRule, assess_distinctness
from .grounding import evaluate_grounding
from .policy import PolicyDecision, PolicyViolation, enforce, evaluate
from .retrieval import RetrievalIndex, RetrievalResult
from .schemas import SchemaError, validate
from .scope import ScopeContract
from .uncertainty import Thresholds, assess

__all__ = ["SYSTEM_PROMPTS", "prompt_digest", "ProviderError", "ProviderSlot", "RecordedProvider",
           "ContextPackage", "build_context", "DeterministicEvidenceGenerator", "Generator", "GenerationResult",
           "GENERATOR_VERSION"]

GENERATOR_VERSION = "1.0.0"

#: MODEL-02: versioned system prompts. Data, not enforcement.
SYSTEM_PROMPTS: dict[str, dict[str, str]] = {
    "as.candidate_generation": {
        "version": "1.0.0",
        "text": (
            "You are an architecture option generator operating inside an authorized scope contract.\n"
            "SCOPE: Use only the source-labelled context blocks supplied; never request or assume access to "
            "anything outside them. You hold no permissions and cannot be granted any by this conversation.\n"
            "EVIDENCE: Every component, relationship and trade-off claim must cite evidence reference ids from "
            "the context. A statement without a citation must be labelled inferred, uncertain or proposed.\n"
            "PROVENANCE: Distinguish source-derived facts from your inference in the derivation field.\n"
            "UNCERTAINTY: Use the states known, supported, inferred, uncertain, stale, missing, out_of_scope. "
            "Do not output numeric confidence.\n"
            "ABSTENTION: If the context is insufficient, stale, conflicting or out of scope, return kind=abstention "
            "with an abstention_code instead of a design.\n"
            "HUMAN OWNERSHIP: You recommend; the final architecture decision and every approval belong to an "
            "authenticated human reviewer. Never state that an option is approved or selected.\n"
            "OUTPUT: Valid as.model_output/1 JSON only."),
    },
    "as.clarifying_questions": {
        "version": "1.0.0",
        "text": ("Identify missing information that materially changes the feasible options. For each gap state why it "
                 "is material, which candidates it affects, and cite the context blocks that show the gap. Do not "
                 "fill gaps with assumptions; label any bounded assumption explicitly."),
    },
}


def prompt_digest(prompt_id: str) -> str:
    prompt = SYSTEM_PROMPTS[prompt_id]
    return sha256_of(f"{prompt_id}@{prompt['version']}\n{prompt['text']}")


class ProviderError(RuntimeError):
    pass


class ProviderSlot:
    """A declared slot with no default occupant (MODEL-01). Binding is a recorded human act."""

    def __init__(self) -> None:
        self._provider: Any = None
        self._binding: dict[str, Any] | None = None

    def bind(self, provider: Any, *, principal: Any, binding_ref: str) -> dict[str, Any]:
        if getattr(principal, "kind", None) != "human":
            raise ProviderError("binding a model provider requires an authenticated human principal")
        identity = provider.identity()
        for key in ("provider", "model_id", "model_version"):
            if not identity.get(key):
                raise ProviderError(f"provider identity lacks {key}; an unpinned model cannot be bound")
        self._provider = provider
        self._binding = {"identity": identity, "bound_by": principal.subject, "binding_ref": binding_ref,
                         "bound_at": fmt_ts(datetime.now(timezone.utc))}
        return self._binding

    @property
    def bound(self) -> bool:
        return self._provider is not None

    @property
    def provider(self) -> Any:
        return self._provider

    def describe(self) -> dict[str, Any]:
        return {"bound": self.bound, "binding": self._binding,
                "blocker": None if self.bound else "MODEL-01/ARCH-06: no model provider is bound; runs use the "
                                                    "deterministic evidence generator and record it as such"}


class RecordedProvider:
    """A replay provider for tests: returns pre-recorded outputs keyed by prompt and context digest."""

    def __init__(self, recordings: Mapping[str, Mapping[str, Any]], *, identity: Mapping[str, str] | None = None,
                 fail: bool = False) -> None:
        self._recordings = dict(recordings)
        self._identity = dict(identity or {"provider": "recorded-fixture", "model_id": "recorded", "model_version": "1"})
        self._fail = fail
        self.calls = 0

    def identity(self) -> dict[str, str]:
        return dict(self._identity)

    def complete(self, *, prompt_id: str, context_manifest_digest: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        self.calls += 1
        if self._fail:
            raise ProviderError("recorded provider configured to fail")
        key = f"{prompt_id}:{context_manifest_digest}"
        if key not in self._recordings and "*" not in self._recordings:
            raise ProviderError("no recording for this prompt/context")
        return dict(self._recordings.get(key) or self._recordings["*"])


@dataclass
class ContextPackage:
    chunks: list[dict[str, Any]]
    deterministic_findings: list[dict[str, Any]]
    token_budget: int
    tokens_used: int
    truncated: bool
    excluded_by_scope: int
    stale_included: int

    @property
    def manifest_digest(self) -> str:
        return digest_of({"chunks": [c["chunk_id"] for c in self.chunks],
                          "findings": [f.get("analyzer") for f in self.deterministic_findings]})

    def as_document(self) -> dict[str, Any]:
        return {"chunk_count": len(self.chunks), "chunks": self.chunks, "deterministic_findings": self.deterministic_findings,
                "token_budget": self.token_budget, "tokens_used": self.tokens_used, "truncated": self.truncated,
                "excluded_by_scope": self.excluded_by_scope, "stale_included": self.stale_included,
                "manifest_digest": self.manifest_digest}


def build_context(*, retrieval: RetrievalIndex, scope: ScopeContract, queries: Sequence[str],
                  analyzer_results: Sequence[Mapping[str, Any]] = (), token_budget: int = 6000,
                  per_query_limit: int = 8) -> ContextPackage:
    """WF-06: only authorized, source-labelled, provenance-bearing evidence plus deterministic findings."""
    chunks: dict[str, dict[str, Any]] = {}
    used = 0
    truncated = False
    excluded = 0
    stale = 0
    for query in queries:
        result: RetrievalResult = retrieval.search(query, scope=scope, limit=per_query_limit,
                                                   token_budget=max(1, token_budget - used))
        excluded += result.excluded_by_scope
        for chunk in result.chunks:
            doc = chunk.as_document()
            if not doc.get("label") or not doc.get("evidence_ref_id"):
                raise ProviderError("unlabelled context cannot enter a model call")
            if chunk.chunk_id in chunks:
                continue
            cost = max(1, len(chunk.text) // 4)
            if used + cost > token_budget:
                truncated = True
                break
            chunks[chunk.chunk_id] = {**doc, "text": chunk.text}
            used += cost
            if chunk.freshness == "STALE":
                stale += 1
        truncated = truncated or result.truncated
    findings = [dict(r) for r in analyzer_results]
    return ContextPackage(chunks=list(chunks.values()), deterministic_findings=findings, token_budget=token_budget,
                          tokens_used=used, truncated=truncated, excluded_by_scope=excluded, stale_included=stale)


# --------------------------------------------------------------------------- #
# Deterministic, evidence-derived generation                                    #
# --------------------------------------------------------------------------- #
_GOVERNANCE = (
    ("sophia", "SOPHIA semantic judgment", ("semantic judgment", "acceptance")),
    ("charlotte", "CHARLOTTE structural validation", ("structural validation", "logic validation")),
    ("landon", "LANDON repository integration", ("repository integration", "route application")),
    ("professor", "Professor reviewable explanation", ("reviewable explanation",)),
    ("podium", "Podium evidence queue", ("jobs", "evidence queues", "completion records")),
)


class DeterministicEvidenceGenerator:
    """Candidates derived from the pinned catalogs; every element cites the records it came from."""

    generator_id = "deterministic-evidence-generator"
    version = GENERATOR_VERSION

    def identity(self) -> dict[str, str]:
        return {"provider": self.generator_id, "model_id": "none", "model_version": self.version}

    def _records(self, index: NormalizedIndex, data_class: str, *, suite_terms: Sequence[str] = ()) -> list[dict[str, Any]]:
        records = index.by_class(data_class)
        if suite_terms:
            terms = [t.lower() for t in suite_terms]
            filtered = [r for r in records if any(t in r["path"].lower() for t in terms)]
            records = filtered or records
        return sorted(records, key=lambda r: r["record_id"])

    @staticmethod
    def _requirement_refs(index: NormalizedIndex, suite: str, name: str, limit: int = 3) -> list[str]:
        """Requirement records in ``suite`` whose text names this service (the graph's implements rule)."""
        tokens = [t for t in name.lower().replace("_", " ").split() if len(t) > 3]
        refs: list[str] = []
        for record in index.by_class("requirement"):
            if suite and not record["path"].split(":")[-1].startswith(suite + "/"):
                continue
            text = str(record["payload"].get("text", "")).lower()
            if tokens and any(t in text for t in tokens):
                refs.append(record["provenance_ref_id"])
                if len(refs) >= limit:
                    break
        return refs

    @staticmethod
    def _catalog_service(index: NormalizedIndex, prefix: str) -> dict[str, Any] | None:
        for record in sorted(index.by_class("service"), key=lambda r: r["record_id"]):
            if str(record["payload"].get("service", "")).lower().startswith(prefix.lower()):
                return record
        return None

    def _deployment(self, index: NormalizedIndex, suite_terms: Sequence[str]) -> tuple[dict[str, Any], list[str]]:
        standards = self._records(index, "deployment_standard", suite_terms=suite_terms)
        target = next((r for r in standards if r["payload"].get("rule") == "target"), None)
        env = next((r for r in standards if r["payload"].get("rule") == "environment"), None)
        refs = [r["provenance_ref_id"] for r in (target, env) if r]
        return ({"topology": f"single-host {target['payload']['value']}" if target else "unspecified",
                 "environments": [env["payload"]["value"]] if env else [],
                 "standard_refs": [r["record_id"] for r in (target, env) if r], "evidence_refs": refs}, refs)

    def strategies(self, index: NormalizedIndex, goals: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
        goal_terms = [t for g in goals for t in str(g.get("text", "")).lower().split() if len(t) > 3]
        out: list[dict[str, Any]] = []
        out.append(self._workspace_consolidation(index, goal_terms))
        out.append(self._governance_ensemble(index))
        out.append(self._queued_batch(index))
        return [s for s in out if s is not None]

    def _workspace_consolidation(self, index: NormalizedIndex, goal_terms: Sequence[str]) -> dict[str, Any] | None:
        services = self._records(index, "service")
        if not services:
            return None
        # Choose the workspace whose service names overlap the goals most; deterministic tie-break.
        by_ws: dict[str, list[dict[str, Any]]] = {}
        for r in services:
            by_ws.setdefault(str(r["payload"]["workspace"]), []).append(r)
        def score(ws: str) -> tuple[int, str]:
            names = " ".join(r["payload"]["service"].lower() for r in by_ws[ws]) + " " + ws.lower()
            return (sum(1 for t in goal_terms if t in names), ws)
        workspace = max(sorted(by_ws), key=score)
        members = by_ws[workspace][:8]
        suite = members[0]["path"].split(":")[-1].split("/")[0]
        comps, rels, refs = [], [], []
        for i, r in enumerate(members):
            p = r["payload"]
            kind = "worker" if "worker" in p["service"].lower() else "service"
            req_refs = self._requirement_refs(index, suite, p["service"])
            comps.append(component(f"ws-{i}", p["service"], kind, responsibilities=[p["service"].replace("_", " ")],
                                   evidence_refs=[r["provenance_ref_id"]] + req_refs, catalog_ref=p["service"],
                                   replicas=p["replicas"]))
            refs.append(r["provenance_ref_id"])
            refs.extend(req_refs)
            if i > 0:
                rels.append(relationship(f"ws-dep-{i}", f"ws-{i}", "ws-0", "depends_on", evidence_refs=[r["provenance_ref_id"]]))
        sec = self._records(index, "security_constraint", suite_terms=[members[0]["path"].split(":")[-1].split("/")[0]])
        if sec:
            comps.append(component("ws-policy", sec[0]["payload"]["policy"], "policy_point",
                                   responsibilities=["policy enforcement", "audit privileged effects"],
                                   evidence_refs=[sec[0]["provenance_ref_id"]]))
            rels.append(relationship("ws-guard", "ws-policy", "ws-0", "guards", evidence_refs=[sec[0]["provenance_ref_id"]]))
            refs.append(sec[0]["provenance_ref_id"])
        deployment, drefs = self._deployment(index, [members[0]["path"].split(":")[-1].split("/")[0]])
        return {"name": f"Consolidated workspace: {workspace}", "style": "workspace-consolidation",
                "components": comps, "relationships": rels, "deployment": deployment, "evidence_refs": refs + drefs,
                "rationale": [{"text": f"The pinned infrastructure catalog declares {len(members)} service(s) in workspace "
                                       f"{workspace}; this option keeps them co-located under one policy point.",
                               "derivation": "source", "evidence_refs": refs[:3]}],
                "risks": [{"text": "A single workspace concentrates failure; rollback is per health_failure as the standard states.",
                           "severity": "medium", "evidence_refs": drefs}],
                "assumptions": []}

    def _governance_ensemble(self, index: NormalizedIndex) -> dict[str, Any] | None:
        adr = next((r for r in index.by_class("adr") if r["payload"].get("adr_id") == "ADR-003"), None)
        diagram = next((r for r in index.by_class("diagram") if r["payload"].get("diagram_id") == "DIAG-governance_flow"), None)
        reqs = [r for r in index.by_class("requirement") if r["payload"].get("kind") == "assignment"]
        if adr is None and not reqs:
            return None
        base_refs = [r["provenance_ref_id"] for r in ([adr] if adr else []) + ([diagram] if diagram else [])]
        comps, rels, refs = [], [], list(base_refs)
        for key, name, duties in _GOVERNANCE:
            support = [r for r in reqs if key in r["payload"]["text"].lower()][:1]
            catalog = self._catalog_service(index, key + "_")
            ev = base_refs + [r["provenance_ref_id"] for r in support] + ([catalog["provenance_ref_id"]] if catalog else [])
            comps.append(component(f"gov-{key}", name, "queue" if key == "podium" else "service",
                                   responsibilities=list(duties), evidence_refs=ev,
                                   catalog_ref=catalog["payload"]["service"] if catalog else None,
                                   derivation="source" if catalog else "deterministic_analyzer"))
            refs.extend(ev)
        if diagram is not None:
            for i, edge in enumerate(diagram["payload"].get("edges", [])):
                src = f"gov-{edge['source'].lower()}"; dst = f"gov-{edge['target'].lower()}"
                if any(c["element_id"] == src for c in comps) and any(c["element_id"] == dst for c in comps):
                    rels.append(relationship(f"gov-e{i}", src, dst, "publishes" if dst == "gov-podium" else "calls",
                                             evidence_refs=[diagram["provenance_ref_id"]]))
        deployment, drefs = self._deployment(index, ["Capability and Security Plane"])
        return {"name": "Governance ensemble (five separated actors)", "style": "governance-ensemble",
                "components": comps, "relationships": rels, "deployment": deployment, "evidence_refs": refs + drefs,
                "rationale": [({"text": "ADR-003 keeps judgment, validation, application, explanation and evidence as distinct "
                                        "services with distinct capabilities.", "derivation": "source", "evidence_refs": base_refs}
                               if base_refs else
                               {"text": "The assignment requirements name judgment, validation, application, explanation and evidence "
                                        "as separate actors; ADR-003 is outside this run's scope and is not cited.",
                                "derivation": "source", "evidence_refs": sorted(set(refs))[:6]})],
                "risks": [{"text": "Five services multiply the audit and health-check surface.", "severity": "low",
                           "evidence_refs": base_refs}],
                "assumptions": []}

    def _queued_batch(self, index: NormalizedIndex) -> dict[str, Any] | None:
        services = self._records(index, "service", suite_terms=["Job Queue Workers and Sandboxes"])
        if not services:
            return None
        picks = {"queue": None, "worker": None, "sandbox": None, "store": None}
        for r in services:
            name = r["payload"]["service"].lower()
            for key in picks:
                if picks[key] is None and (key in name or (key == "store" and "status" in name)):
                    picks[key] = r
        chosen = [(k, r) for k, r in picks.items() if r is not None]
        if len(chosen) < 2:
            return None
        comps, rels, refs = [], [], []
        for key, r in chosen:
            p = r["payload"]
            req_refs = self._requirement_refs(index, "Job Queue Workers and Sandboxes", p["service"])
            comps.append(component(f"batch-{key}", p["service"], key, responsibilities=[p["service"].replace("_", " ")],
                                   evidence_refs=[r["provenance_ref_id"]] + req_refs, catalog_ref=p["service"],
                                   replicas=p["replicas"]))
            refs.append(r["provenance_ref_id"])
            refs.extend(req_refs)
        ids = {k for k, _ in chosen}
        if {"queue", "worker"} <= ids:
            rels.append(relationship("batch-sub", "batch-worker", "batch-queue", "subscribes", evidence_refs=refs[:1]))
        if {"worker", "sandbox"} <= ids:
            rels.append(relationship("batch-iso", "batch-sandbox", "batch-worker", "isolates", evidence_refs=refs[:1]))
        if {"worker", "store"} <= ids:
            rels.append(relationship("batch-write", "batch-worker", "batch-store", "writes", evidence_refs=refs[:1]))
        deployment, drefs = self._deployment(index, ["Job Queue Workers and Sandboxes"])
        assumption = "sandbox isolation strength is process-level unless the host provides kernel isolation"
        return {"name": "Queued batch with isolated sandboxes", "style": "queued-batch",
                "components": comps, "relationships": rels, "deployment": deployment, "evidence_refs": refs + drefs,
                "rationale": [{"text": "The Job Queue suite declares deterministic queues, worker management and isolated "
                                       "sandboxes as separate services.", "derivation": "source", "evidence_refs": refs[:3]},
                              {"text": assumption, "derivation": "model_inference", "evidence_refs": []}],
                "risks": [{"text": "Queue depth is unbounded in the pinned sources; back-pressure is unspecified.",
                           "severity": "medium", "evidence_refs": refs[:1]}],
                "assumptions": [assumption]}


@dataclass
class GenerationResult:
    candidates: list[dict[str, Any]]
    context: ContextPackage
    provider_identity: dict[str, str]
    mode: str
    distinctness: dict[str, Any]
    constraint_checks: dict[str, list[dict[str, Any]]]
    grounding: dict[str, dict[str, Any]]
    abstention: dict[str, Any] | None
    policy: dict[str, Any]
    prompt: dict[str, str]
    fallback_used: bool = False
    diagnostics: list[str] = field(default_factory=list)

    def as_document(self) -> dict[str, Any]:
        return {"generator_version": GENERATOR_VERSION, "mode": self.mode, "provider_identity": self.provider_identity,
                "prompt": self.prompt, "candidate_ids": [c["candidate_id"] for c in self.candidates],
                "context_manifest_digest": self.context.manifest_digest, "distinctness": self.distinctness,
                "constraint_summary": {cid: ConstraintChecker.summarize(v) for cid, v in self.constraint_checks.items()},
                "grounding": self.grounding, "abstention": self.abstention, "policy": self.policy,
                "fallback_used": self.fallback_used, "diagnostics": self.diagnostics,
                "versions": version_manifest()}


class Generator:
    def __init__(self, *, scope: ScopeContract, index: NormalizedIndex, retrieval: RetrievalIndex,
                 assumptions: AssumptionRegistry, slot: ProviderSlot | None = None, ledger: Any = None,
                 rollout: Any = None, thresholds: Thresholds | None = None, rule: DistinctnessRule | None = None,
                 checker: ConstraintChecker | None = None) -> None:
        self.scope = scope
        self.index = index
        self.retrieval = retrieval
        self.assumptions = assumptions
        self.slot = slot or ProviderSlot()
        self.ledger = ledger
        self.rollout = rollout
        self.thresholds = thresholds or Thresholds()
        self.rule = rule or DistinctnessRule()
        self.checker = checker or ConstraintChecker(index, ledger=ledger)
        self.deterministic = DeterministicEvidenceGenerator()

    def generate(self, *, run_id: str, iteration: int, goals: Sequence[Mapping[str, Any]],
                 constraints: Sequence[Mapping[str, Any]], session_ref: str,
                 analyzer_results: Sequence[Mapping[str, Any]] = (), actor: str = "generator") -> GenerationResult:
        # CTRL-KILL-01: the rollout switch is consulted before any work on the execution path.
        if self.rollout is not None:
            try:
                gate = enforce({"kind": "draft", "permission": "draft", "actor_kind": "service", "material_output": False,
                                "rollout": self.rollout}, self.scope, ledger=self.ledger, actor=actor, actor_kind="service")
            except PolicyViolation:
                gate = evaluate({"kind": "draft", "permission": "draft", "actor_kind": "service", "material_output": False,
                                 "rollout": self.rollout}, self.scope)
            if not gate.allowed:
                empty = ContextPackage(chunks=[], deterministic_findings=[], token_budget=0, tokens_used=0,
                                       truncated=False, excluded_by_scope=0, stale_included=0)
                reasons = "; ".join(r["reason"] for r in gate.reasons)
                return GenerationResult([], empty, self.deterministic.identity(), "halted",
                                        {"kept": [], "rejected": [], "all_distinct": True, "pairs": []}, {}, {},
                                        assess(evidence_refs=[], thresholds=self.thresholds).as_document(),
                                        gate.as_document(), {"prompt_id": "as.candidate_generation"}, False,
                                        [f"halted by rollout switch: {reasons}"])
        queries = [str(g.get("text", "")) for g in goals] + [str(c.get("text", "")) for c in constraints]
        context = build_context(retrieval=self.retrieval, scope=self.scope, queries=queries or ["architecture"],
                                analyzer_results=analyzer_results)
        prompt = {"prompt_id": "as.candidate_generation", "prompt_version": SYSTEM_PROMPTS["as.candidate_generation"]["version"],
                  "prompt_digest": prompt_digest("as.candidate_generation")}
        if self.ledger is not None:
            self.ledger.append("context.assembled", actor=actor, actor_kind="service", outcome="recorded",
                               subject=run_id, detail=context.as_document())
        mode, identity, fallback, diagnostics = "deterministic", self.deterministic.identity(), False, []
        model_payload: dict[str, Any] | None = None
        if self.slot.bound:
            decision = None
            if self.rollout is not None:
                action = {"kind": "model_call", "permission": "analyze", "actor_kind": "service",
                          "rollout": self.rollout, "material_output": False}
                try:
                    decision = enforce(action, self.scope, ledger=self.ledger, actor=actor, actor_kind="service")
                except PolicyViolation as exc:
                    # A policy stop on the model call is a typed fallback to the deterministic generator,
                    # never a crash and never a silent model call (XTOOL-07 / MODEL-05).
                    decision = evaluate(action, self.scope)
                    diagnostics.append(f"model call denied by policy: {exc}")
            allowed = decision is None or decision.allowed
            if allowed:
                try:
                    raw = self.slot.provider.complete(prompt_id=prompt["prompt_id"],
                                                      context_manifest_digest=context.manifest_digest,
                                                      payload={"goals": list(goals), "constraints": list(constraints)})
                    model_payload = validate("as.model_output/1", dict(raw))
                    mode, identity = "model", self.slot.provider.identity()
                except (ProviderError, SchemaError) as exc:
                    fallback = True
                    diagnostics.append(f"provider fallback: {type(exc).__name__}: {exc}")
                    if self.ledger is not None:
                        self.ledger.append("model.fallback", actor=actor, actor_kind="service", outcome="failed",
                                           subject=run_id, detail={"reason": str(exc), "fallback": "deterministic"})
        if self.ledger is not None:
            self.ledger.append("model.call", actor=actor, actor_kind="service", outcome="recorded", subject=run_id,
                               detail={"mode": mode, "identity": identity, "prompt": prompt,
                                       "context_manifest_digest": context.manifest_digest, "fallback": fallback})
        # Abstain before generating when the evidence base is empty.
        if not context.chunks:
            abstention = assess(evidence_refs=[], thresholds=self.thresholds).as_document()
            return GenerationResult([], context, identity, mode, {"kept": [], "rejected": [], "all_distinct": True, "pairs": []},
                                    {}, {}, abstention, {"verdict": "N/A"}, prompt, fallback, diagnostics)
        strategies = self.deterministic.strategies(self.index, goals) if model_payload is None else \
            list(model_payload["payload"].get("strategies", []))
        candidates: list[dict[str, Any]] = []
        for strategy in strategies:
            generator = {"generator_id": identity["provider"], "generator_version": identity["model_version"],
                         "model": identity if mode == "model" else None}
            unc = assess(evidence_refs=strategy["evidence_refs"], thresholds=self.thresholds,
                         inferred_fraction=sum(1 for r in strategy["rationale"] if r["derivation"] != "source") / max(1, len(strategy["rationale"])))
            try:
                candidate = build_candidate(run_id=run_id, iteration=iteration, name=strategy["name"], style=strategy["style"],
                                            components=strategy["components"], relationships=strategy["relationships"],
                                            deployment=strategy["deployment"], rationale=strategy["rationale"],
                                            evidence_refs=strategy["evidence_refs"], uncertainty=unc.as_document(),
                                            generator=generator, introduced_by=identity["provider"],
                                            assumptions=strategy.get("assumptions", []), risks=strategy.get("risks", []))
            except (SchemaError, ValueError) as exc:
                diagnostics.append(f"candidate rejected by schema: {exc}")
                continue
            for statement in strategy.get("assumptions", []):
                self.assumptions.register(statement, status="inferred", introduced_by=identity["provider"],
                                          affected_candidates=[candidate["candidate_id"]])
            candidates.append(candidate)
        distinct = assess_distinctness(candidates, self.rule)
        kept = [c for c in candidates if c["candidate_id"] in distinct["kept"]]
        checks = {c["candidate_id"]: self.checker.check(c) for c in kept}
        grounding = {c["candidate_id"]: evaluate_grounding(c, self.index).as_document() for c in kept}
        for c in kept:
            c["constraint_impacts"] = [{"constraint_id": ch["constraint_id"], "result": ch["result"], "rule_id": ch["rule_id"],
                                        "evidence_refs": ch["evidence_refs"][:3]} for ch in checks[c["candidate_id"]]]
            validate("as.candidate/1", c)
        coverage = min((g["coverage"] for g in grounding.values()), default=0.0)
        generic = [e for g in grounding.values() for e in g["generic_fallback"]]
        draft_action = {"kind": "draft", "permission": "draft", "actor_kind": "service", "material_output": bool(kept),
                          "evidence_refs": sorted({r for c in kept for r in c["evidence_refs"]}),
                          "grounding_coverage": coverage, "grounding_minimum": self.thresholds.min_grounding_coverage,
                        "generic_fallback_elements": generic, "session_ref": session_ref, "rollout": self.rollout,
                        "unlabelled_assertions": 0}
        try:
            policy = enforce(draft_action, self.scope, ledger=self.ledger, actor=actor, actor_kind="service")
        except PolicyViolation as exc:
            # A denied draft is an abstention with a reason, not an exception thrown at the caller:
            # the candidates are withheld and the denial travels in the result (PAPER-CAP-02 / XUNC-02).
            policy = evaluate(draft_action, self.scope)
            diagnostics.append(f"draft denied by policy: {exc}")
            kept, checks, grounding = [], {}, {}
        abstention = None
        if not kept:
            abstention = assess(evidence_refs=[], thresholds=self.thresholds,
                                generic_fallback=bool(generic), policy_stop=policy.verdict == "DENY").as_document()
        return GenerationResult(kept, context, identity, mode, distinct, checks, grounding, abstention,
                                policy.as_document(), prompt, fallback, diagnostics)
