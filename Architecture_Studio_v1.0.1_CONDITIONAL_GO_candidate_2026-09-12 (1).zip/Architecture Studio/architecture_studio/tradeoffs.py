"""Trade-off taxonomy and comparison model (AUDIT-ADD-10, COMP-06, PAPER-CAP-04, VERIFY-04).

Dimensions are source-derived: they exist because the pinned sources state a
constraint family in them (latency deadlines, resource envelopes, network
policy, deployment standards, governance separation, evidence obligations),
not because a scoring rubric wants them. Every cell is either quantitative with
a unit and a cited source, qualitative with a cited source, an explicit
inference, or ``unknown`` — and ``unknown`` stays visible ("missing criteria
remain visible", COMP-06).

Weights are never invented (AUDIT-ADD-10): ``weights`` is ``None`` unless a
human authority reference supplies them, and no aggregate score exists without
weights. The comparison names what it could not compare.

Build provenance: BUILD_NEW.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Iterable, Mapping, Sequence

from .canonical import fmt_ts
from .connectors.normalize import NormalizedIndex
from .ids import deterministic_id
from .schemas import validate
from .uncertainty import assess

__all__ = ["TAXONOMY", "TAXONOMY_VERSION", "compare", "uncited_material_claims"]

TAXONOMY_VERSION = "1.0.0"

#: dimension -> (source data classes that ground it, representation, description)
TAXONOMY: dict[str, dict[str, Any]] = {
    "component_count": {"grounds": ("service",), "representation": "quantitative", "unit": "components",
                        "description": "Number of components a reviewer must operate and audit."},
    "governance_separation": {"grounds": ("adr", "security_constraint"), "representation": "qualitative",
                              "description": "Whether judgment, validation, application, explanation and evidence stay separate (ADR-003)."},
    "network_exposure": {"grounds": ("security_constraint", "adr"), "representation": "qualitative",
                         "description": "External components or outbound calls against the deny-by-default network policy."},
    "resource_envelope_fit": {"grounds": ("cost_perf_constraint",), "representation": "quantitative", "unit": "vcpu",
                              "description": "Declared replica footprint against the pinned cpu envelope."},
    "deployment_standard_fit": {"grounds": ("deployment_standard",), "representation": "qualitative",
                                "description": "Environments and target against the pinned deployment standards."},
    "call_chain_depth": {"grounds": ("nfr", "api_operation"), "representation": "quantitative", "unit": "hops",
                         "description": "Longest synchronous call chain against stated per-call deadlines."},
    "evidence_coverage": {"grounds": ("requirement", "service", "adr"), "representation": "quantitative", "unit": "fraction",
                          "description": "Fraction of material elements grounded in local evidence."},
    "open_assumptions": {"grounds": ("adr",), "representation": "quantitative", "unit": "assumptions",
                         "description": "Labelled assumptions the option rests on."},
}


def _chain_depth(candidate: Mapping[str, Any]) -> int:
    calls = [r for r in candidate.get("relationships", []) if r.get("kind") == "calls"]
    out: dict[str, list[str]] = {}
    for r in calls:
        out.setdefault(r["source"], []).append(r["target"])

    def depth(node: str, seen: frozenset[str]) -> int:
        if node in seen or node not in out:
            return 0
        return 1 + max(depth(t, seen | {node}) for t in out[node])
    return max((depth(s, frozenset()) for s in out), default=0)


def _cell(candidate_id: str, dimension: str, *, value_kind: str, value: Any, statement: str, derivation: str,
          evidence_refs: Sequence[str], unit: str | None = None) -> dict[str, Any]:
    return {"candidate_id": candidate_id, "dimension": dimension, "value_kind": value_kind, "value": value,
            "unit": unit, "derivation": derivation, "evidence_refs": list(evidence_refs), "statement": statement}


def compare(*, run_id: str, candidates: Sequence[Mapping[str, Any]], index: NormalizedIndex,
            constraint_checks: Mapping[str, Sequence[Mapping[str, Any]]], grounding: Mapping[str, Mapping[str, Any]],
            assumptions: Mapping[str, int] | None = None, weights: Mapping[str, float] | None = None,
            weight_authority_ref: str | None = None) -> dict[str, Any]:
    """Build the structured comparison artifact. Never invents weights or numbers."""
    if len(candidates) < 2:
        raise ValueError("a comparison needs at least two candidates")
    if weights is not None and not weight_authority_ref:
        raise ValueError("weights require a human authority reference; none supplied")
    cells: list[dict[str, Any]] = []
    missing: set[str] = set()
    unresolved: list[str] = []
    envelope = [r for r in index.by_class("cost_perf_constraint") if r["payload"].get("metric") == "cpu"]
    for candidate in candidates:
        cid = candidate["candidate_id"]
        checks = {c["rule_id"]: c for c in constraint_checks.get(cid, [])}
        comp_refs = [r for c in candidate["components"] for r in c.get("evidence_refs", [])][:3]
        cells.append(_cell(cid, "component_count", value_kind="quantitative", value=len(candidate["components"]),
                           unit="components", statement=f"{len(candidate['components'])} components declared",
                           derivation="deterministic_analyzer", evidence_refs=comp_refs))
        for dimension, rule in (("governance_separation", "RULE-GOV-SEP-01"), ("network_exposure", "RULE-SEC-NET-01"),
                                ("deployment_standard_fit", "RULE-DEP-TGT-01")):
            check = checks.get(rule)
            if check is None or check["result"] == "unknown":
                cells.append(_cell(cid, dimension, value_kind="unknown", value=None,
                                   statement=(check or {}).get("message", "no deterministic check ran"),
                                   derivation="deterministic_analyzer", evidence_refs=(check or {}).get("evidence_refs", [])))
                missing.add(dimension)
            else:
                cells.append(_cell(cid, dimension, value_kind="qualitative", value=check["result"],
                                   statement=check["message"], derivation="deterministic_analyzer",
                                   evidence_refs=check["evidence_refs"]))
        cost = checks.get("RULE-COST-ENV-01")
        if cost is None or cost["result"] == "unknown":
            cells.append(_cell(cid, "resource_envelope_fit", value_kind="unknown", value=None, unit="vcpu",
                               statement=(cost or {}).get("message", "no envelope check"), derivation="deterministic_analyzer",
                               evidence_refs=[r["provenance_ref_id"] for r in envelope[:2]]))
            missing.add("resource_envelope_fit")
            unresolved.append(f"{cid}: cpu per replica is not stated in the sources; no number was invented")
        else:
            cells.append(_cell(cid, "resource_envelope_fit", value_kind="qualitative", value=cost["result"], unit="vcpu",
                               statement=cost["message"], derivation="deterministic_analyzer", evidence_refs=cost["evidence_refs"]))
        depth = _chain_depth(candidate)
        latency = checks.get("RULE-NFR-LAT-01")
        cells.append(_cell(cid, "call_chain_depth", value_kind="quantitative", value=depth, unit="hops",
                           statement=(latency or {}).get("message", f"call chain depth {depth}"),
                           derivation="deterministic_analyzer",
                           evidence_refs=(latency or {}).get("evidence_refs")
                           or sorted({r for rel in candidate.get("relationships", []) for r in rel.get("evidence_refs", [])})[:6]
                           or sorted({r for comp in candidate.get("components", []) for r in comp.get("evidence_refs", [])})[:6]))
        cov = grounding.get(cid, {}).get("coverage")
        cells.append(_cell(cid, "evidence_coverage", value_kind="quantitative" if cov is not None else "unknown",
                           value=round(cov, 4) if cov is not None else None, unit="fraction",
                           statement=f"{cov:.0%} of material elements grounded" if cov is not None else "grounding not evaluated",
                           derivation="deterministic_analyzer", evidence_refs=comp_refs))
        n_assumptions = (assumptions or {}).get(cid, len(candidate.get("assumptions", [])))
        cells.append(_cell(cid, "open_assumptions", value_kind="quantitative", value=n_assumptions, unit="assumptions",
                           statement=f"{n_assumptions} labelled assumption(s)", derivation="deterministic_analyzer",
                           evidence_refs=comp_refs))
    differences = _differences(candidates, cells)
    unc = assess(evidence_refs=sorted({r for c in cells for r in c["evidence_refs"]}) or ["none"],
                 missing_context=sorted(missing))
    doc = {"schema_id": "as.comparison/1",
           "comparison_id": deterministic_id("comparison", run=run_id, candidates=sorted(c["candidate_id"] for c in candidates)),
           "run_id": run_id, "candidate_ids": [c["candidate_id"] for c in candidates], "taxonomy_version": TAXONOMY_VERSION,
           "dimensions": list(TAXONOMY), "cells": cells, "differences": differences, "unresolved": unresolved,
           "missing_criteria": sorted(missing), "weights": dict(weights) if weights else None,
           "weight_authority_ref": weight_authority_ref, "uncertainty": unc.as_document(),
           "built_at": fmt_ts(datetime.now(timezone.utc))}
    return validate("as.comparison/1", doc)


def _differences(candidates: Sequence[Mapping[str, Any]], cells: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for dimension in TAXONOMY:
        values = {c["candidate_id"]: c for c in cells if c["dimension"] == dimension}
        if len({str(v["value"]) for v in values.values()}) > 1:
            refs = sorted({r for v in values.values() for r in v["evidence_refs"]})[:5]
            parts = "; ".join(f"{cid[:12]}={v['value']}" for cid, v in sorted(values.items()))
            out.append({"dimension": dimension, "statement": f"candidates differ on {dimension}: {parts}",
                        "derivation": "deterministic_analyzer", "evidence_refs": refs})
    return out


def uncited_material_claims(comparison: Mapping[str, Any]) -> list[dict[str, Any]]:
    """VERIFY-04: every material trade-off statement carries a citation or an inference marker."""
    problems = []
    for cell in comparison["cells"]:
        if cell["value_kind"] in ("quantitative", "qualitative") and not cell["evidence_refs"] \
                and cell["derivation"] not in ("model_inference",):
            problems.append({"candidate_id": cell["candidate_id"], "dimension": cell["dimension"],
                             "reason": "material claim without evidence reference or inference marker"})
    for diff in comparison["differences"]:
        if not diff["evidence_refs"] and diff["derivation"] != "model_inference":
            problems.append({"dimension": diff["dimension"], "reason": "difference statement without citation"})
    return problems
