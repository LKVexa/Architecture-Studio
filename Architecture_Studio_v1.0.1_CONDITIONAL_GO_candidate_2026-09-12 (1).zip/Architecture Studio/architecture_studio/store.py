"""Persistent state/context store (ARCH-03, STORE-01, STORE-02, STORE-04, STORE-05, AUDIT-ADD-15, XSTATE-03).

Storage is a content-addressed object store plus an append-only ref log, on
plain files: every write is atomic (temp + fsync + rename), every snapshot is
immutable once written, and a ref update is a compare-and-swap against the
expected previous snapshot — which is how concurrent updaters are serialized
without a lock server (AUDIT-ADD-15: a stale write raises
:class:`ConcurrencyError`; nothing is overwritten silently).

Recovery is a consequence of the layout: objects are self-verifying by name, so
a corrupt object is detectable on read, and :meth:`ObjectStore.verify` reports
exactly which snapshots are unreadable. Retention writes tombstones (STORE-06)
and never rewrites history, so the record of *what was deleted and when*
survives the deletion; the deleted payload is removed from the object tree
(AUDIT-ADD-17 reconciliation lives in :mod:`architecture_studio.retention`).

Adapted from the owner's Repository Context Graph runtime (``rcg/versionstore.py``).
"""
from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping

from .canonical import canonical_bytes, compact_json, fmt_ts, parse_ts, sha256_hex, sha256_of
from .evidence_io import atomic_write, loads_strict

__all__ = ["StoreError", "ConcurrencyError", "Snapshot", "ObjectStore", "STORE_SCHEMA_VERSION", "MIGRATIONS"]

STORE_SCHEMA_VERSION = 1
MIGRATIONS: dict[int, str] = {1: "initial: objects + refs + reflog + tombstones"}


class StoreError(RuntimeError):
    pass


class ConcurrencyError(StoreError):
    """A ref moved under us. The caller must re-read and retry (AUDIT-ADD-15)."""


@dataclass(frozen=True)
class Snapshot:
    snapshot_id: str
    ref: str
    revision: int
    parent: str | None
    payload_digest: str
    created_at: str
    lifecycle: str
    retention_expires_at: str | None
    metadata: Mapping[str, Any]

    def as_document(self) -> dict[str, Any]:
        return {"snapshot_id": self.snapshot_id, "ref": self.ref, "revision": self.revision,
                "parent": self.parent, "payload_digest": self.payload_digest, "created_at": self.created_at,
                "lifecycle": self.lifecycle, "retention_expires_at": self.retention_expires_at,
                "metadata": dict(self.metadata)}


class ObjectStore:
    """Content-addressed, append-only temporal store."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.objects = self.root / "objects"
        self.refs = self.root / "refs"
        self.log = self.root / "REFLOG.jsonl"
        for directory in (self.objects, self.refs):
            directory.mkdir(parents=True, exist_ok=True)
        meta = self.root / "STORE.json"
        if not meta.exists():
            atomic_write(meta, canonical_bytes({"schema_version": STORE_SCHEMA_VERSION, "created_at": _now(),
                                                "migrations_applied": sorted(MIGRATIONS)}))
        self.schema_version = loads_strict(meta.read_bytes())["schema_version"]
        if self.schema_version > STORE_SCHEMA_VERSION:
            raise StoreError(f"store schema {self.schema_version} is newer than this runtime supports")

    # -------------------------------------------------------------- objects --
    def put_object(self, payload: Any) -> str:
        data = canonical_bytes(payload)
        digest = sha256_hex(data)
        path = self._object_path(digest)
        if not path.exists():
            atomic_write(path, data)
        return "sha256:" + digest

    def get_object(self, digest: str) -> Any:
        hexd = digest.split(":", 1)[-1]
        path = self._object_path(hexd)
        if not path.exists():
            raise StoreError(f"object {digest} is missing from the store")
        data = path.read_bytes()
        if sha256_hex(data) != hexd:
            raise StoreError(f"object {digest} is corrupt: content does not match its name")
        return loads_strict(data, expect=(dict, list))

    def has_object(self, digest: str) -> bool:
        return self._object_path(digest.split(":", 1)[-1]).exists()

    def _object_path(self, hexd: str) -> Path:
        return self.objects / hexd[:2] / hexd[2:]

    # ---------------------------------------------------------------- refs --
    def head(self, ref: str) -> Snapshot | None:
        path = self._ref_path(ref)
        if not path.exists():
            return None
        return _snapshot_from(loads_strict(path.read_bytes()))

    def commit(self, ref: str, payload: Any, *, expected_parent: str | None = "__unset__",
               metadata: Mapping[str, Any] | None = None, lifecycle: str = "active",
               retention_days: int | None = None) -> Snapshot:
        """Append a snapshot to ``ref``, compare-and-swapping on the parent snapshot id."""
        current = self.head(ref)
        current_id = current.snapshot_id if current else None
        if expected_parent != "__unset__" and expected_parent != current_id:
            raise ConcurrencyError(f"ref {ref!r} expected parent {expected_parent!r} but found {current_id!r}")
        if current is not None and current.lifecycle == "tombstoned" and lifecycle != "tombstoned":
            raise StoreError(f"ref {ref!r} is tombstoned; it cannot be resurrected")
        payload_digest = self.put_object(payload)
        revision = (current.revision + 1) if current else 0
        record = {
            "ref": ref, "revision": revision, "parent": current_id, "payload_digest": payload_digest,
            "created_at": _now(), "lifecycle": lifecycle,
            "retention_expires_at": fmt_ts(datetime.now(timezone.utc) + timedelta(days=retention_days))
            if retention_days is not None else None,
            "metadata": dict(metadata or {}), "schema_version": self.schema_version,
        }
        record["snapshot_id"] = sha256_of(compact_json(record))
        atomic_write(self._ref_path(ref), canonical_bytes(record))
        with self.log.open("a", encoding="utf-8", newline="") as handle:
            handle.write(compact_json(record) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        return _snapshot_from(record)

    def history(self, ref: str) -> list[Snapshot]:
        if not self.log.exists():
            return []
        out = []
        with self.log.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if line:
                    record = json.loads(line)
                    if record["ref"] == ref:
                        out.append(_snapshot_from(record))
        return sorted(out, key=lambda s: s.revision)

    def at_revision(self, ref: str, revision: int) -> Any:
        for snapshot in self.history(ref):
            if snapshot.revision == revision:
                return self.get_object(snapshot.payload_digest)
        raise StoreError(f"ref {ref!r} has no revision {revision}")

    def refs_list(self) -> list[str]:
        return sorted(str(p.relative_to(self.refs)).replace(os.sep, "/") for p in self.refs.rglob("*") if p.is_file())

    def _ref_path(self, ref: str) -> Path:
        safe = ref.strip("/")
        if not safe or ".." in Path(safe).parts or "\x00" in safe:
            raise StoreError(f"illegal ref name {ref!r}")
        return self.refs / safe

    # --------------------------------------------------------- housekeeping --
    def tombstone(self, ref: str, *, reason: str, erase_payload: bool) -> Snapshot | None:
        """STORE-06 / AUDIT-ADD-17: retire a ref; history keeps the fact, not the bytes."""
        head = self.head(ref)
        if not head or head.lifecycle == "tombstoned":
            return None
        snapshot = self.commit(ref, {"tombstone": True, "superseded": head.snapshot_id},
                               expected_parent=head.snapshot_id, lifecycle="tombstoned",
                               metadata={"reason": reason, "original_payload_digest": head.payload_digest,
                                         "payload_erased": erase_payload})
        if erase_payload:
            for past in self.history(ref):
                if past.lifecycle != "tombstoned" and not self._referenced_elsewhere(past.payload_digest, ref):
                    path = self._object_path(past.payload_digest.split(":", 1)[-1])
                    if path.exists():
                        path.unlink()
        return snapshot

    def _referenced_elsewhere(self, digest: str, except_ref: str) -> bool:
        for other in self.refs_list():
            if other == except_ref:
                continue
            if any(s.payload_digest == digest for s in self.history(other)):
                return True
        return False

    def expire(self, *, now: datetime | None = None) -> list[str]:
        moment = now or datetime.now(timezone.utc)
        expired: list[str] = []
        for ref in self.refs_list():
            head = self.head(ref)
            if not head or not head.retention_expires_at or head.lifecycle == "tombstoned":
                continue
            if parse_ts(head.retention_expires_at) <= moment:
                self.tombstone(ref, reason="retention_expired", erase_payload=True)
                expired.append(ref)
        return expired

    def verify(self) -> dict[str, Any]:
        problems: list[dict[str, str]] = []
        checked = 0
        for ref in self.refs_list():
            for snapshot in self.history(ref):
                checked += 1
                if snapshot.lifecycle == "tombstoned":
                    continue
                try:
                    self.get_object(snapshot.payload_digest)
                except StoreError as exc:
                    head = self.head(ref)
                    if head is not None and head.lifecycle == "tombstoned" and head.metadata.get("payload_erased"):
                        continue   # erased on purpose; the tombstone records it
                    problems.append({"ref": ref, "revision": str(snapshot.revision), "error": str(exc)})
        return {"snapshots_checked": checked, "problems": problems, "ok": not problems}

    def backup(self, destination: Path) -> dict[str, Any]:
        destination = Path(destination)
        if destination.exists():
            shutil.rmtree(destination)
        shutil.copytree(self.root, destination)
        manifest = {"backup_of": str(self.root), "created_at": _now(),
                    "refs": {ref: (self.head(ref).snapshot_id if self.head(ref) else None) for ref in self.refs_list()},
                    "object_count": sum(1 for p in self.objects.rglob("*") if p.is_file())}
        manifest["manifest_digest"] = sha256_of(canonical_bytes(manifest))
        atomic_write(destination / "BACKUP_MANIFEST.json", canonical_bytes(manifest))
        return manifest

    @staticmethod
    def restore(backup: Path, destination: Path) -> "ObjectStore":
        backup, destination = Path(backup), Path(destination)
        manifest_path = backup / "BACKUP_MANIFEST.json"
        if not manifest_path.exists():
            raise StoreError("backup has no manifest; refusing to restore an unverified copy")
        manifest = loads_strict(manifest_path.read_bytes())
        expected = manifest.pop("manifest_digest")
        if sha256_of(canonical_bytes(manifest)) != expected:
            raise StoreError("backup manifest digest mismatch; refusing to restore")
        if destination.exists():
            shutil.rmtree(destination)
        shutil.copytree(backup, destination)
        (destination / "BACKUP_MANIFEST.json").unlink()
        store = ObjectStore(destination)
        report = store.verify()
        if not report["ok"]:
            raise StoreError(f"restored store failed verification: {report['problems']}")
        for ref, snapshot_id in manifest["refs"].items():
            head = store.head(ref)
            if (head.snapshot_id if head else None) != snapshot_id:
                raise StoreError(f"restored ref {ref!r} does not match the backup manifest")
        return store


def _snapshot_from(record: Mapping[str, Any]) -> Snapshot:
    return Snapshot(snapshot_id=record["snapshot_id"], ref=record["ref"], revision=record["revision"],
                    parent=record["parent"], payload_digest=record["payload_digest"],
                    created_at=record["created_at"], lifecycle=record.get("lifecycle", "active"),
                    retention_expires_at=record.get("retention_expires_at"), metadata=record.get("metadata", {}))


def _now() -> str:
    return fmt_ts(datetime.now(timezone.utc))
