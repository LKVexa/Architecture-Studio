"""Release, versioning, promotion and rollback (AUDIT-ADD-21, XEVAL-07, XSTATE-02).

A release candidate is a *manifest*: every versioned component (runtime,
schemas, policy, prompts, analyzers, benchmark corpus, documentation), the
digest of the overlay tree it was cut from, the corpus baseline digest, the
benchmark/evaluation report digests it was qualified against, and the
promotion chain it may travel. :func:`qualify` applies the documented
acceptance rule — every required report present, every gate that must be PASS
is PASS, no threshold in PROPOSED state counted as met, rollback procedure
present and exercised — and returns ``QUALIFIED`` or ``NOT_QUALIFIED`` with
the reasons. Nothing here promotes: promotion is a human act recorded through
:class:`architecture_studio.review.ApprovalGate`; this module only says whether
the candidate is eligible to be proposed.

Rollback: :func:`rollback_plan` names the previous release manifest, the store
refs that keep their history (the object store is append-only, so rolling back
the runtime never orphans stored state or provenance) and the schema versions
that must remain readable (the registry keeps every version it has ever
registered).
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

from . import PACKAGE_VERSION_APPLIED, __version__, version_manifest
from .canonical import canonical_bytes, fmt_ts, sha256_hex, sha256_of
from .evidence_io import atomic_write, loads_strict
from .schemas import schema_versions

__all__ = ["RELEASE_SCHEMA", "CONDITIONAL_GO_SCHEMA", "PROMOTION_CHAIN", "CONDITIONAL_GO_ENVIRONMENTS",
           "tree_digest", "build_manifest", "qualify", "conditional_qualify", "rollback_plan", "ACCEPTANCE_RULE"]

RELEASE_SCHEMA = "as.release_manifest/1"
CONDITIONAL_GO_SCHEMA = "as.conditional_go/1"
PROMOTION_CHAIN = ("local", "ci", "staging", "production_read_only")
CONDITIONAL_GO_ENVIRONMENTS = ("local", "test_tenant")
EXCLUDED_DIRS = {".git", "__pycache__", "evidence", ".pytest_cache"}

#: XEVAL-07 documented acceptance rule. Evaluated mechanically by :func:`qualify`.
ACCEPTANCE_RULE: dict[str, Any] = {
    "rule_id": "ACCEPT-RELEASE-01", "version": "1.0.0", "status": "PROPOSED", "owner_role": "release_owner",
    "required_reports": ["tests", "benchmark", "evaluation", "supply_chain", "gates"],
    "required_pass": {"tests": "all suites PASS", "supply_chain": "policy PASS", "gates": "every GATE-PROD-* PASS for production; "
                      "for staging, GATE-PROD-01/03/04/05 PASS"},
    "threshold_rule": "a PROPOSED threshold never counts as met; qualification for production requires APPROVED thresholds",
    "rollback_rule": "a rollback plan must exist and the recovery exercise (AUDIT-ADD-20) must have passed in this release's evidence",
}


def tree_digest(root: Path, *, exclude: Iterable[str] = EXCLUDED_DIRS) -> dict[str, Any]:
    """Deterministic digest of the overlay tree (paths + contents), excluding evidence and VCS metadata."""
    root = Path(root)
    exclude = set(exclude)
    files = []
    h = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if any(part in exclude for part in rel.parts) or not path.is_file():
            continue
        digest = sha256_hex(path.read_bytes())
        files.append((rel.as_posix(), digest))
        h.update(f"{rel.as_posix()}\0{digest}\n".encode("utf-8"))
    return {"root": root.name, "root_portable": True, "files": len(files), "digest": "sha256:" + h.hexdigest()}


def build_manifest(*, overlay_root: Path, corpus_digest: str, reports: Mapping[str, str], environment: str = "local",
                   previous_release: str | None = None, changelog_ref: str = "CHANGELOG.md") -> dict[str, Any]:
    tree = tree_digest(overlay_root)
    manifest = {
        "schema_id": RELEASE_SCHEMA, "release": __version__, "package_applied": PACKAGE_VERSION_APPLIED,
        "cut_at": fmt_ts(datetime.now(timezone.utc)), "components": version_manifest(), "schemas": schema_versions(),
        "overlay_tree": tree, "corpus_baseline_digest": corpus_digest, "reports": dict(sorted(reports.items())),
        "environment": environment, "promotion_chain": list(PROMOTION_CHAIN), "previous_release": previous_release,
        "changelog_ref": changelog_ref, "acceptance_rule": ACCEPTANCE_RULE,
    }
    manifest["manifest_digest"] = sha256_of(canonical_bytes(manifest))
    return manifest


def qualify(manifest: Mapping[str, Any], *, test_report: Mapping[str, Any] | None, benchmark_report: Mapping[str, Any] | None,
            evaluation_report: Mapping[str, Any] | None, supply_chain_report: Mapping[str, Any] | None,
            gate_report: Mapping[str, Any] | None, recovery_exercise: Mapping[str, Any] | None,
            target_environment: str) -> dict[str, Any]:
    reasons: list[str] = []
    present = {"tests": test_report, "benchmark": benchmark_report, "evaluation": evaluation_report,
               "supply_chain": supply_chain_report, "gates": gate_report}
    for name in ACCEPTANCE_RULE["required_reports"]:
        if present.get(name) is None:
            reasons.append(f"required report missing: {name}")
    if test_report is not None and not test_report.get("all_passed", False):
        reasons.append("test report is not all-pass")
    if supply_chain_report is not None and supply_chain_report.get("verdict") != "PASS":
        reasons.append("supply-chain policy check did not PASS")
    if gate_report is not None:
        required = {"staging": ("GATE-PROD-01", "GATE-PROD-03", "GATE-PROD-04", "GATE-PROD-05")}.get(
            target_environment, tuple(g["gate_id"] for g in gate_report.get("gates", [])))
        status = {g["gate_id"]: g["status"] for g in gate_report.get("gates", [])}
        for gate_id in required:
            if status.get(gate_id) != "PASS":
                reasons.append(f"{gate_id} is {status.get(gate_id, 'absent')}, not PASS")
    if benchmark_report is not None and benchmark_report.get("thresholds_status") == "PROPOSED" \
            and target_environment in ("production_read_only", "privileged_execution"):
        reasons.append("benchmark thresholds are PROPOSED; production qualification requires APPROVED thresholds")
    if recovery_exercise is None or not recovery_exercise.get("passed"):
        reasons.append("recovery exercise absent or failed")
    if target_environment not in PROMOTION_CHAIN:
        reasons.append(f"unknown target environment {target_environment!r}")
    else:
        idx = PROMOTION_CHAIN.index(target_environment)
        if idx > 0 and manifest.get("environment") != PROMOTION_CHAIN[idx - 1] and manifest.get("environment") != target_environment:
            reasons.append(f"promotion to {target_environment} must come from {PROMOTION_CHAIN[idx - 1]}, not {manifest.get('environment')}")
    return {"release": manifest.get("release"), "manifest_digest": manifest.get("manifest_digest"),
            "target_environment": target_environment, "verdict": "QUALIFIED" if not reasons else "NOT_QUALIFIED",
            "reasons": reasons, "acceptance_rule": ACCEPTANCE_RULE["rule_id"], "acceptance_rule_status": ACCEPTANCE_RULE["status"],
            "promotion_is_a_human_act": True}


def conditional_qualify(*, manifest: Mapping[str, Any], evidence: Mapping[str, Any],
                        gate_report: Mapping[str, Any], target_environment: str = "local",
                        now: datetime | None = None, validity_hours: int = 72) -> dict[str, Any]:
    """Qualify a candidate for a bounded, non-production evaluation scope.

    Conditional GO is intentionally distinct from :func:`qualify` and from
    :func:`production_verdict`.  It is a mechanical release recommendation for
    the local or synthetic test-tenant boundary only.  It cannot promote,
    approve thresholds, create an independent review, bind a host IdP/KMS, or
    turn a production ``NO_GO`` into ``GO``.

    The minimum bar is deliberately operational: the complete suite, clean
    write-authority scan, real-run VERIFY-01, incident drill, recovery exercise,
    current DOC-11/DOC-12, and the mechanical pass for controls, bypass
    resistance, and provenance.  Human review and host prerequisites remain
    explicit conditions on the returned record.
    """
    if not isinstance(validity_hours, int) or not 1 <= validity_hours <= 168:
        raise ValueError("validity_hours must be an integer from 1 through 168")

    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    issued_at = fmt_ts(now)
    expires_at = fmt_ts(now + timedelta(hours=validity_hours))

    hard_blockers: list[str] = []
    conditions: list[dict[str, Any]] = []

    if target_environment not in CONDITIONAL_GO_ENVIRONMENTS:
        hard_blockers.append(f"target environment {target_environment!r} is outside the conditional scope")
    if manifest.get("environment") not in (None, target_environment, "local"):
        hard_blockers.append(f"manifest environment {manifest.get('environment')!r} is not the conditional source")

    tests = evidence.get("tests")
    if not tests or not tests.get("all_passed"):
        hard_blockers.append("the complete candidate test suite is not all-pass")
    else:
        conditions.append({"id": "CG-01", "status": "SATISFIED", "control": "complete test suite",
                           "evidence": f"{tests.get('passed', 0)}/{tests.get('total', 0)} tests passed"})

    benchmark = evidence.get("benchmark")
    if not benchmark or not benchmark.get("suite_passed") or not benchmark.get("all_guardrail_cases_pass"):
        hard_blockers.append("benchmark or guardrail cases are missing or failed")
    elif benchmark.get("thresholds_status") != "APPROVED":
        conditions.append({"id": "CG-02", "status": "CONDITION", "control": "evaluation thresholds",
                           "requirement": "thresholds remain PROPOSED; use measurements for evaluation only",
                           "evidence": benchmark.get("report_digest")})
    else:
        conditions.append({"id": "CG-02", "status": "SATISFIED", "control": "approved evaluation thresholds",
                           "evidence": benchmark.get("report_digest")})

    scan = evidence.get("write_authority_scan") or {}
    if scan.get("verdict") != "PASS" or scan.get("hidden_write_paths"):
        hard_blockers.append("write-authority scan is not clean")
    else:
        conditions.append({"id": "CG-03", "status": "SATISFIED", "control": "write authority",
                           "evidence": f"{scan.get('write_sites', 0)} classified site(s), zero hidden"})

    verification = evidence.get("verification") or {}
    verify_01 = next((row for row in verification.get("checks", []) if row.get("check_id") == "VERIFY-01"), None)
    if not verify_01 or verify_01.get("result") != "PASS":
        hard_blockers.append("real-run VERIFY-01 evidence is absent or failed")
    else:
        conditions.append({"id": "CG-04", "status": "SATISFIED", "control": "output provenance",
                           "evidence": verify_01.get("summary")})

    drill = evidence.get("incident_drill") or {}
    recovery = evidence.get("recovery_exercise") or {}
    if not drill.get("passed") or not recovery.get("passed"):
        hard_blockers.append("incident drill and recovery exercise must both pass")
    else:
        conditions.append({"id": "CG-05", "status": "SATISFIED", "control": "rollback and incident readiness",
                           "evidence": "incident drill passed; recovery exercise passed"})

    docs = evidence.get("docs") or {}
    doc_rows = {row.get("doc_id"): row for row in docs.get("documents", [])}
    docs_current = all(doc_rows.get(doc_id, {}).get("current") for doc_id in ("DOC-11", "DOC-12"))
    if not docs_current:
        for doc_id in ("DOC-11", "DOC-12"):
            if not doc_rows.get(doc_id, {}).get("current"):
                hard_blockers.append(f"{doc_id} is missing or stale")
    if docs_current and not doc_rows["DOC-12"].get("published_ref"):
        hard_blockers.append("DOC-12 has no publication reference")
    elif docs_current:
        conditions.append({"id": "CG-06", "status": "SATISFIED", "control": "operational limitations",
                           "evidence": doc_rows.get("DOC-12", {}).get("published_ref")})

    gates = {row.get("gate_id"): row for row in gate_report.get("gates", [])}
    required_mechanical = ("GATE-PROD-01", "GATE-PROD-03", "GATE-PROD-04", "GATE-PROD-05", "GATE-PROD-06", "GATE-PROD-08")
    for gate_id in required_mechanical:
        row = gates.get(gate_id)
        if not row or row.get("mechanical") != "EVIDENCE_PASS":
            hard_blockers.append(f"{gate_id} lacks passing mechanical evidence")

    pending_reviews = [gate_id for gate_id, row in gates.items() if row.get("status") != "PASS"]
    if pending_reviews:
        conditions.append({"id": "CG-07", "status": "CONDITION", "control": "independent review",
                           "requirement": "human reviewers must review the evidence before any broader promotion",
                           "pending_gates": pending_reviews})

    gate_07 = gates.get("GATE-PROD-07")
    if gate_07 and gate_07.get("status") == "NO_EVIDENCE":
        conditions.append({"id": "CG-08", "status": "CONDITION", "control": "security and privacy review",
                           "requirement": "independent human security/privacy review is still required",
                           "gate": "GATE-PROD-07"})
    elif gate_07 and gate_07.get("status") not in ("PASS", "AWAITING_INDEPENDENT_REVIEW"):
        hard_blockers.append("GATE-PROD-07 has a failing security/privacy status")

    conditions.extend([
        {"id": "CG-09", "status": "CONDITION", "control": "scope boundary",
         "requirement": "local or synthetic test-tenant data only; no production or live connector access"},
        {"id": "CG-10", "status": "CONDITION", "control": "permission boundary",
         "requirement": "draft_only/read_only; no modify, commit, deploy, or external writes"},
        {"id": "CG-11", "status": "CONDITION", "control": "runtime boundary",
         "requirement": "no host IdP, KMS, CI, staging, privileged environment, or model provider is claimed"},
        {"id": "CG-12", "status": "CONDITION", "control": "expiry",
         "requirement": f"re-qualify after {expires_at}", "expires_at": expires_at},
    ])

    production = "NO_GO"
    return {
        "schema_id": CONDITIONAL_GO_SCHEMA,
        "release": manifest.get("release"),
        "manifest_digest": manifest.get("manifest_digest"),
        "issued_at": issued_at,
        "expires_at": expires_at,
        "validity_hours": validity_hours,
        "target_environment": target_environment,
        "scope": {
            "data": "local checkout or synthetic test tenant only",
            "mode": "draft_only/read_only",
            "allowed_permissions": ["read", "analyze", "draft", "write_evidence"],
            "forbidden_permissions": ["modify", "commit", "deploy", "network_write"],
            "model_provider": "unbound; deterministic evidence generator only",
        },
        "verdict": "CONDITIONAL_GO" if not hard_blockers else "NOT_CONDITIONALLY_QUALIFIED",
        "production_verdict": production,
        "promotion_authorized": False,
        "hard_blockers": hard_blockers,
        "conditions": conditions,
        "pending_independent_reviews": pending_reviews,
        "evidence_digest": evidence.get("evidence_digest"),
        "note": ("Conditional GO is a time-bounded, local/test-tenant evaluation recommendation. "
                  "It is not Production GO, approval, independent verification, or promotion."),
    }


def rollback_plan(current: Mapping[str, Any], previous: Mapping[str, Any] | None) -> dict[str, Any]:
    return {
        "from_release": current.get("release"), "to_release": previous.get("release") if previous else None,
        "to_manifest_digest": previous.get("manifest_digest") if previous else None,
        "steps": [
            "1. Halt: set as.enabled=false through the flag store (incident.FlagStore.emergency_disable) — new runs refuse to start.",
            "2. Preserve: export a case file for every run in a non-terminal state (casefile.export_case_file).",
            "3. Restore code: check out the previous release tag; the object store is append-only and content-addressed, "
            "so no stored state or provenance is rewritten by the code change.",
            "4. Schemas: the previous runtime reads every schema version it registered; newer-schema objects remain in the store "
            "untouched and are reported by store.verify() as 'unreadable by this runtime' rather than deleted.",
            "5. Re-enable only after tests/run_all.py passes on the restored tree and a human records the decision.",
        ],
        "state_preserved": ["object store (all revisions)", "run ledgers (hash-chained)", "flag store history", "evidence records"],
        "verified_by": "backup.exercise (AUDIT-ADD-20) + tests/test_environments_release.py",
        "no_previous_release": previous is None,
    }


def write_manifest(manifest: Mapping[str, Any], path: Path) -> None:
    atomic_write(Path(path), canonical_bytes(manifest))


def read_manifest(path: Path) -> dict[str, Any]:
    return loads_strict(Path(path).read_bytes())
