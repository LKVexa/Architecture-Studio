"""Sibling project-corpus contract and preflight (ASGO-0.3, 0.5, 0.6, 2.1).

Architecture Studio is an **overlay-only** product: it sits in one directory on
top of a generic 612-file corpus it must never modify. The corpus is a sibling
of that overlay (``overlay.parent``), not files inside the overlay and not
archive-wrapper files such as an outer ``SHA256SUMS.txt``.

Missing, wrong-root, or digest-mismatched corpora fail closed with an
actionable code. This module does not approve a production GO.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Iterable

__all__ = [
    "EXPECTED_FILES",
    "EXPECTED_DIGEST",
    "SKIP_TOP_LEVEL_DIRS",
    "SKIP_TOP_LEVEL_FILES",
    "PRODUCT_KIND",
    "iter_corpus_files",
    "corpus_digest",
    "preflight",
    "product_contract",
    "CORPUS_VERSION",
]

CORPUS_VERSION = "1.0.0"
EXPECTED_FILES = 612
EXPECTED_DIGEST = "16b9800f326777dcd5f6e4d58aeb97cc99ceb3a972abbbce37b0d48f1289d4e2"
SKIP_TOP_LEVEL_DIRS = frozenset({"Architecture Studio", ".git", "_archive"})
#: Top-level *files* that are archive wrappers, never corpus. Nested copies
#: (e.g. Anthology/SHA256SUMS.txt) remain corpus members.
SKIP_TOP_LEVEL_FILES = frozenset({
    "SHA256SUMS.txt",
    "CANDIDATE_README.md",
    "CANDIDATE_MANIFEST.json",
})
PRODUCT_KIND = "overlay_only"


def _is_wrapper(rel: Path) -> bool:
    if not rel.parts:
        return True
    if rel.parts[0] in SKIP_TOP_LEVEL_DIRS:
        return True
    if len(rel.parts) == 1 and rel.name in SKIP_TOP_LEVEL_FILES:
        return True
    return False


def iter_corpus_files(root: Path) -> Iterable[tuple[str, str]]:
    """Yield ``(posix_relative_path, sha256)`` for corpus members, sorted."""
    root = Path(root)
    rows = []
    if not root.is_dir():
        return rows
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        rel = path.relative_to(root)
        if _is_wrapper(rel):
            continue
        rows.append((rel.as_posix(), hashlib.sha256(path.read_bytes()).hexdigest()))
    return rows


def corpus_digest(root: Path) -> dict[str, Any]:
    files = list(iter_corpus_files(root))
    digest = hashlib.sha256()
    for rel, sha in files:
        digest.update(f"{rel}\0{sha}\n".encode("utf-8"))
    return {
        "root": str(root),
        "files": len(files),
        "digest": digest.hexdigest(),
        "expected_files": EXPECTED_FILES,
        "expected_digest": EXPECTED_DIGEST,
    }


def preflight(root: Path | None = None) -> dict[str, Any]:
    """Fail closed when the 612-file corpus is absent, wrong, or drifted.

    Codes: ``ok``, ``corpus_absent``, ``wrong_root_or_layout``, ``digest_mismatch``.
    """
    from .fixtures import CORPUS_ROOT
    root = Path(root) if root is not None else CORPUS_ROOT
    if not root.is_dir():
        return {
            "ok": False, "code": "corpus_absent",
            "detail": (f"no corpus directory at {root}; overlay-only installs require the "
                       "612-file generic project repository as the overlay's parent directory"),
            "root": str(root), "files": 0, "digest": None,
        }
    members = list(iter_corpus_files(root))
    if not members:
        return {
            "ok": False, "code": "corpus_absent",
            "detail": (f"{root} contains no corpus files (overlay-only wrappers skipped). "
                       "Mount the 612-file sibling corpus as this directory."),
            "root": str(root), "files": 0, "digest": None,
        }
    report = corpus_digest(root)
    if report["files"] != EXPECTED_FILES:
        return {
            "ok": False, "code": "wrong_root_or_layout",
            "detail": (f"found {report['files']} files, expected {EXPECTED_FILES}. "
                       "Likely the wrong root, an extra wrapper counted, or a truncated corpus. "
                       "Archive wrappers belong in `_archive/` or as top-level SHA256SUMS.txt, "
                       "never mixed into suite folders."),
            **report,
        }
    if report["digest"] != EXPECTED_DIGEST:
        return {
            "ok": False, "code": "digest_mismatch",
            "detail": (f"corpus digest {report['digest']} != {EXPECTED_DIGEST}. "
                       "The overlay must never mutate the sibling corpus."),
            **report,
        }
    return {
        "ok": True, "code": "ok",
        "detail": f"{EXPECTED_FILES} files, digest match",
        **report,
    }


def product_contract() -> dict[str, Any]:
    """ASGO-0.2/0.3: overlay-only contract. Status is PROPOSED until product_owner signs."""
    return {
        "schema_id": "as.product_contract/1",
        "product_kind": PRODUCT_KIND,
        "status": "PROPOSED",
        "unblocks_go": False,
        "signed_by": None,
        "overlay_directory": "Architecture Studio",
        "corpus_relation": "sibling: corpus is overlay.parent; overlay directory name is 'Architecture Studio'",
        "layout": {
            "overlay_directory": "Architecture Studio",
            "corpus_is": "parent of the overlay directory",
            "archive_wrappers": "top-level SHA256SUMS.txt or `_archive/` are not corpus",
        },
        "permissions": {
            "overlay_may_write": "inside the overlay directory only, through WriteGate for external effects",
            "corpus_may_write": False,
            "archive_wrappers": "top-level SHA256SUMS.txt or `_archive/` are not corpus",
        },
        "tenant_project": {
            "fixture_tenant": "linearfinance",
            "fixture_project": "project",
            "production_tenant": "UNSET_PENDING_HOST",
        },
        "preflight": "architecture_studio.corpus.preflight; CLI `architecture-studio preflight`",
        "self_contained_packaging": "NOT_APPLICABLE while product_kind is overlay_only",
        "python": {">=": "3.10", "tested_here": ["3.10"], "declared": ["3.10", "3.11", "3.12"]},
        "console_entry_point": "architecture-studio = architecture_studio.cli:main",
        "note": "A PROPOSED overlay-only decision is not a product_owner signature and is not GO.",
    }
