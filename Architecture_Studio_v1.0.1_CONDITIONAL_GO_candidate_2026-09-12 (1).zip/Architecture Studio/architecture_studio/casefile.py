"""Auditable case-file export (AUDIT-ADD-23, XPROV-07, WF-11, XPROV-06).

A case file is a portable directory: one ``MANIFEST.json`` naming every part
with its SHA-256, the parts themselves (scope, pinned sources, analyzer
results, model/tool versions, candidates, comparison, verification,
uncertainty, assumptions, questions, review history, approvals, workflow
transitions, the run ledger) and an optional detached signature over the
manifest digest. :func:`inspect_case_file` re-hashes every part, re-verifies
the ledger chain and checks that every evidence reference cited by a candidate
resolves to a pinned source entry — independent inspection without the
studio's runtime state.

Nothing here alters the run: export is a read of the store and ledger, and the
export itself is logged (``casefile.exported``) so the trail records that it
was read.
"""
from __future__ import annotations

import hmac
import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from . import version_manifest
from .canonical import canonical_bytes, fmt_ts, sha256_hex, sha256_of
from .evidence_io import atomic_write, loads_strict
from .ledger import Ledger

__all__ = ["CASE_FILE_SCHEMA", "REQUIRED_PARTS", "export_case_file", "inspect_case_file"]

CASE_FILE_SCHEMA = "as.case_file/1"
REQUIRED_PARTS = ("scope", "pinned_sources", "analyzer_results", "versions", "candidates", "verification",
                  "uncertainty", "assumptions", "review_history", "approvals", "transitions", "ledger")
OPTIONAL_PARTS = ("comparison", "questions", "design_state_history", "conflicts", "context_manifest", "policy_decisions",
                  "telemetry", "diagrams")


def export_case_file(*, run_id: str, destination: Path, parts: Mapping[str, Any], ledger: Ledger,
                     actor: str, actor_kind: str = "human", signing_key: bytes | None = None,
                     key_id: str | None = None) -> dict[str, Any]:
    """Write ``destination/<part>.json`` for every supplied part plus MANIFEST.json (+ MANIFEST.sig)."""
    missing = [p for p in REQUIRED_PARTS if p not in parts and p != "ledger"]
    if missing:
        raise ValueError(f"case file is missing required part(s): {missing}")
    unknown = [p for p in parts if p not in REQUIRED_PARTS + OPTIONAL_PARTS]
    if unknown:
        raise ValueError(f"unknown case-file part(s): {unknown}")
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    entries: dict[str, dict[str, Any]] = {}
    for name, payload in sorted(parts.items()):
        # Every part is a JSON object so the strict evidence reader accepts it; sequences travel under "items".
        data = canonical_bytes(payload if isinstance(payload, Mapping) else {"items": payload})
        atomic_write(destination / f"{name}.json", data)
        entries[name] = {"file": f"{name}.json", "sha256": sha256_hex(data), "bytes": len(data)}
    # The ledger is copied byte-for-byte so its hash chain can be re-verified from the export.
    ledger_bytes = Path(ledger.path).read_bytes()
    atomic_write(destination / "ledger.jsonl", ledger_bytes)
    entries["ledger"] = {"file": "ledger.jsonl", "sha256": sha256_hex(ledger_bytes), "bytes": len(ledger_bytes),
                         "events": ledger.length, "head_digest": ledger.head_digest}
    manifest = {"schema_id": CASE_FILE_SCHEMA, "run_id": run_id, "exported_at": fmt_ts(datetime.now(timezone.utc)),
                "exported_by": {"subject": actor, "kind": actor_kind}, "versions": version_manifest(),
                "parts": entries, "required_parts": list(REQUIRED_PARTS)}
    manifest["manifest_digest"] = sha256_of(canonical_bytes({k: v for k, v in manifest.items() if k != "manifest_digest"}))
    atomic_write(destination / "MANIFEST.json", canonical_bytes(manifest))
    if signing_key is not None:
        sig = hmac.new(signing_key, manifest["manifest_digest"].encode("ascii"), hashlib.sha256).hexdigest()
        atomic_write(destination / "MANIFEST.sig", canonical_bytes({"algorithm": "hmac-sha256", "key_id": key_id,
                                                                    "manifest_digest": manifest["manifest_digest"], "signature": sig}))
        manifest["signature"] = {"algorithm": "hmac-sha256", "key_id": key_id}
    ledger.append("casefile.exported", actor=actor, actor_kind=actor_kind, outcome="recorded", subject=run_id,
                  detail={"destination": str(destination), "manifest_digest": manifest["manifest_digest"],
                          "parts": sorted(entries)})
    return manifest


def _candidate_refs(candidates: Sequence[Mapping[str, Any]]) -> set[str]:
    refs: set[str] = set()
    for c in candidates:
        refs.update(c.get("evidence_refs", []))
        for comp in c.get("components", []):
            refs.update(comp.get("evidence_refs", []))
        for rel in c.get("relationships", []):
            refs.update(rel.get("evidence_refs", []))
    return refs


def inspect_case_file(directory: Path, *, signing_key: bytes | None = None) -> dict[str, Any]:
    """Independent inspection: hashes, ledger chain, lineage resolution, separation of derivations."""
    directory = Path(directory)
    manifest = loads_strict((directory / "MANIFEST.json").read_bytes())
    problems: list[str] = []
    expected = manifest.get("manifest_digest")
    recomputed = sha256_of(canonical_bytes({k: v for k, v in manifest.items() if k not in ("manifest_digest", "signature")}))
    if expected != recomputed:
        problems.append("manifest digest mismatch")
    for name, entry in manifest["parts"].items():
        path = directory / entry["file"]
        if not path.exists():
            problems.append(f"missing part {name}")
            continue
        if sha256_hex(path.read_bytes()) != entry["sha256"]:
            problems.append(f"part {name} hash mismatch")
    for name in manifest.get("required_parts", REQUIRED_PARTS):
        if name not in manifest["parts"]:
            problems.append(f"required part {name} absent from manifest")
    ledger_ok, ledger_reason = Ledger(directory / "ledger.jsonl", manifest["run_id"]).verify() if (directory / "ledger.jsonl").exists() else (False, "no ledger")
    if not ledger_ok:
        problems.append(f"ledger: {ledger_reason}")
    signature_state = "absent"
    if (directory / "MANIFEST.sig").exists():
        sig = loads_strict((directory / "MANIFEST.sig").read_bytes())
        if signing_key is None:
            signature_state = "present_unverified"
        else:
            good = hmac.compare_digest(sig["signature"], hmac.new(signing_key, sig["manifest_digest"].encode("ascii"), hashlib.sha256).hexdigest())
            signature_state = "valid" if good and sig["manifest_digest"] == expected else "INVALID"
            if signature_state == "INVALID":
                problems.append("manifest signature invalid")
    # Lineage: every evidence ref cited by a candidate resolves to a pinned source entry or an evidence record.
    lineage = {"cited": 0, "resolved": 0, "unresolved": []}
    separation = {"source": 0, "deterministic_analyzer": 0, "model_inference": 0, "human": 0, "unlabelled": 0}
    if (directory / "candidates.json").exists() and (directory / "pinned_sources.json").exists():
        candidates = loads_strict((directory / "candidates.json").read_bytes()).get("items", [])
        pinned = loads_strict((directory / "pinned_sources.json").read_bytes())
        known: set[str] = set(pinned.get("evidence_ref_ids", []))
        pinned_artifacts: set[str] = set()
        for entry in pinned.get("pins", {}).values() if isinstance(pinned.get("pins"), dict) else []:
            arts = entry.get("artifacts", {})
            for art in (arts.values() if isinstance(arts, dict) else arts):
                if isinstance(art, Mapping):
                    pinned_artifacts.add(art.get("artifact_id", ""))
        # An evidence ref is resolvable when it is in the exported evidence-ref set (which the run derived from pinned artifacts).
        lineage["pinned_artifacts"] = len(pinned_artifacts)
        cited = _candidate_refs(candidates)
        lineage["cited"] = len(cited)
        lineage["resolved"] = len(cited & known)
        lineage["unresolved"] = sorted(cited - known)[:25]
        if cited - known:
            problems.append(f"{len(cited - known)} cited evidence reference(s) do not resolve to a pinned source")
        for c in candidates:
            for element in list(c.get("components", [])) + list(c.get("rationale", [])):
                separation[element.get("derivation") or "unlabelled"] = separation.get(element.get("derivation") or "unlabelled", 0) + 1
        if separation["unlabelled"]:
            problems.append(f"{separation['unlabelled']} element(s) carry no derivation label")
    return {"run_id": manifest.get("run_id"), "manifest_digest": expected, "parts": sorted(manifest["parts"]),
            "ledger": {"ok": ledger_ok, "detail": ledger_reason}, "signature": signature_state, "lineage": lineage,
            "derivation_separation": separation, "problems": problems, "ok": not problems}
