"""Append-only, hash-chained evidence and audit ledger (ARCH-08, STORE-07, SEC-08, IMPL-09, XPROV-06).

Each event binds the digest of the one before it, so a modified or removed
record breaks verification at that point and every point after. Nothing here
offers an update or delete path — ``append`` is the only writer.

Writers are restricted (SEC-08): a :class:`Ledger` is constructed with a
*writer identity*; the model-facing tool surface receives a
:class:`ReadOnlyLedger` view that has no ``append`` at all, and an attempt to
append under a model actor kind is refused before the file is touched. The
integrity walk (:meth:`Ledger.verify`) detects tampering; the writer
restriction prevents it from a model-accessible interface.

Structure from the shop's Scoped PR Builder ``adapters/archive_adapter.py``
(chaining, genesis link, verification walk, no update or delete method) via the
owner's Repository Context Graph ``rcg/provenance.py``.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator, Mapping

from .canonical import compact_json, digest_of, fmt_ts, sha256_of
from .schemas import validate

__all__ = ["LedgerError", "Ledger", "ReadOnlyLedger", "OUTCOMES", "MODEL_WRITER_REFUSED"]

OUTCOMES = ("allowed", "denied", "failed", "abstained", "recorded")
MODEL_WRITER_REFUSED = "a model principal cannot write audit records"


class LedgerError(RuntimeError):
    pass


class ReadOnlyLedger:
    """The only ledger handle a model-facing surface ever receives."""

    def __init__(self, ledger: "Ledger") -> None:
        self._ledger = ledger

    def events(self) -> Iterator[dict[str, Any]]:
        return self._ledger.events()

    def verify(self) -> tuple[bool, str]:
        return self._ledger.verify()

    @property
    def head_digest(self) -> str | None:
        return self._ledger.head_digest

    @property
    def run_id(self) -> str:
        return self._ledger.run_id


class Ledger:
    def __init__(self, path: Path, run_id: str, *, writer: str = "architecture_studio.ledger") -> None:
        self.path = Path(path)
        self.run_id = run_id
        self.writer = writer
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._sequence = 0
        self._last_digest: str | None = None
        if self.path.exists():
            self._replay()

    # ------------------------------------------------------------- writing --
    def append(self, event_type: str, *, actor: str, actor_kind: str, outcome: str, detail: Mapping[str, Any],
               subject: str | None = None, authority_ref: str | None = None,
               occurred_at: str | None = None) -> dict[str, Any]:
        if outcome not in OUTCOMES:
            raise LedgerError(f"illegal outcome {outcome!r}")
        if actor_kind == "model":
            raise LedgerError(MODEL_WRITER_REFUSED)
        detail = dict(detail)
        event = {
            "schema_id": "as.audit_event/1", "sequence": self._sequence, "run_id": self.run_id,
            "event_type": event_type, "actor": actor, "actor_kind": actor_kind,
            "authority_ref": authority_ref, "subject": subject, "outcome": outcome,
            "detail_digest": digest_of(detail), "occurred_at": occurred_at or fmt_ts(datetime.now(timezone.utc)),
            "previous_digest": self._last_digest, "writer": self.writer,
        }
        validate("as.audit_event/1", event)
        line = compact_json({"event": event, "detail": detail})
        with self.path.open("a", encoding="utf-8", newline="") as handle:
            handle.write(line + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        self._last_digest = sha256_of(compact_json(event))
        self._sequence += 1
        return event

    def read_only(self) -> ReadOnlyLedger:
        return ReadOnlyLedger(self)

    # ------------------------------------------------------------- reading --
    def events(self) -> Iterator[dict[str, Any]]:
        if not self.path.exists():
            return iter(())

        def _iter() -> Iterator[dict[str, Any]]:
            with self.path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    line = line.strip()
                    if line:
                        yield json.loads(line)
        return _iter()

    def events_of(self, event_type: str) -> list[dict[str, Any]]:
        return [r for r in self.events() if r["event"]["event_type"] == event_type]

    def verify(self) -> tuple[bool, str]:
        previous: str | None = None
        expected_sequence = 0
        for record in self.events():
            event = record["event"]
            if event["sequence"] != expected_sequence:
                return False, f"sequence gap at {event['sequence']} (expected {expected_sequence})"
            if event["previous_digest"] != previous:
                return False, f"chain break at sequence {event['sequence']}"
            if event["detail_digest"] != digest_of(record["detail"]):
                return False, f"detail tampered at sequence {event['sequence']}"
            previous = sha256_of(compact_json(event))
            expected_sequence += 1
        return True, "ok"

    @property
    def head_digest(self) -> str | None:
        return self._last_digest

    @property
    def length(self) -> int:
        return self._sequence

    def _replay(self) -> None:
        for record in self.events():
            self._last_digest = sha256_of(compact_json(record["event"]))
            self._sequence = record["event"]["sequence"] + 1
