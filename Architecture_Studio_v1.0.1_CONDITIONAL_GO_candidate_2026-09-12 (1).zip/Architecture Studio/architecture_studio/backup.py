"""Backup, restore and disaster-recovery exercise (AUDIT-ADD-20).

Scope: the object store (run/design state, candidates, approvals refs), the
run ledger, the flag store and the provenance export. Objectives (RPO/RTO) are
PROPOSED targets in :mod:`architecture_studio.slo`. :func:`exercise` restores a
representative run into a fresh location and verifies state, lineage and audit
integrity — the drill the acceptance criterion names — and reports measured
durations against the proposed objectives without calling them met.

Key/secret dependencies: an encrypted store needs its KEK to restore; the
manifest names the key id it depends on and the exercise fails closed if the
provider cannot open it.

Build provenance: adapted from the owner's ``rcg/versionstore.backup/restore``
and the EQG ``backup.py``.
"""
from __future__ import annotations

import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .canonical import canonical_bytes, fmt_ts, sha256_hex, sha256_of
from .evidence_io import atomic_write, loads_strict
from .ledger import Ledger
from .store import ObjectStore

__all__ = ["backup", "restore", "exercise", "BACKUP_SCOPE"]

BACKUP_SCOPE = ("store", "ledger", "flags")


def backup(*, store: ObjectStore, ledger_path: Path, flags_path: Path | None, destination: Path,
           key_ids: list[str] | None = None) -> dict[str, Any]:
    destination = Path(destination)
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True)
    store_manifest = store.backup(destination / "store")
    shutil.copy2(ledger_path, destination / "ledger.jsonl")
    if flags_path and Path(flags_path).exists():
        shutil.copy2(flags_path, destination / "flags.json")
    manifest = {"scope": list(BACKUP_SCOPE), "created_at": fmt_ts(datetime.now(timezone.utc)),
                "store_manifest_digest": store_manifest["manifest_digest"],
                "ledger_sha256": sha256_hex((destination / "ledger.jsonl").read_bytes()),
                "flags_sha256": sha256_hex((destination / "flags.json").read_bytes()) if (destination / "flags.json").exists() else None,
                "key_dependencies": list(key_ids or []), "restore_requires_keys": bool(key_ids)}
    manifest["manifest_digest"] = sha256_of(canonical_bytes(manifest))
    atomic_write(destination / "BACKUP.json", canonical_bytes(manifest))
    return manifest


def restore(*, backup_dir: Path, destination: Path, run_id: str) -> dict[str, Any]:
    backup_dir, destination = Path(backup_dir), Path(destination)
    manifest = loads_strict((backup_dir / "BACKUP.json").read_bytes())
    expected = manifest.pop("manifest_digest")
    if sha256_of(canonical_bytes(manifest)) != expected:
        raise RuntimeError("backup manifest digest mismatch; refusing to restore")
    if (backup_dir / "ledger.jsonl").exists() and sha256_hex((backup_dir / "ledger.jsonl").read_bytes()) != manifest["ledger_sha256"]:
        raise RuntimeError("ledger copy does not match the backup manifest")
    destination.mkdir(parents=True, exist_ok=True)
    store = ObjectStore.restore(backup_dir / "store", destination / "store")
    shutil.copy2(backup_dir / "ledger.jsonl", destination / "ledger.jsonl")
    ledger = Ledger(destination / "ledger.jsonl", run_id)
    ok, reason = ledger.verify()
    if not ok:
        raise RuntimeError(f"restored ledger failed verification: {reason}")
    if (backup_dir / "flags.json").exists():
        shutil.copy2(backup_dir / "flags.json", destination / "flags.json")
    return {"store_ok": store.verify()["ok"], "ledger_ok": ok, "ledger_events": ledger.length,
            "refs": store.refs_list(), "manifest": manifest}


def exercise(*, store: ObjectStore, ledger: Ledger, flags_path: Path | None, workdir: Path, run_id: str,
             key_ids: list[str] | None = None) -> dict[str, Any]:
    """AUDIT-ADD-20 recovery exercise: back up, destroy nothing, restore elsewhere, verify, time it."""
    started = time.perf_counter()
    manifest = backup(store=store, ledger_path=ledger.path, flags_path=flags_path, destination=workdir / "backup", key_ids=key_ids)
    backup_ms = round((time.perf_counter() - started) * 1000, 3)
    started = time.perf_counter()
    result = restore(backup_dir=workdir / "backup", destination=workdir / "restored", run_id=run_id)
    restore_ms = round((time.perf_counter() - started) * 1000, 3)
    original_refs = {ref: (store.head(ref).snapshot_id if store.head(ref) else None) for ref in store.refs_list()}
    restored = ObjectStore(workdir / "restored" / "store")
    restored_refs = {ref: (restored.head(ref).snapshot_id if restored.head(ref) else None) for ref in restored.refs_list()}
    lineage_intact = original_refs == restored_refs
    return {"backup_ms": backup_ms, "restore_ms": restore_ms, "state_verified": result["store_ok"],
            "lineage_intact": lineage_intact, "audit_integrity": result["ledger_ok"], "ledger_events": result["ledger_events"],
            "refs_restored": len(restored_refs), "manifest_digest": manifest["manifest_digest"],
            "objectives": {"rto_minutes_measured": round(restore_ms / 60000, 6), "rto_target_status": "PROPOSED",
                           "rpo": "point-in-time of the backup; continuous replication is a host capability (not claimed)"},
            "passed": result["store_ok"] and result["ledger_ok"] and lineage_intact}
