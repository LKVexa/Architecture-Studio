"""Provenance model and lineage (IMPL-04, API-03, COMP-10, XPROV-01..05, STORE-03, WF-11).

Entities and edges link sources → normalized artifacts → analyzer results →
context bundles → model outputs → generated artifacts → reviewer actions →
approvals. The distinction the whole system rests on is ``derivation``: a fact
is read from source bytes, produced by a named deterministic analyzer,
asserted by a model, or decided by a human. They live in the same graph and are
never merged (XPROV-04/05); :meth:`ProvenanceGraph.facts` returns one class
without the others.

A material finding cannot be recorded without at least one evidence reference
(XPROV-03) and every evidence reference carries identity, revision, hash,
freshness and status (XPROV-01/02). Lineage walks backward to pinned sources
and forward to later decisions (ARCH-08), and detect dangling references
(STORE-03).

Adapted from the owner's Repository Context Graph runtime (``rcg/provenance.py``).
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any, Iterable, Sequence

from .canonical import fmt_ts
from .ids import deterministic_id
from .schemas import DERIVATIONS, EVIDENCE_STATES, validate

__all__ = ["EvidenceRef", "ProvenanceFact", "ProvenanceError", "ProvenanceGraph", "ENTITY_KINDS", "EDGE_KINDS"]

ENTITY_KINDS = ("source", "normalized_artifact", "analyzer_result", "context_bundle", "model_output",
                "candidate", "comparison", "diagram", "question", "assumption", "review_action", "approval",
                "case_file")
EDGE_KINDS = ("normalized_from", "analyzed_from", "assembled_from", "generated_from", "derived_from",
              "compared", "rendered_from", "raised_about", "assumed_for", "reviewed", "approved", "exported")


class ProvenanceError(ValueError):
    pass


@dataclass(frozen=True)
class EvidenceRef:
    """API-03: stable identity + revision + hash + status for one piece of evidence."""

    artifact_id: str
    source_system: str
    revision: str
    source_hash: str
    observed_at: str
    derivation: str = "source"
    evidence_status: str = "current"
    location: str | None = None
    span: str | None = None
    retrieval_event: str | None = None
    transformation_chain: tuple[str, ...] = ()
    analyzer: str | None = None

    def __post_init__(self) -> None:
        if self.derivation not in DERIVATIONS:
            raise ProvenanceError(f"derivation must be one of {DERIVATIONS}")
        if self.evidence_status not in EVIDENCE_STATES:
            raise ProvenanceError(f"evidence_status must be one of {EVIDENCE_STATES}")
        if self.derivation in ("deterministic_analyzer", "model_inference") and not self.analyzer:
            raise ProvenanceError("a derived reference must name its analyzer or model")

    def as_document(self) -> dict[str, Any]:
        doc = {"schema_id": "as.evidence_ref/1", **asdict(self)}
        doc["transformation_chain"] = list(self.transformation_chain)
        return validate("as.evidence_ref/1", doc)

    @property
    def ref_id(self) -> str:
        return deterministic_id("evidence", **{k: (list(v) if isinstance(v, tuple) else v)
                                               for k, v in asdict(self).items()})

    def stale(self) -> "EvidenceRef":
        return EvidenceRef(**{**asdict(self), "evidence_status": "stale",
                              "transformation_chain": self.transformation_chain})


@dataclass(frozen=True)
class ProvenanceFact:
    fact_id: str
    subject: str
    statement: str
    derivation: str
    evidence_refs: tuple[str, ...]
    analyzer: str | None
    impact: str
    recorded_at: str

    def as_document(self) -> dict[str, Any]:
        doc = asdict(self)
        doc["evidence_refs"] = list(self.evidence_refs)
        return doc


class ProvenanceGraph:
    """Typed entities and edges; every edge carries the evidence that justifies it."""

    def __init__(self, run_id: str, *, ledger: Any = None) -> None:
        self.run_id = run_id
        self.ledger = ledger
        self._entities: dict[str, dict[str, Any]] = {}
        self._edges: list[dict[str, Any]] = []
        self._refs: dict[str, EvidenceRef] = {}
        self._facts: dict[str, ProvenanceFact] = {}

    # ------------------------------------------------------------ entities --
    def add_entity(self, entity_id: str, kind: str, *, evidence: Iterable[EvidenceRef] = (),
                   attributes: dict[str, Any] | None = None) -> dict[str, Any]:
        if kind not in ENTITY_KINDS:
            raise ProvenanceError(f"unknown entity kind {kind!r}")
        if entity_id in self._entities:
            existing = self._entities[entity_id]
            if existing["kind"] != kind:
                raise ProvenanceError(f"entity {entity_id} already exists with kind {existing['kind']!r}")
            return existing
        refs = []
        for ref in evidence:
            self._refs[ref.ref_id] = ref
            refs.append(ref.ref_id)
        if kind == "source" and not refs:
            raise ProvenanceError("a source entity must carry its own evidence reference")
        entity = {"entity_id": entity_id, "kind": kind, "evidence_refs": refs, "attributes": dict(attributes or {}),
                  "recorded_at": _now()}
        self._entities[entity_id] = entity
        return entity

    def add_edge(self, source: str, target: str, kind: str, *, evidence: Iterable[EvidenceRef] = (),
                 derivation: str = "source", actor: str = "system") -> dict[str, Any]:
        if kind not in EDGE_KINDS:
            raise ProvenanceError(f"unknown edge kind {kind!r}")
        if source not in self._entities or target not in self._entities:
            raise ProvenanceError(f"edge {source}->{target} references an unknown entity (dangling)")
        if derivation not in DERIVATIONS:
            raise ProvenanceError(f"derivation must be one of {DERIVATIONS}")
        refs = []
        for ref in evidence:
            self._refs[ref.ref_id] = ref
            refs.append(ref.ref_id)
        if not refs:
            # An edge inherits its target's evidence when none is supplied; if there is none anywhere, refuse.
            refs = list(self._entities[source]["evidence_refs"]) or list(self._entities[target]["evidence_refs"])
        if not refs and derivation != "human":
            raise ProvenanceError("an edge without supporting evidence cannot exist")
        edge = {"edge_id": deterministic_id("edge", source=source, target=target, edge_kind=kind),
                "source": source, "target": target, "kind": kind, "derivation": derivation,
                "evidence_refs": refs, "actor": actor, "recorded_at": _now()}
        self._edges.append(edge)
        return edge

    def record_fact(self, *, subject: str, statement: str, derivation: str,
                    evidence: Sequence[EvidenceRef], analyzer: str | None = None, impact: str = "low",
                    actor: str = "architecture_studio", actor_kind: str = "analyzer") -> ProvenanceFact:
        """XPROV-03: no material finding without at least one evidence reference."""
        if derivation not in DERIVATIONS:
            raise ProvenanceError(f"derivation must be one of {DERIVATIONS}")
        if not evidence:
            raise ProvenanceError("a material finding must reference at least one piece of evidence")
        if derivation in ("deterministic_analyzer", "model_inference") and not analyzer:
            raise ProvenanceError("a derived finding must name its analyzer or model")
        if impact not in ("low", "medium", "high"):
            raise ProvenanceError("impact must be low, medium or high")
        refs = []
        for ref in evidence:
            self._refs[ref.ref_id] = ref
            refs.append(ref.ref_id)
        fact = ProvenanceFact(
            fact_id=deterministic_id("finding", run=self.run_id, subject=subject, statement=statement,
                                     derivation=derivation, refs=list(refs)),
            subject=subject, statement=statement, derivation=derivation, evidence_refs=tuple(refs),
            analyzer=analyzer, impact=impact, recorded_at=_now())
        self._facts[fact.fact_id] = fact
        if self.ledger is not None:
            self.ledger.append("fact.recorded", actor=actor, actor_kind=actor_kind, outcome="recorded",
                               subject=subject,
                               detail={"fact": fact.as_document(), "evidence": [e.as_document() for e in evidence]})
        return fact

    # ------------------------------------------------------------- queries --
    def facts(self, *, derivation: str | None = None) -> list[ProvenanceFact]:
        return [f for f in self._facts.values() if derivation is None or f.derivation == derivation]

    def evidence(self, ref_id: str) -> EvidenceRef:
        try:
            return self._refs[ref_id]
        except KeyError:
            raise ProvenanceError(f"evidence reference {ref_id} is dangling") from None

    def entity(self, entity_id: str) -> dict[str, Any]:
        return self._entities[entity_id]

    def lineage_backward(self, entity_id: str) -> dict[str, Any]:
        """Walk to pinned sources; report every step and any dangling reference."""
        if entity_id not in self._entities:
            raise ProvenanceError(f"unknown entity {entity_id}")
        seen: set[str] = set()
        frontier = [entity_id]
        path: list[dict[str, Any]] = []
        sources: list[str] = []
        dangling: list[str] = []
        while frontier:
            current = frontier.pop()
            if current in seen:
                continue
            seen.add(current)
            entity = self._entities[current]
            for ref in entity["evidence_refs"]:
                if ref not in self._refs:
                    dangling.append(ref)
            if entity["kind"] == "source":
                sources.append(current)
            for edge in self._edges:
                if edge["source"] == current:
                    path.append(edge)
                    frontier.append(edge["target"])
        return {"entity_id": entity_id, "sources": sorted(sources), "edges": path,
                "dangling_refs": sorted(set(dangling)), "complete": bool(sources) and not dangling}

    def lineage_forward(self, entity_id: str) -> dict[str, Any]:
        """Walk to later decisions: what was built on, reviewed or approved from this entity."""
        if entity_id not in self._entities:
            raise ProvenanceError(f"unknown entity {entity_id}")
        seen: set[str] = set()
        frontier = [entity_id]
        downstream: list[str] = []
        while frontier:
            current = frontier.pop()
            if current in seen:
                continue
            seen.add(current)
            for edge in self._edges:
                if edge["target"] == current and edge["source"] not in seen:
                    downstream.append(edge["source"])
                    frontier.append(edge["source"])
        decisions = [e for e in downstream if self._entities[e]["kind"] in ("review_action", "approval")]
        return {"entity_id": entity_id, "downstream": sorted(set(downstream)), "decisions": sorted(set(decisions))}

    def dangling(self) -> list[str]:
        """STORE-03: every evidence reference an entity or edge names must resolve."""
        named = {r for e in self._entities.values() for r in e["evidence_refs"]}
        named |= {r for e in self._edges for r in e["evidence_refs"]}
        named |= {r for f in self._facts.values() for r in f.evidence_refs}
        return sorted(named - set(self._refs))

    def separation_report(self) -> dict[str, int]:
        """XPROV-04/05: counts per derivation class, kept apart."""
        return {d: sum(1 for f in self._facts.values() if f.derivation == d) for d in DERIVATIONS}

    def as_document(self) -> dict[str, Any]:
        return {"run_id": self.run_id, "entities": list(self._entities.values()), "edges": list(self._edges),
                "evidence": {k: v.as_document() for k, v in sorted(self._refs.items())},
                "facts": [f.as_document() for f in self._facts.values()], "dangling": self.dangling(),
                "separation": self.separation_report()}


def _now() -> str:
    return fmt_ts(datetime.now(timezone.utc))
