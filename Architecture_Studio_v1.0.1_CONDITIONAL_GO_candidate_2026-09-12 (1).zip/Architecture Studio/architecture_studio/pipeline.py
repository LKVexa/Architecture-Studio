"""The end-to-end workflow (WF-01..WF-12) and its fault scenarios.

:class:`Run` wires the modules together in the order the workflow prescribes:

    WF-01 authenticate + authority → WF-02 pin → WF-03 collect (authorized only)
    → WF-04 normalize/index → WF-05 deterministic analysis → WF-06/07 bounded
    generation under policy → WF-08 independent verification → WF-09 review
    package → WF-10 human decision (token-gated) → WF-11 case file → WF-12
    rollback/abort handlers.

Every stage writes to the run ledger and advances the :class:`WorkflowMachine`;
a failure at any stage lands in an explicit safe terminal with the evidence
preserved. :func:`scenarios` executes the golden path and the fault paths
(rejection, scope narrowing, tool failure, abstention, forged approval,
rollback on export failure, kill switch mid-run) against the real corpus and
returns one document per scenario — these are the WF-* acceptance runs.

Nothing in a run writes outside ``workdir`` (a temp dir in tests) except the
case-file export, which goes through the write gate under an approval.
"""
from __future__ import annotations

import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from . import version_manifest
from .analysis import ConstraintChecker, run_analyzers
from .approvals import ApprovalService, load_or_create_key
from .assumptions import AssumptionRegistry
from .authority import IdentityProvider, Principal
from .canonical import digest_of, fmt_ts, sha256_of
from .casefile import export_case_file, inspect_case_file
from .connectors.base import pin_source_set
from .connectors.normalize import NormalizedIndex, Normalizer
from .connectors.typed import connector_for_class
from .design_state import DesignStateStore
from .distinctness import DistinctnessRule
from .fixtures import CORPUS_ROOT, FIXTURES_ROOT, make_scope
from .generator import Generator, ProviderSlot
from .grounding import detect_conflicts
from .incident import FlagStore
from .ledger import Ledger
from .observability import Telemetry
from .policy import POLICY_VERSION, PolicyViolation
from .questions import detect_gaps, material_open, raise_questions
from .retrieval import RetrievalIndex
from .review import ApprovalGate, DecisionRecorder, ReviewError, build_review_package
from .scope import ScopeContract, ScopeError
from .store import ObjectStore
from .tradeoffs import compare
from .uncertainty import Thresholds
from .verify import gate_verdict, verify_outputs
from .workflow import SAFE_TERMINALS, TransitionError, WorkflowMachine, WorkflowState
from .writes import WriteDenied, WriteGate

__all__ = ["Run", "RunAborted", "scenarios", "SCENARIOS", "PIPELINE_VERSION"]

PIPELINE_VERSION = "1.0.0"


class RunAborted(RuntimeError):
    def __init__(self, stage: str, reason: str, terminal: str) -> None:
        self.stage, self.reason, self.terminal = stage, reason, terminal
        super().__init__(f"{stage}: {reason} -> {terminal}")


class Run:
    def __init__(self, *, run_id: str, workdir: Path, identity: IdentityProvider, subject: str, secret: str,
                 scope_document: Mapping[str, Any] | None = None, scope: ScopeContract | None = None,
                 corpus_root: Path | None = None, connector_hook: Callable[[Any], None] | None = None,
                 slot: ProviderSlot | None = None, flags: FlagStore | None = None) -> None:
        self.run_id = run_id
        self.workdir = Path(workdir)
        self.workdir.mkdir(parents=True, exist_ok=True)
        self.identity = identity
        self._subject, self._secret = subject, secret
        self._scope_document = dict(scope_document) if scope_document else None
        self._scope_override = scope
        self.corpus_root = Path(corpus_root or CORPUS_ROOT)
        self.connector_hook = connector_hook
        self.slot = slot or ProviderSlot()
        self.ledger = Ledger(self.workdir / "ledger.jsonl", run_id)
        self.flags = flags if flags is not None else FlagStore(self.workdir / "flags.json", ledger=self.ledger)
        self.telemetry = Telemetry(run_id)
        self.machine = WorkflowMachine(run_id)
        self.store = ObjectStore(self.workdir / "store")
        self.principal: Principal | None = None
        self.scope: ScopeContract | None = None
        self.pins = None
        self.connectors: list[Any] = []
        self.index = NormalizedIndex()
        self.retrieval = RetrievalIndex()
        self.analyzers: list[Any] = []
        self.assumptions = AssumptionRegistry(run_id)
        self.generation = None
        self.comparison: dict[str, Any] | None = None
        self.verification = None
        self.questions: list[dict[str, Any]] = []
        self.package = None
        self.decision: dict[str, Any] | None = None
        self.design = DesignStateStore(self.store, run_id, ledger=self.ledger)
        self.approvals = ApprovalService(key=load_or_create_key(self.workdir / "keys" / "approval.key"), issuer="as.pipeline",
                                         key_id="pipeline", ledger=self.ledger)
        self.recorder = DecisionRecorder(ledger=self.ledger)
        self.gate = ApprovalGate(self.approvals, self.recorder, ledger=self.ledger)
        self.export_dir: Path | None = None
        self.iteration = 1

    # ------------------------------------------------------------------ helpers --
    def _fire(self, event: str, *, actor: str | None = None, actor_kind: str = "service", authority_ref: str | None = None,
              detail: Mapping[str, Any] | None = None) -> str:
        actor = actor or "architecture_studio"
        state = self.machine.fire(event, actor=actor, actor_kind=actor_kind, ledger=self.ledger, authority_ref=authority_ref, detail=detail)
        self.telemetry.logger.transition(self.run_id, self.machine.history[-1]["from"], event, state)
        return state

    def _abort(self, stage: str, reason: str, event: str = "abort") -> None:
        """WF-12: land in an explicit safe terminal with the evidence preserved."""
        self.ledger.append("run.aborted", actor="architecture_studio", actor_kind="service", outcome="failed", subject=self.run_id,
                           detail={"stage": stage, "reason": reason})
        if self.machine.state not in SAFE_TERMINALS and self.machine.state not in ("COMPLETED",):
            try:
                self._fire(event, detail={"stage": stage, "reason": reason})
            except TransitionError:
                self._fire("abort", detail={"stage": stage, "reason": reason})
        raise RunAborted(stage, reason, self.machine.state)

    # ------------------------------------------------------------------- WF-01 --
    def authenticate(self) -> ScopeContract:
        try:
            self.principal = self.identity.authenticate(self._subject, self._secret)
        except Exception as exc:
            self._abort("WF-01", f"authentication failed: {exc}", "policy_denied")
        try:
            self.scope = self._scope_override or ScopeContract.from_document(self._scope_document, target_root=self.corpus_root)
            if self.scope.subject != self.principal.subject:
                raise ScopeError("scope contract was issued to a different subject")
            if not self.scope.is_current(datetime.now(timezone.utc)):
                raise ScopeError("scope contract is expired or not yet valid")
        except (ScopeError, Exception) as exc:
            self._abort("WF-01", f"authority not established: {exc}", "policy_denied")
        if not self.flags.enabled:
            self._abort("WF-01", f"rollout switch: {self.flags.reason}", "policy_denied")
        self.ledger.append("run.authorized", actor=self.principal.subject, actor_kind=self.principal.kind, outcome="allowed",
                           subject=self.run_id, authority_ref=self.scope.human_authority_ref,
                           detail={"scope_digest": self.scope.scope_digest, "versions": version_manifest(), "principal": self.principal.as_record()})
        self._fire("authority_established", actor=self.principal.subject, actor_kind="human", authority_ref=self.scope.human_authority_ref)
        return self.scope

    # ------------------------------------------------------------------- WF-02 --
    def pin(self) -> Any:
        self.connectors = [connector_for_class(c, corpus_root=self.corpus_root, tenant=self.scope.tenant, project=self.scope.project,
                                               fixtures_root=FIXTURES_ROOT, ledger=self.ledger, sleep=lambda s: None)
                           for c in sorted(self.scope.allowed_artifact_classes)]
        if self.connector_hook:
            for connector in self.connectors:
                self.connector_hook(connector)
        try:
            with self.telemetry.tracer.span("pin"):
                self.pins = pin_source_set(self.run_id, self.connectors, self.scope)
        except Exception as exc:
            self._abort("WF-02", f"pinning failed: {exc}")
        self.store.commit(f"runs/{self.run_id}/pins", self.pins.as_document(), expected_parent=None)
        self._fire("revisions_pinned", detail={"pinned_digest": self.pins.digest})
        return self.pins

    # ------------------------------------------------------------ WF-03 / WF-04 --
    def collect_and_index(self) -> NormalizedIndex:
        self._fire("collect_evidence")
        normalizer = Normalizer(ledger=self.ledger)
        failures = []
        with self.telemetry.tracer.span("collect"):
            for connector in self.connectors:
                result = connector.read(self.scope)
                self.telemetry.metrics.increment("tool.calls")
                if result.status in ("failed", "unavailable", "malformed"):
                    self.telemetry.metrics.increment("tool.failed")
                    failures.append({"source": result.source_system, "status": result.status, "diagnostics": result.diagnostics[:3]})
                    continue
                self.index = normalizer.ingest([result], index=self.index, allowed_classes=self.scope.allowed_artifact_classes)
        if failures and not self.index.records:
            self._abort("WF-03", f"every connector failed: {failures}", "tool_failure")
        if failures:
            self.ledger.append("connector.partial", actor="architecture_studio", actor_kind="service", outcome="failed", subject=self.run_id,
                               detail={"failures": failures})
        # WF-03 proof: nothing outside the scope's source set / classes entered the index.
        foreign = [r["record_id"] for r in self.index.records.values()
                   if r["data_class"] not in self.scope.allowed_artifact_classes or r["source_system"] not in self.scope.source_set]
        if foreign:
            self._abort("WF-03", f"{len(foreign)} record(s) outside scope entered the index", "policy_denied")
        if not self.index.records:
            self._fire("abstain", detail={"reason": "no authorized evidence"})
            raise RunAborted("WF-04", "no authorized evidence to index", self.machine.state)
        with self.telemetry.tracer.span("index"):
            self.retrieval.add_index(self.index)
        self.store.commit(f"runs/{self.run_id}/index-summary", self.index.summary(), expected_parent=None)
        self._fire("evidence_indexed", detail=self.index.summary())
        self.design.initialize(scope_digest=self.scope.scope_digest, actor=self.principal.subject)
        return self.index

    # ------------------------------------------------------------------- WF-05 --
    def analyze(self) -> list[Any]:
        with self.telemetry.tracer.span("analyzers"):
            self.analyzers = run_analyzers(self.index, trace=self.telemetry.tracer)
        self.store.commit(f"runs/{self.run_id}/analyzers", [a.as_document() for a in self.analyzers], expected_parent=None)
        self._fire("analysis_complete", detail={"analyzers": [a.analyzer for a in self.analyzers]})
        return self.analyzers

    # ------------------------------------------------------------ WF-06 / WF-07 --
    def generate(self, *, goals: Sequence[Mapping[str, Any]], constraints: Sequence[Mapping[str, Any]] = ()) -> Any:
        generator = Generator(scope=self.scope, index=self.index, retrieval=self.retrieval, assumptions=self.assumptions, slot=self.slot,
                              ledger=self.ledger, rollout=self.flags, checker=ConstraintChecker(self.index, ledger=self.ledger))
        try:
            with self.telemetry.tracer.span("model.generate"):
                self.generation = generator.generate(run_id=self.run_id, iteration=self.iteration, goals=goals, constraints=constraints,
                                                     session_ref=f"session:{self.run_id}", analyzer_results=[a.as_document() for a in self.analyzers])
        except PolicyViolation as exc:
            self._abort("WF-07", f"policy denied generation: {exc}", "policy_denied")
        self.telemetry.metrics.increment("model.calls")
        if self.generation.mode == "halted":
            self._abort("WF-06", "rollout switch disabled on the execution path", "policy_denied")
        if not self.generation.candidates:
            self.telemetry.metrics.increment("model.abstained")
            self._fire("abstain", detail={"abstention": self.generation.abstention})
            raise RunAborted("WF-07", f"abstained: {(self.generation.abstention or {}).get('abstention_code')}", self.machine.state)
        ids = [c["candidate_id"] for c in self.generation.candidates]
        for c in self.generation.candidates:
            self.store.put_object(c)
        self.store.commit(f"runs/{self.run_id}/candidates", self.generation.candidates, expected_parent=None)
        state = self.design.load()
        self.design.register_candidates(ids, actor="architecture_studio", actor_kind="service", expected_version=state.version,
                                        rationale="candidates generated from pinned evidence", evidence_refs=sorted({r for c in self.generation.candidates for r in c["evidence_refs"]}))
        if len(self.generation.candidates) >= 2:
            self.comparison = compare(run_id=self.run_id, candidates=self.generation.candidates, index=self.index,
                                      constraint_checks=self.generation.constraint_checks, grounding=self.generation.grounding,
                                      assumptions={c["candidate_id"]: len(self.assumptions.entries(candidate_id=c["candidate_id"])) for c in self.generation.candidates})
            self.store.commit(f"runs/{self.run_id}/comparison", self.comparison, expected_parent=None)
            self.design.register_comparison(self.comparison["comparison_id"], ids, actor="architecture_studio", actor_kind="service",
                                            expected_version=self.design.load().version, rationale="comparison built from constraint checks and grounding")
        conflicts = detect_conflicts(self.run_id, self.index)
        gaps = detect_gaps(candidates=self.generation.candidates, constraint_checks=self.generation.constraint_checks, conflicts=conflicts,
                           assumptions=self.assumptions.entries())
        self.questions = raise_questions(self.run_id, gaps)
        self._fire("candidates_generated", detail={"candidates": ids, "mode": self.generation.mode, "questions": len(self.questions)})
        return self.generation

    # ------------------------------------------------------------------- WF-08 --
    def verify(self) -> Any:
        with self.telemetry.tracer.span("verify"):
            self.verification = verify_outputs(run_id=self.run_id, iteration=self.iteration, candidates=self.generation.candidates,
                                               index=self.index, assumptions=self.assumptions, comparison=self.comparison,
                                               design_history=self.design.history(), decisions=self.recorder.history(self.run_id),
                                               ledger_events=self.ledger.events(), policy_decision=self.generation.policy, ledger=self.ledger)
        verdict, reason = gate_verdict(self.verification)
        self.store.commit(f"runs/{self.run_id}/verification", self.verification.as_document(), expected_parent=None)
        if verdict == "DENY":
            self._fire("verification_failed", detail={"reason": reason})
            raise RunAborted("WF-08", reason, self.machine.state)
        self._fire("verification_passed", detail={"verdict": verdict, "reason": reason})
        return self.verification

    # ------------------------------------------------------------------- WF-09 --
    def present(self, gate: str = "final_selection") -> Any:
        evidence = {ref_id: ref.as_document() for ref_id, ref in self.index.evidence.items()
                    if any(ref_id in c["evidence_refs"] for c in self.generation.candidates)}
        self.package = build_review_package(
            run_id=self.run_id, gate=gate, scope=self.scope, pinned_digest=self.pins.digest,
            analyzed={"analyzers": [a.analyzer for a in self.analyzers], "records": len(self.index.records), "classes": sorted(self.scope.allowed_artifact_classes)},
            not_analyzed={"classes_outside_scope": sorted(set(("requirement", "nfr", "adr", "api_operation", "service", "diagram", "security_constraint",
                                                               "cost_perf_constraint", "deployment_standard")) - set(self.scope.allowed_artifact_classes)),
                          "quarantined": len(self.index.quarantine)},
            candidates=self.generation.candidates, comparison=self.comparison, evidence=evidence,
            uncertainty={c["candidate_id"]: c["uncertainty"] for c in self.generation.candidates},
            verification=self.verification.as_document(), questions=self.questions,
            excluded_or_failed=[{"kind": "distinctness_rejected", **p} for p in self.generation.distinctness.get("pairs", []) if not p.get("distinct", True)],
            policy_decision=self.generation.policy)
        self.store.commit(f"runs/{self.run_id}/review-package", self.package.as_document(), expected_parent=None)
        self.design.set_review_state("awaiting_review", actor="architecture_studio", expected_version=self.design.load().version)
        self._fire("submit_for_review", detail={"subject_digest": self.package.subject_digest, "material_open_questions": len(material_open(self.questions))})
        return self.package

    # ------------------------------------------------------------------- WF-10 --
    def decide(self, *, principal: Principal, decision: str, rationale: str, token: Mapping[str, Any] | None = None, **kw: Any) -> dict[str, Any]:
        authority = f"decision:{principal.subject}:{self.run_id}"
        try:
            self.decision = self.gate.decide(package=self.package, principal=principal, decision=decision, scope=self.scope,
                                             policy_version=POLICY_VERSION, token=token, rationale=rationale, **kw)
        except (ReviewError, Exception) as exc:
            self.ledger.append("approval.refused", actor=principal.subject, actor_kind=principal.kind, outcome="denied", subject=self.run_id,
                               detail={"decision": decision, "reason": str(exc)})
            self.telemetry.metrics.increment("review.decisions")
            raise
        self.telemetry.metrics.increment("review.decisions")
        event = {"approve": "approve", "reject": "reject", "narrow_scope": "narrow_scope", "request_more_evidence": "request_more_evidence", "edit": "edit"}[decision]
        if decision == "approve":
            self.telemetry.metrics.increment("review.approved")
        self._fire(event, actor=principal.subject, actor_kind="human", authority_ref=authority, detail={"decision_id": self.decision["decision_id"]})
        self.design.set_review_state(decision, actor=principal.subject, expected_version=self.design.load().version)
        return self.decision

    def issue_token(self, *, approver: Principal, gate: str = "final_selection", action: str = "approve") -> dict[str, Any]:
        """One token per human act: ``approve`` for the selection, ``write`` for the case-file export."""
        return self.approvals.issue(approver=approver, run_id=self.run_id, gate=gate, artifact_ids=[c["candidate_id"] for c in self.generation.candidates],
                                    action=action, scope_digest=self.scope.scope_digest, subject_digest=self.package.subject_digest)

    # ------------------------------------------------------------------- WF-11 --
    def export(self, *, actor: Principal, token: Mapping[str, Any], output_root: Path, fail: bool = False) -> dict[str, Any]:
        self._fire("export_case_file", actor=actor.subject, actor_kind="human")
        parts = {
            "scope": self.scope.to_document(), "pinned_sources": {**self.pins.as_document(), "evidence_ref_ids": sorted(self.index.evidence)},
            "analyzer_results": [a.as_document() for a in self.analyzers], "versions": version_manifest(),
            "candidates": self.generation.candidates, "comparison": self.comparison, "verification": self.verification.as_document(),
            "uncertainty": {c["candidate_id"]: c["uncertainty"] for c in self.generation.candidates},
            "assumptions": self.assumptions.entries(), "questions": self.questions, "review_history": self.recorder.history(self.run_id),
            "approvals": [self.decision] if self.decision else [], "transitions": list(self.machine.history),
            "design_state_history": self.design.history(), "context_manifest": self.generation.context.as_document(),
            "policy_decisions": [self.generation.policy], "telemetry": self.telemetry.as_document(),
        }
        gate = WriteGate(service=self.approvals, scope=self.scope, machine=self.machine, output_root=Path(output_root), ledger=self.ledger,
                         permission="write_evidence")
        try:
            if fail:
                raise WriteDenied("write.io_error", "injected export failure")
            staging = self.workdir / "casefile"
            manifest = export_case_file(run_id=self.run_id, destination=staging, parts=parts, ledger=self.ledger, actor=actor.subject)
            # Every exported byte leaves through the write gate. Staging is workdir-internal;
            # copying leftover files with shutil after a single-file preview was a hidden write path.
            files = [(f"{self.run_id}/{path.name}", path.read_bytes()) for path in sorted(staging.iterdir()) if path.is_file()]
            receipts = gate.attempt_bundle(
                actor=actor, files=files, token=token,
                artifact_ids=[c["candidate_id"] for c in self.generation.candidates],
                subject_digest=self.package.subject_digest, run_id=self.run_id, gate="final_selection")
            self.export_dir = Path(output_root) / self.run_id
            receipt = receipts[0] if receipts else None
        except (WriteDenied, Exception) as exc:
            self.ledger.append("export.failed", actor=actor.subject, actor_kind=actor.kind, outcome="failed", subject=self.run_id, detail={"reason": str(exc)})
            self._fire("export_failed", detail={"reason": str(exc)})
            raise RunAborted("WF-11", f"export failed: {exc}", self.machine.state)
        inspection = inspect_case_file(self.export_dir)
        self._fire("export_succeeded", detail={"manifest_digest": manifest["manifest_digest"], "inspection_ok": inspection["ok"]})
        return {"manifest": manifest, "inspection": inspection, "receipt": receipt.as_document() if hasattr(receipt, "as_document") else str(receipt)}

    # ------------------------------------------------------------------ summary --
    def summary(self) -> dict[str, Any]:
        ok, reason = self.ledger.verify()
        return {"run_id": self.run_id, "state": self.machine.state, "terminal": self.machine.terminal, "ledger_ok": ok, "ledger_events": self.ledger.length,
                "records": len(self.index.records), "candidates": len(self.generation.candidates) if self.generation else 0,
                "mode": self.generation.mode if self.generation else None, "verification_passed": self.verification.passed if self.verification else None,
                "decision": self.decision["decision"] if self.decision else None, "transitions": [h["event"] for h in self.machine.history],
                "design_versions": len(self.design.history()) if self.store.head(f"runs/{self.run_id}/design-state") else 0,
                "telemetry": self.telemetry.metrics.snapshot(), "export_dir": str(self.export_dir) if self.export_dir else None}


# ------------------------------------------------------------------ scenarios --
DEFAULT_GOALS = ({"text": "Consolidate the governance services behind one published contract", "derivation": "human"},)
DEFAULT_CLASSES = ("requirement", "api_operation", "service", "security_constraint", "deployment_standard")


def _new_run(workdir: Path, name: str, *, classes=DEFAULT_CLASSES, mode="draft_only", **kw: Any) -> tuple[Run, Principal, IdentityProvider]:
    idp = IdentityProvider()
    idp.enroll("architect@example.test", "human", "architect-secret")
    idp.enroll("approver@example.test", "human", "approver-secret")
    approver = idp.authenticate("approver@example.test", "approver-secret")
    from .fixtures import scope_document
    doc = scope_document(f"RUN-{name}", subject="architect@example.test", classes=classes, mode=mode)
    run = Run(run_id=f"RUN-{name}", workdir=workdir / name, identity=idp, subject="architect@example.test", secret="architect-secret",
              scope_document=doc, **kw)
    return run, approver, idp


def _golden_prefix(run: Run) -> None:
    run.authenticate(); run.pin(); run.collect_and_index(); run.analyze(); run.generate(goals=DEFAULT_GOALS); run.verify(); run.present()


def scenario_golden(workdir: Path) -> dict[str, Any]:
    run, approver, _ = _new_run(workdir, "golden")
    _golden_prefix(run)
    token = run.issue_token(approver=approver)
    run.decide(principal=approver, decision="approve", rationale="reviewed candidates against the pinned evidence", token=token)
    write_token = run.issue_token(approver=approver, action="write")
    out = run.export(actor=approver, token=write_token, output_root=workdir / "golden-out")
    s = run.summary()
    return {**s, "case_file_ok": out["inspection"]["ok"], "case_file_problems": out["inspection"]["problems"], "passed": s["state"] == WorkflowState.COMPLETED and out["inspection"]["ok"]}


def scenario_rejection(workdir: Path) -> dict[str, Any]:
    run, approver, _ = _new_run(workdir, "reject")
    _golden_prefix(run)
    run.decide(principal=approver, decision="reject", rationale="the consolidation option does not satisfy the security fallback constraint")
    s = run.summary()
    return {**s, "passed": s["state"] == WorkflowState.REJECTED and s["ledger_ok"]}


def scenario_narrowing(workdir: Path) -> dict[str, Any]:
    run, approver, _ = _new_run(workdir, "narrow")
    _golden_prefix(run)
    before = len(run.index.records)
    run.decide(principal=approver, decision="narrow_scope", rationale="limit the iteration to the API catalog and services",
               narrowed_scope={"allowed_artifact_classes": ["api_operation", "service"]})
    narrowed = run.scope.narrowed(artifact_classes=["api_operation", "service"])
    widen_refused = False
    try:
        run.scope.narrowed(artifact_classes=["api_operation", "service", "diagram"])
    except ScopeError:
        widen_refused = True
    s = run.summary()
    return {**s, "records_before": before, "narrowed_classes": sorted(narrowed.allowed_artifact_classes), "widening_refused": widen_refused,
            "design_versions_preserved": s["design_versions"] >= 3,
            "passed": s["state"] == WorkflowState.SCOPE_NARROWED and widen_refused and s["ledger_ok"]}


def scenario_tool_failure(workdir: Path) -> dict[str, Any]:
    def hook(connector: Any) -> None:
        for loc in connector._discover(run.scope):
            connector.simulate_unavailable(loc)
    run, approver, _ = _new_run(workdir, "toolfail", connector_hook=lambda c: None)
    run.connector_hook = hook
    run.authenticate()
    try:
        run.pin()
        run.collect_and_index()
        outcome = "unexpected success"
    except RunAborted as exc:
        outcome = exc.terminal
    s = run.summary()
    return {**s, "outcome": outcome, "passed": s["state"] in SAFE_TERMINALS and s["ledger_ok"]}


def scenario_abstention(workdir: Path) -> dict[str, Any]:
    run, approver, _ = _new_run(workdir, "abstain", classes=("cost_perf_constraint",))
    run.authenticate(); run.pin()
    try:
        run.collect_and_index(); run.analyze(); run.generate(goals=DEFAULT_GOALS)
        outcome = "generated"
    except RunAborted as exc:
        outcome = exc.terminal
    s = run.summary()
    return {**s, "outcome": outcome, "passed": s["state"] == WorkflowState.ABSTAINED and s["ledger_ok"]}


def scenario_forged_approval(workdir: Path) -> dict[str, Any]:
    run, approver, idp = _new_run(workdir, "forged")
    _golden_prefix(run)
    token = run.issue_token(approver=approver)
    forged = dict(token); forged["signature"] = ("0" if token["signature"][0] != "0" else "1") + token["signature"][1:]
    refused_forged = refused_service = refused_other = False
    try:
        run.decide(principal=approver, decision="approve", rationale="forged", token=forged)
    except Exception:
        refused_forged = True
    idp.enroll("svc-runner", "service", "svc")
    svc = idp.authenticate("svc-runner", "svc")
    try:
        run.decide(principal=svc, decision="approve", rationale="service", token=token)
    except Exception:
        refused_service = True
    idp.enroll("other@example.test", "human", "other")
    other = idp.authenticate("other@example.test", "other")
    try:
        run.decide(principal=other, decision="approve", rationale="someone else's token", token=token)
    except Exception:
        refused_other = True
    # no side effect: an export without a valid decision is refused by the write gate
    try:
        run.export(actor=approver, token=forged, output_root=workdir / "forged-out")
        export_refused = False
    except (RunAborted, TransitionError):
        export_refused = True
    s = run.summary()
    return {**s, "refused_forged": refused_forged, "refused_service": refused_service, "refused_other_principal": refused_other,
            "export_refused": export_refused, "passed": refused_forged and refused_service and refused_other and export_refused
            and s["state"] in (WorkflowState.AWAITING_REVIEW,) and s["ledger_ok"]}


def scenario_rollback(workdir: Path) -> dict[str, Any]:
    run, approver, _ = _new_run(workdir, "rollback")
    _golden_prefix(run)
    token = run.issue_token(approver=approver)
    run.decide(principal=approver, decision="approve", rationale="approved for export", token=token)
    write_token = run.issue_token(approver=approver, action="write")
    try:
        run.export(actor=approver, token=write_token, output_root=workdir / "rollback-out", fail=True)
        outcome = "unexpected success"
    except RunAborted as exc:
        outcome = exc.terminal
    leaked = list((workdir / "rollback-out").rglob("*")) if (workdir / "rollback-out").exists() else []
    s = run.summary()
    return {**s, "outcome": outcome, "external_files_written": len([p for p in leaked if p.is_file()]),
            "passed": s["state"] == WorkflowState.ROLLED_BACK and not leaked and s["ledger_ok"]}


def scenario_kill_switch(workdir: Path) -> dict[str, Any]:
    run, approver, _ = _new_run(workdir, "kill")
    run.authenticate(); run.pin(); run.collect_and_index(); run.analyze()
    run.flags.emergency_disable(actor=approver, reason="scenario: kill switch mid-run")
    try:
        run.generate(goals=DEFAULT_GOALS)
        outcome = "generated"
    except RunAborted as exc:
        outcome = exc.terminal
    s = run.summary()
    return {**s, "outcome": outcome, "passed": s["state"] == WorkflowState.DENIED and s["candidates"] == 0 and s["ledger_ok"]}


def scenario_unauthenticated(workdir: Path) -> dict[str, Any]:
    run, approver, _ = _new_run(workdir, "unauth")
    run._secret = "wrong"
    try:
        run.authenticate()
        outcome = "authenticated"
    except RunAborted as exc:
        outcome = exc.terminal
    source_access = any(e["event"]["event_type"].startswith("connector.") for e in run.ledger.events())
    s = run.summary()
    return {**s, "outcome": outcome, "source_access_before_denial": source_access, "passed": s["state"] == WorkflowState.DENIED and not source_access}


SCENARIOS: dict[str, Callable[[Path], dict[str, Any]]] = {
    "golden_path": scenario_golden, "rejection": scenario_rejection, "scope_narrowing": scenario_narrowing,
    "tool_failure": scenario_tool_failure, "abstention": scenario_abstention, "forged_approval": scenario_forged_approval,
    "rollback_on_export_failure": scenario_rollback, "kill_switch_mid_run": scenario_kill_switch, "unauthenticated_start": scenario_unauthenticated,
}


def scenarios(workdir: Path | None = None, *, only: Sequence[str] | None = None) -> dict[str, Any]:
    workdir = Path(workdir or tempfile.mkdtemp(prefix="as-scenarios-"))
    results = {}
    for name, fn in SCENARIOS.items():
        if only and name not in only:
            continue
        try:
            results[name] = fn(workdir)
        except Exception as exc:  # a scenario that crashes is a failed scenario, reported not hidden
            results[name] = {"passed": False, "error": f"{type(exc).__name__}: {exc}"}
    return {"pipeline_version": PIPELINE_VERSION, "workdir": str(workdir), "scenarios": results,
            "all_passed": all(r.get("passed") for r in results.values()), "at": fmt_ts(datetime.now(timezone.utc))}
