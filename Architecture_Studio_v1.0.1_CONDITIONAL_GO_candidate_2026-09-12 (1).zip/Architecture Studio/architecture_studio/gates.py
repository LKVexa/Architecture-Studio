"""Production readiness gates and program state (GATE-PROD-01..08, XEVAL-07, AUDIT-ADD-21).

Each gate is a machine-evaluated *evidence check* plus a human *review slot*.
The mechanical part inspects the reports this runtime produces (test report,
benchmark, verification, supply chain, recovery exercise, docs freshness) and
yields ``EVIDENCE_PASS`` / ``EVIDENCE_FAIL`` / ``NO_EVIDENCE``. The gate's
*status* is ``PASS`` only when the mechanical part passes **and** an
independent human review record is attached whose reviewer is a distinct
trusted principal (never the runtime, never the builder of the evidence).
Otherwise it is ``AWAITING_INDEPENDENT_REVIEW`` (evidence passes, nobody has
reviewed it), ``FAIL`` (evidence fails) or ``NO_EVIDENCE``.

Exceptions are only representable as a *documented human risk acceptance*
record naming the gate, the accepter, the expiry and the compensating
control; an exception without all four is ignored, and an exception never
turns a ``FAIL`` into ``PASS`` — it turns it into ``ACCEPTED_RISK`` which the
production verdict still counts as not-PASS.

The production verdict is ``NO_GO`` unless every gate is ``PASS``. This module
builds the desk and binds nobody: it names the *role* that must review each
gate, never a person.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from .canonical import digest_of

__all__ = ["Gate", "GATES", "evaluate_gates", "production_verdict", "GATES_VERSION"]

GATES_VERSION = "1.0.0"

Evidence = Mapping[str, Any]


def _tests_all_pass(ev: Evidence) -> tuple[str, str]:
    report = ev.get("tests")
    if not report:
        return "NO_EVIDENCE", "no test report"
    return ("EVIDENCE_PASS" if report.get("all_passed") else "EVIDENCE_FAIL"), f"{report.get('passed', 0)}/{report.get('total', 0)} tests passed"


def _gate_01(ev: Evidence) -> tuple[str, str]:
    controls = ev.get("controls")
    tests = ev.get("tests")
    if not controls or not tests:
        return "NO_EVIDENCE", "controls document and test report required"
    unmapped = [c["control_id"] for c in controls.get("controls", []) if not c.get("tests")]
    status, detail = _tests_all_pass(ev)
    if unmapped:
        return "EVIDENCE_FAIL", f"controls without tests: {unmapped}"
    return status, f"{len(controls.get('controls', []))} enforceable controls, each test-mapped; {detail}"


def _gate_02(ev: Evidence) -> tuple[str, str]:
    bench = ev.get("benchmark")
    if not bench:
        return "NO_EVIDENCE", "no benchmark report"
    if bench.get("thresholds_status") != "APPROVED":
        return "EVIDENCE_FAIL", "benchmark thresholds are PROPOSED; 'acceptable' is undefined until a human approves them"
    if not bench.get("suite_passed"):
        return "EVIDENCE_FAIL", f"benchmark cases failed: {bench.get('failed_cases')}"
    return "EVIDENCE_PASS", "benchmark passed against APPROVED thresholds"


def _gate_03(ev: Evidence) -> tuple[str, str]:
    tests = ev.get("tests")
    scan = ev.get("write_authority_scan")
    if not tests or scan is None:
        return "NO_EVIDENCE", "write-gate truth-table tests and a write-authority scan required"
    if scan.get("hidden_write_paths"):
        return "EVIDENCE_FAIL", f"write paths outside the WriteGate: {scan['hidden_write_paths']}"
    return _tests_all_pass(ev)[0], f"{scan.get('write_sites', 0)} write site(s), all routed through WriteGate; write-gate tests in report"


def _gate_04(ev: Evidence) -> tuple[str, str]:
    ver = ev.get("verification")
    if not ver:
        return "NO_EVIDENCE", "no verification report over a real run"
    check = next((c for c in ver.get("checks", []) if c["check_id"] == "VERIFY-01"), None)
    if check is None:
        return "NO_EVIDENCE", "verification report lacks VERIFY-01"
    return ("EVIDENCE_PASS" if check["result"] == "PASS" else "EVIDENCE_FAIL"), check["summary"]


def _gate_05(ev: Evidence) -> tuple[str, str]:
    bench = ev.get("benchmark")
    tests = ev.get("tests")
    if not bench or not tests:
        return "NO_EVIDENCE", "benchmark guardrail cases and approval truth-table tests required"
    if not bench.get("all_guardrail_cases_pass"):
        return "EVIDENCE_FAIL", "a guardrail/workflow bypass case failed"
    return _tests_all_pass(ev)[0], "bypass cases (service approver, replay, forgery, model write, no approval path) pass"


def _gate_06(ev: Evidence) -> tuple[str, str]:
    drill, recovery, docs = ev.get("incident_drill"), ev.get("recovery_exercise"), ev.get("docs")
    if not drill or not recovery or not docs:
        return "NO_EVIDENCE", "incident drill, recovery exercise and runbook freshness required"
    runbook = next((d for d in docs.get("documents", []) if d["doc_id"] == "DOC-11"), None)
    if runbook is None or not runbook.get("current"):
        return "EVIDENCE_FAIL", "incident/rollback runbook missing or stale"
    ok = drill.get("passed") and recovery.get("passed")
    return ("EVIDENCE_PASS" if ok else "EVIDENCE_FAIL"), f"drill passed={drill.get('passed')}, recovery passed={recovery.get('passed')}, runbook current"


def _gate_07(ev: Evidence) -> tuple[str, str]:
    review = ev.get("security_review")
    if not review:
        return "NO_EVIDENCE", "no security/privacy review record; the runtime cannot review itself"
    if review.get("reviewer_kind") != "human" or not review.get("independent"):
        return "EVIDENCE_FAIL", "security review must be by an independent human reviewer"
    return "EVIDENCE_PASS", f"review {review.get('review_ref')} complete"


def _gate_08(ev: Evidence) -> tuple[str, str]:
    docs = ev.get("docs")
    if not docs:
        return "NO_EVIDENCE", "no documentation report"
    lim = next((d for d in docs.get("documents", []) if d["doc_id"] == "DOC-12"), None)
    if lim is None or not lim.get("current"):
        return "EVIDENCE_FAIL", "known limitations document missing or stale"
    if not lim.get("published_ref"):
        return "EVIDENCE_FAIL", "known limitations document exists but has no publication reference (published where reviewers read)"
    return "EVIDENCE_PASS", f"published at {lim['published_ref']}"


@dataclass(frozen=True)
class Gate:
    gate_id: str
    condition: str
    evidence_owner_role: str
    review_role: str
    required_artifacts: tuple[str, ...]
    check: Callable[[Evidence], tuple[str, str]]

    def as_document(self) -> dict[str, Any]:
        return {"gate_id": self.gate_id, "condition": self.condition, "evidence_owner_role": self.evidence_owner_role,
                "review_role": self.review_role, "required_artifacts": list(self.required_artifacts)}


GATES: tuple[Gate, ...] = (
    Gate("GATE-PROD-01", "All paper-stated guardrails are implemented as enforceable controls.", "security_privacy_owner",
         "independent_security_reviewer", ("policy.controls_document", "tests/test_policy.py report"), _gate_01),
    Gate("GATE-PROD-02", "Evaluation demonstrates acceptable grounding and false-positive behavior.", "ml_evaluation_owner",
         "independent_evaluation_reviewer", ("benchmark report with APPROVED thresholds",), _gate_02),
    Gate("GATE-PROD-03", "No hidden write authority exists outside approved workflows.", "security_privacy_owner",
         "independent_security_reviewer", ("write-authority scan", "tests/test_security.py write-gate truth table"), _gate_03),
    Gate("GATE-PROD-04", "Every material output is traceable to evidence.", "architecture_owner",
         "independent_architecture_reviewer", ("verification report VERIFY-01 over a real run",), _gate_04),
    Gate("GATE-PROD-05", "Human approval gates have been tested for bypass resistance.", "human_review_policy_owner",
         "independent_security_reviewer", ("benchmark guardrail cases", "tests/test_approvals_review.py truth table"), _gate_05),
    Gate("GATE-PROD-06", "Rollback and incident procedures are documented and exercised.", "incident_response_owner",
         "independent_operations_reviewer", ("incident drill result", "recovery exercise result", "DOC-11 current"), _gate_06),
    Gate("GATE-PROD-07", "Security/privacy review is complete.", "security_privacy_owner", "independent_security_reviewer",
         ("security review record by an independent human",), _gate_07),
    Gate("GATE-PROD-08", "Known limitations and non-goals are published.", "documentation_owner", "product_owner",
         ("DOC-12 current with publication reference",), _gate_08),
)


def _review_ok(review: Mapping[str, Any] | None, builder_subjects: Sequence[str]) -> tuple[bool, str]:
    if not review:
        return False, "no independent review record"
    if review.get("reviewer_kind") != "human":
        return False, "reviewer is not a human principal"
    if review.get("reviewer_subject") in set(builder_subjects) | {"architecture_studio", "runtime", "generator"}:
        return False, "reviewer is the builder/runtime; not independent"
    if review.get("decision") != "PASS":
        return False, f"reviewer decision is {review.get('decision')!r}"
    if not review.get("evidence_digest"):
        return False, "review does not name the evidence digest it reviewed"
    return True, f"reviewed by {review.get('reviewer_subject')} ({review.get('review_ref')})"


def _exception_ok(exc: Mapping[str, Any] | None) -> bool:
    return bool(exc) and all(exc.get(k) for k in ("gate_id", "accepted_by", "expires_at", "compensating_control", "rationale")) \
        and exc.get("accepter_kind") == "human"


def evaluate_gates(evidence: Evidence, *, reviews: Mapping[str, Mapping[str, Any]] | None = None,
                   exceptions: Mapping[str, Mapping[str, Any]] | None = None,
                   builder_subjects: Sequence[str] = ()) -> dict[str, Any]:
    reviews = reviews or {}
    exceptions = exceptions or {}
    rows = []
    for gate in GATES:
        mech, detail = gate.check(evidence)
        ok, review_detail = _review_ok(reviews.get(gate.gate_id), builder_subjects)
        if mech == "EVIDENCE_PASS" and ok:
            status = "PASS"
        elif mech == "EVIDENCE_PASS":
            status = "AWAITING_INDEPENDENT_REVIEW"
        elif mech == "EVIDENCE_FAIL":
            status = "ACCEPTED_RISK" if _exception_ok(exceptions.get(gate.gate_id)) else "FAIL"
        else:
            status = "NO_EVIDENCE"
        rows.append({**gate.as_document(), "mechanical": mech, "mechanical_detail": detail, "review": review_detail, "status": status,
                     "evidence_digest": digest_of({k: evidence.get(k) for k in sorted(evidence) if evidence.get(k) is not None})})
    return {"gates_version": GATES_VERSION, "gates": rows, "all_pass": all(r["status"] == "PASS" for r in rows),
            "counts": {s: sum(1 for r in rows if r["status"] == s) for s in ("PASS", "AWAITING_INDEPENDENT_REVIEW", "FAIL", "ACCEPTED_RISK", "NO_EVIDENCE")}}


def production_verdict(gate_report: Mapping[str, Any]) -> dict[str, Any]:
    blocking = [r["gate_id"] for r in gate_report["gates"] if r["status"] != "PASS"]
    return {"verdict": "GO" if not blocking else "NO_GO", "blocking_gates": blocking,
            "note": "GO requires every gate PASS: passing evidence plus an independent human review; ACCEPTED_RISK never counts as PASS"}
