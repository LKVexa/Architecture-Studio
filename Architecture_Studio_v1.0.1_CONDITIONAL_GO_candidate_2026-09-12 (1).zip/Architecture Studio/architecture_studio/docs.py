"""Required documentation artifacts, generated from authoritative configuration (DOC-01..12, AUDIT-ADD-22).

Every document is *rendered* from the runtime's own data structures — the
schema registry, the policy controls, the connector registry, the environment
descriptors, the workflow transitions, the benchmark and SLO tables — so the
document cannot drift from the thing it describes without the freshness check
noticing: each rendered file carries the SHA-256 of the inputs it was
generated from, and :func:`freshness_report` recomputes those digests and
marks a document ``current`` only when they match. Each document names an
owner *role* and the requirement/control IDs it covers.

DOC-12 (known limitations and non-goals) is derived from the runtime's
declared blockers so that it is the one place a reader can see what this pass
did **not** do, stated as data.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping

from . import PACKAGE_VERSION_APPLIED, __version__, version_manifest
from .canonical import digest_of, fmt_ts
from .connectors.typed import REGISTRY
from .environments import ENVIRONMENTS, boundary_report
from .evaluation import BURDEN_LIMITS, PILOT_EXIT_CRITERIA
from .evidence_io import atomic_write
from .gates import GATES
from .generator import ProviderSlot, SYSTEM_PROMPTS
from .policy import ACTION_KINDS, STOP_CONDITIONS, controls_document
from .registry import CONTROL_OWNERSHIP, ESCALATION_PATH, RACI
from .release import ACCEPTANCE_RULE, rollback_plan
from .review import ACCOUNTABILITY
from .schemas import DATA_CLASSES, PERMISSIONS, export_schemas
from .scope import MUTATING, PRIVILEGED, SYSTEM_BOUND
from .security import MATRIX
from .slo import CEILINGS, TARGETS
from .supply_chain import inventory, policy_check
from .workflow import HUMAN_ONLY_EVENTS, SAFE_TERMINALS, TERMINAL_STATES, TRANSITIONS

__all__ = ["DOCUMENTS", "render_all", "freshness_report", "KNOWN_LIMITATIONS", "DOCS_VERSION"]

DOCS_VERSION = "1.0.0"

#: DOC-12 content — the blockers this pass declares, as data.
KNOWN_LIMITATIONS: tuple[dict[str, str], ...] = (
    {"id": "LIM-01", "area": "model", "statement": "No model provider is bound (MODEL-01/ARCH-06). All candidates come from the deterministic evidence generator and are labelled deterministic_analyzer. Binding is a recorded human act."},
    {"id": "LIM-02", "area": "thresholds", "statement": "Every numeric threshold (grounding coverage, distinctness similarity, SLO targets, benchmark targets, burden limits, pilot exit criteria) is PROPOSED. Nothing passes on a proposed threshold."},
    {"id": "LIM-03", "area": "environments", "statement": "Only the local sandbox and the isolated test tenant are provisioned (they are this checkout). CI, staging, production read-only and the privileged path are declared descriptors; ENV-04/ENV-05 applicability is UNRESOLVED."},
    {"id": "LIM-04", "area": "identity", "statement": "The identity provider is a local reference implementation with an empty binding slot for a host IdP; production authentication is a host blocker (XAUTH-01)."},
    {"id": "LIM-05", "area": "encryption", "statement": "Encryption at rest works with the local KEK reference provider; the KMS slot is empty and encryption in transit is a host responsibility, not claimed."},
    {"id": "LIM-06", "area": "sandbox", "statement": "Tool execution isolation is process-level (subprocess, timeout, cwd, env allowlist). Container or VM isolation is a host capability."},
    {"id": "LIM-07", "area": "verification", "statement": "No task record is VERIFIED or ACCEPTED. The runtime cannot verify its own work; every record awaits an independent human verifier. The production verdict is NO_GO."},
    {"id": "LIM-08", "area": "gates", "statement": "GATE-PROD-01..08 evaluate evidence mechanically but reach PASS only with an independent human review record; none exists yet. GATE-PROD-02 FAILs while every numeric threshold remains PROPOSED. GATE-PROD-07 has no security/privacy review evidence (the runtime cannot review itself). Remaining gates, once their mechanical evidence is assembled, are AWAITING_INDEPENDENT_REVIEW."},
    {"id": "LIM-09", "area": "retrieval", "statement": "Retrieval is deterministic BM25 over the local corpus; the recall benchmark is a self-retrieval proxy until a human-labelled query set exists."},
    {"id": "LIM-10", "area": "injection", "statement": "Injection detection is heuristic (measured recall on BIPIA is partial, false positives on llmail controls are zero); the enforced control is channel isolation, not detection."},
    {"id": "LIM-11", "area": "corpus", "statement": "Evidence connectors read the checked-in project corpus and fixtures only; live requirement/ADR/API/infra systems are connector slots satisfied by the same contract tests."},
    {"id": "LIM-12", "area": "non-goal", "statement": "The studio does not deploy, commit, or modify any external system. modify/commit/deploy exist as permissions so that they can be denied by default, not so that they can be used."},
    {"id": "LIM-13", "area": "asfw", "statement": "The ASFW 545-item package is ingested as an immutable pin. Source INDEX.csv is ABSENT. Missing DOD-02/04/05/08/09 definitions and the GATE-PROD 8-vs-9 question are UNRESOLVED source ambiguities and were not inferred. IMPLEMENTED ASFW items remain incomplete until independent human review. Production GO from ASFW is NO_GO."},
    {"id": "LIM-14", "area": "asgo", "statement": "The ASGO 150-item Production GO package is ingested as an immutable pin (sha256 41209097b7b6d7fdaf905a7d52776be8557214049741ad4df5c89bf1982971b9). Architecture Studio is overlay-only: the 612-file corpus is a sibling input, not shipped in the overlay zip. INDEX.csv remains ABSENT and is not substituted. This implementer cannot mark ASGO items DONE, VERIFIED, or GO. A same-session chat signature is not independent review. Production GO from ASGO is NO_GO."},
)


def _md_table(headers: list[str], rows: list[list[Any]]) -> str:
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    for row in rows:
        out.append("| " + " | ".join(str(c).replace("|", "\\|").replace("\n", " ") for c in row) + " |")
    return "\n".join(out)


def _doc_01() -> tuple[dict[str, Any], str]:
    modules = ["authority", "scope", "policy", "connectors", "normalize", "retrieval", "analysis", "generator", "verify", "review",
               "approvals", "writes", "casefile", "ledger", "store", "incident", "observability"]
    edges = [("authority", "scope"), ("scope", "policy"), ("policy", "connectors"), ("connectors", "normalize"), ("normalize", "retrieval"),
             ("retrieval", "analysis"), ("analysis", "generator"), ("generator", "verify"), ("verify", "review"), ("review", "approvals"),
             ("approvals", "writes"), ("writes", "casefile"), ("policy", "incident"), ("ledger", "casefile"), ("store", "casefile"),
             ("observability", "casefile")]
    src = {"modules": modules, "edges": edges, "versions": version_manifest()}
    mermaid = "\n".join(["flowchart LR"] + [f"  {a} --> {b}" for a, b in edges] +
                        ["  subgraph trusted_control_plane", "    authority", "    scope", "    policy", "    approvals", "    writes", "    incident", "  end",
                         "  subgraph evidence_plane", "    connectors", "    normalize", "    retrieval", "    analysis", "  end",
                         "  subgraph synthesis_plane_untrusted_output", "    generator", "  end"])
    body = f"""Generated from the module dependency declaration in `architecture_studio/docs.py` (versions: `{version_manifest()['runtime']}`).

```mermaid
{mermaid}
```

Controls referenced: {", ".join(sorted(c["control_id"] for c in controls_document()["controls"]))}.
The synthesis plane produces untrusted output; nothing it emits is executed or written without passing `verify` → `review` → `approvals` → `writes`.
"""
    return src, body


def _doc_02() -> tuple[dict[str, Any], str]:
    src = {"matrix": MATRIX, "sources": sorted(REGISTRY), "permissions": list(PERMISSIONS)}
    mermaid = "\n".join([
        "flowchart TB",
        "  subgraph B0[Trust boundary 0: corpus and fixtures - read only]", "    SRC[9 typed connectors]", "  end",
        "  subgraph B1[Trust boundary 1: evidence plane - data channel]", "    NORM[normalize + classify + quarantine]", "    IDX[retrieval index]", "  end",
        "  subgraph B2[Trust boundary 2: synthesis - untrusted output]", "    GEN[generator / provider slot]", "  end",
        "  subgraph B3[Trust boundary 3: human control plane]", "    VER[independent verification]", "    REV[review package]", "    APP[approval token]", "  end",
        "  subgraph B4[Trust boundary 4: side effects]", "    WG[write gate]", "    OUT[(output root)]", "  end",
        "  SRC -->|labelled DATA blocks| NORM --> IDX -->|context manifest| GEN --> VER --> REV --> APP --> WG --> OUT",
        "  LEDGER[(hash-chained ledger)]", "  NORM -.-> LEDGER", "  GEN -.-> LEDGER", "  APP -.-> LEDGER", "  WG -.-> LEDGER"])
    rows = [[lvl, *[MATRIX[lvl].get(d, "-") for d in ("model", "reviewer", "export", "log")]] for lvl in MATRIX]
    body = f"""Generated from `security.MATRIX` and the connector registry.

```mermaid
{mermaid}
```

## Classification × destination

{_md_table(["level", "model", "reviewer", "export", "log"], rows)}

Retrieved content enters the model only as a labelled data block (`security.isolate_content`); authority is never read from content (SEC-01, XSEC-01..03).
"""
    return src, body


def _doc_03() -> tuple[dict[str, Any], str]:
    rows = []
    for data_class, cls in REGISTRY.items():
        rows.append([data_class, cls.source_system, cls.__name__, ", ".join(getattr(cls, "suffixes", ()) or ()), ", ".join(getattr(cls, "root_files", ()) or ()) or "-",
                     getattr(cls, "fixture_glob", None) or "-"])
    src = {"registry": {k: v.__name__ for k, v in REGISTRY.items()}}
    body = f"""Generated from `connectors.typed.REGISTRY` (DATA-01..09).

{_md_table(["data class", "source system", "connector", "suffixes", "root files", "fixtures"], rows)}

All connectors are read-only (`ConnectorCapabilities.write=False`), revision semantics `content-hash`, paginated (40/page), and pass `connectors.base.contract_test`. Live systems occupy the same slots under the same contract.
"""
    return src, body


def _doc_04() -> tuple[dict[str, Any], str]:
    src = {"permissions": list(PERMISSIONS), "mutating": sorted(MUTATING), "privileged": sorted(PRIVILEGED), "system_bound": sorted(SYSTEM_BOUND),
           "environments": {e.environment_id: list(e.permissions_ceiling) for e in ENVIRONMENTS}, "actions": list(ACTION_KINDS)}
    rows = []
    for p in PERMISSIONS:
        rows.append([p, "yes" if p in MUTATING else "", "yes" if p in PRIVILEGED else "", "yes" if p in SYSTEM_BOUND else "",
                     *["✓" if p in e.permissions_ceiling else "·" for e in ENVIRONMENTS]])
    body = f"""Generated from `schemas.PERMISSIONS`, `scope.MUTATING/PRIVILEGED/SYSTEM_BOUND` and `environments.ENVIRONMENTS` (XAUTH-03, XAUTH-04, IMPL-01).

{_md_table(["permission", "mutating", "privileged", "system-bound", *[e.environment_id for e in ENVIRONMENTS]], rows)}

Composition only narrows (`scope.effective_permissions`): a run holds the intersection of contract, environment ceiling, rollout mode and human authority. `approve` is never held by a service or model principal.
"""
    return src, body


def _doc_05() -> tuple[dict[str, Any], str]:
    controls = controls_document()
    src = {"controls": controls, "stop_conditions": STOP_CONDITIONS}
    threats = [
        ["T1 indirect prompt injection via evidence", "SEC-01/XSEC-02", "channel isolation + detector (advisory) + BIPIA benchmark", "CTRL-GRD-*"],
        ["T2 model self-approval / final selection", "SEC-07/HUMAN-06", "approval tokens bound to human principals; ApprovalGate", "CTRL-AUTH-01, CTRL-GRD-01"],
        ["T3 hidden write path", "XTOOL-05/GATE-PROD-03", "single WriteGate; model-originated mutating calls refused", "CTRL-AUTH-02"],
        ["T4 replay / forged approval", "SEC-08/WF-10", "nonce store, HMAC/Ed25519 signatures, scope+subject digests", "CTRL-VERIFY-01"],
        ["T5 cross-tenant evidence leak", "XSEC-03", "tenant filter at connector + canary + assert_no_cross_tenant", "CTRL-AUTHZ"],
        ["T6 stale evidence presented as current", "AUDIT-ADD-12", "freshness demotion, stale abstention, conflict records", "CTRL-PROV-01"],
        ["T7 secret disclosure in outputs", "XSEC-01", "classification before model/tool, redaction, secret scan in verification", "CTRL-GRD-03"],
        ["T8 rollout without kill switch", "AUDIT-ADD-26", "FlagStore consulted on the execution path; fail closed when unreadable", "CTRL-KILL-01"],
    ]
    body = f"""Generated from `policy.controls_document()` and `policy.STOP_CONDITIONS`.

## Threats and controls

{_md_table(["threat", "requirement", "mitigation", "control ids"], threats)}

## Enforceable controls ({controls['control_count']})

{_md_table(["control", "requirement", "title", "stop condition"], [[c['control_id'], c['requirement_id'], c['title'], c['stop_condition']] for c in controls['controls']])}

## Stop conditions

{_md_table(["stop", "condition", "requirement"], [[s['stop_id'], s['condition'], s['requirement_id']] for s in STOP_CONDITIONS])}

Residual risk: detection heuristics are advisory; the enforced control for injected content is isolation. This threat model has not been reviewed by an independent security reviewer (GATE-PROD-07: NO_EVIDENCE).
"""
    return src, body


def _doc_06() -> tuple[dict[str, Any], str]:
    inv = inventory()
    slot = ProviderSlot().describe()
    src = {"slot": slot, "prompts": {k: v["version"] for k, v in SYSTEM_PROMPTS.items()}, "third_party": inv.get("third_party_imports"), "versions": version_manifest()}
    body = f"""Generated from `generator.ProviderSlot`, `generator.SYSTEM_PROMPTS`, `supply_chain.inventory()` and `version_manifest()`.

## Model provider slot

- bound: **{slot['bound']}**
- blocker: {slot['blocker']}
- deterministic generator: `architecture_studio.generator.DeterministicEvidenceGenerator` (labels its output `deterministic_analyzer`)

## Prompts (versioned data, MODEL-02)

{_md_table(["prompt id", "version"], [[k, v] for k, v in sorted(src['prompts'].items())])}

## Tools and third-party runtime imports

- runtime third-party imports required: **none**; optional: `cryptography` (Ed25519 signatures, AES-GCM at rest) — absence is labelled, never downgraded silently.
- supply-chain policy: {policy_check(inv)['verdict']}

## Component versions

{_md_table(["component", "version"], [[k, v] for k, v in version_manifest().items()])}
"""
    return src, body


def _doc_07() -> tuple[dict[str, Any], str]:
    schemas = export_schemas()["schemas"]
    keep = {k: v for k, v in schemas.items() if k in ("as.evidence_ref/1", "as.uncertainty/1", "as.connector_record/1", "as.audit_event/1", "as.case_file/1")}
    src = {"schemas": keep}
    parts = [f"Generated from `schemas.export_schemas()` (API-03, XPROV-01..07)."]
    for sid, schema in keep.items():
        parts.append(f"\n## `{sid}` (v{schema['version']})\n\n{schema['description']}\n\n" +
                     _md_table(["field", "type", "constraints"], [[f, spec.get("type"), ", ".join(f"{k}={v}" for k, v in spec.items() if k not in ("type", "properties", "items"))]
                                                                   for f, spec in schema["fields"].items()]))
    return src, "\n".join(parts) + "\n"


def _doc_08() -> tuple[dict[str, Any], str]:
    schemas = export_schemas()["schemas"]
    keep = {k: v for k, v in schemas.items() if k in ("as.workflow_state/1", "as.design_state/1", "as.option_event/1", "as.scope_contract/1")}
    src = {"transitions": TRANSITIONS, "terminal": sorted(TERMINAL_STATES), "safe": sorted(SAFE_TERMINALS), "human_only": sorted(HUMAN_ONLY_EVENTS), "schemas": keep}
    states = sorted({s for s in TRANSITIONS} | {t for m in TRANSITIONS.values() for t in m.values()})
    mermaid = "\n".join(["stateDiagram-v2"] + [f"  {s} --> {t}: {e}" for s, m in TRANSITIONS.items() for e, t in m.items()])
    body = f"""Generated from `workflow.TRANSITIONS` and the run-state schemas (XSTATE-01..05, ARCH-05).

- states: {len(states)}; terminal: {', '.join(sorted(TERMINAL_STATES))}; safe terminals (WF-12): {', '.join(sorted(SAFE_TERMINALS))}
- human-only events (require a human principal and authority ref): {', '.join(sorted(HUMAN_ONLY_EVENTS))}

```mermaid
{mermaid}
```

## Schemas

{chr(10).join(f"- `{k}` v{v['version']}: {v['description']}" for k, v in keep.items())}

Design state is append-only in the content-addressed store with compare-and-swap on the ref (`design_state.DesignStateStore`); every version is reconstructable (`history()`, `at_version()`).
"""
    return src, body


def _doc_09() -> tuple[dict[str, Any], str]:
    src = {"accountability": ACCOUNTABILITY, "human_only": sorted(HUMAN_ONLY_EVENTS), "raci": RACI, "escalation": ESCALATION_PATH}
    body = f"""Generated from `review.ACCOUNTABILITY`, `workflow.HUMAN_ONLY_EVENTS`, `registry.RACI` and `registry.ESCALATION_PATH` (HUMAN-01..07, SEC-07, WF-10).

## Statement of accountability (rendered on every review page)

> {ACCOUNTABILITY}

## What only a human may do

{chr(10).join(f"- `{e}`" for e in sorted(HUMAN_ONLY_EVENTS))}

Each requires an authenticated human `Principal`, an `authority_ref`, and — for approve — an approval token bound to approver, run, gate, artifacts, action, scope digest, subject digest, expiry and nonce (`approvals.ApprovalService`). Service and model principals are refused before signing (`authority.assert_not_self_attested`). A used token cannot be replayed. Every subsequent state change is gated on the verified token (`writes.WriteGate`).

## Escalation

{_md_table(["step", "role", "trigger"], [[i + 1, s.get('role', s) if isinstance(s, dict) else s, s.get('trigger', '') if isinstance(s, dict) else ''] for i, s in enumerate(ESCALATION_PATH)])}

Names are roles. Binding people to roles is an organisational act recorded outside this repository.
"""
    return src, body


def _doc_10() -> tuple[dict[str, Any], str]:
    src = {"targets": [t.as_document() for t in TARGETS], "burden": BURDEN_LIMITS, "pilot": PILOT_EXIT_CRITERIA, "acceptance": ACCEPTANCE_RULE}
    body = f"""Generated from `slo.TARGETS`, `evaluation.BURDEN_LIMITS`, `evaluation.PILOT_EXIT_CRITERIA` and `release.ACCEPTANCE_RULE` (IMPL-10, XEVAL-01..07, AUDIT-ADD-12/13/25).

## Benchmark corpus

- project corpus: 612 files / 66 suites, pinned by content hash (`fixtures.make_index`)
- MADR + Mermaid fixtures: `fixtures/adrs`, `fixtures/diagrams`
- adversarial: BIPIA attack instructions (125) and llmail benign controls (203), verbatim, MIT — `fixtures/adversarial`
- dimensions: grounding, provenance, distinctness, constraints, uncertainty, guardrail bypass, workflow outcomes, retrieval, and MODEL-07 failure modes reported separately

## Targets (all PROPOSED)

{_md_table(["target", "metric", "cmp", "value", "unit", "env", "owner role", "status"], [[t.target_id, t.metric, t.comparator, t.value, t.unit, t.environment, t.owner_role, t.status] for t in TARGETS])}

## Review-burden limits (PROPOSED)

{_md_table(["limit", "value"], [[k, v] for k, v in BURDEN_LIMITS.items()])}

## Pilot exit criteria `{PILOT_EXIT_CRITERIA['criteria_id']}` ({PILOT_EXIT_CRITERIA['status']})

{_md_table(["metric", "cmp", "value"], [[k, v['comparator'], v['value']] for k, v in PILOT_EXIT_CRITERIA['metrics'].items()])}

Rollout rule: {PILOT_EXIT_CRITERIA['rollout_rule']}

## Release acceptance rule `{ACCEPTANCE_RULE['rule_id']}` ({ACCEPTANCE_RULE['status']})

{chr(10).join(f"- {k}: {v}" for k, v in ACCEPTANCE_RULE.items() if k not in ('rule_id', 'version', 'status'))}
"""
    return src, body


def _doc_11() -> tuple[dict[str, Any], str]:
    plan = rollback_plan({"release": __version__}, None)
    src = {"plan": plan, "gates": [g.as_document() for g in GATES]}
    body = f"""Generated from `release.rollback_plan()` and `incident.drill()` (AUDIT-ADD-20, AUDIT-ADD-26, WF-12, ENV-*).

## Kill switch

`incident.FlagStore.emergency_disable(actor=<human>, reason=...)` sets `as.enabled=false`; the switch is consulted on the execution path (`generator.Generator.generate`, `policy.CTRL-KILL-01`) and a missing/unreadable/stale flag file is treated as disabled. Drill procedure: `incident.drill()` — stop, revoke identity, preserve ledger, prove zero provider calls after stop.

## Rollback

{chr(10).join(plan['steps'])}

State preserved: {', '.join(plan['state_preserved'])}. Verified by: {plan['verified_by']}.

## Incident roles

{_md_table(["gate", "evidence owner role", "review role"], [[g.gate_id, g.evidence_owner_role, g.review_role] for g in GATES if g.gate_id in ('GATE-PROD-06', 'GATE-PROD-07')])}

Quarantine: `incident.Quarantine.disable_connector()` / `quarantine_run()` keep artifacts for forensics and are ledger-logged.
"""
    return src, body


def _doc_12() -> tuple[dict[str, Any], str]:
    src = {"limitations": KNOWN_LIMITATIONS}
    body = f"""Generated from `docs.KNOWN_LIMITATIONS` (GATE-PROD-08, AUDIT-ADD-25). Runtime {__version__}, package applied {PACKAGE_VERSION_APPLIED}.

{_md_table(["id", "area", "statement"], [[l['id'], l['area'], l['statement']] for l in KNOWN_LIMITATIONS])}

Publication reference: `Architecture Studio/docs/DOC-12-known-limitations.md` in this repository, linked from `README.md`.
"""
    return src, body


DOCUMENTS: tuple[dict[str, Any], ...] = (
    {"doc_id": "DOC-01", "title": "Architecture diagram", "file": "DOC-01-architecture-diagram.md", "owner_role": "architecture_owner", "render": _doc_01, "covers": ["ARCH-01", "ARCH-02", "ARCH-06", "ARCH-07"]},
    {"doc_id": "DOC-02", "title": "Data-flow and trust-boundary diagram", "file": "DOC-02-data-flow-trust-boundaries.md", "owner_role": "security_privacy_owner", "render": _doc_02, "covers": ["SEC-01", "XSEC-01", "XSEC-02", "XSEC-03"]},
    {"doc_id": "DOC-03", "title": "Source/connector inventory", "file": "DOC-03-source-connector-inventory.md", "owner_role": "data_owner", "render": _doc_03, "covers": ["DATA-01", "DATA-02", "DATA-03", "DATA-04", "DATA-05", "DATA-06", "DATA-07", "DATA-08", "DATA-09"]},
    {"doc_id": "DOC-04", "title": "Permission matrix", "file": "DOC-04-permission-matrix.md", "owner_role": "security_privacy_owner", "render": _doc_04, "covers": ["XAUTH-03", "XAUTH-04", "IMPL-01", "ENV-01"]},
    {"doc_id": "DOC-05", "title": "Threat model", "file": "DOC-05-threat-model.md", "owner_role": "security_privacy_owner", "render": _doc_05, "covers": ["IMPL-06", "SEC-01", "SEC-07", "SEC-08", "GATE-PROD-01"]},
    {"doc_id": "DOC-06", "title": "Model/tool inventory", "file": "DOC-06-model-tool-inventory.md", "owner_role": "ml_evaluation_owner", "render": _doc_06, "covers": ["MODEL-01", "MODEL-02", "XTOOL-06", "AUDIT-ADD-18"]},
    {"doc_id": "DOC-07", "title": "Provenance schema", "file": "DOC-07-provenance-schema.md", "owner_role": "architecture_owner", "render": _doc_07, "covers": ["API-03", "XPROV-01", "XPROV-07"]},
    {"doc_id": "DOC-08", "title": "Run-state schema", "file": "DOC-08-run-state-schema.md", "owner_role": "architecture_owner", "render": _doc_08, "covers": ["XSTATE-01", "XSTATE-02", "ARCH-05", "WF-12"]},
    {"doc_id": "DOC-09", "title": "Human approval policy", "file": "DOC-09-human-approval-policy.md", "owner_role": "human_review_policy_owner", "render": _doc_09, "covers": ["HUMAN-06", "HUMAN-07", "SEC-07", "WF-10", "AUDIT-ADD-24"]},
    {"doc_id": "DOC-10", "title": "Evaluation plan and benchmark corpus description", "file": "DOC-10-evaluation-plan.md", "owner_role": "ml_evaluation_owner", "render": _doc_10, "covers": ["IMPL-10", "XEVAL-01", "AUDIT-ADD-12", "AUDIT-ADD-13", "AUDIT-ADD-25"]},
    {"doc_id": "DOC-11", "title": "Incident/rollback runbook", "file": "DOC-11-incident-rollback-runbook.md", "owner_role": "incident_response_owner", "render": _doc_11, "covers": ["AUDIT-ADD-20", "AUDIT-ADD-26", "WF-12", "GATE-PROD-06"]},
    {"doc_id": "DOC-12", "title": "Known limitations and non-goals", "file": "DOC-12-known-limitations.md", "owner_role": "documentation_owner", "render": _doc_12, "covers": ["GATE-PROD-08", "AUDIT-ADD-25"]},
)


def _header(doc: Mapping[str, Any], source_digest: str) -> str:
    return (f"<!-- generated by architecture_studio.docs v{DOCS_VERSION}; sources_digest={source_digest}; do not edit by hand -->\n"
            f"# {doc['doc_id']} — {doc['title']}\n\n"
            f"- owner role: `{doc['owner_role']}`\n- covers: {', '.join(doc['covers'])}\n- runtime: {__version__} · package: {PACKAGE_VERSION_APPLIED}\n"
            f"- sources digest: `{source_digest}`\n- review trigger: any change to the modules named as sources (freshness check fails otherwise)\n\n")


def render_all(directory: Path) -> dict[str, Any]:
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    written = []
    for doc in DOCUMENTS:
        src, body = doc["render"]()
        source_digest = digest_of(src)
        text = _header(doc, source_digest) + body
        atomic_write(directory / doc["file"], text.encode("utf-8"))
        written.append({"doc_id": doc["doc_id"], "file": doc["file"], "sources_digest": source_digest})
    index = "# Generated documentation index\n\n" + _md_table(["id", "title", "file", "owner role"], [[d["doc_id"], d["title"], f"[{d['file']}]({d['file']})", d["owner_role"]] for d in DOCUMENTS]) + "\n"
    atomic_write(directory / "INDEX.md", index.encode("utf-8"))
    return {"docs_version": DOCS_VERSION, "rendered_at": fmt_ts(datetime.now(timezone.utc)), "documents": written}


def freshness_report(directory: Path) -> dict[str, Any]:
    directory = Path(directory)
    rows = []
    for doc in DOCUMENTS:
        path = directory / doc["file"]
        src, _ = doc["render"]()
        expected = digest_of(src)
        current = False
        stored = None
        if path.exists():
            first = path.read_text(encoding="utf-8").splitlines()[0] if path.stat().st_size else ""
            if "sources_digest=" in first:
                stored = first.split("sources_digest=")[1].split(";")[0].strip()
                current = stored == expected
        rows.append({"doc_id": doc["doc_id"], "file": doc["file"], "exists": path.exists(), "current": current,
                     "stored_digest": stored, "expected_digest": expected, "owner_role": doc["owner_role"],
                     "published_ref": f"Architecture Studio/docs/{doc['file']}" if path.exists() else None, "covers": doc["covers"]})
    return {"docs_version": DOCS_VERSION, "documents": rows, "all_current": all(r["current"] for r in rows)}
