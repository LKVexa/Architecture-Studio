"""Canonical serialization, hashing and timestamps.

Two canonical forms, never confused:

* :func:`canonical_json` — the contract form for anything that is hashed and
  shared (evidence manifests, review packages, approval payloads): sorted keys,
  compact separators, **ASCII-only** output, one trailing LF. ASCII-only is a
  deliberate lesson: a sibling project signed ``json.dumps(ensure_ascii=True)``
  bytes in Python and verified ``JSON.stringify`` bytes in a browser, and every
  em-dash in a scope string produced an ``approval.signature_invalid`` that read
  like a wrong key. Signing bytes are fixed here once.
* :func:`compact_json` — the same form without the trailing LF, used for
  in-process record identity.

Adapted from the owner's Repository Context Graph runtime (``rcg/canonical.py``).
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any

__all__ = [
    "canonical_json", "canonical_bytes", "compact_json", "sha256_hex", "sha256_of",
    "digest_of", "merkle_root", "now_iso", "fmt_ts", "parse_ts",
]


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                      allow_nan=False) + "\n"


def canonical_bytes(value: Any) -> bytes:
    return canonical_json(value).encode("ascii")


def compact_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                      allow_nan=False)


def sha256_hex(payload: bytes | str) -> str:
    data = payload.encode("utf-8") if isinstance(payload, str) else payload
    return hashlib.sha256(data).hexdigest()


def sha256_of(payload: bytes | str) -> str:
    """Prefixed digest ``sha256:<hex>`` for record fields."""
    return "sha256:" + sha256_hex(payload)


def digest_of(value: Any) -> str:
    """Prefixed digest over the compact canonical form of a JSON value."""
    return sha256_of(compact_json(value))


def merkle_root(leaves: list[str]) -> str:
    """Binary Merkle root over hex leaves; sorted, odd node promoted (no duplication)."""
    if not leaves:
        return sha256_hex(b"")
    level = sorted(leaf if _is_hex(leaf) else sha256_hex(leaf) for leaf in leaves)
    while len(level) > 1:
        nxt: list[str] = []
        for i in range(0, len(level) - 1, 2):
            nxt.append(sha256_hex(level[i] + level[i + 1]))
        if len(level) % 2:
            nxt.append(level[-1])
        level = nxt
    return level[0]


def _is_hex(value: str) -> bool:
    return len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def fmt_ts(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def now_iso() -> str:
    return fmt_ts(datetime.now(timezone.utc))


def parse_ts(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("timestamps must carry a timezone")
    return parsed
