"""Diagram semantics and generation (AUDIT-ADD-11, COMP-09).

The canonical notation is ``as-component-lite/1``: elements and relations with
stable IDs that are the candidate's own element IDs, and layout kept apart from
semantics. Rendering to Mermaid is a deterministic projection of the semantic
document; :func:`round_trip` parses the rendered Mermaid back and proves the
element set is preserved, so a regenerated diagram keeps provenance and IDs.

Build provenance: BUILD_NEW (the yard's diagram hits were decision diagrams and
BI visuals, not architecture projections).
"""
from __future__ import annotations

import re
from typing import Any, Mapping

from .canonical import digest_of
from .connectors.parsers import parse_mermaid
from .ids import deterministic_id
from .schemas import validate

__all__ = ["SEMANTICS_VERSION", "NOTATION", "diagram_from_candidate", "render_mermaid", "round_trip"]

SEMANTICS_VERSION = "1.0.0"
NOTATION = "as-component-lite/1"
_SAFE = re.compile(r"[^A-Za-z0-9_]")
_SHAPES = {"queue": ("[[", "]]"), "store": ("[(", ")]"), "external": ("{{", "}}"), "policy_point": ("{", "}"),
           "sandbox": ("(", ")")}


def _mermaid_id(element_id: str) -> str:
    return "n_" + _SAFE.sub("_", element_id)


def diagram_from_candidate(candidate: Mapping[str, Any], *, layout_hints: Mapping[str, Any] | None = None) -> dict[str, Any]:
    elements = [{"element_id": c["element_id"], "label": c["name"], "kind": c["kind"], "candidate_element_id": c["element_id"]}
                for c in candidate["components"]]
    relations = [{"element_id": r["element_id"], "source": r["source"], "target": r["target"], "label": r["kind"],
                  "candidate_element_id": r["element_id"]} for r in candidate["relationships"]]
    doc = {"schema_id": "as.diagram/1",
           "diagram_id": deterministic_id("diagram", candidate=candidate["candidate_id"], structure=candidate["structure_digest"]),
           "candidate_id": candidate["candidate_id"], "notation": NOTATION, "elements": elements, "relations": relations,
           "layout_hints": dict(layout_hints or {"direction": "LR"}),
           "provenance_digest": digest_of({"candidate": candidate["candidate_id"],
                                            "refs": sorted(candidate.get("evidence_refs", []))}),
           "semantics_version": SEMANTICS_VERSION}
    return validate("as.diagram/1", doc)


def render_mermaid(diagram: Mapping[str, Any]) -> str:
    direction = str(diagram.get("layout_hints", {}).get("direction", "LR"))
    lines = [f"flowchart {direction}",
             f"  %% notation={diagram['notation']} semantics={diagram['semantics_version']} diagram={diagram['diagram_id']}",
             f"  %% candidate={diagram['candidate_id']} provenance={diagram['provenance_digest']}"]
    for element in diagram["elements"]:
        left, right = _SHAPES.get(element["kind"], ("[", "]"))
        label = element["label"].replace("[", "(").replace("]", ")").replace('"', "'")
        lines.append(f"  {_mermaid_id(element['element_id'])}{left}{label} #{element['element_id']}{right}")
    for relation in diagram["relations"]:
        lines.append(f"  {_mermaid_id(relation['source'])} -->|{relation['label']} #{relation['element_id']}| "
                     f"{_mermaid_id(relation['target'])}")
    return "\n".join(lines) + "\n"


def round_trip(diagram: Mapping[str, Any]) -> dict[str, Any]:
    """Render, parse back, and compare element/relation IDs (AUDIT-ADD-11 round-trip expectation)."""
    text = render_mermaid(diagram)
    parsed = parse_mermaid(text)
    node_ids = {n["label"].rsplit("#", 1)[-1].strip() for n in parsed["nodes"] if "#" in n["label"]}
    edge_ids = {e["label"].rsplit("#", 1)[-1].strip() for e in parsed["edges"] if "#" in e["label"]}
    expected_nodes = {e["element_id"] for e in diagram["elements"]}
    expected_edges = {r["element_id"] for r in diagram["relations"]}
    return {"elements_preserved": node_ids == expected_nodes, "relations_preserved": edge_ids == expected_edges,
            "missing_elements": sorted(expected_nodes - node_ids), "missing_relations": sorted(expected_edges - edge_ids),
            "ambiguities": [a for a in parsed["ambiguities"] if "%%" not in a],
            "ok": node_ids == expected_nodes and edge_ids == expected_edges}
