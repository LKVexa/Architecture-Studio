"""Material distinctness (AUDIT-ADD-06, VERIFY-02, PAPER-CAP-03).

Two options are materially distinct when their *structure* differs — component
kinds and responsibilities, the shape of their relationships, their deployment
topology, or their constraint impacts — not when their labels or layout differ.
The rule is executable: :func:`structure_signature` normalizes names away, so a
renamed or cosmetically rearranged option has the *same* signature and is a
near-duplicate by construction (similarity 1.0); a genuinely different option
scores below the rule's ceiling.

The similarity ceiling is a PROPOSED number until an owner approves it. Near-
duplicates by identical signature are rejected regardless, because that rule
needs no threshold.

Build provenance: BUILD_NEW; the Jaccard-over-features shape follows the owner's
Trace-to-Diff ``similarity.py``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence

from .candidates import structure_digest, structure_signature

__all__ = ["DistinctnessRule", "similarity", "features", "assess_distinctness", "DistinctnessVerdict"]


@dataclass(frozen=True)
class DistinctnessRule:
    max_similarity: float = 0.85
    status: str = "PROPOSED"
    approval_ref: str | None = None
    rule_version: str = "1.0.0"

    @property
    def approved(self) -> bool:
        return self.status == "APPROVED" and bool(self.approval_ref)

    def as_document(self) -> dict[str, Any]:
        return {"max_similarity": self.max_similarity, "status": self.status, "approval_ref": self.approval_ref,
                "rule_version": self.rule_version, "identical_signature_is_duplicate": True,
                "boundary": "labels, ordering and layout never count as difference"}


def features(candidate: Mapping[str, Any]) -> set[str]:
    signature = structure_signature(candidate)
    out: set[str] = set()
    for kind, tokens, catalog in signature["components"]:
        out.add(f"c:{kind}")
        for token in tokens:
            out.add(f"r:{kind}:{token}")
        if catalog:
            out.add(f"cat:{catalog}")
    for src, kind, dst in signature["edges"]:
        out.add(f"e:{src}-{kind}->{dst}")
    if signature["topology"]:
        out.add(f"t:{signature['topology']}")
    for env in signature["environments"]:
        out.add(f"env:{env}")
    for constraint, result in signature["constraint_impacts"]:
        out.add(f"ci:{constraint}={result}")
    return out


def similarity(a: Mapping[str, Any], b: Mapping[str, Any]) -> float:
    fa, fb = features(a), features(b)
    if not fa and not fb:
        return 1.0
    return len(fa & fb) / len(fa | fb)


@dataclass
class DistinctnessVerdict:
    distinct: bool
    similarity: float
    reason: str
    identical_signature: bool

    def as_document(self) -> dict[str, Any]:
        return {"distinct": self.distinct, "similarity": round(self.similarity, 4), "reason": self.reason,
                "identical_signature": self.identical_signature}


def assess_pair(a: Mapping[str, Any], b: Mapping[str, Any], rule: DistinctnessRule) -> DistinctnessVerdict:
    if structure_digest(a) == structure_digest(b):
        return DistinctnessVerdict(False, 1.0, "identical structure signature: a rename or re-layout, not a different option", True)
    sim = similarity(a, b)
    if sim > rule.max_similarity:
        return DistinctnessVerdict(False, sim, f"similarity {sim:.2f} exceeds the ceiling {rule.max_similarity:.2f} "
                                              f"({rule.status} rule)", False)
    return DistinctnessVerdict(True, sim, f"structures differ (similarity {sim:.2f})", False)


def assess_distinctness(candidates: Sequence[Mapping[str, Any]], rule: DistinctnessRule | None = None) -> dict[str, Any]:
    """Pairwise verdicts plus the set of candidates that survive de-duplication."""
    rule = rule or DistinctnessRule()
    pairs: list[dict[str, Any]] = []
    rejected: set[str] = set()
    ordered = sorted(candidates, key=lambda c: c["candidate_id"])
    for i, a in enumerate(ordered):
        for b in ordered[i + 1:]:
            verdict = assess_pair(a, b, rule)
            pairs.append({"a": a["candidate_id"], "b": b["candidate_id"], **verdict.as_document()})
            if not verdict.distinct and b["candidate_id"] not in rejected and a["candidate_id"] not in rejected:
                rejected.add(b["candidate_id"])
    kept = [c["candidate_id"] for c in ordered if c["candidate_id"] not in rejected]
    return {"rule": rule.as_document(), "pairs": pairs, "kept": kept, "rejected": sorted(rejected),
            "all_distinct": not rejected, "labels_only_differences_detected": any(p["identical_signature"] for p in pairs)}
