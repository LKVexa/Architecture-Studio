"""Write-authority scan (GATE-PROD-03, XTOOL-05).

Walks the runtime sources and reports every site that can persist bytes, then
classifies each as routed through :class:`WriteGate`, an internal audit/store
path, a workdir-staging writer, or a *hidden* write (a caller-supplied output
root that is not confined by the write gate).

String methods named ``replace`` are not writes. The scanner only counts
``shutil``/``os`` persist helpers, ``Path.write_*``, ``open`` in a write mode,
``atomic_write``, and ``WriteGate.attempt`` / ``attempt_bundle``.
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Any, Iterable

from .canonical import digest_of

__all__ = ["scan_write_authority", "WRITE_SCAN_VERSION"]

WRITE_SCAN_VERSION = "1.0.1"

_PATH_WRITES = {"write_text", "write_bytes"}
_SHUTIL_WRITES = {"copy", "copy2", "copytree", "move", "copyfile"}
_OS_WRITES = {"replace", "rename", "remove", "unlink"}
_GATE_WRITES = {"attempt", "attempt_bundle", "atomic_write"}


def _qualifier(func: ast.AST) -> tuple[str | None, str | None]:
    """Return (owner_name, attr) for obj.attr(...) calls."""
    if isinstance(func, ast.Name):
        return None, func.id
    if isinstance(func, ast.Attribute):
        owner = None
        if isinstance(func.value, ast.Name):
            owner = func.value.id
        return owner, func.attr
    return None, None


def _enclosing_function(stack: list[ast.AST]) -> str:
    for node in reversed(stack):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            return node.name
    return "<module>"


def _is_write_open(node: ast.Call) -> bool:
    owner, name = _qualifier(node.func)
    if name not in {"open", "fdopen"}:
        return False
    mode = None
    for keyword in node.keywords:
        if keyword.arg == "mode" and isinstance(keyword.value, ast.Constant):
            mode = keyword.value.value
    if mode is None and len(node.args) >= 2 and isinstance(node.args[1], ast.Constant):
        mode = node.args[1].value
    if not isinstance(mode, str):
        # os.open(path, flags) — treat O_WRONLY/O_CREAT forms as writes when the
        # second argument is not a string; callers using os.open for locks still
        # persist a file. Count them.
        return name == "open" and owner == "os"
    return any(flag in mode for flag in ("w", "a", "x", "+"))


def _is_persist_call(node: ast.Call) -> str | None:
    owner, name = _qualifier(node.func)
    if name is None:
        return None
    if name in _GATE_WRITES:
        return name
    if name in _PATH_WRITES:
        return name
    if owner == "shutil" and name in _SHUTIL_WRITES:
        return f"shutil.{name}"
    if owner == "os" and name in _OS_WRITES:
        return f"os.{name}"
    if _is_write_open(node):
        return "open"
    return None


def _iter_write_sites(path: Path) -> Iterable[dict[str, Any]]:
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(path))
    stack: list[ast.AST] = []

    class Visitor(ast.NodeVisitor):
        def generic_visit(self, node: ast.AST) -> None:  # type: ignore[override]
            stack.append(node)
            super().generic_visit(node)
            stack.pop()

        def visit_Call(self, node: ast.Call) -> None:  # noqa: N802
            kind = _is_persist_call(node)
            if kind:
                sites.append({
                    "file": path.name,
                    "function": _enclosing_function(stack),
                    "lineno": node.lineno,
                    "call": kind,
                })
            self.generic_visit(node)

    sites: list[dict[str, Any]] = []
    Visitor().visit(tree)
    return sites


#: (module file name, function) → classification. Unclassified persist sites are hidden.
_APPROVED: dict[tuple[str, str], str] = {
    ("writes.py", "attempt"): "write_gate",
    ("writes.py", "attempt_bundle"): "write_gate",
    ("writes.py", "_validate"): "write_gate",
    ("writes.py", "preview"): "write_gate",
    ("evidence_io.py", "atomic_write"): "internal_atomic_helper",
    ("ledger.py", "append"): "audit_trail",
    ("store.py", "put_object"): "content_addressed_store",
    ("store.py", "commit"): "content_addressed_store",
    ("store.py", "__init__"): "content_addressed_store",
    ("store.py", "backup"): "content_addressed_store",
    ("store.py", "restore"): "content_addressed_store",
    ("incident.py", "_write"): "rollout_store",
    ("incident.py", "__enter__"): "rollout_lock",
    ("incident.py", "__exit__"): "rollout_lock",
    ("incident.py", "quarantine_run"): "forensic_quarantine",
    ("casefile.py", "export_case_file"): "workdir_staging",
    ("docs.py", "render_all"): "documentation_render",
    ("backup.py", "backup"): "recovery_backup",
    ("backup.py", "restore"): "recovery_restore",
    ("environments.py", "write_descriptors"): "environment_descriptors",
    ("release.py", "write_manifest"): "release_manifest",
    ("crypto.py", "__init__"): "local_key_material",
    ("crypto.py", "write_encrypted"): "envelope_persist",
    ("approvals.py", "load_or_create_key"): "approval_key_material",
    ("approvals.py", "consume"): "nonce_store",
    ("sandbox.py", "run"): "sandbox_workdir",
    ("evidence_records.py", "write"): "evidence_builder",
    ("evidence_records.py", "build"): "evidence_builder",
    ("cli.py", "_benchmark"): "cli_optional_report",
    ("cli.py", "_gates"): "cli_optional_report",
    ("cli.py", "_conditional_go"): "cli_conditional_report",
    ("pipeline.py", "export"): "write_gate",  # attempt_bundle
    ("asfw.py", "export_register"): "asfw_register_export",
    ("asgo.py", "export_register"): "asgo_register_export",
    ("asgo.py", "write_item_evidence"): "asgo_register_export",
    ("roster.py", "export_roster"): "roster_proposal_export",
}


def scan_write_authority(root: Path | None = None) -> dict[str, Any]:
    """Scan ``architecture_studio`` for persist sites and classify each one."""
    root = Path(root) if root is not None else Path(__file__).resolve().parent
    sites: list[dict[str, Any]] = []
    hidden: list[str] = []
    for path in sorted(root.rglob("*.py")):
        if path.name.startswith(".") or path.name == "write_scan.py":
            continue
        rel = path.relative_to(root).as_posix()
        for site in _iter_write_sites(path):
            key = (path.name, site["function"])
            classification = _APPROVED.get(key, "unreviewed")
            record = {**site, "path": rel, "classification": classification}
            sites.append(record)
            if classification in {"unreviewed", "hidden"}:
                hidden.append(f"{rel}:{site['lineno']}:{site['function']}.{site['call']}")
    write_gate_sites = [s for s in sites if s["classification"] == "write_gate"]
    return {
        "scan_version": WRITE_SCAN_VERSION,
        "root": str(root),
        "write_sites": len(sites),
        "write_gate_sites": len(write_gate_sites),
        "hidden_write_paths": hidden,
        "sites": sites,
        "digest": digest_of({"sites": [{"path": s["path"], "lineno": s["lineno"], "call": s["call"],
                                        "classification": s["classification"]} for s in sites],
                             "hidden": hidden}),
        "verdict": "PASS" if not hidden else "FAIL",
        "note": ("every persist site in architecture_studio is classified; unreviewed sites "
                 "are treated as hidden write authority"),
    }
