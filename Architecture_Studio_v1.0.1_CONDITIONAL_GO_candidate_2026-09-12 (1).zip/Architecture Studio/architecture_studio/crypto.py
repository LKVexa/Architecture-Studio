"""Envelope encryption at rest (XSEC-04).

A random data-encryption key protects each payload with AES-256-GCM (the
record's associated data is bound into the authentication tag); the DEK is
wrapped by a key held behind a :class:`KeyProvider` boundary so the wrapped key
travels beside the ciphertext while the unwrapping key does not. The provider
is a *slot*: the :class:`LocalKeyProvider` is the offline reference; a host KMS
occupies the slot in production, and the :class:`NullKeyProvider` refuses.

Fail-closed contract: when no backend or no provider is available the store
refuses to write under an encryption claim; it never writes plaintext while
reporting "encrypted", and :func:`status` says exactly what is in force.
Encryption *in transit* is a host property (TLS termination is outside this
process); it is reported here as ``host_responsibility`` and never claimed.

Build provenance: architecture from ``custom-azure-data-encryption.git`` (MIT)
via the owner's Embedded Quality Gate ``crypto.py``; AES-GCM/RSA-OAEP-SHA256
replace the donor's CBC/NUL padding and SHA-1, as the ledger's proven fit records.
"""
from __future__ import annotations

import base64
import json
import os
import secrets
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .canonical import canonical_bytes, sha256_of
from .evidence_io import atomic_write, loads_strict

__all__ = ["EncryptionUnavailable", "EncryptionIntegrityError", "KeyProvider", "NullKeyProvider", "LocalKeyProvider",
           "EnvelopeEncryptor", "backend_available", "status", "ENVELOPE_SCHEMA"]

ENVELOPE_SCHEMA = "as.envelope/1"
DATA_ALGORITHM = "AES-256-GCM"
KEY_ALGORITHM = "AES-256-KEYWRAP-GCM"


class EncryptionUnavailable(RuntimeError):
    pass


class EncryptionIntegrityError(ValueError):
    pass


def backend_available() -> bool:
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: F401
    except Exception:
        return False
    return True


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


def _unb64(text: str) -> bytes:
    return base64.b64decode(text.encode("ascii"))


class KeyProvider:
    provider_id = "abstract"

    def wrap(self, data_key: bytes) -> tuple[str, str]:
        raise NotImplementedError

    def unwrap(self, wrapped: str, key_id: str) -> bytes:
        raise NotImplementedError

    def describe(self) -> dict[str, Any]:
        return {"provider_id": self.provider_id}


class NullKeyProvider(KeyProvider):
    """The empty slot: refuses to wrap or unwrap, so nothing is stored as 'encrypted' without a key."""

    provider_id = "null"

    def wrap(self, data_key: bytes) -> tuple[str, str]:
        raise EncryptionUnavailable("no key provider is bound; refusing to encrypt under an unverifiable claim")

    def unwrap(self, wrapped: str, key_id: str) -> bytes:
        raise EncryptionUnavailable("no key provider is bound; ciphertext cannot be opened")


class LocalKeyProvider(KeyProvider):
    """Offline reference provider: a 32-byte KEK on disk (0600), never inside a run directory."""

    provider_id = "local-kek"

    def __init__(self, key_path: Path, *, create: bool = True) -> None:
        if not backend_available():
            raise EncryptionUnavailable("the cryptography backend is not installed on this host")
        self.key_path = Path(key_path)
        if self.key_path.exists():
            self._kek = bytes.fromhex(self.key_path.read_text(encoding="utf-8").strip())
        elif create:
            self._kek = secrets.token_bytes(32)
            self.key_path.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(str(self.key_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(self._kek.hex() + "\n")
        else:
            raise EncryptionUnavailable(f"no key at {self.key_path}")
        self.key_id = "kek-" + sha256_of(self._kek)[7:23]

    def wrap(self, data_key: bytes) -> tuple[str, str]:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        nonce = secrets.token_bytes(12)
        return _b64(nonce + AESGCM(self._kek).encrypt(nonce, data_key, self.key_id.encode())), self.key_id

    def unwrap(self, wrapped: str, key_id: str) -> bytes:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        if key_id != self.key_id:
            raise EncryptionIntegrityError("wrapped key belongs to a different key id")
        raw = _unb64(wrapped)
        try:
            return AESGCM(self._kek).decrypt(raw[:12], raw[12:], key_id.encode())
        except Exception as exc:
            raise EncryptionIntegrityError("wrapped key failed authentication") from exc

    def describe(self) -> dict[str, Any]:
        return {"provider_id": self.provider_id, "key_id": self.key_id, "key_path": str(self.key_path)}


@dataclass(frozen=True)
class Envelope:
    schema: str
    data_algorithm: str
    key_algorithm: str
    key_id: str
    wrapped_key: str
    nonce: str
    ciphertext: str
    aad_digest: str

    def as_document(self) -> dict[str, Any]:
        return {"schema": self.schema, "data_algorithm": self.data_algorithm, "key_algorithm": self.key_algorithm,
                "key_id": self.key_id, "wrapped_key": self.wrapped_key, "nonce": self.nonce,
                "ciphertext": self.ciphertext, "aad_digest": self.aad_digest}


class EnvelopeEncryptor:
    def __init__(self, provider: KeyProvider) -> None:
        self.provider = provider

    def encrypt(self, plaintext: bytes, *, aad: bytes = b"") -> Envelope:
        if not backend_available():
            raise EncryptionUnavailable("the cryptography backend is not installed on this host")
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        data_key = secrets.token_bytes(32)
        wrapped, key_id = self.provider.wrap(data_key)
        nonce = secrets.token_bytes(12)
        ciphertext = AESGCM(data_key).encrypt(nonce, plaintext, aad or None)
        return Envelope(ENVELOPE_SCHEMA, DATA_ALGORITHM, KEY_ALGORITHM, key_id, wrapped, _b64(nonce), _b64(ciphertext),
                        sha256_of(aad))

    def decrypt(self, envelope: Envelope, *, aad: bytes = b"") -> bytes:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        if envelope.schema != ENVELOPE_SCHEMA or envelope.data_algorithm != DATA_ALGORITHM:
            raise EncryptionIntegrityError("envelope schema/algorithm mismatch")
        if envelope.aad_digest != sha256_of(aad):
            raise EncryptionIntegrityError("associated data does not match the envelope")
        data_key = self.provider.unwrap(envelope.wrapped_key, envelope.key_id)
        try:
            return AESGCM(data_key).decrypt(_unb64(envelope.nonce), _unb64(envelope.ciphertext), aad or None)
        except Exception as exc:
            raise EncryptionIntegrityError("ciphertext failed authentication") from exc

    def write_encrypted(self, path: Path, plaintext: bytes, *, aad: bytes = b"") -> dict[str, Any]:
        envelope = self.encrypt(plaintext, aad=aad)
        atomic_write(path, canonical_bytes(envelope.as_document()))
        return {"path": str(path), "encrypted": True, "key_id": envelope.key_id, "algorithm": DATA_ALGORITHM}

    def read_encrypted(self, path: Path, *, aad: bytes = b"") -> bytes:
        doc = loads_strict(Path(path).read_bytes())
        return self.decrypt(Envelope(**doc), aad=aad)


def status(provider: KeyProvider) -> dict[str, Any]:
    """XSEC-04 status, honest about what is and is not in force."""
    return {"at_rest": {"backend_available": backend_available(), "provider": provider.describe(),
                        "in_force": backend_available() and not isinstance(provider, NullKeyProvider),
                        "algorithm": DATA_ALGORITHM},
            "in_transit": {"in_force": None, "responsibility": "host",
                           "note": "TLS termination and transport encryption are provisioned outside this process; "
                                   "not claimed here (ENV-03 / host blocker)"}}
