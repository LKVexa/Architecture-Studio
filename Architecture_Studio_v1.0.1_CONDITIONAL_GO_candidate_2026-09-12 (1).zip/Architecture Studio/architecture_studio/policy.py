"""Policy and authority enforcement layer (ARCH-07, IMPL-06, PAPER-GRD-01..04, MODEL-06, XAUTH-03).

The four paper guardrails are executable controls, each with a stable control
ID, a check and a stop condition. :func:`evaluate` runs every control that
applies to an action kind and returns a verdict; ``DENY`` is terminal for that
action and cannot be argued with by anything downstream, including a model —
there is deliberately no code path by which model output widens a permission
or clears a control (MODEL-06).

The enforcement boundary sits *around* sources, tools, workflow transitions,
writes, approvals and exports: every one of those call sites calls
:func:`enforce` immediately before the effect. Changing prompt text cannot
change what this module decides, because nothing here reads prompt text.

The kill switch is consulted here, on the execution path (AUDIT-ADD-26): a
disabled rollout store denies every consequential action, which is how an
operator stops a run without asking the run's cooperation.

Adapted from the owner's Repository Context Graph runtime (``rcg/policy.py``);
the controls are this package's guardrails.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

from .scope import ScopeContract, ScopeDenied

__all__ = ["Verdict", "Control", "PolicyDecision", "CONTROLS", "evaluate", "enforce",
           "controls_document", "PolicyViolation", "POLICY_VERSION", "ACTION_KINDS", "STOP_CONDITIONS"]

POLICY_VERSION = "1.0.0"

ACTION_KINDS = ("read", "analyze", "draft", "modify", "approve", "final_selection", "export",
                "communicate", "deploy", "tool_call", "model_call", "commit")

#: IMPL-06 stop conditions: any of these ends the run's forward progress until a human acts.
STOP_CONDITIONS: tuple[dict[str, str], ...] = (
    {"stop_id": "STOP-AUTH", "condition": "authority missing, expired or revoked", "requirement_id": "WF-12"},
    {"stop_id": "STOP-SCOPE", "condition": "requested action or artifact class outside the scope contract", "requirement_id": "IMPL-01"},
    {"stop_id": "STOP-EVIDENCE", "condition": "material output without local evidence", "requirement_id": "PAPER-GRD-03"},
    {"stop_id": "STOP-ASSUMPTION", "condition": "unlabelled non-source assertion", "requirement_id": "PAPER-GRD-02"},
    {"stop_id": "STOP-FINAL", "condition": "non-human principal attempts final selection or approval", "requirement_id": "PAPER-GRD-01"},
    {"stop_id": "STOP-STEER", "condition": "candidate presented outside a steerable session", "requirement_id": "PAPER-GRD-04"},
    {"stop_id": "STOP-KILL", "condition": "rollout switch disabled or store unreadable", "requirement_id": "AUDIT-ADD-26"},
    {"stop_id": "STOP-VERIFY", "condition": "verification failed or unknown for a material output", "requirement_id": "WF-08"},
    {"stop_id": "STOP-ASFW", "condition": "ASFW item unverified, source ambiguity unresolved, or self-attested GO", "requirement_id": "ASFW-0005"},
    {"stop_id": "STOP-ASGO", "condition": "ASGO item unverified/incomplete, INDEX.csv invented, ninth gate invented, or self-attested GO", "requirement_id": "ASGO-10.11"},
)


class PolicyViolation(PermissionError):
    pass


class Verdict:
    ALLOW = "ALLOW"
    DENY = "DENY"
    REVIEW = "REVIEW"


@dataclass(frozen=True)
class Control:
    control_id: str
    requirement_id: str
    title: str
    stop_condition: str
    applies_to: tuple[str, ...]
    check: Callable[[Mapping[str, Any], ScopeContract], tuple[str, str]]

    def describe(self) -> dict[str, Any]:
        return {"control_id": self.control_id, "requirement_id": self.requirement_id, "title": self.title,
                "stop_condition": self.stop_condition, "applies_to": list(self.applies_to)}


@dataclass
class PolicyDecision:
    verdict: str
    reasons: list[dict[str, str]] = field(default_factory=list)
    evaluated: list[str] = field(default_factory=list)

    @property
    def allowed(self) -> bool:
        return self.verdict == Verdict.ALLOW

    def as_document(self) -> dict[str, Any]:
        return {"policy_version": POLICY_VERSION, "verdict": self.verdict, "reasons": self.reasons,
                "controls_evaluated": self.evaluated}

    def raise_if_denied(self) -> None:
        if self.verdict == Verdict.DENY:
            raise PolicyViolation("; ".join(r["reason"] for r in self.reasons if r["verdict"] == Verdict.DENY))


# --------------------------------------------------------------------------- #
# The controls                                                                  #
# --------------------------------------------------------------------------- #
def _grd01(action: Mapping[str, Any], scope: ScopeContract) -> tuple[str, str]:
    """PAPER-GRD-01: the final architecture decision is a human-only transition."""
    if action.get("kind") in ("final_selection", "approve"):
        if action.get("actor_kind") != "human":
            return Verdict.DENY, (f"{action.get('kind')} requires an authenticated human principal; "
                                  f"a {action.get('actor_kind')!r} principal cannot settle the architecture")
        if "approve" not in scope.permissions:
            return Verdict.DENY, "the scope contract grants no approve permission to this subject"
    if action.get("model_asserted_final_decision"):
        return Verdict.DENY, "model output asserted a final decision; the decision state is human-owned"
    return Verdict.ALLOW, "no non-human attempt to settle the architecture"


def _grd02(action: Mapping[str, Any], scope: ScopeContract) -> tuple[str, str]:
    """PAPER-GRD-02: every non-source assertion is labelled; silent invention is refused."""
    unlabelled = int(action.get("unlabelled_assertions", 0))
    if unlabelled:
        return Verdict.DENY, (f"{unlabelled} assertion(s) are neither source-derived nor labelled "
                              "inferred/uncertain/proposed; silent requirement invention fails verification")
    invented = action.get("invented_requirements") or ()
    if invented:
        return Verdict.DENY, f"requirement(s) {sorted(invented)[:5]} do not resolve to any pinned source"
    return Verdict.ALLOW, "every non-source assertion is labelled or none was made"


def _grd03(action: Mapping[str, Any], scope: ScopeContract) -> tuple[str, str]:
    """PAPER-GRD-03: no generic pattern without local grounding."""
    if action.get("kind") not in ("draft", "export", "model_call"):
        return Verdict.ALLOW, "not a generation or export action"
    coverage = action.get("grounding_coverage")
    minimum = action.get("grounding_minimum")
    if action.get("material_output"):
        if coverage is None or minimum is None:
            return Verdict.REVIEW, "grounding coverage was not computed for a material output"
        if coverage < minimum:
            return Verdict.DENY, (f"local grounding coverage {coverage:.0%} is below the minimum "
                                  f"{minimum:.0%}; generic fallback is blocked and routed to clarification")
    if action.get("generic_fallback_elements"):
        return Verdict.DENY, (f"{len(action['generic_fallback_elements'])} element(s) are generic patterns "
                              "with no local evidence; they must be labelled or removed")
    return Verdict.ALLOW, "material elements are grounded in local evidence"


def _grd04(action: Mapping[str, Any], scope: ScopeContract) -> tuple[str, str]:
    """PAPER-GRD-04: candidates are presented only inside a steerable, persistent session."""
    if action.get("kind") in ("draft", "export") and action.get("material_output"):
        if not action.get("session_ref"):
            return Verdict.DENY, "a candidate set was produced outside a persistent design session; "\
                                 "one-shot output is not steerable"
        if action.get("steering_disabled"):
            return Verdict.DENY, "steering operations are disabled for this session; refusing an unsteerable design"
    return Verdict.ALLOW, "output is bound to a steerable session, or no candidate was produced"


def _model_cannot_self_authorize(action: Mapping[str, Any], scope: ScopeContract) -> tuple[str, str]:
    """MODEL-06 / SEC-07: model output can never widen permissions or assert approval."""
    requested = set(action.get("requested_permissions") or ())
    if action.get("actor_kind") == "model" and requested - scope.permissions:
        return Verdict.DENY, (f"model requested permission(s) {sorted(requested - scope.permissions)} "
                              "not held by the scope contract")
    if action.get("model_asserted_approval") or action.get("content_asserted_authority"):
        return Verdict.DENY, "an approval or authority asserted by model output or retrieved content is never valid"
    if action.get("actor_kind") == "model" and action.get("kind") in ("approve", "final_selection", "deploy", "commit"):
        return Verdict.DENY, f"a model principal cannot perform {action.get('kind')}"
    return Verdict.ALLOW, "no self-granted permission or model-asserted approval"


def _permission_present(action: Mapping[str, Any], scope: ScopeContract) -> tuple[str, str]:
    """XAUTH-02/03: the specific permission must be held, current and in scope."""
    needed = action.get("permission")
    if not needed:
        return Verdict.DENY, "action did not declare the permission it needs"
    try:
        scope.check(needed, source_system=action.get("source_system"), artifact_class=action.get("artifact_class"),
                    external_system=action.get("external_system"), tenant=action.get("tenant"),
                    now=action.get("now"))
    except ScopeDenied as denial:
        return Verdict.DENY, str(denial)
    return Verdict.ALLOW, f"permission {needed!r} is granted and current"


def _evidence_present(action: Mapping[str, Any], scope: ScopeContract) -> tuple[str, str]:
    """MODEL-05 / GATE-PROD-04: a material output is traceable to evidence."""
    if action.get("material_output") and not action.get("evidence_refs"):
        return Verdict.DENY, "a material output was produced with no evidence reference"
    if action.get("high_impact_unsupported"):
        return Verdict.DENY, "a high-impact conclusion lacks supporting evidence references"
    return Verdict.ALLOW, "material output carries evidence, or none was produced"


def _kill_switch(action: Mapping[str, Any], scope: ScopeContract) -> tuple[str, str]:
    """AUDIT-ADD-26: consulted on the execution path for every consequential action."""
    rollout = action.get("rollout")
    if rollout is None:
        return Verdict.ALLOW, "no rollout store supplied for a non-consequential action"
    if not getattr(rollout, "ok", False):
        return Verdict.DENY, f"rollout store is unusable, so nothing is permitted: {getattr(rollout, 'reason', '?')}"
    if not getattr(rollout, "enabled", False):
        return Verdict.DENY, "as.enabled is false; the run may not start or continue"
    if action.get("kind") == "model_call" and not getattr(rollout, "model_reasoning", False):
        return Verdict.DENY, "as.model_reasoning is false; the model may not be contacted"
    return Verdict.ALLOW, "rollout switch is on"


def _verification_gate(action: Mapping[str, Any], scope: ScopeContract) -> tuple[str, str]:
    """WF-08 / WF-07: a failed or unknown verification blocks advancement to review or export."""
    if action.get("kind") in ("export", "approve", "final_selection"):
        status = action.get("verification_status")
        if status is None:
            if action.get("material_output"):
                return Verdict.REVIEW, "a material output reached this action with no verification result"
            return Verdict.ALLOW, "no verification result attached to a non-material action"
        if status == "FAIL":
            return Verdict.DENY, "independent verification failed; the output cannot advance"
        if status == "UNKNOWN":
            return Verdict.REVIEW, "verification is unknown for this output; a human must decide"
    return Verdict.ALLOW, "verification does not block this action"


def _asfw_fail_closed(action: Mapping[str, Any], scope: ScopeContract) -> tuple[str, str]:
    """ASFW-0005 / ASFW-0545: incomplete ASFW status or inferred source gaps cannot become GO."""
    if action.get("claimed_production_go") and not action.get("asfw_all_verified"):
        return Verdict.DENY, "Production GO claimed while ASFW items are not independently VERIFIED"
    if action.get("inferred_missing_dod") or action.get("inferred_ninth_gate"):
        return Verdict.DENY, "source ambiguity must not be inferred; missing DOD/gate-count stay BLOCKED"
    if action.get("self_verified_asfw"):
        return Verdict.DENY, "the implementer or runtime cannot mark ASFW items VERIFIED"
    if action.get("asfw_status") in ("PROPOSED", "IMPLEMENTED", "AWAITING_CONFIRMATION", "ACCEPTED_RISK"):
        if action.get("kind") in ("approve", "final_selection", "deploy"):
            return Verdict.DENY, (f"ASFW status {action.get('asfw_status')} is incomplete until independent "
                                  "human review; it cannot authorize approve/final_selection/deploy")
    return Verdict.ALLOW, "no ASFW self-attestation or inferred source gap"


def _asgo_fail_closed(action: Mapping[str, Any], scope: ScopeContract) -> tuple[str, str]:
    """ASGO-10.11 / 7.11: incomplete ASGO status or invented INDEX/ninth-gate cannot become GO."""
    if action.get("claimed_production_go") and not action.get("asgo_all_verified"):
        return Verdict.DENY, "Production GO claimed while ASGO items are not independently complete"
    if action.get("invented_index_csv") or action.get("inferred_ninth_gate"):
        return Verdict.DENY, "INDEX.csv and GATE-PROD-09 must not be invented; source gaps stay BLOCKED"
    if action.get("self_verified_asgo") or action.get("asgo_claimed_done"):
        return Verdict.DENY, "the implementer or runtime cannot mark ASGO items DONE or VERIFIED"
    if action.get("asgo_status") in ("PROPOSED", "IMPLEMENTED", "AWAITING_CONFIRMATION", "ACCEPTED_RISK", "BLOCKED"):
        if action.get("kind") in ("approve", "final_selection", "deploy"):
            return Verdict.DENY, (f"ASGO status {action.get('asgo_status')} is incomplete until independent "
                                  "human review; it cannot authorize approve/final_selection/deploy")
    return Verdict.ALLOW, "no ASGO self-attestation or invented source artifact"


CONTROLS: tuple[Control, ...] = (
    Control("CTRL-GRD-01", "PAPER-GRD-01", "Must not settle the final architecture decision",
            "A non-human principal or model output attempts final selection or approval.",
            ("approve", "final_selection", "draft", "export"), _grd01),
    Control("CTRL-GRD-02", "PAPER-GRD-02", "Must not silently invent requirements or assumptions",
            "An assertion that is neither source-derived nor labelled; a requirement with no pinned source.",
            ("draft", "export", "model_call"), _grd02),
    Control("CTRL-GRD-03", "PAPER-GRD-03", "Must not fall back to generic patterns without local grounding",
            "Grounding coverage below the minimum or a generic element with no local evidence.",
            ("draft", "export", "model_call"), _grd03),
    Control("CTRL-GRD-04", "PAPER-GRD-04", "Must not produce a one-shot unsteerable design",
            "A material candidate set outside a persistent, steerable session.",
            ("draft", "export"), _grd04),
    Control("CTRL-AUTH-01", "MODEL-06", "A model cannot grant itself permissions",
            "Model-requested permission beyond the contract, or content-asserted approval/authority.",
            ACTION_KINDS, _model_cannot_self_authorize),
    Control("CTRL-AUTH-02", "XAUTH-03", "Every action names and holds its own permission",
            "The declared permission is absent, expired, out of scope or not granted.",
            ACTION_KINDS, _permission_present),
    Control("CTRL-PROV-01", "MODEL-05", "Material output is traceable to evidence",
            "A material output with an empty evidence reference set or an unsupported high-impact conclusion.",
            ("draft", "modify", "export", "model_call"), _evidence_present),
    Control("CTRL-KILL-01", "AUDIT-ADD-26", "The rollout switch is consulted on the execution path",
            "Rollout store disabled, stale, malformed or unreadable.",
            ("read", "analyze", "draft", "modify", "approve", "final_selection", "export",
             "communicate", "deploy", "tool_call", "model_call", "commit"), _kill_switch),
    Control("CTRL-VERIFY-01", "WF-08", "Verification failures block advancement",
            "A material output with FAIL or UNKNOWN verification advancing to review, export or approval.",
            ("export", "approve", "final_selection"), _verification_gate),
    Control("CTRL-ASFW-01", "ASFW-0005", "Incomplete ASFW status cannot authorize GO",
            "Production GO, inferred DOD/gate-count, or self-verified ASFW items.",
            ACTION_KINDS, _asfw_fail_closed),
    Control("CTRL-ASGO-01", "ASGO-10.11", "Incomplete ASGO status cannot authorize GO",
            "Production GO, invented INDEX.csv, invented ninth gate, or self-verified ASGO items.",
            ACTION_KINDS, _asgo_fail_closed),
)


def evaluate(action: Mapping[str, Any], scope: ScopeContract) -> PolicyDecision:
    """Run every control applicable to ``action['kind']``. DENY wins; REVIEW otherwise; ALLOW only if clean."""
    kind = action.get("kind", "")
    if kind not in ACTION_KINDS:
        decision = PolicyDecision(verdict=Verdict.DENY)
        decision.reasons.append({"control_id": "CTRL-KIND", "verdict": Verdict.DENY,
                                 "reason": f"unknown action kind {kind!r}"})
        return decision
    decision = PolicyDecision(verdict=Verdict.ALLOW)
    for control in CONTROLS:
        if kind not in control.applies_to:
            continue
        verdict, reason = control.check(action, scope)
        decision.evaluated.append(control.control_id)
        if verdict != Verdict.ALLOW:
            decision.reasons.append({"control_id": control.control_id, "verdict": verdict, "reason": str(reason)})
    if any(r["verdict"] == Verdict.DENY for r in decision.reasons):
        decision.verdict = Verdict.DENY
    elif decision.reasons:
        decision.verdict = Verdict.REVIEW
    return decision


def enforce(action: Mapping[str, Any], scope: ScopeContract, *, ledger: Any = None,
            actor: str = "system", actor_kind: str = "system") -> PolicyDecision:
    """Evaluate, record the decision (denials included), and raise on DENY."""
    decision = evaluate(action, scope)
    if ledger is not None:
        ledger.append("policy.decision", actor=actor, actor_kind=actor_kind,
                      outcome="allowed" if decision.allowed else "denied" if decision.verdict == Verdict.DENY else "recorded",
                      subject=str(action.get("kind")),
                      detail={"action": {k: v for k, v in action.items() if k not in ("rollout", "now")},
                              "decision": decision.as_document()})
    decision.raise_if_denied()
    return decision


def controls_document() -> dict[str, Any]:
    """DOC-04 / GATE-PROD-01 input: the enforceable-control inventory."""
    from .registry import CONTROL_OWNERSHIP
    by_requirement: dict[str, str] = {}
    for family in CONTROL_OWNERSHIP.values():
        tests = family.get("tests") or ""
        for alias in family.get("aliases", ()):
            by_requirement.setdefault(alias, tests)
    rows = []
    for control in CONTROLS:
        row = control.describe()
        row["tests"] = by_requirement.get(control.requirement_id, "tests/test_policy.py")
        rows.append(row)
    return {"policy_version": POLICY_VERSION, "control_count": len(CONTROLS),
            "controls": rows, "stop_conditions": list(STOP_CONDITIONS),
            "guardrails_implemented": sorted({c.requirement_id for c in CONTROLS
                                              if c.requirement_id.startswith("PAPER-GRD")})}
