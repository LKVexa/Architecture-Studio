"""Scope contract and permission separation (IMPL-01, API-02, XAUTH-02..06, WF-01, WF-03).

The scope contract is the single object that says *what this run may touch*:
project/tenant, source set, revision bounds, allowed artifact classes, allowed
actions, write authority, reviewer authority, approval rights, expiration and
policy version. It is enforced in one place, :meth:`ScopeContract.check`, and
every module that could produce an effect calls through it. Nothing consults a
model, a prompt, or retrieved content to decide whether an action is allowed —
that is XAUTH-06.

Permissions form a lattice, not a scalar level (XAUTH-03): holding ``modify``
does not imply ``commit``; ``read`` does not imply ``network_read``. Each is
granted or it is not. Read-only is the default mode (XAUTH-04): a contract that
grants nothing mutating is ``read_only`` and a ``read_only`` contract cannot
carry a mutating permission.

Adapted from the owner's Repository Context Graph runtime (``rcg/scope.py``).
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Mapping, Sequence

from .canonical import canonical_bytes, fmt_ts, parse_ts, sha256_of
from .schemas import PERMISSIONS, DATA_CLASSES, validate

__all__ = ["ScopeError", "ScopeDenied", "ScopeContract", "PERMISSIONS", "PRIVILEGED", "MUTATING",
           "SYSTEM_BOUND", "mode_admits", "EffectivePermissions", "effective_permissions",
           "reconcile_environment"]

PRIVILEGED = frozenset({"modify", "commit", "approve", "deploy", "communicate", "install",
                        "network_read", "network_write", "credential_use"})
MUTATING = frozenset({"modify", "commit", "approve", "deploy", "communicate", "install",
                      "network_write", "credential_use"})
SYSTEM_BOUND = frozenset({"network_read", "network_write"})
_MODE_ORDER = {"read_only": 0, "draft_only": 1, "modify": 2}


class ScopeError(ValueError):
    """The contract itself is malformed."""


class ScopeDenied(PermissionError):
    """A requested action is outside the contract. Always fail closed."""

    def __init__(self, reason: str, *, permission: str | None = None, path: str | None = None) -> None:
        self.reason = reason
        self.permission = permission
        self.path = path
        super().__init__(reason)


def mode_admits(mode: str, permissions: Iterable[str], *, external_systems: Iterable[str] = ()) -> tuple[bool, str]:
    granted = frozenset(permissions)
    unknown = granted - set(PERMISSIONS)
    if unknown:
        return False, f"unknown permission(s): {sorted(unknown)}"
    if mode == "read_only" and "draft" in granted:
        return False, "read_only mode cannot grant draft"
    if mode in ("read_only", "draft_only"):
        mutating = granted & MUTATING
        if mutating:
            return False, f"{mode} mode cannot grant mutating permission(s): {sorted(mutating)}"
        if "network_read" in granted and not tuple(external_systems):
            return False, f"{mode} mode admits network_read only with a named external allowlist"
    if mode not in _MODE_ORDER:
        return False, f"unknown mode {mode!r}"
    return True, "permissions are admissible under this mode"


@dataclass(frozen=True)
class ScopeContract:
    run_id: str
    subject: str
    tenant: str
    project: str
    source_set: frozenset[str]
    revision_bounds: Mapping[str, str]
    allowed_artifact_classes: frozenset[str]
    permissions: frozenset[str]
    write_authority: str
    reviewer_authority: tuple[str, ...]
    approval_rights: tuple[str, ...]
    authorized_paths: tuple[PurePosixPath, ...]
    denied_paths: tuple[PurePosixPath, ...]
    data_handling_profile: str
    issued_at: datetime
    expires_at: datetime
    issuer_ref: str
    human_authority_ref: str
    policy_version: str
    mode: str
    target_root: Path = Path(".")

    # ---------------------------------------------------------------- build --
    @classmethod
    def from_document(cls, document: Mapping[str, Any], *, target_root: str | os.PathLike[str] | None = None
                      ) -> "ScopeContract":
        doc = dict(document)
        doc.setdefault("schema_id", "as.scope_contract/1")
        validate("as.scope_contract/1", doc)
        granted = frozenset(doc["allowed_actions"])
        admitted, reason = mode_admits(doc["mode"], granted)
        if not admitted:
            raise ScopeError(reason)
        if doc["write_authority"] == "none" and (granted & MUTATING):
            raise ScopeError("write_authority 'none' cannot coexist with a mutating permission")
        if doc["write_authority"] == "draft" and "modify" in granted:
            raise ScopeError("write_authority 'draft' cannot grant modify")
        issued = parse_ts(doc["issued_at"])
        expires = parse_ts(doc["expires_at"])
        if issued >= expires:
            raise ScopeError("issued_at must precede expires_at")
        for system, bound in doc["revision_bounds"].items():
            if system not in doc["source_set"]:
                raise ScopeError(f"revision bound names {system!r}, which is not in the source set")
            if not isinstance(bound, str) or not bound:
                raise ScopeError(f"revision bound for {system!r} must be a non-empty revision")
        unknown_classes = set(doc["allowed_artifact_classes"]) - set(DATA_CLASSES)
        if unknown_classes:
            raise ScopeError(f"unknown artifact class(es): {sorted(unknown_classes)}")
        return cls(
            run_id=doc["run_id"], subject=doc["subject"], tenant=doc["tenant"], project=doc["project"],
            source_set=frozenset(doc["source_set"]), revision_bounds=dict(doc["revision_bounds"]),
            allowed_artifact_classes=frozenset(doc["allowed_artifact_classes"]), permissions=granted,
            write_authority=doc["write_authority"], reviewer_authority=tuple(doc["reviewer_authority"]),
            approval_rights=tuple(doc["approval_rights"]),
            authorized_paths=tuple(PurePosixPath(p) for p in doc["authorized_paths"]),
            denied_paths=tuple(PurePosixPath(p) for p in doc["denied_paths"]),
            data_handling_profile=doc["data_handling_profile"], issued_at=issued, expires_at=expires,
            issuer_ref=doc["issuer_ref"], human_authority_ref=doc["human_authority_ref"],
            policy_version=doc["policy_version"], mode=doc["mode"],
            target_root=Path(target_root).resolve() if target_root is not None else Path(".").resolve(),
        )

    def to_document(self) -> dict[str, Any]:
        return {
            "schema_id": "as.scope_contract/1", "run_id": self.run_id, "subject": self.subject,
            "tenant": self.tenant, "project": self.project, "source_set": sorted(self.source_set),
            "revision_bounds": dict(sorted(self.revision_bounds.items())),
            "allowed_artifact_classes": sorted(self.allowed_artifact_classes),
            "allowed_actions": sorted(self.permissions), "write_authority": self.write_authority,
            "reviewer_authority": list(self.reviewer_authority), "approval_rights": list(self.approval_rights),
            "authorized_paths": [str(p) for p in self.authorized_paths],
            "denied_paths": [str(p) for p in self.denied_paths],
            "data_handling_profile": self.data_handling_profile, "issued_at": fmt_ts(self.issued_at),
            "expires_at": fmt_ts(self.expires_at), "issuer_ref": self.issuer_ref,
            "human_authority_ref": self.human_authority_ref, "policy_version": self.policy_version,
            "mode": self.mode,
        }

    @property
    def scope_digest(self) -> str:
        return sha256_of(canonical_bytes(self.to_document()))

    # ---------------------------------------------------------------- check --
    def check(self, permission: str, *, path: str | os.PathLike[str] | None = None,
              source_system: str | None = None, artifact_class: str | None = None,
              external_system: str | None = None, tenant: str | None = None,
              now: datetime | None = None) -> None:
        """Authorize one action at time of use, or raise :class:`ScopeDenied`."""
        moment = now or datetime.now(timezone.utc)
        if permission not in PERMISSIONS:
            raise ScopeDenied(f"unknown permission {permission!r}", permission=permission)
        if moment < self.issued_at:
            raise ScopeDenied("contract is not yet in force", permission=permission)
        if moment >= self.expires_at:
            raise ScopeDenied("contract has expired", permission=permission)
        if permission not in self.permissions:
            raise ScopeDenied(f"permission {permission!r} is not granted by this contract", permission=permission)
        if tenant is not None and tenant != self.tenant:
            raise ScopeDenied(f"tenant {tenant!r} is outside this contract's tenant {self.tenant!r}",
                              permission=permission)
        if source_system is not None and source_system not in self.source_set:
            raise ScopeDenied(f"source system {source_system!r} is not in the authorized source set",
                              permission=permission)
        if artifact_class is not None and artifact_class not in self.allowed_artifact_classes:
            raise ScopeDenied(f"artifact class {artifact_class!r} is not allowed by this contract",
                              permission=permission)
        if permission in SYSTEM_BOUND and external_system is None:
            raise ScopeDenied(f"{permission!r} requires a named external system at time of use",
                              permission=permission)
        if external_system is not None:
            raise ScopeDenied(f"external system {external_system!r}: this contract authorizes no "
                              "external systems", permission=permission)
        if path is not None:
            self.check_path(path, permission=permission)

    def check_path(self, path: str | os.PathLike[str], *, permission: str | None = None) -> Path:
        candidate = Path(path)
        if not candidate.is_absolute():
            candidate = self.target_root / candidate
        try:
            resolved = candidate.resolve()
        except (OSError, RuntimeError) as exc:  # pragma: no cover
            raise ScopeDenied(f"path could not be canonicalized: {exc}", permission=permission,
                              path=str(path)) from None
        try:
            relative = resolved.relative_to(self.target_root)
        except ValueError:
            raise ScopeDenied("path escapes the approved target root", permission=permission,
                              path=str(path)) from None
        rel = PurePosixPath(relative.as_posix())
        for denied in self.denied_paths:
            if _under(rel, denied):
                raise ScopeDenied(f"path is inside denied scope {str(denied)!r}", permission=permission,
                                  path=str(path))
        if self.authorized_paths and not any(_under(rel, allowed) for allowed in self.authorized_paths):
            raise ScopeDenied("path is outside every authorized scope", permission=permission, path=str(path))
        return resolved

    def allows(self, permission: str) -> bool:
        return permission in self.permissions

    def is_current(self, now: datetime | None = None) -> bool:
        moment = now or datetime.now(timezone.utc)
        return self.issued_at <= moment < self.expires_at

    def narrowed(self, *, authorized_paths: Sequence[str] | None = None,
                 permissions: Iterable[str] | None = None,
                 source_set: Iterable[str] | None = None,
                 artifact_classes: Iterable[str] | None = None) -> "ScopeContract":
        """HUMAN-03 / XHITL-03: a strictly narrower contract. Widening raises."""
        new_paths = self.authorized_paths
        if authorized_paths is not None:
            requested = tuple(PurePosixPath(p) for p in authorized_paths)
            for p in requested:
                if self.authorized_paths and not any(_under(p, a) for a in self.authorized_paths):
                    raise ScopeError(f"narrowing cannot introduce unauthorized path {str(p)!r}")
            new_paths = requested
        new_perms = self.permissions
        if permissions is not None:
            requested_perms = frozenset(permissions)
            if requested_perms - self.permissions:
                raise ScopeError(f"narrowing cannot add permission(s): {sorted(requested_perms - self.permissions)}")
            new_perms = requested_perms
        new_sources = self.source_set
        if source_set is not None:
            requested_sources = frozenset(source_set)
            if requested_sources - self.source_set:
                raise ScopeError("narrowing cannot add source systems")
            if not requested_sources:
                raise ScopeError("a scope needs at least one source system")
            new_sources = requested_sources
        new_classes = self.allowed_artifact_classes
        if artifact_classes is not None:
            requested_classes = frozenset(artifact_classes)
            if requested_classes - self.allowed_artifact_classes:
                raise ScopeError("narrowing cannot add artifact classes")
            new_classes = requested_classes
        mode = self.mode
        write_authority = self.write_authority
        if not (new_perms & MUTATING):
            mode = "draft_only" if "draft" in new_perms else "read_only"
            write_authority = "draft" if "draft" in new_perms else "none"
        return ScopeContract(**{**self.__dict__, "authorized_paths": new_paths, "permissions": new_perms,
                                "mode": mode, "write_authority": write_authority, "source_set": new_sources,
                                "allowed_artifact_classes": new_classes,
                                "revision_bounds": {k: v for k, v in self.revision_bounds.items() if k in new_sources}})


def _under(path: PurePosixPath, root: PurePosixPath) -> bool:
    if str(root) in (".", ""):
        return True
    return path == root or root in path.parents


# --------------------------------------------------------------------------- #
# Environment ceilings and effective permissions (ENV-01..06, XAUTH-04)         #
# --------------------------------------------------------------------------- #
class EnvironmentConflict(ScopeError):
    """A declared environment profile cannot produce a contract."""


def reconcile_environment(profile: Mapping[str, Any]) -> dict[str, Any]:
    ident = str(profile.get("id") or profile.get("name") or "<unnamed>")
    mode = profile.get("mode_ceiling")
    if mode not in _MODE_ORDER:
        raise EnvironmentConflict(f"{ident}: unknown mode_ceiling {mode!r}")
    ceiling = tuple(profile.get("permissions_ceiling") or ())
    unknown = sorted(set(ceiling) - set(PERMISSIONS))
    if unknown:
        raise EnvironmentConflict(f"{ident}: unknown permission(s) in ceiling: {unknown}")
    admitted, reason = mode_admits(mode, ceiling, external_systems=profile.get("network_allowlist") or ())
    if not admitted:
        raise EnvironmentConflict(f"{ident}: {reason}")
    return {"environment_id": ident, "mode_ceiling": mode, "permissions_ceiling": sorted(ceiling),
            "mutating_permissions": sorted(set(ceiling) & MUTATING), "instantiable": True,
            "provisioned": bool(profile.get("provisioned", False))}


@dataclass(frozen=True)
class EffectivePermissions:
    permissions: frozenset[str]
    mode: str
    dropped: tuple[dict[str, str], ...]

    def allows(self, permission: str) -> bool:
        return permission in self.permissions

    def as_document(self) -> dict[str, Any]:
        return {"effective_permissions": sorted(self.permissions), "effective_mode": self.mode,
                "dropped": [dict(d) for d in self.dropped], "mutating_retained": sorted(self.permissions & MUTATING)}


def effective_permissions(*, scope: ScopeContract, environment_ceiling: Iterable[str] | None = None,
                          environment_mode: str | None = None, rollout_mode: str | None = None,
                          authority_permissions: Iterable[str] | None = None,
                          production_data_access: bool = False) -> EffectivePermissions:
    """Intersect every authority a run holds. Narrowing only; widening raises."""
    granted = frozenset(scope.permissions)
    dropped: list[dict[str, str]] = []

    def narrow(source: str, allowed: Iterable[str]) -> None:
        nonlocal granted
        allowed_set = frozenset(allowed)
        widening = sorted(allowed_set - frozenset(scope.permissions))
        if widening:
            raise ScopeError(f"{source} would widen the contract with {widening}; composition may only narrow")
        for permission in sorted(granted - allowed_set):
            dropped.append({"permission": permission, "dropped_by": source})
        granted = granted & allowed_set

    if environment_ceiling is not None:
        narrow("environment ceiling", environment_ceiling)
    if authority_permissions is not None:
        narrow("human authority", authority_permissions)
    modes = [m for m in (scope.mode, environment_mode, rollout_mode) if m in _MODE_ORDER]
    mode = min(modes, key=lambda m: _MODE_ORDER[m]) if modes else scope.mode
    if mode in ("read_only", "draft_only"):
        for permission in sorted(granted & MUTATING):
            dropped.append({"permission": permission, "dropped_by": f"mode ceiling {mode!r}"})
        granted = granted - MUTATING
        if mode == "read_only" and "draft" in granted:
            dropped.append({"permission": "draft", "dropped_by": "mode ceiling 'read_only'"})
            granted = granted - {"draft"}
    if production_data_access:
        for permission in sorted(granted & MUTATING):
            dropped.append({"permission": permission,
                            "dropped_by": "ENV-04 invariant: production data access excludes mutation"})
        granted = granted - MUTATING
    return EffectivePermissions(permissions=granted, mode=mode, dropped=tuple(dropped))
