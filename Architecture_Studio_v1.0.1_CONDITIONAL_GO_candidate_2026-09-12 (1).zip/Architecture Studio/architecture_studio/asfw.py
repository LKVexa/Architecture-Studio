"""ASFW 545-item Full-Loop Design Workbench register (ASFW-TODO-0001..0545).

Ingests the immutable master prompt/workflow package, assigns every checkbox a
role-level owner/implementer/reviewer/environment/due-date/evidence slot,
preserves source identifiers, issues unique implementation IDs, links evidence,
and treats ``PROPOSED`` / ``IMPLEMENTED`` / ``AWAITING_CONFIRMATION`` /
``ACCEPTED_RISK`` as incomplete until an independent human review is attached.

This module is the implementer. It may parse, organize, draft, and report. It
may not mark ``VERIFIED``, ``PASS``, ``GO``, or ``DONE``. Missing ``INDEX.csv``
is recorded as absent — a derived index is not the source of truth. Missing
``DOD-02/04/05/08/09`` definitions and the eight-vs-nine gate question are
source-ambiguity blockers; they are not inferred.
"""
from __future__ import annotations

import csv
import hashlib
import io
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping

from .canonical import digest_of, sha256_hex
from .evidence_io import atomic_write
from .fixtures import OVERLAY_ROOT, portable_overlay_path
from .gate_evidence import IMPLEMENTER_SUBJECTS

__all__ = [
    "ASFW_VERSION",
    "EXPECTED_ITEM_COUNT",
    "EXPECTED_PACKAGE_SHA256",
    "INCOMPLETE_STATUSES",
    "IMPLEMENTER_PASS",
    "AsfwError",
    "AsfwAuthorityError",
    "package_pin",
    "load_items",
    "build_register",
    "register_document",
    "register_summary",
    "item_record",
    "apply_review",
    "claim_verified",
    "production_go_from_asfw",
    "export_register",
    "preserved_identifiers",
    "MISSING_DOD_IDS",
    "EXECUTABLE_GATE_IDS",
]

ASFW_VERSION = "1.0.0"
EXPECTED_ITEM_COUNT = 545
#: SHA-256 of attachments/MASTER_PROMPT_WORKFLOW_PACKAGE.md as received 2026-09-11.
EXPECTED_PACKAGE_SHA256 = "c94ed9bd6f41bd034cc0136183010f9f7ddb1823fcdb25c55a7c138a026048d2"
PACKAGE_FILENAME = "MASTER_PROMPT_WORKFLOW_PACKAGE.md"
SOURCE_INDEX_FILENAME = "INDEX.csv"

INCOMPLETE_STATUSES = frozenset({
    "PROPOSED", "IMPLEMENTED", "AWAITING_CONFIRMATION", "ACCEPTED_RISK",
})
TERMINAL_STATUSES = frozenset({
    "VERIFIED", "BLOCKED", "FAILED", "NOT_APPLICABLE",
})
ALLOWED_STATUSES = INCOMPLETE_STATUSES | TERMINAL_STATUSES

IMPLEMENTER_PASS = "builder:architecture-studio-asfw-2026-09-11"
ASFW_IMPLEMENTER_SUBJECTS = IMPLEMENTER_SUBJECTS + (IMPLEMENTER_PASS, "asfw", "implementer")

MISSING_DOD_IDS = ("DOD-02", "DOD-04", "DOD-05", "DOD-08", "DOD-09")
VISIBLE_DOD_IDS = ("DOD-01", "DOD-03", "DOD-06", "DOD-07")
EXECUTABLE_GATE_IDS = tuple(f"GATE-PROD-{n:02d}" for n in range(1, 9))  # eight; ninth unresolved
PDF_GATE_RANGE_CLAIM = "GATE-PROD-01-09"

IDENTIFIER_RE = re.compile(
    r"`("
    r"BLK-[A-Z]+-\d+"
    r"|DEC-\d{2}"
    r"|DOD-\d{2}"
    r"|FLOW-\d{2}"
    r"|P\d{1,2}"
    r"|GATE-PROD-\d{2}(?:-\d{2})?"
    r"|AUDIT-ADD-\*?"
    r"|AUDIT-ADD-\d+"
    r"|TEST-[A-Za-z0-9*-]+"
    r"|IMPL-[A-Za-z]+"
    r"|DATA-[A-Za-z]+"
    r"|ENV-\d{2}"
    r")`"
)
BARE_IDENTIFIER_RE = re.compile(
    r"\b("
    r"BLK-[A-Z]+-\d+"
    r"|DEC-\d{2}"
    r"|DOD-\d{2}"
    r"|FLOW-\d{2}"
    r"|GATE-PROD-\d{2}(?:-\d{2})?"
    r")\b"
)
PHASE_IN_SECTION_RE = re.compile(r"`(P\d{1,2})`")
HEADER_RE = re.compile(r"^## (ASFW-TODO-(\d{4})) - (.+)$", re.M)
FIELD_RE = {
    "category": re.compile(r"\*\*Category:\*\*\s*`?([^`\n]+)`?"),
    "source_section": re.compile(r"\*\*Source section:\*\*\s*(.+)"),
    "source_references": re.compile(r"\*\*Source references:\*\*\s*(.+)"),
    "primary_owner": re.compile(r"\*\*Primary owner:\*\*\s*(.+)"),
    "target_phase": re.compile(r"\*\*Target phase context:\*\*\s*(.+)"),
}

#: Formal source-ambiguity item numbers. Do not infer their missing content.
SOURCE_AMBIGUITY_NUMBERS = frozenset({
    7, 8, 311, 507,
    *range(437, 443),   # DOD-02 cluster
    *range(451, 456),   # DOD-04 cluster
    *range(456, 461),   # DOD-05 cluster
    *range(477, 481),   # DOD-08 cluster
    *range(481, 486),   # DOD-09 cluster
})

OWNER_TO_REVIEW_ROLE = {
    "Identity, governance, or human-review owner": "independent_governance_reviewer",
    "Evaluation and quality owner": "independent_evaluation_reviewer",
    "Data and provenance owner": "independent_data_reviewer",
    "Architecture Authority": "independent_architecture_reviewer",
    "Security and privacy owner": "independent_security_reviewer",
    "Technical owner named in the execution register": "independent_technical_reviewer",
    "Release owner": "independent_verifier",
    "Platform operations owner": "independent_operations_reviewer",
    "Workspace UX and architecture owner": "independent_architecture_reviewer",
    "Cryptography and attestation owner": "independent_crypto_reviewer",
}

OWNER_TO_OWNER_ROLE = {
    "Identity, governance, or human-review owner": "human_review_policy_owner",
    "Evaluation and quality owner": "ml_evaluation_owner",
    "Data and provenance owner": "data_owner",
    "Architecture Authority": "architecture_owner",
    "Security and privacy owner": "security_privacy_owner",
    "Technical owner named in the execution register": "architecture_owner",
    "Release owner": "release_owner",
    "Platform operations owner": "operations_owner",
    "Workspace UX and architecture owner": "architecture_owner",
    "Cryptography and attestation owner": "crypto_owner",
}

#: Overlay modules that already encode the named identifier. Coverage is not verification.
OVERLAY_COVERAGE: dict[str, tuple[str, ...]] = {
    "FLOW-01": ("architecture_studio.pipeline.Run.authenticate",),
    "FLOW-02": ("architecture_studio.pipeline.Run.pin",),
    "FLOW-03": ("architecture_studio.pipeline.Run.collect_and_index",),
    "FLOW-04": ("architecture_studio.connectors.normalize",),
    "FLOW-05": ("architecture_studio.analysis",),
    "FLOW-06": ("architecture_studio.generator", "architecture_studio.uncertainty"),
    "FLOW-07": ("architecture_studio.generator",),
    "FLOW-08": ("architecture_studio.verify",),
    "FLOW-09": ("architecture_studio.review",),
    "FLOW-10": ("architecture_studio.approvals",),
    "FLOW-11": ("architecture_studio.ledger", "architecture_studio.casefile"),
    "FLOW-12": ("architecture_studio.writes.WriteGate",),
    "P0": ("architecture_studio.registry",),
    "P1": ("architecture_studio.authority", "architecture_studio.scope", "architecture_studio.policy"),
    "P2": ("architecture_studio.schemas",),
    "P3": ("architecture_studio.ledger", "architecture_studio.store"),
    "P4": ("architecture_studio.connectors",),
    "P5": ("architecture_studio.graph", "architecture_studio.retrieval"),
    "P6": ("architecture_studio.analysis",),
    "P7": ("architecture_studio.generator", "architecture_studio.uncertainty"),
    "P8": ("architecture_studio.diagrams", "architecture_studio.steering"),
    "P9": ("architecture_studio.review", "architecture_studio.approvals"),
    "P10": ("architecture_studio.security", "architecture_studio.sandbox"),
    "P11": ("architecture_studio.observability", "architecture_studio.incident"),
    "P12": ("architecture_studio.benchmark",),
    "P13": ("architecture_studio.environments", "architecture_studio.release"),
    "P14": ("architecture_studio.docs",),
    "P15": ("architecture_studio.gates",),  # eight executable gates; ninth unresolved
    "DEC-01": ("architecture_studio.canonical", "architecture_studio.schemas"),
    "DEC-02": ("architecture_studio.diagrams",),
    "DEC-03": ("architecture_studio.connectors",),
    "DEC-04": ("architecture_studio.writes",),
    "DEC-05": ("architecture_studio.connectors.base.pin_source_set",),
    "DEC-06": ("architecture_studio.uncertainty.Thresholds",),
    "DEC-07": ("architecture_studio.security",),
    "DEC-08": ("architecture_studio.slo",),
    "DEC-09": ("architecture_studio.backup", "architecture_studio.store"),
    "DOD-01": ("architecture_studio.acceptance", "architecture_studio.provenance"),
    "DOD-03": ("architecture_studio.provenance",),
    "DOD-06": ("architecture_studio.uncertainty",),
    "DOD-07": ("architecture_studio.approvals", "architecture_studio.review"),
    "BLK-GOV-01": (),
    "BLK-ATTEST-02": (),
    "BLK-ENV-03": (),
    "BLK-PROD-04": (),
    "BLK-EVAL-05": (),
    "BLK-PLAT-06": (),
}

GOVERNANCE_IMPL = {
    1: ("architecture_studio.asfw.build_register", "assignment slots on every item"),
    2: ("architecture_studio.asfw.preserved_identifiers", "identifier extraction and exact preservation"),
    3: ("architecture_studio.asfw — implementation_id ASFW-IMPL-NNNN", "unique implementation task IDs"),
    4: ("architecture_studio.asfw.evidence_links", "evidence-link schema"),
    5: ("architecture_studio.asfw.completion_state", "incomplete-until-review rule"),
    6: ("architecture_studio.asfw.package_pin", "immutable package pin by SHA-256"),
}


class AsfwError(ValueError):
    """The ASFW package cannot be accepted as a baseline."""


class AsfwAuthorityError(PermissionError):
    """The runtime attempted an authority it does not hold."""


def _package_candidates() -> list[Path]:
    env = os.environ.get("ASFW_PACKAGE_PATH")
    out: list[Path] = []
    if env:
        out.append(Path(env))
    out.extend([
        OVERLAY_ROOT / "asfw" / "source" / PACKAGE_FILENAME,
        OVERLAY_ROOT.parent.parent / "attachments" / PACKAGE_FILENAME,
        OVERLAY_ROOT.parent / "attachments" / PACKAGE_FILENAME,
    ])
    return out


def _index_candidates() -> list[Path]:
    env = os.environ.get("ASFW_INDEX_PATH")
    out: list[Path] = []
    if env:
        out.append(Path(env))
    out.extend([
        OVERLAY_ROOT / "asfw" / "source" / SOURCE_INDEX_FILENAME,
        OVERLAY_ROOT.parent.parent / "attachments" / SOURCE_INDEX_FILENAME,
    ])
    return out


def locate_package() -> Path:
    for path in _package_candidates():
        if path.is_file():
            return path
    raise AsfwError(
        f"{PACKAGE_FILENAME} is not present; searched "
        + ", ".join(str(p) for p in _package_candidates())
    )


def locate_source_index() -> Path | None:
    for path in _index_candidates():
        if path.is_file():
            return path
    return None


def package_pin(path: Path | None = None) -> dict[str, Any]:
    """ASFW-TODO-0006: pin the package by digest. Refuse a mutated baseline."""
    path = path or locate_package()
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != EXPECTED_PACKAGE_SHA256:
        raise AsfwError(
            f"package digest {digest} does not match pinned baseline "
            f"{EXPECTED_PACKAGE_SHA256}; issue a new version rather than silently replacing the baseline"
        )
    source_index = locate_source_index()
    return {
        "schema_id": "as.asfw_package_pin/1",
        "filename": path.name,
        "path": portable_overlay_path(path),
        "bytes": len(data),
        "sha256": digest,
        "item_count_declared": EXPECTED_ITEM_COUNT,
        "source_index_csv": {
            "filename": SOURCE_INDEX_FILENAME,
            "status": "PRESENT" if source_index is not None else "ABSENT",
            "path": portable_overlay_path(source_index) if source_index is not None else None,
            "note": ("INDEX.csv is the machine-readable source of truth named by the package. "
                     "It was not in the received attachment set. A derived index from the markdown "
                     "is not a substitute source of truth."),
        },
        "immutable": True,
        "next_version_rule": "issue a new version when requirements change; do not edit this pin",
    }


def _field(block: str, name: str) -> str:
    match = FIELD_RE[name].search(block)
    return match.group(1).strip() if match else ""


def preserved_identifiers(*texts: str) -> list[str]:
    """ASFW-TODO-0002: extract BLK-*/DEC-*/P*/FLOW-*/DOD-* (and related) exactly."""
    found: list[str] = []
    seen: set[str] = set()
    for text in texts:
        if not text:
            continue
        for match in IDENTIFIER_RE.finditer(text):
            token = match.group(1)
            if token not in seen:
                seen.add(token)
                found.append(token)
        for match in BARE_IDENTIFIER_RE.finditer(text):
            token = match.group(1)
            if token not in seen:
                seen.add(token)
                found.append(token)
        for match in PHASE_IN_SECTION_RE.finditer(text):
            token = match.group(1)
            if token not in seen:
                seen.add(token)
                found.append(token)
        for token in re.findall(r"`([^`]+)`", text):
            if token in seen:
                continue
            if re.match(r"^(BLK|DEC|DOD|FLOW|P\d|P\*|GATE-PROD|AUDIT-ADD|TEST|IMPL|DATA|ENV)", token):
                seen.add(token)
                found.append(token)
    return found


def _parse_items(text: str) -> list[dict[str, Any]]:
    matches = list(HEADER_RE.finditer(text))
    if len(matches) != EXPECTED_ITEM_COUNT:
        raise AsfwError(
            f"package parsed {len(matches)} items; expected {EXPECTED_ITEM_COUNT}. "
            "Do not infer or drop checkboxes."
        )
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, match in enumerate(matches):
        item_id, number_s, source_text = match.group(1), match.group(2), match.group(3).strip()
        if item_id in seen:
            raise AsfwError(f"duplicate item id {item_id}")
        seen.add(item_id)
        number = int(number_s)
        if number != index + 1:
            raise AsfwError(f"{item_id} is out of source order at position {index + 1}")
        start = match.start()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        block = text[start:end]
        head = block.split("### Technical prompt", 1)[0]
        category = _field(head, "category").strip("`").strip()
        source_section = _field(head, "source_section")
        source_references = _field(head, "source_references")
        primary_owner = _field(head, "primary_owner")
        target_phase = _field(head, "target_phase")
        identifiers = preserved_identifiers(source_text, source_section, source_references)
        items.append({
            "item_id": item_id,
            "number": number,
            "source_text": source_text,
            "category": category,
            "source_section": source_section,
            "source_references": source_references,
            "primary_owner": primary_owner,
            "target_phase_context": target_phase,
            "source_identifiers": identifiers,
            "source_line": text[:match.start()].count("\n") + 1,
        })
    return items


_CACHE: dict[str, Any] = {}


def load_items(path: Path | None = None) -> list[dict[str, Any]]:
    pin = package_pin(path)
    cached = _CACHE.get(pin["sha256"])
    if cached is not None:
        return cached
    package_path = Path(path) if path is not None else locate_package()
    items = _parse_items(package_path.read_text(encoding="utf-8"))
    _CACHE[pin["sha256"]] = items
    return items


def _reviewer_role(primary_owner: str) -> str:
    return OWNER_TO_REVIEW_ROLE.get(primary_owner, "independent_reviewer")


def _owner_role(primary_owner: str) -> str:
    return OWNER_TO_OWNER_ROLE.get(primary_owner, "technical_owner")


def _overlay_refs_for(identifiers: Iterable[str]) -> list[str]:
    refs: list[str] = []
    seen: set[str] = set()
    for ident in identifiers:
        for module in OVERLAY_COVERAGE.get(ident, ()):
            if module not in seen:
                seen.add(module)
                refs.append(module)
    return refs


def _is_host_item(item: Mapping[str, Any]) -> bool:
    blob = f"{item['source_text']} {item['source_section']}".lower()
    needles = (
        "idp", "kms", "host, kernel", "container runtime",
        "windows and linux", "provision", "production environment meets",
    )
    return any(n in blob for n in needles)


def _is_named_human_item(item: Mapping[str, Any]) -> bool:
    text = item["source_text"]
    lowered = text.lower()
    if item["category"] == "blocker" and item["number"] != 2:
        if lowered.startswith("name the") or "named owner" in lowered or "name the architecture" in lowered:
            return True
        if any(ident.startswith("BLK-") for ident in item["source_identifiers"]):
            # Blocker clusters require named human authorities.
            return "preserve the source identifiers" not in lowered
    if "independent reviewer" in lowered and item["number"] not in {1, 5}:
        if lowered.startswith("name ") or "obtain" in lowered or "sign-off" in lowered:
            return True
    if any(phrase in lowered for phrase in (
        "obtain architecture authority", "obtain human approval",
        "release owner signs", "independently verify closure",
        "named owner sign-off",
    )):
        return True
    return False


def classify(item: Mapping[str, Any]) -> dict[str, Any]:
    """Deterministic execution class. Never upgrades authority."""
    number = int(item["number"])
    category = item["category"]
    section = item["source_section"]
    text = item["source_text"]
    identifiers = list(item["source_identifiers"])
    overlay_refs = _overlay_refs_for(identifiers)

    if number in SOURCE_AMBIGUITY_NUMBERS or "Definition missing from source PDF" in section:
        return {
            "execution_class": "source_ambiguity",
            "status": "BLOCKED",
            "block_reason": (
                "source ambiguity: missing DOD definition or unresolved GATE-PROD 8-vs-9 count. "
                "Do not infer. Formal resolution record required from Data and provenance owner."
            ),
            "overlay_refs": overlay_refs,
            "in_repo_action": "resolution_record_only",
        }
    if number in GOVERNANCE_IMPL:
        module, note = GOVERNANCE_IMPL[number]
        return {
            "execution_class": "governance_machinery",
            "status": "IMPLEMENTED",
            "block_reason": None,
            "overlay_refs": [module, *overlay_refs],
            "in_repo_action": note,
        }
    if number == 545:
        return {
            "execution_class": "governance_machinery",
            "status": "IMPLEMENTED",
            "block_reason": None,
            "overlay_refs": [
                "architecture_studio.asfw.production_go_from_asfw",
                "architecture_studio.policy",
                "architecture_studio.gates.production_verdict",
            ],
            "in_repo_action": "any ASFW/authority violation keeps Production GO at NO_GO",
        }
    if category == "release" or number >= 505:
        return {
            "execution_class": "release_or_post_go",
            "status": "BLOCKED",
            "block_reason": (
                "release and post-GO controls require an independently verified candidate, "
                "gate PASS records, and a human release_owner. This pass is the implementer."
            ),
            "overlay_refs": overlay_refs,
            "in_repo_action": "handoff_only",
        }
    if _is_host_item(item):
        return {
            "execution_class": "host_binding",
            "status": "BLOCKED",
            "block_reason": "requires a provisioned host environment, IdP, KMS, or platform qualification this sandbox cannot bind",
            "overlay_refs": overlay_refs,
            "in_repo_action": "handoff_only",
        }
    if _is_named_human_item(item) or (category == "blocker" and number != 2):
        return {
            "execution_class": "human_authority",
            "status": "BLOCKED",
            "block_reason": "requires a named human principal from the roster; roles are assigned, persons are UNSET",
            "overlay_refs": overlay_refs,
            "in_repo_action": "handoff_only",
        }
    if number == 10:
        return {
            "execution_class": "missing_source_artifact",
            "status": "BLOCKED",
            "block_reason": "cited literature PDF / retrieval record is not in the received attachment set",
            "overlay_refs": overlay_refs,
            "in_repo_action": "handoff_only",
        }
    if number == 11:
        return {
            "execution_class": "unresolved_product_boundary",
            "status": "BLOCKED",
            "block_reason": (
                "Design-to-Sprint Workbench, Design Analyzer, Decision Context, and Full-Loop Workspace "
                "are not in this checkout. Reconciling them by assumption would invent scope."
            ),
            "overlay_refs": overlay_refs,
            "in_repo_action": "handoff_only",
        }

    # Remaining principle / phase / lifecycle / decision / metric / visible-DOD
    # items: overlay may already encode the behavior. That is IMPLEMENTED code,
    # not a verified checkbox.
    if overlay_refs or category in {"principle", "phase", "lifecycle", "decision", "metric",
                                    "definition_of_done", "governance"}:
        return {
            "execution_class": "in_repo_capability",
            "status": "IMPLEMENTED",
            "block_reason": None,
            "overlay_refs": overlay_refs or ["architecture_studio (overlay capability; independent review outstanding)"],
            "in_repo_action": "linked to overlay capability; not independently reviewed",
        }
    return {
        "execution_class": "unmapped",
        "status": "BLOCKED",
        "block_reason": "no overlay mapping and no in-repo execution authorized this pass",
        "overlay_refs": [],
        "in_repo_action": "handoff_only",
    }


def evidence_links(item: Mapping[str, Any], classification: Mapping[str, Any]) -> dict[str, Any]:
    """ASFW-TODO-0004: schema for linking code, tests, results, review, digest, candidate."""
    item_id = item["item_id"]
    return {
        "code_configuration": list(classification.get("overlay_refs") or ()),
        "tests": ["tests/test_asfw.py"] if classification["status"] == "IMPLEMENTED" else [],
        "raw_results": None,
        "reviewer_decision": None,
        "artifact_digest": None,
        "release_candidate": None,
        "evidence_location": f"evidence/asfw/{item_id}/",
        "handoff": _handoff_for(classification["execution_class"]),
        "complete": False,
        "missing": [
            field for field in (
                "raw_results", "reviewer_decision", "artifact_digest", "release_candidate",
            )
        ],
    }


def _handoff_for(execution_class: str) -> str | None:
    return {
        "source_ambiguity": "handoff/HANDOFF-ASFW-0007-0008-SOURCE-AMBIGUITY.md",
        "human_authority": "handoff/HANDOFF-ASFW-INDEPENDENT-REVIEW.md",
        "host_binding": "handoff/HANDOFF-IDP-BINDING.md",
        "release_or_post_go": "handoff/HANDOFF-ASFW-RELEASE.md",
        "missing_source_artifact": "handoff/HANDOFF-ASFW-0007-0008-SOURCE-AMBIGUITY.md",
        "unresolved_product_boundary": "handoff/HANDOFF-ASFW-INDEPENDENT-REVIEW.md",
        "unmapped": "handoff/HANDOFF-ASFW-INDEPENDENT-REVIEW.md",
    }.get(execution_class)


def completion_state(status: str, review: Mapping[str, Any] | None) -> dict[str, Any]:
    """ASFW-TODO-0005: incomplete until required human review is complete."""
    if status in INCOMPLETE_STATUSES:
        return {
            "complete": False,
            "reason": f"status {status} is incomplete until independent human review is signed",
        }
    if status == "BLOCKED":
        return {"complete": False, "reason": "blocked; not a completion"}
    if status == "FAILED":
        return {"complete": False, "reason": "failed acceptance check"}
    if status == "NOT_APPLICABLE":
        return {"complete": False, "reason": "NOT_APPLICABLE requires written authority, expiry, and independent review"}
    if status == "VERIFIED":
        if not review or review.get("decision") != "PASS":
            raise AsfwAuthorityError("VERIFIED is not representable without an independent PASS review")
        return {"complete": True, "reason": "independent review PASS"}
    return {"complete": False, "reason": f"unknown status {status}"}


def item_record(raw: Mapping[str, Any], *, reviews: Mapping[str, Mapping[str, Any]] | None = None) -> dict[str, Any]:
    classification = classify(raw)
    status = classification["status"]
    review = None
    if reviews and raw["item_id"] in reviews:
        review = dict(reviews[raw["item_id"]])
        reviewer = str(review.get("reviewer") or review.get("reviewer_subject") or "")
        if reviewer in ASFW_IMPLEMENTER_SUBJECTS or review.get("reviewer_kind") in {"runtime", "model", "generator"}:
            review = {
                "refused": True,
                "reason": "implementer/runtime/model self-review is not independent",
                "attempted_reviewer": reviewer,
            }
    completion = completion_state(status, review if review and not review.get("refused") else None)
    owner_role = _owner_role(raw["primary_owner"])
    reviewer_role = _reviewer_role(raw["primary_owner"])
    if owner_role == reviewer_role:
        reviewer_role = "independent_reviewer"
    impl_id = f"ASFW-IMPL-{raw['number']:04d}"
    environment = "local_sandbox"
    if classification["execution_class"] in {"host_binding", "release_or_post_go"}:
        environment = "unprovisioned_host"
    record = {
        "item_id": raw["item_id"],
        "implementation_id": impl_id,
        "source_text": raw["source_text"],
        "source_section": raw["source_section"],
        "source_references": raw["source_references"],
        "source_line": raw["source_line"],
        "source_identifiers": list(raw["source_identifiers"]),
        "category": raw["category"],
        "target_phase_context": raw["target_phase_context"],
        "assignment": {
            "owner_role": owner_role,
            "owner_person": "UNSET",
            "implementer_role": "implementer",
            "implementer_person": "UNSET",
            "independent_reviewer_role": reviewer_role,
            "independent_reviewer_person": "UNSET",
            "environment": environment,
            "due_date": "UNSET",
            "due_date_status": "BLOCKED_NO_ROSTER",
            "evidence_location": f"evidence/asfw/{raw['item_id']}/",
            "primary_owner_as_packaged": raw["primary_owner"],
        },
        "execution_class": classification["execution_class"],
        "status": status,
        "block_reason": classification["block_reason"],
        "in_repo_action": classification["in_repo_action"],
        "overlay_refs": classification["overlay_refs"],
        "evidence": evidence_links(raw, classification),
        "review": review,
        "completion": completion,
        "risks": _risks(raw, classification),
        "rollback": "revert architecture_studio/asfw.py and exported asfw/ artifacts; package pin is unchanged",
        "next_action": _next_action(classification, completion),
    }
    return record


def _risks(raw: Mapping[str, Any], classification: Mapping[str, Any]) -> list[str]:
    risks = []
    if classification["execution_class"] == "source_ambiguity":
        risks.append("Production GO is blocked until an authorized decision record resolves the source gap")
    if classification["status"] == "IMPLEMENTED":
        risks.append("IMPLEMENTED is not VERIFIED; independent review is outstanding")
    if any(ident in MISSING_DOD_IDS for ident in raw["source_identifiers"]):
        risks.append("item references a DOD id whose definition is missing from the source PDF")
    if PDF_GATE_RANGE_CLAIM in raw["source_text"] or "GATE-PROD-01-09" in raw["source_references"]:
        risks.append("PDF gate range GATE-PROD-01-09 disagrees with the executable registry GATE-PROD-01..08")
    return risks or ["none recorded beyond outstanding independent review"]


def _next_action(classification: Mapping[str, Any], completion: Mapping[str, Any]) -> str:
    if classification["execution_class"] == "source_ambiguity":
        return "Data and provenance owner files a decision record; do not infer missing DOD or a ninth gate"
    if classification["execution_class"] == "human_authority":
        return "Fill handoff/ROSTER.md with named distinct humans, then independent review"
    if classification["execution_class"] == "host_binding":
        return "Bind host IdP/KMS/environment per existing handoff packages"
    if classification["execution_class"] == "release_or_post_go":
        return "Independent verifier first; release_owner only after verifier signs"
    if classification["status"] == "IMPLEMENTED":
        return "Independent reviewer inspects implementation and evidence; implementer cannot sign"
    return "Keep BLOCKED; do not convert to GO by editing a status field"


def load_item_reviews(root: Path | None = None) -> dict[str, dict[str, Any]]:
    """Load optional human review files. Missing = none. Self-review refused later."""
    root = Path(root) if root is not None else OVERLAY_ROOT
    directory = root / "evidence" / "asfw"
    if not directory.is_dir():
        return {}
    out: dict[str, dict[str, Any]] = {}
    for path in sorted(directory.glob("ASFW-TODO-*/review.json")):
        try:
            import json
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if isinstance(payload, dict) and payload.get("item_id"):
            out[str(payload["item_id"])] = payload
    return out


def build_register(*, path: Path | None = None, reviews: Mapping[str, Mapping[str, Any]] | None = None) -> dict[str, Any]:
    pin = package_pin(path)
    raw_items = load_items(path)
    loaded_reviews = dict(reviews) if reviews is not None else load_item_reviews()
    items = [item_record(raw, reviews=loaded_reviews) for raw in raw_items]
    identifiers: dict[str, int] = {}
    for item in items:
        for ident in item["source_identifiers"]:
            identifiers[ident] = identifiers.get(ident, 0) + 1
    return {
        "schema_id": "as.asfw_register/1",
        "asfw_version": ASFW_VERSION,
        "package_pin": pin,
        "implementer": IMPLEMENTER_PASS,
        "implementer_cannot": ["VERIFIED", "PASS", "GO", "DONE", "APPROVED", "ACCEPTED"],
        "source_index_csv": pin["source_index_csv"],
        "executable_gates": list(EXECUTABLE_GATE_IDS),
        "pdf_gate_range_claim": PDF_GATE_RANGE_CLAIM,
        "gate_count_resolution": "UNRESOLVED",
        "missing_dod_ids": list(MISSING_DOD_IDS),
        "visible_dod_ids": list(VISIBLE_DOD_IDS),
        "dod_resolution": "UNRESOLVED",
        "items": items,
        "preserved_identifier_histogram": dict(sorted(identifiers.items())),
        "summary": _summarize(items, pin),
    }


def _summarize(items: list[dict[str, Any]], pin: Mapping[str, Any]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    classes: dict[str, int] = {}
    categories: dict[str, int] = {}
    complete = 0
    verified = 0
    for item in items:
        counts[item["status"]] = counts.get(item["status"], 0) + 1
        classes[item["execution_class"]] = classes.get(item["execution_class"], 0) + 1
        categories[item["category"]] = categories.get(item["category"], 0) + 1
        if item["completion"]["complete"]:
            complete += 1
        if item["status"] == "VERIFIED":
            verified += 1
    return {
        "total": len(items),
        "by_status": dict(sorted(counts.items())),
        "by_execution_class": dict(sorted(classes.items())),
        "by_category": dict(sorted(categories.items())),
        "complete": complete,
        "verified": verified,
        "assignments_with_unset_persons": sum(
            1 for item in items if item["assignment"]["owner_person"] == "UNSET"
        ),
        "source_index_csv_status": pin["source_index_csv"]["status"],
        "production_go": "NO_GO",
        "production_go_reason": (
            "ASFW complete==0 and verified==0; GATE-PROD independent reviews absent; "
            "source ambiguity on missing DOD and gate count unresolved; this pass is the implementer"
        ),
    }


def register_document(**kwargs: Any) -> dict[str, Any]:
    return build_register(**kwargs)


def register_summary(**kwargs: Any) -> dict[str, Any]:
    document = build_register(**kwargs)
    return {
        "asfw_version": document["asfw_version"],
        "package_sha256": document["package_pin"]["sha256"],
        "source_index_csv": document["source_index_csv"],
        "executable_gates": document["executable_gates"],
        "gate_count_resolution": document["gate_count_resolution"],
        "missing_dod_ids": document["missing_dod_ids"],
        "dod_resolution": document["dod_resolution"],
        "implementer": document["implementer"],
        "implementer_cannot": document["implementer_cannot"],
        **document["summary"],
    }


def claim_verified(item_id: str, *, actor: str) -> None:
    """The runtime may never call this successfully."""
    raise AsfwAuthorityError(
        f"{actor} cannot mark {item_id} VERIFIED; independent human review is required"
    )


def apply_review(item_id: str, review: Mapping[str, Any]) -> dict[str, Any]:
    reviewer = str(review.get("reviewer") or review.get("reviewer_subject") or "")
    if reviewer in ASFW_IMPLEMENTER_SUBJECTS:
        raise AsfwAuthorityError(f"{reviewer} is the implementer/runtime and cannot review {item_id}")
    if review.get("reviewer_kind") in {"runtime", "model", "generator", None}:
        if review.get("reviewer_kind") != "human":
            raise AsfwAuthorityError(f"review of {item_id} requires reviewer_kind=human")
    return {"item_id": item_id, "accepted_for_storage": True, "applied": False,
            "note": "write the review to evidence/asfw/<id>/review.json; this runtime will load it read-only"}


def production_go_from_asfw(register: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """ASFW-TODO-0545: any incomplete/blocked/ambiguous ASFW item is an automatic NO_GO."""
    document = register or build_register()
    items = document["items"]
    blocking = []
    for item in items:
        if item["status"] != "VERIFIED" or not item["completion"]["complete"]:
            blocking.append(item["item_id"])
    if document.get("gate_count_resolution") != "RESOLVED":
        blocking.append("GATE-COUNT-UNRESOLVED")
    if document.get("dod_resolution") != "RESOLVED":
        blocking.append("DOD-DEFINITIONS-UNRESOLVED")
    if document["source_index_csv"]["status"] != "PRESENT":
        blocking.append("INDEX.CSV-ABSENT")
    return {
        "verdict": "GO" if not blocking else "NO_GO",
        "blocking_count": len(blocking),
        "blocking_preview": blocking[:12],
        "verified": document["summary"]["verified"],
        "complete": document["summary"]["complete"],
        "total": document["summary"]["total"],
        "note": "GO from ASFW requires every item independently VERIFIED; this function never attests",
    }


def _derived_index_rows(items: Iterable[Mapping[str, Any]]) -> list[dict[str, str]]:
    rows = []
    for item in items:
        rows.append({
            "item_id": item["item_id"],
            "implementation_id": item["implementation_id"],
            "category": item["category"],
            "source_text": item["source_text"],
            "source_section": item["source_section"],
            "source_references": item["source_references"],
            "source_identifiers": " ".join(item["source_identifiers"]),
            "owner_role": item["assignment"]["owner_role"],
            "implementer_role": item["assignment"]["implementer_role"],
            "independent_reviewer_role": item["assignment"]["independent_reviewer_role"],
            "environment": item["assignment"]["environment"],
            "due_date": item["assignment"]["due_date"],
            "evidence_location": item["assignment"]["evidence_location"],
            "status": item["status"],
            "execution_class": item["execution_class"],
            "complete": "yes" if item["completion"]["complete"] else "no",
            "block_reason": item["block_reason"] or "",
        })
    return rows


def export_register(directory: Path, *, register: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Write the derived register, derived INDEX.csv, pin, and summary. Not source INDEX.csv."""
    import json
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    document = dict(register) if register is not None else build_register()
    summary = {k: document[k] for k in (
        "schema_id", "asfw_version", "package_pin", "implementer", "implementer_cannot",
        "source_index_csv", "executable_gates", "pdf_gate_range_claim", "gate_count_resolution",
        "missing_dod_ids", "visible_dod_ids", "dod_resolution", "summary",
        "preserved_identifier_histogram",
    ) if k in document}
    go = production_go_from_asfw(document)
    summary["production_go_from_asfw"] = go

    register_bytes = json.dumps(document, indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8")
    summary_bytes = json.dumps(summary, indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8")
    pin_bytes = json.dumps(document["package_pin"], indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8")

    buf = io.StringIO()
    rows = _derived_index_rows(document["items"])
    writer = csv.DictWriter(buf, fieldnames=list(rows[0].keys()), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    csv_text = (
        "# DERIVED from MASTER_PROMPT_WORKFLOW_PACKAGE.md; NOT the source INDEX.csv "
        f"(source INDEX.csv is {document['source_index_csv']['status']})\n"
        + buf.getvalue()
    )

    written = []
    for name, payload in (
        ("ASFW_REGISTER.json", register_bytes),
        ("ASFW_SUMMARY.json", summary_bytes),
        ("PACKAGE_PIN.json", pin_bytes),
        ("INDEX.derived.csv", csv_text.encode("utf-8")),
    ):
        target = directory / name
        atomic_write(target, payload)
        written.append({"file": name, "sha256": sha256_hex(payload), "bytes": len(payload)})

    md = _markdown_report(document, go)
    atomic_write(directory / "ASFW_REGISTER.md", md.encode("utf-8"))
    written.append({"file": "ASFW_REGISTER.md", "sha256": sha256_hex(md.encode("utf-8")),
                    "bytes": len(md.encode("utf-8"))})
    return {
        "directory": str(directory),
        "written": written,
        "digest": digest_of(written),
        "production_go": go["verdict"],
        "note": "derived artifacts; source INDEX.csv remains ABSENT; nothing here is a GO",
    }


def _markdown_report(document: Mapping[str, Any], go: Mapping[str, Any]) -> str:
    summary = document["summary"]
    lines = [
        "# ASFW 545-item register",
        "",
        f"**Production GO from ASFW:** `{go['verdict']}`",
        "",
        "This register is the implementer's intake of the master prompt/workflow package. "
        "`IMPLEMENTED` means machinery or overlay coverage exists. It is **not** `VERIFIED`. "
        "Source `INDEX.csv` was **not** in the received attachment set. Missing DOD definitions "
        "and the eight-vs-nine production-gate question are **unresolved**; they were not inferred.",
        "",
        f"- package sha256: `{document['package_pin']['sha256']}`",
        f"- items: {summary['total']}",
        f"- verified: {summary['verified']}",
        f"- complete: {summary['complete']}",
        f"- source INDEX.csv: {document['source_index_csv']['status']}",
        f"- executable gates: {', '.join(document['executable_gates'])}",
        f"- PDF claim: `{document['pdf_gate_range_claim']}` — resolution `{document['gate_count_resolution']}`",
        f"- missing DOD: {', '.join(document['missing_dod_ids'])} — resolution `{document['dod_resolution']}`",
        "",
        "## Counts by status",
        "",
        "| status | n |",
        "|---|---|",
    ]
    for key, value in summary["by_status"].items():
        lines.append(f"| {key} | {value} |")
    lines += [
        "",
        "## Counts by execution class",
        "",
        "| class | n |",
        "|---|---|",
    ]
    for key, value in summary["by_execution_class"].items():
        lines.append(f"| {key} | {value} |")
    lines += [
        "",
        "## Source-ambiguity blockers (do not infer)",
        "",
    ]
    for item in document["items"]:
        if item["execution_class"] == "source_ambiguity":
            lines.append(f"- `{item['item_id']}` {item['source_text']}")
    lines += [
        "",
        "## Governance items 0001–0006",
        "",
    ]
    for item in document["items"][:6]:
        lines.append(
            f"- `{item['item_id']}` `{item['status']}` complete={item['completion']['complete']} "
            f"— {item['source_text']}"
        )
    lines += [
        "",
        "Independent review is outstanding on every item. This file is not a Production GO.",
        "",
    ]
    return "\n".join(lines)
