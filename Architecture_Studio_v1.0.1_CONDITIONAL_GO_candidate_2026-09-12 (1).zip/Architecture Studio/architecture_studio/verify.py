"""Independent verification of generated outputs (WF-08, VERIFY-01..06, XEVAL-05 hooks).

Verification is a *separate* pass from generation: it takes candidates, the
comparison, the assumption registry, the normalized index and the design-state
history as inputs and produces one :class:`VerificationReport` whose checks are
recorded on their own ledger event (``verification.recorded``), never folded
into the generation record. Each check names the requirement it verifies and
carries the concrete gap list, so a FAIL is inspectable and a PASS is not a
sentence but a count of resolved links.

Checks:

* ``VERIFY-01`` traceability — every material element (component, relationship,
  deployment) resolves through an evidence reference to an indexed record of a
  requirement/constraint class, or is listed as a gap.
* ``VERIFY-02`` distinctness — independent pairwise similarity against the
  distinctness rule (the rule's threshold stays PROPOSED; the check reports
  under it).
* ``VERIFY-03`` labelled assumptions — no unlabelled assertion; seeded
  unsupported assertions are caught before review.
* ``VERIFY-04`` cited trade-offs — every material comparison cell/difference
  carries a citation or an inference marker.
* ``VERIFY-05`` human ownership — no accountability-violating text, no non-human
  approver in any decision record, no approval event by a model actor.
* ``VERIFY-06`` history preservation — design-state history is monotonic,
  snapshot digests chain, and no prior version was overwritten.
* ``SCHEMA`` / ``SECURITY`` / ``POLICY`` — the schema, secret/injection scan and
  policy decision re-run independently of the generator.

Failures block advancement according to policy: :func:`gate_verdict` maps the
report to ALLOW / REVIEW / DENY without ever softening a DENY.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

from .assumptions import AssumptionRegistry, unlabelled_assertions
from .canonical import digest_of
from .connectors.normalize import NormalizedIndex
from .distinctness import DistinctnessRule, assess_distinctness
from .grounding import evaluate_grounding
from .review import accountability_violations
from .schemas import SchemaError, validate
from .security import scan_for_injection, scan_for_secrets
from .tradeoffs import uncited_material_claims

__all__ = ["Check", "VerificationReport", "verify_outputs", "gate_verdict", "VERIFIER_VERSION", "TRACEABLE_CLASSES"]

VERIFIER_VERSION = "1.0.0"
#: Classes whose records count as "requirements and constraints" for VERIFY-01.
TRACEABLE_CLASSES = ("requirement", "nfr", "adr", "security_constraint", "cost_perf_constraint", "deployment_standard",
                     "api_operation", "service")


@dataclass
class Check:
    check_id: str
    requirement_id: str
    result: str                      # PASS | FAIL | UNKNOWN
    summary: str
    gaps: list[dict[str, Any]] = field(default_factory=list)
    counts: dict[str, int] = field(default_factory=dict)
    threshold_status: str | None = None   # PROPOSED / APPROVED when a threshold was involved

    def as_document(self) -> dict[str, Any]:
        return {"check_id": self.check_id, "requirement_id": self.requirement_id, "result": self.result,
                "summary": self.summary, "gaps": self.gaps, "counts": self.counts, "threshold_status": self.threshold_status}


@dataclass
class VerificationReport:
    run_id: str
    iteration: int
    checks: list[Check]
    candidate_ids: list[str]

    @property
    def failed(self) -> list[Check]:
        return [c for c in self.checks if c.result == "FAIL"]

    @property
    def unknown(self) -> list[Check]:
        return [c for c in self.checks if c.result == "UNKNOWN"]

    @property
    def passed(self) -> bool:
        return not self.failed and not self.unknown

    def as_document(self) -> dict[str, Any]:
        doc = {"verifier_version": VERIFIER_VERSION, "run_id": self.run_id, "iteration": self.iteration,
               "candidate_ids": self.candidate_ids, "checks": [c.as_document() for c in self.checks],
               "failed": [c.check_id for c in self.failed], "unknown": [c.check_id for c in self.unknown],
               "passed": self.passed, "recorded_separately_from_generation": True}
        doc["report_digest"] = digest_of(doc)
        return doc


_CLASS_CACHE: dict[int, dict[str, set[str]]] = {}


def _classes_by_ref(index: NormalizedIndex) -> dict[str, set[str]]:
    key = id(index)
    cached = _CLASS_CACHE.get(key)
    if cached is None or sum(len(v) for v in cached.values()) < len(index.records):
        cached = {}
        for record in index.records.values():
            cached.setdefault(record["provenance_ref_id"], set()).add(record["data_class"])
        _CLASS_CACHE.clear()
        _CLASS_CACHE[key] = cached
    return cached


def _trace(candidate: Mapping[str, Any], index: NormalizedIndex) -> tuple[list[dict[str, Any]], dict[str, int]]:
    gaps: list[dict[str, Any]] = []
    elements = 0
    linked = 0

    classes_by_ref = _classes_by_ref(index)

    def resolves(refs: Sequence[str]) -> list[str]:
        classes = []
        for ref_id in refs:
            if ref_id not in index.evidence:
                continue
            classes.extend(c for c in classes_by_ref.get(ref_id, ()) if c in TRACEABLE_CLASSES)
        return classes

    for comp in candidate.get("components", []):
        elements += 1
        classes = resolves(comp.get("evidence_refs", []))
        if classes:
            linked += 1
        elif comp.get("derivation") == "source":
            gaps.append({"element_id": comp["element_id"], "kind": "component", "reason": "no resolvable requirement/constraint path"})
        else:
            gaps.append({"element_id": comp["element_id"], "kind": "component", "reason": f"{comp.get('derivation')} element (labelled, not grounded)", "labelled": True})
    for rel in candidate.get("relationships", []):
        elements += 1
        if resolves(rel.get("evidence_refs", [])):
            linked += 1
        else:
            gaps.append({"element_id": rel.get("element_id", "?"), "kind": "relationship",
                         "reason": "no resolvable requirement/constraint path", "labelled": rel.get("derivation") != "source"})
    if candidate.get("deployment"):
        elements += 1
        if resolves(candidate["deployment"].get("evidence_refs", [])):
            linked += 1
        else:
            gaps.append({"element_id": "deployment", "kind": "deployment", "reason": "no resolvable deployment-standard path",
                         "labelled": not candidate["deployment"].get("evidence_refs") and not candidate["deployment"].get("standard_refs")})
    return gaps, {"material_elements": elements, "linked_elements": linked}


def verify_outputs(*, run_id: str, iteration: int, candidates: Sequence[Mapping[str, Any]], index: NormalizedIndex,
                   assumptions: AssumptionRegistry, comparison: Mapping[str, Any] | None = None,
                   design_history: Sequence[Mapping[str, Any]] = (), decisions: Sequence[Mapping[str, Any]] = (),
                   ledger_events: Sequence[Mapping[str, Any]] = (), rule: DistinctnessRule | None = None,
                   policy_decision: Mapping[str, Any] | None = None, ledger: Any = None, actor: str = "verifier"
                   ) -> VerificationReport:
    rule = rule or DistinctnessRule()
    ledger_events = list(ledger_events)
    decisions = list(decisions)
    design_history = list(design_history)
    checks: list[Check] = []
    ids = [c["candidate_id"] for c in candidates]

    # SCHEMA — independent re-validation.
    schema_gaps = []
    for c in candidates:
        try:
            validate("as.candidate/1", dict(c))
        except SchemaError as exc:
            schema_gaps.append({"candidate_id": c["candidate_id"], "reason": str(exc)})
    checks.append(Check("SCHEMA", "MODEL-04", "FAIL" if schema_gaps else "PASS",
                        f"{len(candidates) - len(schema_gaps)}/{len(candidates)} candidates valid against as.candidate/1", schema_gaps,
                        {"candidates": len(candidates)}))

    # VERIFY-01 traceability.
    trace_gaps: list[dict[str, Any]] = []
    totals = {"material_elements": 0, "linked_elements": 0}
    unlabelled_gaps = 0
    for c in candidates:
        gaps, counts = _trace(c, index)
        for g in gaps:
            g["candidate_id"] = c["candidate_id"]
        trace_gaps.extend(gaps)
        unlabelled_gaps += sum(1 for g in gaps if not g.get("labelled"))
        totals = {k: totals[k] + counts[k] for k in totals}
    grounding = {c["candidate_id"]: evaluate_grounding(c, index).as_document() for c in candidates}
    generic = [g for doc in grounding.values() for g in doc["generic_fallback"]]
    checks.append(Check("VERIFY-01", "VERIFY-01", "FAIL" if (unlabelled_gaps or generic) else ("PASS" if candidates else "UNKNOWN"),
                        f"{totals['linked_elements']}/{totals['material_elements']} material elements resolve to requirement/constraint "
                        f"records; {unlabelled_gaps} unlabelled gap(s); {len(generic)} generic fallback element(s)",
                        trace_gaps + [{"kind": "generic_fallback", **g} for g in generic], totals))

    # VERIFY-02 distinctness.
    if len(candidates) >= 2:
        distinct = assess_distinctness(list(candidates), rule)
        near = [p for p in distinct["pairs"] if not p.get("distinct", True)]
        checks.append(Check("VERIFY-02", "VERIFY-02", "FAIL" if near else "PASS",
                            f"{len(distinct['pairs'])} pair(s) compared, {len(near)} near-duplicate(s) under max_similarity="
                            f"{rule.max_similarity} ({rule.status})", near, {"pairs": len(distinct["pairs"]), "near_duplicates": len(near)},
                            threshold_status=rule.status))
    else:
        checks.append(Check("VERIFY-02", "VERIFY-02", "UNKNOWN", "fewer than two candidates; distinctness not assessable",
                            counts={"candidates": len(candidates)}, threshold_status=rule.status))

    # VERIFY-03 labelled assumptions.
    label_gaps = []
    for c in candidates:
        for g in unlabelled_assertions(c, assumptions):
            label_gaps.append({"candidate_id": c["candidate_id"], **g})
    checks.append(Check("VERIFY-03", "VERIFY-03", "FAIL" if label_gaps else ("PASS" if candidates else "UNKNOWN"),
                        f"{len(label_gaps)} unlabelled assertion(s); {len(assumptions.entries())} registered assumption(s)",
                        label_gaps, {"registered": len(assumptions.entries()), "unlabelled": len(label_gaps)}))

    # VERIFY-04 cited trade-offs.
    if comparison is not None:
        uncited = uncited_material_claims(comparison)
        checks.append(Check("VERIFY-04", "VERIFY-04", "FAIL" if uncited else "PASS",
                            f"{len(comparison.get('cells', []))} cell(s), {len(uncited)} uncited material claim(s)", uncited,
                            {"cells": len(comparison.get("cells", [])), "uncited": len(uncited)}))
    else:
        checks.append(Check("VERIFY-04", "VERIFY-04", "UNKNOWN", "no comparison artifact supplied"))

    # VERIFY-05 human ownership.
    own_gaps: list[dict[str, Any]] = []
    for c in candidates:
        text = json.dumps(c, ensure_ascii=True)
        for phrase in accountability_violations(text):
            own_gaps.append({"candidate_id": c["candidate_id"], "reason": f"accountability phrase: {phrase!r}"})
    if comparison is not None:
        for phrase in accountability_violations(json.dumps(comparison, ensure_ascii=True)):
            own_gaps.append({"artifact": "comparison", "reason": f"accountability phrase: {phrase!r}"})
    for d in decisions:
        approver = d.get("approver_identity") or {}
        if d.get("decision") in ("approve", "approved", "select", "selected") and approver.get("kind") != "human":
            own_gaps.append({"decision_id": d.get("decision_id"), "reason": "final decision not authored by a human principal"})
    for record in ledger_events:
        event = record.get("event", record)
        if event.get("event_type") in ("review.decision", "approval.issued") and event.get("actor_kind") not in ("human",):
            own_gaps.append({"event": event.get("event_type"), "actor_kind": event.get("actor_kind"),
                             "reason": "approval-class ledger event by a non-human actor"})
    checks.append(Check("VERIFY-05", "VERIFY-05", "FAIL" if own_gaps else "PASS",
                        f"{len(own_gaps)} ownership violation(s) across candidates, comparison, {len(decisions)} decision(s) and "
                        f"{len(ledger_events)} ledger event(s)", own_gaps, {"decisions": len(decisions)}))

    # VERIFY-06 history preservation.
    hist_gaps = []
    versions = [h.get("version") for h in design_history]
    if versions != sorted(versions) or len(set(versions)) != len(versions):
        hist_gaps.append({"reason": "design-state versions are not strictly increasing", "versions": versions})
    for prev, cur in zip(design_history, design_history[1:]):
        if cur.get("parent_digest") not in (None, prev.get("digest")) and "parent_digest" in cur:
            hist_gaps.append({"version": cur.get("version"), "reason": "snapshot does not chain to its predecessor"})
    checks.append(Check("VERIFY-06", "VERIFY-06", "UNKNOWN" if not design_history else ("FAIL" if hist_gaps else "PASS"),
                        f"{len(design_history)} design-state version(s) inspected; {len(hist_gaps)} chain fault(s)", hist_gaps,
                        {"versions": len(design_history)}))

    # SECURITY — independent secret/injection scan over the outputs.
    sec_gaps = []
    for c in candidates:
        text = json.dumps(c, ensure_ascii=True)
        for f in scan_for_secrets(text):
            sec_gaps.append({"candidate_id": c["candidate_id"], "kind": "secret", "detail": f.kind})
        for f in scan_for_injection(text):
            sec_gaps.append({"candidate_id": c["candidate_id"], "kind": "injection", "detail": f.kind})
    checks.append(Check("SECURITY", "XSEC-02", "FAIL" if sec_gaps else "PASS", f"{len(sec_gaps)} secret/injection finding(s) in outputs", sec_gaps))

    # POLICY — the generation-time decision is re-read, not trusted.
    if policy_decision is not None:
        verdict = policy_decision.get("verdict")
        checks.append(Check("POLICY", "IMPL-06", "PASS" if verdict == "ALLOW" else ("FAIL" if verdict == "DENY" else "UNKNOWN"),
                            f"generation policy verdict was {verdict}", [r for r in policy_decision.get("reasons", []) if r.get("verdict") != "ALLOW"]))
    else:
        checks.append(Check("POLICY", "IMPL-06", "UNKNOWN", "no policy decision supplied"))

    report = VerificationReport(run_id, iteration, checks, ids)
    if ledger is not None:
        ledger.append("verification.recorded", actor=actor, actor_kind="service",
                      outcome="allowed" if report.passed else "failed", subject=run_id, detail=report.as_document())
    return report


def gate_verdict(report: VerificationReport) -> tuple[str, str]:
    """WF-08: failures block advancement according to policy. DENY on FAIL, REVIEW on UNKNOWN, ALLOW only when clean."""
    if report.failed:
        return "DENY", "verification failed: " + ", ".join(c.check_id for c in report.failed)
    if report.unknown:
        return "REVIEW", "verification incomplete: " + ", ".join(c.check_id for c in report.unknown)
    return "ALLOW", "all independent checks passed"
