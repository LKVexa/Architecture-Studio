"""Architecture Studio for Requirements-to-Design — runtime package.

Built by the junkyard chop shop against the ASRTD v1.4.0 prompt/workflow
package (227 tasks, 16 phases, evidence protocol ASRTD/*/3). The package is a
sealed input; this runtime is the implementation it describes, applied as an
overlay on the owner's generic project repository (the 612-file, 66-suite
JA21/DeepML corpus), which is never modified and which the studio treats as its
authorized local evidence set.

Standard library only at run time. ``cryptography`` is probed for Ed25519
approval signatures and its absence is an algorithm-labelled HMAC identity,
never a silent downgrade (see :mod:`architecture_studio.approvals`).

Version discipline (AUDIT-ADD-21 / XSTATE-02): every component that can change
behaviour has a version string here, and :func:`version_manifest` is what a run
records (STORE-05 / XTOOL-06 / MODEL-01).
"""
from __future__ import annotations

__all__ = ["__version__", "PACKAGE_ID", "PACKAGE_VERSION_APPLIED", "VERSIONS", "version_manifest"]

__version__ = "1.0.1"
PACKAGE_ID = "architecture_studio"
#: The prompt/workflow package this runtime implements.
PACKAGE_VERSION_APPLIED = "ASRTD/1.4.0"

VERSIONS: dict[str, str] = {
    "runtime": __version__,
    "package_applied": PACKAGE_VERSION_APPLIED,
    "state_machine": "1.0.0",
    "schemas": "1.0.0",
    "api_contracts": "1.0.0",
    "policy": "1.0.0",
    "prompts": "1.0.0",
    "candidate_model": "1.0.0",
    "diagram_semantics": "1.0.0",
    "tradeoff_taxonomy": "1.0.0",
    "benchmark_corpus": "1.0.0",
    "retrieval": "1.0.0",
    "analyzers": "1.0.0",
    "classification_matrix": "1.0.0",
    "store": "1.0.0",
    "ledger": "1.0.0",
}


def version_manifest() -> dict[str, str]:
    """A copy of every component version, sorted, for run records."""
    return dict(sorted(VERSIONS.items()))
