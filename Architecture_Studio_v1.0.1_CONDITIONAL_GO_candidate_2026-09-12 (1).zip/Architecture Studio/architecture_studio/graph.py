"""Typed requirement/constraint graph and query layer (COMP-02, ARCH-04).

Nodes are the normalized records (requirements, NFRs, ADRs, API operations,
services, diagram components, security constraints, cost/performance
constraints, deployment standards) plus candidate elements, assumptions and
conflicts. Edges are typed and every edge carries the evidence that justifies
it — an edge with no supporting record cannot exist, which is VERIFY-01 made
structural.

Queries answer the three questions the package names (COMP-02): *why does this
element exist*, *what constrains it*, and *which sources support or conflict
with it*. Authorization is enforced at the query layer (ARCH-04): a query runs
under a scope contract and returns nothing from a source system or data class
the contract does not allow, whatever the caller asks for.

Adapted from the owner's Repository Context Graph ``rcg/graph.py`` (node/edge
discipline); the ontology and derivation rules are this package's.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping

from .canonical import digest_of
from .connectors.normalize import NormalizedIndex
from .ids import deterministic_id
from .scope import ScopeContract

__all__ = ["GraphError", "NODE_TYPES", "EDGE_TYPES", "RequirementGraph", "build_graph"]

NODE_TYPES = ("requirement", "nfr", "adr", "api_operation", "service", "diagram_component", "security_constraint",
              "cost_perf_constraint", "deployment_standard", "candidate_element", "assumption", "conflict", "suite")
EDGE_TYPES = ("constrains", "supports", "conflicts_with", "supersedes", "superseded_by", "belongs_to", "implements",
              "depends_on", "derived_from", "assumed_for", "exposes")

_CLASS_TO_NODE = {"requirement": "requirement", "nfr": "nfr", "adr": "adr", "api_operation": "api_operation",
                  "service": "service", "diagram": "diagram_component", "security_constraint": "security_constraint",
                  "cost_perf_constraint": "cost_perf_constraint", "deployment_standard": "deployment_standard"}


class GraphError(ValueError):
    pass


@dataclass
class RequirementGraph:
    nodes: dict[str, dict[str, Any]] = field(default_factory=dict)
    edges: list[dict[str, Any]] = field(default_factory=list)
    _out: dict[str, list[int]] = field(default_factory=lambda: defaultdict(list))
    _in: dict[str, list[int]] = field(default_factory=lambda: defaultdict(list))

    # ---------------------------------------------------------------- build --
    def add_node(self, node_id: str, node_type: str, *, source_system: str, data_class: str,
                 evidence_refs: Iterable[str], attributes: Mapping[str, Any] | None = None,
                 derivation: str = "source") -> dict[str, Any]:
        if node_type not in NODE_TYPES:
            raise GraphError(f"unknown node type {node_type!r}")
        refs = list(evidence_refs)
        if derivation == "source" and not refs:
            raise GraphError(f"source node {node_id} has no evidence reference")
        node = {"node_id": node_id, "node_type": node_type, "source_system": source_system, "data_class": data_class,
                "evidence_refs": refs, "derivation": derivation, "attributes": dict(attributes or {})}
        self.nodes[node_id] = node
        return node

    def add_edge(self, source: str, target: str, edge_type: str, *, evidence_refs: Iterable[str] = (),
                 derivation: str = "deterministic_analyzer", analyzer: str = "graph_builder/1.0.0") -> dict[str, Any]:
        if edge_type not in EDGE_TYPES:
            raise GraphError(f"unknown edge type {edge_type!r}")
        if source not in self.nodes or target not in self.nodes:
            raise GraphError(f"edge {source}->{target} references an unknown node")
        refs = list(evidence_refs) or list(self.nodes[source]["evidence_refs"]) or list(self.nodes[target]["evidence_refs"])
        if not refs:
            raise GraphError("an edge without supporting evidence cannot exist")
        edge = {"edge_id": deterministic_id("edge", source=source, target=target, edge_type=edge_type),
                "source": source, "target": target, "edge_type": edge_type, "evidence_refs": refs,
                "derivation": derivation, "analyzer": analyzer}
        index = len(self.edges)
        self.edges.append(edge)
        self._out[source].append(index)
        self._in[target].append(index)
        return edge

    # -------------------------------------------------------------- queries --
    def _visible(self, node: Mapping[str, Any], scope: ScopeContract | None) -> bool:
        if scope is None:
            return True
        if node["node_type"] in ("candidate_element", "assumption", "conflict", "suite"):
            return True
        return node["source_system"] in scope.source_set and node["data_class"] in scope.allowed_artifact_classes

    def neighbors(self, node_id: str, *, direction: str = "out", edge_types: Iterable[str] | None = None,
                  scope: ScopeContract | None = None) -> list[dict[str, Any]]:
        wanted = set(edge_types) if edge_types else None
        indices = self._out.get(node_id, []) if direction == "out" else self._in.get(node_id, [])
        out = []
        for index in indices:
            edge = self.edges[index]
            if wanted and edge["edge_type"] not in wanted:
                continue
            other = self.nodes[edge["target"] if direction == "out" else edge["source"]]
            if self._visible(other, scope):
                out.append({"edge": edge, "node": other})
        return out

    def why(self, node_id: str, *, scope: ScopeContract | None = None) -> dict[str, Any]:
        """Why does this element exist: the requirements/ADRs it implements or derives from."""
        if node_id not in self.nodes:
            raise GraphError(f"unknown node {node_id}")
        reasons = self.neighbors(node_id, direction="out", edge_types=("implements", "derived_from", "belongs_to"), scope=scope)
        return {"node_id": node_id, "reasons": [{"via": r["edge"]["edge_type"], "node_id": r["node"]["node_id"],
                                                 "node_type": r["node"]["node_type"],
                                                 "evidence_refs": r["edge"]["evidence_refs"]} for r in reasons],
                "grounded": bool(reasons) or self.nodes[node_id]["derivation"] == "source"}

    def constraints_on(self, node_id: str, *, scope: ScopeContract | None = None) -> list[dict[str, Any]]:
        incoming = self.neighbors(node_id, direction="in", edge_types=("constrains",), scope=scope)
        return [{"constraint_id": r["node"]["node_id"], "node_type": r["node"]["node_type"],
                 "evidence_refs": r["edge"]["evidence_refs"], "attributes": r["node"]["attributes"]} for r in incoming]

    def support_and_conflict(self, node_id: str, *, scope: ScopeContract | None = None) -> dict[str, Any]:
        supports = self.neighbors(node_id, direction="in", edge_types=("supports",), scope=scope)
        conflicts = self.neighbors(node_id, direction="in", edge_types=("conflicts_with",), scope=scope) + \
            self.neighbors(node_id, direction="out", edge_types=("conflicts_with",), scope=scope)
        return {"node_id": node_id,
                "supports": [{"node_id": r["node"]["node_id"], "evidence_refs": r["edge"]["evidence_refs"]} for r in supports],
                "conflicts": [{"node_id": r["node"]["node_id"], "evidence_refs": r["edge"]["evidence_refs"]} for r in conflicts]}

    def nodes_of_type(self, node_type: str, *, scope: ScopeContract | None = None) -> list[dict[str, Any]]:
        return [n for n in self.nodes.values() if n["node_type"] == node_type and self._visible(n, scope)]

    def stats(self) -> dict[str, Any]:
        by_type: dict[str, int] = defaultdict(int)
        for node in self.nodes.values():
            by_type[node["node_type"]] += 1
        by_edge: dict[str, int] = defaultdict(int)
        for edge in self.edges:
            by_edge[edge["edge_type"]] += 1
        return {"nodes": len(self.nodes), "edges": len(self.edges), "by_type": dict(sorted(by_type.items())),
                "by_edge": dict(sorted(by_edge.items())),
                "graph_digest": digest_of({"n": sorted(self.nodes), "e": sorted(e["edge_id"] for e in self.edges)})}


def build_graph(index: NormalizedIndex) -> RequirementGraph:
    """Deterministically derive nodes and typed edges from the normalized index."""
    graph = RequirementGraph()
    suites: set[str] = set()
    services_by_workspace: dict[str, list[str]] = defaultdict(list)
    services_by_suite: dict[str, list[str]] = defaultdict(list)
    for record_id, record in sorted(index.records.items()):
        node_type = _CLASS_TO_NODE[record["data_class"]]
        payload = record["payload"]
        suite = _suite_from_path(record["path"])
        graph.add_node(record_id, node_type, source_system=record["source_system"], data_class=record["data_class"],
                       evidence_refs=[record["provenance_ref_id"]],
                       attributes={**{k: v for k, v in payload.items() if k not in ("components", "edges")},
                                   "declared_suite": payload.get("suite"), "suite": suite,
                                   "freshness": record["freshness"]})
        if suite:
            suites.add(suite)
        if node_type == "service":
            services_by_workspace[str(payload.get("workspace"))].append(record_id)
            services_by_suite[suite].append(record_id)
    for suite in sorted(suites):
        graph.add_node(f"suite:{suite}", "suite", source_system="corpus", data_class="document", evidence_refs=[],
                       derivation="deterministic_analyzer", attributes={"name": suite})
    adr_by_id = {n["attributes"].get("adr_id"): nid for nid, n in graph.nodes.items() if n["node_type"] == "adr"}
    for node_id, node in list(graph.nodes.items()):
        suite = node["attributes"].get("suite")
        if suite and node["node_type"] != "suite" and f"suite:{suite}" in graph.nodes:
            graph.add_edge(node_id, f"suite:{suite}", "belongs_to")
        if node["node_type"] == "adr":
            sup = node["attributes"].get("supersedes")
            if sup and sup in adr_by_id:
                graph.add_edge(node_id, adr_by_id[sup], "supersedes")
            by = node["attributes"].get("superseded_by")
            if by and by in adr_by_id:
                graph.add_edge(node_id, adr_by_id[by], "superseded_by")
        if node["node_type"] in ("security_constraint", "cost_perf_constraint", "deployment_standard", "nfr"):
            # A constraint binds the services declared in the SAME workspace/module file (exact), and only
            # falls back to the suite's services when it names no workspace at all.
            workspace = node["attributes"].get("workload_scope") or node["attributes"].get("scope") \
                or node["attributes"].get("workspace")
            targets = services_by_workspace.get(str(workspace), [])
            if not targets and node["node_type"] == "security_constraint":
                targets = services_by_suite.get(suite, [])[:8] if suite else []
            for target in targets:
                graph.add_edge(node_id, target, "constrains")
        if node["node_type"] == "api_operation":
            for target in services_by_suite.get(suite, [])[:8]:
                graph.add_edge(target, node_id, "exposes")
        if node["node_type"] == "requirement" and suite:
            text = str(node["attributes"].get("text", "")).lower()
            for target in services_by_suite.get(suite, []):
                service_name = str(graph.nodes[target]["attributes"].get("service", "")).lower()
                tokens = [t for t in service_name.replace("_", " ").split() if len(t) > 3]
                if tokens and any(t in text for t in tokens):
                    graph.add_edge(target, node_id, "implements")
    return graph


def _suite_from_path(path: str) -> str:
    rel = path.split(":", 1)[-1]
    return rel.split("/", 1)[0] if "/" in rel else ""
