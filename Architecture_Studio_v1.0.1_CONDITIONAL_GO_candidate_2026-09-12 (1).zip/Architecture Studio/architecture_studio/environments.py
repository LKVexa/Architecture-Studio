"""Environment descriptors, boundaries and smoke tests (ENV-01..06, XAUTH-04, AUDIT-ADD-19).

Six environments are *declared* here as data — identity provider, config
namespace, secrets namespace, data boundary, observability sink, deployment
control, permission ceiling, mode ceiling, network allowlist. Declaring an
environment is not provisioning it: every descriptor carries a ``provisioned``
flag that only becomes true when a host operator's provisioning record is
supplied, and :func:`smoke_test` reports ``NOT_PROVISIONED`` for anything that
has none. ENV-04 and ENV-05 are conditional in the source ("where
applicable", "only where explicitly authorized"); their applicability is
``UNRESOLVED`` until a human resolves it, and they cannot be provisioned or
smoke-tested before that.

The boundaries that *can* be verified offline are verified for real:
no two environments share an identity provider, secrets namespace or data
boundary; ceilings compose by narrowing only (:func:`scope.effective_permissions`);
no non-production environment lists production data in its boundary; and the
local/ci environments carry no mutating permission at all.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

from .canonical import canonical_bytes, digest_of
from .evidence_io import atomic_write, loads_strict
from .scope import EnvironmentConflict, ScopeContract, effective_permissions, reconcile_environment
from .slo import CEILINGS

__all__ = ["Environment", "ENVIRONMENTS", "write_descriptors", "load_descriptors", "boundary_report", "smoke_test",
           "ENVIRONMENTS_VERSION"]

ENVIRONMENTS_VERSION = "1.0.0"


@dataclass(frozen=True)
class Environment:
    environment_id: str
    requirement_id: str
    name: str
    purpose: str
    identity_provider: str
    config_namespace: str
    secrets_namespace: str
    data_boundary: str
    observability_sink: str
    deployment_control: str
    permissions_ceiling: tuple[str, ...]
    mode_ceiling: str
    network_allowlist: tuple[str, ...] = ()
    applicability: str = "APPLICABLE"          # APPLICABLE | UNRESOLVED | NOT_APPLICABLE
    applicability_owner: str = "operations_owner"
    promotion_from: str | None = None
    provisioned: bool = False
    provisioning_record: str | None = None
    notes: tuple[str, ...] = ()

    def as_document(self) -> dict[str, Any]:
        return {"environment_id": self.environment_id, "requirement_id": self.requirement_id, "name": self.name,
                "purpose": self.purpose, "identity_provider": self.identity_provider, "config_namespace": self.config_namespace,
                "secrets_namespace": self.secrets_namespace, "data_boundary": self.data_boundary,
                "observability_sink": self.observability_sink, "deployment_control": self.deployment_control,
                "permissions_ceiling": list(self.permissions_ceiling), "mode_ceiling": self.mode_ceiling,
                "network_allowlist": list(self.network_allowlist), "applicability": self.applicability,
                "applicability_owner": self.applicability_owner, "promotion_from": self.promotion_from,
                "provisioned": self.provisioned, "provisioning_record": self.provisioning_record,
                "resource_ceilings": CEILINGS.get(self.environment_id, CEILINGS["local"]), "notes": list(self.notes)}


ENVIRONMENTS: tuple[Environment, ...] = (
    Environment("local", "ENV-01", "Developer/local sandbox", "Run the studio against the checked-in corpus with no network.",
                "as.local-idp", "as.config.local", "as.secrets.local (per-developer, never committed)", "corpus-checkout + temp dirs",
                "stdout structured log", "none (developer runs tests)", ("read", "analyze", "draft", "write_evidence"), "draft_only",
                provisioned=True, provisioning_record="this repository (tests/run_all.py executes here)",
                notes=("The only environment this pass can truthfully call provisioned: it is the checkout itself.",)),
    Environment("ci", "ENV-02", "CI validation environment", "Run the full test/benchmark suite on every change.",
                "ci-runner-oidc", "as.config.ci", "as.secrets.ci (none required; zero third-party deps)", "ephemeral checkout",
                "CI job log + artifacts", "workflow file ci/architecture-studio.yml", ("read", "analyze", "write_evidence"), "read_only",
                promotion_from="local", notes=("Declared by ci/architecture-studio.yml; executes only when a CI host runs it.",)),
    Environment("staging", "ENV-03", "Staging/pre-production", "Exercise the workflow against staging connectors under draft-only.",
                "host-idp:staging", "as.config.staging", "host-kms:staging", "staging tenant data only", "host telemetry: staging",
                "release promotion (release.py) + human approval", ("read", "analyze", "draft", "write_evidence"), "draft_only",
                promotion_from="ci", notes=("Requires a host: identity provider, KMS and telemetry are slots, not implementations.",)),
    Environment("production_read_only", "ENV-04", "Production read-only integration (where applicable)",
                "Read production sources for analysis without any write path.", "host-idp:prod-ro", "as.config.prod-ro",
                "host-kms:prod-ro", "production sources, read-only, no export outside tenant", "host telemetry: production",
                "release promotion + pilot exit criteria (AUDIT-ADD-25)", ("read", "analyze", "write_evidence"), "read_only",
                applicability="UNRESOLVED", promotion_from="staging",
                notes=("Source says 'where applicable'; a human must resolve applicability before provisioning.",)),
    Environment("privileged_execution", "ENV-05", "Separate privileged execution path (only where explicitly authorized)",
                "Isolated path for the modify/commit permissions if ever authorized.", "host-idp:privileged", "as.config.privileged",
                "host-kms:privileged (short-lived leases only)", "explicitly enumerated targets", "host telemetry: privileged (alerting on every use)",
                "explicit human authorization per run + approval token", ("read", "analyze", "draft", "modify", "commit", "write_evidence"), "modify",
                applicability="UNRESOLVED", applicability_owner="human_review_policy_owner", promotion_from="staging",
                notes=("Never instantiated by this pass; exists so the boundary is declared rather than implied.",)),
    Environment("test_tenant", "ENV-06", "Isolated test tenant/data set", "Privacy/security validation with synthetic data and canaries.",
                "as.local-idp", "as.config.test-tenant", "as.secrets.test-tenant", "synthetic tenant 'canary' + fixtures/",
                "stdout structured log", "none (tests)", ("read", "analyze", "draft", "write_evidence"), "draft_only",
                provisioned=True, provisioning_record="fixtures/ and TenantCanary (tests/test_security.py)"),
)
_BY_ID = {e.environment_id: e for e in ENVIRONMENTS}


def write_descriptors(directory: Path) -> dict[str, str]:
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    written = {}
    for env in ENVIRONMENTS:
        path = directory / f"{env.environment_id}.json"
        atomic_write(path, canonical_bytes(env.as_document()))
        written[env.environment_id] = str(path)
    atomic_write(directory / "INDEX.json", canonical_bytes({"version": ENVIRONMENTS_VERSION, "environments": sorted(written),
                                                            "digest": digest_of([e.as_document() for e in ENVIRONMENTS])}))
    return written


def load_descriptors(directory: Path) -> dict[str, dict[str, Any]]:
    directory = Path(directory)
    return {p.stem: loads_strict(p.read_bytes()) for p in sorted(directory.glob("*.json")) if p.name != "INDEX.json"}


def boundary_report() -> dict[str, Any]:
    """Offline-verifiable boundary properties across the declared environments."""
    problems: list[str] = []
    seen: dict[str, dict[str, str]] = {"identity_provider": {}, "secrets_namespace": {}, "data_boundary": {}, "config_namespace": {}}
    for env in ENVIRONMENTS:
        for key in seen:
            value = getattr(env, key)
            if value in seen[key] and not (key == "identity_provider" and value == "as.local-idp" and env.environment_id in ("local", "test_tenant")):
                problems.append(f"{env.environment_id} shares {key} {value!r} with {seen[key][value]}")
            seen[key].setdefault(value, env.environment_id)
        if env.environment_id in ("local", "ci", "test_tenant") and set(env.permissions_ceiling) & {"modify", "commit", "deploy"}:
            problems.append(f"{env.environment_id} carries a mutating permission")
        if env.environment_id != "production_read_only" and "production" in env.data_boundary and env.environment_id != "privileged_execution":
            problems.append(f"{env.environment_id} names production data in its boundary")
        try:
            reconcile_environment({"id": env.environment_id, "mode_ceiling": env.mode_ceiling,
                                   "permissions_ceiling": env.permissions_ceiling, "network_allowlist": env.network_allowlist})
        except EnvironmentConflict as exc:
            problems.append(str(exc))
    chain = {e.environment_id: e.promotion_from for e in ENVIRONMENTS}
    for env_id, parent in chain.items():
        if parent is not None and parent not in chain:
            problems.append(f"{env_id} promotes from unknown environment {parent!r}")
    return {"version": ENVIRONMENTS_VERSION, "environments": [e.environment_id for e in ENVIRONMENTS], "promotion_chain": chain,
            "problems": problems, "ok": not problems,
            "unresolved_applicability": [e.environment_id for e in ENVIRONMENTS if e.applicability == "UNRESOLVED"]}


def smoke_test(environment_id: str, scope: ScopeContract) -> dict[str, Any]:
    """ENV-0x smoke test: ceiling composition, mode narrowing and provisioning status — never claims a host it lacks."""
    env = _BY_ID[environment_id]
    result: dict[str, Any] = {"environment_id": environment_id, "requirement_id": env.requirement_id,
                              "applicability": env.applicability, "provisioned": env.provisioned}
    if env.applicability == "UNRESOLVED":
        result.update(status="NOT_APPLICABLE_YET", reason=f"applicability unresolved; owner {env.applicability_owner}")
        return result
    try:
        eff = effective_permissions(scope=scope, environment_ceiling=[p for p in env.permissions_ceiling if p in scope.permissions],
                                    environment_mode=env.mode_ceiling)
    except Exception as exc:  # ScopeError: widening attempted
        result.update(status="FAIL", reason=str(exc))
        return result
    result["effective"] = eff.as_document()
    widened = set(eff.permissions) - set(scope.permissions)
    if widened:
        result.update(status="FAIL", reason=f"environment widened the contract: {sorted(widened)}")
    elif not env.provisioned:
        result.update(status="NOT_PROVISIONED", reason="descriptor declared; no provisioning record from a host operator")
    else:
        result.update(status="PASS", reason="ceiling composed by narrowing; provisioning record present")
    return result
