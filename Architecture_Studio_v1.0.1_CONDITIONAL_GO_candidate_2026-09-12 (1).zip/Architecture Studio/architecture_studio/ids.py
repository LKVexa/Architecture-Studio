"""Deterministic identifiers (XSTATE-05, API-07).

Every run, artifact, candidate, option event, finding, question, decision and
approval identity is a pure function of its defining fields: nothing is drawn
from a clock or a random source, so the same pinned inputs reconstruct the same
identifiers on another machine (XSTATE-04) and a model cannot mint or replace
an identifier — IDs are generated at trusted boundaries from fields the model
does not control.

Adapted from the owner's Repository Context Graph runtime (``rcg/ids.py``).
"""
from __future__ import annotations

from .canonical import compact_json, sha256_hex

__all__ = ["deterministic_id", "run_id", "artifact_id", "candidate_id", "event_id",
           "finding_id", "question_id", "decision_id", "approval_id", "attempt_id", "is_valid_id"]

_PREFIX = {
    "run": "RUN", "artifact": "ART", "candidate": "CND", "event": "EVT", "finding": "FND",
    "question": "QST", "decision": "DEC", "approval": "APR", "context": "CTX",
    "evidence": "EV", "comparison": "CMP", "diagram": "DGM", "assumption": "ASM",
    "requirement": "REQ", "node": "ND", "edge": "EG", "record": "REC",
}


def deterministic_id(kind: str, **fields: object) -> str:
    """``<PREFIX>-<20 hex>`` from ``kind`` plus the named fields (``kind`` itself is reserved)."""
    prefix = _PREFIX.get(kind, kind.upper()[:3])
    return f"{prefix}-{sha256_hex(compact_json({'kind': kind, 'fields': fields}))[:20]}"


def run_id(*, tenant: str, project: str, source_set_digest: str, package_version: str, purpose: str) -> str:
    return deterministic_id("run", tenant=tenant, project=project, source_set_digest=source_set_digest,
                            package_version=package_version, purpose=purpose)


def artifact_id(*, source_system: str, tenant: str, project: str, path: str, revision: str) -> str:
    return deterministic_id("artifact", source_system=source_system, tenant=tenant, project=project,
                            path=path, revision=revision)


def candidate_id(*, run: str, iteration: int, structure_digest: str) -> str:
    return deterministic_id("candidate", run=run, iteration=iteration, structure_digest=structure_digest)


def event_id(*, run: str, sequence: int, kind: str) -> str:
    return deterministic_id("event", run=run, sequence=sequence, event_kind=kind)


def finding_id(*, run: str, kind: str, subject: str, detail_digest: str) -> str:
    return deterministic_id("finding", run=run, finding_kind=kind, subject=subject, detail_digest=detail_digest)


def question_id(*, run: str, gap: str) -> str:
    return deterministic_id("question", run=run, gap=gap)


def decision_id(*, run: str, gate: str, subject_digest: str, decision: str, approver: str) -> str:
    return deterministic_id("decision", run=run, gate=gate, subject_digest=subject_digest,
                            decision=decision, approver=approver)


def approval_id(*, run: str, gate: str, subject_digest: str) -> str:
    return deterministic_id("approval", run=run, gate=gate, subject_digest=subject_digest)


def attempt_id(sequence: int) -> str:
    if sequence < 1:
        raise ValueError("attempt sequence starts at 1")
    return f"A{sequence:04d}"


def is_valid_id(value: str, kind: str | None = None) -> bool:
    if not isinstance(value, str) or "-" not in value:
        return False
    prefix, _, body = value.partition("-")
    if kind is not None and prefix != _PREFIX.get(kind, kind.upper()[:3]):
        return False
    return prefix.isupper() and len(body) == 20 and all(c in "0123456789abcdef" for c in body)
