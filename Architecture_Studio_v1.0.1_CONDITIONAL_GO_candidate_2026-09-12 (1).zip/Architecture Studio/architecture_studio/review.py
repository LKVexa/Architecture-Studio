"""Human review surface, decisions and the approval gate (ARCH-09, IMPL-08, WF-09, WF-10, HUMAN-01..07, XHITL-01..05, VERIFY-05, STORE-04, COMP-08).

The review package is built from the run's own evidence: the analyzed set and
the *not*-analyzed set side by side (HUMAN-02), the evidence behind every
statement (HUMAN-01), candidates, comparison, uncertainty, verification
results, open questions and excluded/failed analyses (WF-09). Its subject digest
covers the exact bytes the reviewer saw; a decision binds to that digest, so a
material change after approval invalidates it.

Decisions (approve / reject / edit / narrow_scope / request_more_evidence) are
recorded only for an authenticated **human** principal through an approval
token from the trusted service (SEC-07). ``reject`` produces no side effect
beyond the record (HUMAN-04). Decision history is immutable with supersession
(STORE-04). Accountability language is checked, not assumed (HUMAN-07): the
package, the decision record and the rendered page all carry the statement
that the human role owns the decision, and :func:`accountability_violations`
scans generated text for phrasing that attributes ownership to the system.

Build provenance: adapted from the owner's ``rcg/review.py``; the token gate is
this package's :mod:`approvals`.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping, Sequence

from .approvals import ApprovalService
from .authority import Principal, assert_not_self_attested
from .canonical import canonical_bytes, fmt_ts, sha256_of
from .ids import decision_id as make_decision_id
from .schemas import DECISIONS, validate
from .scope import ScopeContract

__all__ = ["ACCOUNTABILITY", "ReviewError", "ReviewPackage", "build_review_package", "DecisionRecorder",
           "ApprovalGate", "ReviewBurden", "accountability_violations"]

ACCOUNTABILITY = ("Final accountability for this decision rests with the named human reviewer role. The system "
                  "produced the analysis and the candidates; it did not approve them and cannot attest to its own work.")

_FORBIDDEN = (
    re.compile(r"(?i)\b(?:the )?(?:system|model|ai|assistant|studio)\b[^.\n]{0,40}\b(?:approved|approves|selected|decided|signed off)\b"),
    re.compile(r"(?i)\bfinal (?:decision|architecture)\b[^.\n]{0,30}\b(?:made|owned|taken)\b[^.\n]{0,20}\b(?:by the )?(?:system|model|ai)\b"),
    re.compile(r"(?i)\bauto-?approved\b"),
)


class ReviewError(RuntimeError):
    pass


def accountability_violations(text: str) -> list[str]:
    """HUMAN-07 / VERIFY-05: phrases that represent the AI as owning the decision."""
    return [m.group(0) for pattern in _FORBIDDEN for m in pattern.finditer(text)]


@dataclass
class ReviewBurden:
    """XEVAL-04: what it costs a human to review this, measured not asserted."""

    statements_to_check: int
    evidence_items: int
    candidates: int
    comparison_cells: int
    unresolved_items: int
    open_questions: int
    material_open_questions: int

    def as_document(self) -> dict[str, Any]:
        doc = {"statements_to_check": self.statements_to_check, "evidence_items": self.evidence_items,
               "candidates": self.candidates, "comparison_cells": self.comparison_cells,
               "unresolved_items": self.unresolved_items, "open_questions": self.open_questions,
               "material_open_questions": self.material_open_questions}
        doc["burden_score"] = (self.statements_to_check + self.comparison_cells + self.unresolved_items
                               + 2 * self.material_open_questions)
        return doc


@dataclass
class ReviewPackage:
    run_id: str
    gate: str
    scope_digest: str
    pinned_digest: str
    analyzed: dict[str, Any]
    not_analyzed: dict[str, Any]
    statements: list[dict[str, Any]]
    evidence: dict[str, dict[str, Any]]
    candidates: list[dict[str, Any]]
    comparison: dict[str, Any] | None
    uncertainty: dict[str, Any]
    verification: dict[str, Any]
    questions: list[dict[str, Any]]
    excluded_or_failed: list[dict[str, Any]]
    policy_decision: dict[str, Any]
    burden: ReviewBurden
    accountability: str = ACCOUNTABILITY
    built_at: str = ""
    status: str = "awaiting human review"

    def as_document(self) -> dict[str, Any]:
        return {"run_id": self.run_id, "gate": self.gate, "scope_digest": self.scope_digest, "pinned_digest": self.pinned_digest,
                "analyzed": self.analyzed, "not_analyzed": self.not_analyzed, "statements": self.statements,
                "evidence": self.evidence, "candidates": self.candidates, "comparison": self.comparison,
                "uncertainty": self.uncertainty, "verification": self.verification, "questions": self.questions,
                "excluded_or_failed": self.excluded_or_failed, "policy_decision": self.policy_decision,
                "burden": self.burden.as_document(), "accountability": self.accountability, "built_at": self.built_at,
                "status": self.status}

    @property
    def subject_digest(self) -> str:
        doc = self.as_document()
        doc.pop("status", None)
        return sha256_of(canonical_bytes(doc))

    def evidence_for(self, statement_index: int) -> list[dict[str, Any]]:
        """HUMAN-01: drill from a statement to its original evidence."""
        refs = self.statements[statement_index].get("evidence_refs", [])
        return [self.evidence[r] for r in refs if r in self.evidence]


def build_review_package(*, run_id: str, gate: str, scope: ScopeContract, pinned_digest: str,
                         analyzed: Mapping[str, Any], not_analyzed: Mapping[str, Any],
                         candidates: Sequence[Mapping[str, Any]], comparison: Mapping[str, Any] | None,
                         evidence: Mapping[str, Mapping[str, Any]], uncertainty: Mapping[str, Any],
                         verification: Mapping[str, Any], questions: Sequence[Mapping[str, Any]],
                         excluded_or_failed: Sequence[Mapping[str, Any]], policy_decision: Mapping[str, Any]) -> ReviewPackage:
    statements: list[dict[str, Any]] = []
    for candidate in candidates:
        for entry in candidate.get("rationale", []):
            statements.append({"candidate_id": candidate["candidate_id"], "text": entry["text"],
                               "derivation": entry["derivation"], "evidence_refs": list(entry.get("evidence_refs", []))})
        for risk in candidate.get("risks", []):
            statements.append({"candidate_id": candidate["candidate_id"], "text": risk["text"], "derivation": "source"
                               if risk.get("evidence_refs") else "model_inference",
                               "evidence_refs": list(risk.get("evidence_refs", []))})
    if comparison:
        for diff in comparison.get("differences", []):
            statements.append({"candidate_id": None, "text": diff["statement"], "derivation": diff["derivation"],
                               "evidence_refs": list(diff.get("evidence_refs", []))})
    material_open = [q for q in questions if q["materiality"] == "material" and q["status"] == "open"]
    burden = ReviewBurden(statements_to_check=len(statements), evidence_items=len(evidence), candidates=len(candidates),
                          comparison_cells=len(comparison["cells"]) if comparison else 0,
                          unresolved_items=len(comparison["unresolved"]) if comparison else 0,
                          open_questions=sum(1 for q in questions if q["status"] == "open"),
                          material_open_questions=len(material_open))
    package = ReviewPackage(run_id=run_id, gate=gate, scope_digest=scope.scope_digest, pinned_digest=pinned_digest,
                            analyzed=dict(analyzed), not_analyzed=dict(not_analyzed), statements=statements,
                            evidence={k: dict(v) for k, v in evidence.items()}, candidates=[dict(c) for c in candidates],
                            comparison=dict(comparison) if comparison else None, uncertainty=dict(uncertainty),
                            verification=dict(verification), questions=[dict(q) for q in questions],
                            excluded_or_failed=[dict(e) for e in excluded_or_failed], policy_decision=dict(policy_decision),
                            burden=burden, built_at=fmt_ts(datetime.now(timezone.utc)))
    violations = accountability_violations(canonical_bytes(package.as_document()).decode("ascii"))
    if violations:
        raise ReviewError(f"review package attributes the decision to the system: {violations[:3]}")
    return package


class DecisionRecorder:
    """STORE-04 / COMP-08: immutable, attributable decisions with supersession."""

    def __init__(self, *, ledger: Any = None) -> None:
        self.ledger = ledger
        self._decisions: dict[str, dict[str, Any]] = {}
        self._current: dict[tuple[str, str], str] = {}

    def record(self, *, principal: Principal, run_id: str, gate: str, decision: str, package: ReviewPackage,
               scope: ScopeContract, policy_version: str, rationale: str | None = None,
               requested_changes: Sequence[str] = (), requested_evidence: Sequence[str] = (),
               narrowed_scope: Mapping[str, Any] | None = None, artifact_ids: Sequence[str] = ()) -> dict[str, Any]:
        if decision not in DECISIONS:
            raise ReviewError(f"unknown decision {decision!r}")
        assert_not_self_attested(principal.kind, gate)
        if decision == "narrow_scope" and not narrowed_scope:
            raise ReviewError("narrow_scope requires the narrowed scope")
        if decision == "request_more_evidence" and not requested_evidence:
            raise ReviewError("request_more_evidence must name the evidence needed")
        previous = self._current.get((run_id, gate))
        doc = {
            "schema_id": "as.review_decision/1",
            "decision_id": make_decision_id(run=run_id, gate=gate, subject_digest=package.subject_digest,
                                            decision=decision, approver=principal.subject),
            "run_id": run_id, "gate": gate, "decision": decision, "approver_identity": principal.as_record(),
            "approved_scope_digest": scope.scope_digest, "subject_digest": package.subject_digest,
            "artifact_ids": sorted(artifact_ids), "decided_at": fmt_ts(datetime.now(timezone.utc)),
            "rationale": rationale, "requested_changes": list(requested_changes),
            "requested_evidence": list(requested_evidence),
            "narrowed_scope": dict(narrowed_scope) if narrowed_scope else None, "policy_version": policy_version,
            "accountability": ACCOUNTABILITY, "supersedes": previous,
        }
        validate("as.review_decision/1", doc)
        if doc["decision_id"] in self._decisions:
            return self._decisions[doc["decision_id"]]
        self._decisions[doc["decision_id"]] = doc
        self._current[(run_id, gate)] = doc["decision_id"]
        if self.ledger is not None:
            self.ledger.append("review.decision", actor=principal.subject, actor_kind="human", outcome="recorded",
                               subject=gate, authority_ref=doc["decision_id"], detail=doc)
        return doc

    def history(self, run_id: str, gate: str | None = None) -> list[dict[str, Any]]:
        return [d for d in self._decisions.values() if d["run_id"] == run_id and (gate is None or d["gate"] == gate)]

    def current(self, run_id: str, gate: str) -> dict[str, Any] | None:
        key = self._current.get((run_id, gate))
        return self._decisions.get(key) if key else None

    def is_superseded(self, decision_id: str) -> bool:
        return any(d["supersedes"] == decision_id for d in self._decisions.values())


class ApprovalGate:
    """WF-10 / XHITL-02: nothing proceeds past here without a verified human token."""

    def __init__(self, service: ApprovalService, recorder: DecisionRecorder, *, ledger: Any = None) -> None:
        self.service = service
        self.recorder = recorder
        self.ledger = ledger

    def decide(self, *, package: ReviewPackage, principal: Principal, decision: str, scope: ScopeContract,
               policy_version: str, token: Mapping[str, Any] | None = None, **kw: Any) -> dict[str, Any]:
        """Record a decision; ``approve`` additionally requires a verified token for this exact package."""
        assert_not_self_attested(principal.kind, package.gate)
        if decision == "approve":
            if token is None:
                raise ReviewError("approve requires an approval token from the trusted service")
            artifact_ids = kw.get("artifact_ids") or [c["candidate_id"] for c in package.candidates]
            # Check the approver binding BEFORE verifying: a decision by the wrong principal must not
            # consume the nonce of a token issued to someone else.
            if not isinstance(token, Mapping) or (token.get("approver") or {}).get("subject") != principal.subject:
                raise ReviewError("approval refused: approval.approver_mismatch: token was issued to another principal")
            result = self.service.verify(token, run_id=package.run_id, gate=package.gate, artifact_ids=artifact_ids,
                                         action="approve", scope_digest=scope.scope_digest,
                                         subject_digest=package.subject_digest)
            if not result.valid:
                raise ReviewError(f"approval refused: {result.code}: {result.reason}")
            kw["artifact_ids"] = artifact_ids
        record = self.recorder.record(principal=principal, run_id=package.run_id, gate=package.gate, decision=decision,
                                      package=package, scope=scope, policy_version=policy_version, **kw)
        return record

    def authorizes(self, decision: Mapping[str, Any], package: ReviewPackage, scope: ScopeContract) -> tuple[bool, str]:
        """Is this recorded decision still valid authorization for this exact package?"""
        if decision["decision"] != "approve":
            return False, f"decision is {decision['decision']!r}, which never authorizes"
        if self.recorder.is_superseded(decision["decision_id"]):
            return False, "a later decision superseded this approval"
        if decision["subject_digest"] != package.subject_digest:
            return False, "material change since approval: the package digest no longer matches what was approved"
        if decision["approved_scope_digest"] != scope.scope_digest:
            return False, "the scope contract changed after approval"
        if decision["run_id"] != package.run_id:
            return False, "approval belongs to a different run"
        return True, "approval is current and bound to this exact package and scope"
