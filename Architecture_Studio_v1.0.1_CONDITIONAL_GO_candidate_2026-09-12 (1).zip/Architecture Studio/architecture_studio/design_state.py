"""Explicit design state and option lifecycle (PAPER-CAP-01, PAPER-CAP-06, PAPER-GRD-04, COMP-01, COMP-08, AUDIT-ADD-15, VERIFY-06).

The DesignState is the domain model the studio is *about*: goals, constraints,
open questions, candidates, comparisons, assumptions and the exploration
history that explains why every option was introduced, modified, forked,
compared or discarded. It is persisted through :class:`DesignStateStore` as a
versioned, content-addressed snapshot chain: every mutation is a new version
with a compare-and-swap on the previous one (AUDIT-ADD-15), so two reviewers
cannot silently overwrite each other and no iteration is ever destroyed
(VERIFY-06). A session can stop and resume with identical state (COMP-01).

Option lifecycle events (COMP-08) are append-only: each names the actor, the
rationale, the evidence, and the state digest before and after, and each is
also written to the run ledger. Steering (PAPER-GRD-04) is expressed as the
operations that produce a *new version*: edit goals or constraints, add
evidence, narrow scope, modify or discard an option, rerun.

Build provenance: BUILD_NEW (the yard's graph and workbench cars model
repositories and traces, not design sessions); the CAS snapshot discipline
comes from the owner's ``rcg/versionstore.py``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping, Sequence

from .canonical import digest_of, fmt_ts
from .ids import deterministic_id, event_id
from .schemas import OPTION_EVENTS, validate
from .store import ConcurrencyError, ObjectStore, Snapshot

__all__ = ["DesignStateError", "DesignState", "OptionEvent", "DesignStateStore", "STEERING_OPERATIONS"]

#: PAPER-GRD-04 / COMP-07: the operations that make a session steerable.
STEERING_OPERATIONS = ("inspect", "compare", "ask", "edit_goals", "edit_constraints", "add_evidence",
                       "narrow_scope", "modify_option", "discard_option", "reinstate_option", "rerun")


class DesignStateError(RuntimeError):
    pass


@dataclass(frozen=True)
class OptionEvent:
    event_id: str
    run_id: str
    sequence: int
    candidate_id: str
    kind: str
    actor: str
    actor_kind: str
    rationale: str
    evidence_refs: tuple[str, ...]
    prior_state_digest: str | None
    new_state_digest: str
    at: str

    def as_document(self) -> dict[str, Any]:
        doc = {"schema_id": "as.option_event/1", "event_id": self.event_id, "run_id": self.run_id,
               "sequence": self.sequence, "candidate_id": self.candidate_id, "kind": self.kind,
               "actor": self.actor, "actor_kind": self.actor_kind, "rationale": self.rationale,
               "evidence_refs": list(self.evidence_refs), "prior_state_digest": self.prior_state_digest,
               "new_state_digest": self.new_state_digest, "at": self.at}
        return validate("as.option_event/1", doc)


@dataclass
class DesignState:
    run_id: str
    scope_digest: str
    version: int = 0
    iteration: int = 0
    goals: list[dict[str, Any]] = field(default_factory=list)
    constraints: list[dict[str, Any]] = field(default_factory=list)
    open_questions: list[str] = field(default_factory=list)
    candidates: list[str] = field(default_factory=list)
    comparisons: list[str] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    exploration_events: list[str] = field(default_factory=list)
    review_state: str = "not_submitted"
    updated_at: str = ""
    updated_by: str = "system"
    candidate_states: dict[str, str] = field(default_factory=dict)

    def as_document(self) -> dict[str, Any]:
        doc = {
            "schema_id": "as.design_state/1", "run_id": self.run_id, "version": self.version,
            "iteration": self.iteration, "goals": [dict(g) for g in self.goals],
            "constraints": [dict(c) for c in self.constraints], "open_questions": list(self.open_questions),
            "candidates": list(self.candidates), "comparisons": list(self.comparisons),
            "assumptions": list(self.assumptions), "exploration_events": list(self.exploration_events),
            "review_state": self.review_state, "scope_digest": self.scope_digest,
            "updated_at": self.updated_at or fmt_ts(datetime.now(timezone.utc)), "updated_by": self.updated_by,
        }
        return validate("as.design_state/1", doc)

    @property
    def digest(self) -> str:
        doc = self.as_document()
        doc.pop("updated_at", None)
        return digest_of({**doc, "candidate_states": dict(sorted(self.candidate_states.items()))})

    @classmethod
    def from_document(cls, doc: Mapping[str, Any], candidate_states: Mapping[str, str] | None = None) -> "DesignState":
        validate("as.design_state/1", dict(doc))
        return cls(run_id=doc["run_id"], scope_digest=doc["scope_digest"], version=doc["version"],
                   iteration=doc["iteration"], goals=[dict(g) for g in doc["goals"]],
                   constraints=[dict(c) for c in doc["constraints"]], open_questions=list(doc["open_questions"]),
                   candidates=list(doc["candidates"]), comparisons=list(doc["comparisons"]),
                   assumptions=list(doc["assumptions"]), exploration_events=list(doc["exploration_events"]),
                   review_state=doc["review_state"], updated_at=doc["updated_at"], updated_by=doc["updated_by"],
                   candidate_states=dict(candidate_states or {}))

    def active_candidates(self) -> list[str]:
        return [c for c in self.candidates if self.candidate_states.get(c, "introduced") != "discarded"]


class DesignStateStore:
    """Versioned persistence for one run's design state, with CAS and lifecycle events."""

    def __init__(self, store: ObjectStore, run_id: str, *, ledger: Any = None) -> None:
        self.store = store
        self.run_id = run_id
        self.ledger = ledger
        self._ref = f"runs/{run_id}/design-state"
        self._events_ref = f"runs/{run_id}/option-events"

    # ----------------------------------------------------------- lifecycle --
    def initialize(self, *, scope_digest: str, goals: Sequence[Mapping[str, Any]] = (),
                   constraints: Sequence[Mapping[str, Any]] = (), actor: str = "system") -> DesignState:
        if self.store.head(self._ref) is not None:
            raise DesignStateError(f"design state for run {self.run_id} already exists")
        state = DesignState(run_id=self.run_id, scope_digest=scope_digest, goals=[dict(g) for g in goals],
                            constraints=[dict(c) for c in constraints], updated_by=actor,
                            updated_at=fmt_ts(datetime.now(timezone.utc)))
        for item in state.goals + state.constraints:
            if not item.get("evidence_refs") and item.get("derivation", "source") == "source":
                raise DesignStateError("a source-derived goal or constraint must carry evidence references")
        self.store.commit(self._ref, self._payload(state), expected_parent=None,
                          metadata={"version": 0, "actor": actor})
        self.store.commit(self._events_ref, [], expected_parent=None)
        return state

    def load(self) -> DesignState:
        head = self.store.head(self._ref)
        if head is None:
            raise DesignStateError(f"no design state for run {self.run_id}")
        payload = self.store.get_object(head.payload_digest)
        return DesignState.from_document(payload["state"], payload.get("candidate_states"))

    def head(self) -> Snapshot | None:
        return self.store.head(self._ref)

    def _payload(self, state: DesignState) -> dict[str, Any]:
        return {"state": state.as_document(), "candidate_states": dict(state.candidate_states)}

    def _commit(self, state: DesignState, *, actor: str, expected_version: int, operation: str) -> DesignState:
        head = self.store.head(self._ref)
        current = self.store.get_object(head.payload_digest)["state"]["version"] if head else -1
        if expected_version != current:
            raise ConcurrencyError(f"design state moved: expected version {expected_version}, found {current}; "
                                   "re-read and retry so the other reviewer's change is not lost")
        state.version = current + 1
        state.updated_at = fmt_ts(datetime.now(timezone.utc))
        state.updated_by = actor
        self.store.commit(self._ref, self._payload(state), expected_parent=head.snapshot_id if head else None,
                          metadata={"version": state.version, "actor": actor, "operation": operation})
        if self.ledger is not None:
            self.ledger.append("design_state.updated", actor=actor, actor_kind="human" if operation in
                               ("edit_goals", "edit_constraints", "narrow_scope", "discard_option",
                                "reinstate_option", "modify_option") else "service",
                               outcome="recorded", subject=operation,
                               detail={"version": state.version, "digest": state.digest, "operation": operation})
        return state

    # -------------------------------------------------------------- steering --
    def apply(self, operation: str, *, actor: str, actor_kind: str, expected_version: int,
              rationale: str, evidence_refs: Iterable[str] = (), **change: Any) -> DesignState:
        """One steering operation → one new version. Unknown operations are refused."""
        if operation not in STEERING_OPERATIONS:
            raise DesignStateError(f"unknown steering operation {operation!r}")
        if operation in ("inspect", "compare", "ask"):
            raise DesignStateError(f"{operation} is a read operation; it does not create a version")
        if not rationale or len(rationale.strip()) < 8:
            raise DesignStateError("a steering operation carries a rationale a reviewer can read")
        state = self.load()
        prior_digest = state.digest
        refs = tuple(evidence_refs)
        if operation == "edit_goals":
            state.goals = [dict(g) for g in change["goals"]]
        elif operation == "edit_constraints":
            state.constraints = [dict(c) for c in change["constraints"]]
        elif operation == "add_evidence":
            if not refs:
                raise DesignStateError("add_evidence needs at least one evidence reference")
            for goal in state.goals:
                if goal["goal_id"] in change.get("goal_ids", ()):
                    goal["evidence_refs"] = sorted(set(goal.get("evidence_refs", [])) | set(refs))
        elif operation == "narrow_scope":
            state.scope_digest = change["scope_digest"]
        elif operation in ("modify_option", "discard_option", "reinstate_option"):
            cid = change["candidate_id"]
            if cid not in state.candidates:
                raise DesignStateError(f"candidate {cid} is not part of this design state")
            new_state = {"modify_option": "modified", "discard_option": "discarded",
                         "reinstate_option": "introduced"}[operation]
            if operation == "reinstate_option" and state.candidate_states.get(cid) != "discarded":
                raise DesignStateError("only a discarded option can be reinstated")
            state.candidate_states[cid] = new_state
            if operation == "modify_option" and change.get("replacement_candidate_id"):
                state.candidates.append(change["replacement_candidate_id"])
                state.candidate_states[change["replacement_candidate_id"]] = "introduced"
        elif operation == "rerun":
            state.iteration += 1
            state.review_state = "not_submitted"
        self._commit(state, actor=actor, expected_version=expected_version, operation=operation)
        if operation in ("modify_option", "discard_option", "reinstate_option"):
            kind = {"modify_option": "modified", "discard_option": "discarded",
                    "reinstate_option": "reinstated"}[operation]
            self.record_event(candidate_id=change["candidate_id"], kind=kind, actor=actor, actor_kind=actor_kind,
                              rationale=rationale, evidence_refs=refs, prior_state_digest=prior_digest,
                              new_state_digest=state.digest)
        return state

    def register_candidates(self, candidate_ids: Sequence[str], *, actor: str, actor_kind: str,
                            expected_version: int, rationale: str, evidence_refs: Iterable[str] = (),
                            parent: str | None = None) -> DesignState:
        state = self.load()
        prior = state.digest
        refs = tuple(evidence_refs)
        for cid in candidate_ids:
            if cid in state.candidates:
                continue
            state.candidates.append(cid)
            state.candidate_states[cid] = "introduced"
        self._commit(state, actor=actor, expected_version=expected_version, operation="rerun" if parent else "introduce")
        for cid in candidate_ids:
            self.record_event(candidate_id=cid, kind="forked" if parent else "introduced", actor=actor,
                              actor_kind=actor_kind, rationale=rationale, evidence_refs=refs,
                              prior_state_digest=prior, new_state_digest=state.digest)
        return state

    def register_comparison(self, comparison_id: str, candidate_ids: Sequence[str], *, actor: str,
                            actor_kind: str, expected_version: int, rationale: str,
                            evidence_refs: Iterable[str] = ()) -> DesignState:
        state = self.load()
        prior = state.digest
        if comparison_id not in state.comparisons:
            state.comparisons.append(comparison_id)
        self._commit(state, actor=actor, expected_version=expected_version, operation="compare")
        for cid in candidate_ids:
            self.record_event(candidate_id=cid, kind="compared", actor=actor, actor_kind=actor_kind,
                              rationale=rationale, evidence_refs=tuple(evidence_refs), prior_state_digest=prior,
                              new_state_digest=state.digest)
        return state

    def set_review_state(self, review_state: str, *, actor: str, expected_version: int) -> DesignState:
        state = self.load()
        state.review_state = review_state
        return self._commit(state, actor=actor, expected_version=expected_version, operation="review_state")

    def add_open_question(self, question_id: str, *, actor: str, expected_version: int) -> DesignState:
        state = self.load()
        if question_id not in state.open_questions:
            state.open_questions.append(question_id)
        return self._commit(state, actor=actor, expected_version=expected_version, operation="question")

    def resolve_question(self, question_id: str, *, actor: str, expected_version: int) -> DesignState:
        state = self.load()
        state.open_questions = [q for q in state.open_questions if q != question_id]
        return self._commit(state, actor=actor, expected_version=expected_version, operation="question")

    def add_assumptions(self, assumption_ids: Sequence[str], *, actor: str, expected_version: int) -> DesignState:
        state = self.load()
        for aid in assumption_ids:
            if aid not in state.assumptions:
                state.assumptions.append(aid)
        return self._commit(state, actor=actor, expected_version=expected_version, operation="assumptions")

    # --------------------------------------------------------------- events --
    def record_event(self, *, candidate_id: str, kind: str, actor: str, actor_kind: str, rationale: str,
                     evidence_refs: Iterable[str], prior_state_digest: str | None, new_state_digest: str) -> OptionEvent:
        if kind not in OPTION_EVENTS:
            raise DesignStateError(f"unknown option event {kind!r}")
        head = self.store.head(self._events_ref)
        events = list(self.store.get_object(head.payload_digest)) if head else []
        sequence = len(events)
        event = OptionEvent(event_id=event_id(run=self.run_id, sequence=sequence, kind=kind), run_id=self.run_id,
                            sequence=sequence, candidate_id=candidate_id, kind=kind, actor=actor,
                            actor_kind=actor_kind, rationale=rationale.strip(), evidence_refs=tuple(evidence_refs),
                            prior_state_digest=prior_state_digest, new_state_digest=new_state_digest,
                            at=fmt_ts(datetime.now(timezone.utc)))
        events.append(event.as_document())
        self.store.commit(self._events_ref, events, expected_parent=head.snapshot_id if head else None)
        state = self.load()
        if event.event_id not in state.exploration_events:
            state.exploration_events.append(event.event_id)
            self._commit(state, actor=actor, expected_version=state.version, operation="event")
        if self.ledger is not None:
            self.ledger.append("option.lifecycle", actor=actor, actor_kind="service" if actor_kind == "model" else actor_kind,
                               outcome="recorded", subject=candidate_id, detail=event.as_document())
        return event

    def events(self) -> list[dict[str, Any]]:
        head = self.store.head(self._events_ref)
        return list(self.store.get_object(head.payload_digest)) if head else []

    def explain(self, candidate_id: str) -> list[dict[str, Any]]:
        """PAPER-CAP-06: the full evolution of one option, in order."""
        return [e for e in self.events() if e["candidate_id"] == candidate_id]

    # -------------------------------------------------------------- history --
    def history(self) -> list[dict[str, Any]]:
        """VERIFY-06: every version ever written, reconstructable in order."""
        out = []
        for snapshot in self.store.history(self._ref):
            payload = self.store.get_object(snapshot.payload_digest)
            out.append({"revision": snapshot.revision, "snapshot_id": snapshot.snapshot_id,
                        "version": payload["state"]["version"], "iteration": payload["state"]["iteration"],
                        "candidates": list(payload["state"]["candidates"]),
                        "digest": DesignState.from_document(payload["state"], payload.get("candidate_states")).digest,
                        "operation": snapshot.metadata.get("operation")})
        return out

    def at_version(self, version: int) -> DesignState:
        for snapshot in self.store.history(self._ref):
            payload = self.store.get_object(snapshot.payload_digest)
            if payload["state"]["version"] == version:
                return DesignState.from_document(payload["state"], payload.get("candidate_states"))
        raise DesignStateError(f"no version {version} for run {self.run_id}")
