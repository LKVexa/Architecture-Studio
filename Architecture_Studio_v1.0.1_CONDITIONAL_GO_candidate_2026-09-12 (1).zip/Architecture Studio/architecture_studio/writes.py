"""Fail-closed write gate (SEC-05, XHITL-01, WF-07, HUMAN-04).

Every externally consequential write goes through :meth:`WriteGate.attempt`
or :meth:`WriteGate.attempt_bundle`. It admits a write only when the workflow
state, the scope contract, the actor, the target and a verified approval token
*all* validate — and it refuses on the first failure with a typed reason,
producing no side effect and one denial audit event. ``preview`` returns
exactly what would be written without writing it (XHITL-01). Ambiguity is a
refusal: an unknown state, an unresolvable target or a token the service cannot
verify all deny.

A multi-file export (the case file) must not copy leftover files with
``shutil`` after a single-file gate check: that is a hidden write path.
``attempt_bundle`` confines every relative path, writes nothing until every
path and payload is accepted, then consumes the token once. A mid-bundle
failure rolls back files already written under the output root.

The genuine-positive-plus-truth-table proof lives in the tests: one write with
every input real succeeds; each single omission is refused.

Build provenance: BUILD_NEW; the "revalidate everything, then apply, then prove
the result" order follows the SPB ``approval_adapter.apply_isolated``.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from .approvals import ApprovalService
from .authority import Principal
from .canonical import sha256_of
from .evidence_io import UnsafeReference, atomic_write, confine
from .scope import ScopeContract, ScopeDenied
from .workflow import WorkflowMachine, WorkflowState

__all__ = ["WriteDenied", "WriteGate", "WriteReceipt"]

_ALLOWED_STATES = frozenset({WorkflowState.APPROVED, WorkflowState.EXPORTING})


class WriteDenied(PermissionError):
    def __init__(self, code: str, message: str) -> None:
        self.code = code
        super().__init__(f"{code}: {message}")


@dataclass(frozen=True)
class WriteReceipt:
    path: str
    sha256: str
    bytes: int
    token_id: str
    actor: str

    def as_document(self) -> dict[str, Any]:
        return {"path": self.path, "sha256": self.sha256, "bytes": self.bytes, "token_id": self.token_id, "actor": self.actor}


class WriteGate:
    def __init__(self, *, service: ApprovalService, scope: ScopeContract, machine: WorkflowMachine,
                 output_root: Path, ledger: Any = None, permission: str = "modify") -> None:
        if permission not in ("modify", "write_evidence"):
            raise ValueError("a write gate guards either 'modify' (external targets) or 'write_evidence' (case-file export)")
        self.permission = permission
        self.service = service
        self.scope = scope
        self.machine = machine
        self.output_root = Path(output_root).resolve()
        self.ledger = ledger

    def _deny(self, code: str, message: str, *, actor: str, target: str) -> WriteDenied:
        if self.ledger is not None:
            self.ledger.append("artifact.write", actor=actor, actor_kind="service", outcome="denied", subject=target,
                               detail={"code": code, "reason": message, "permission": self.permission})
        return WriteDenied(code, message)

    def _authorize(self, *, actor: Any, token: Mapping[str, Any] | None,
                   artifact_ids: Sequence[str], subject_digest: str, run_id: str, gate: str) -> str:
        """Shared authorization: actor, run, state, scope, token. Does not confine a path."""
        name = getattr(actor, "subject", str(actor))
        if not isinstance(actor, Principal):
            raise self._deny("write.actor_unauthenticated", "writes require an authenticated Principal", actor=name, target="")
        if self.machine.run_id != run_id:
            raise self._deny("write.run_mismatch", "workflow belongs to a different run", actor=name, target="")
        if self.machine.state not in _ALLOWED_STATES:
            raise self._deny("write.state_not_approved", f"workflow state {self.machine.state} does not permit writes",
                             actor=name, target="")
        try:
            self.scope.check(self.permission)
        except ScopeDenied as exc:
            raise self._deny("write.scope_denied", str(exc), actor=name, target="")
        if token is None:
            raise self._deny("write.token_missing", "no approval token was presented", actor=name, target="")
        result = self.service.verify(token, run_id=run_id, gate=gate, artifact_ids=artifact_ids, action="write",
                                     scope_digest=self.scope.scope_digest, subject_digest=subject_digest, consume=False)
        if not result.valid:
            raise self._deny(result.code, result.reason, actor=name, target="")
        if token["approver"]["subject"] != actor.subject:
            raise self._deny("write.approver_mismatch", "token was issued to a different principal", actor=name, target="")
        return name

    def _confine(self, target: str, *, actor: str) -> Path:
        try:
            return confine(self.output_root, target)
        except (UnsafeReference, Exception) as exc:
            raise self._deny("write.target_unresolvable", str(exc), actor=actor, target=target)

    def _validate(self, *, actor: Any, target: str, payload: bytes, token: Mapping[str, Any] | None,
                  artifact_ids: Sequence[str], subject_digest: str, run_id: str, gate: str) -> Path:
        name = self._authorize(actor=actor, token=token, artifact_ids=artifact_ids, subject_digest=subject_digest,
                               run_id=run_id, gate=gate)
        resolved = self._confine(target, actor=name)
        if not payload:
            raise self._deny("write.empty_payload", "refusing to write an empty artifact", actor=name, target=target)
        return resolved

    def preview(self, *, actor: Any, target: str, payload: bytes, token: Mapping[str, Any] | None,
                artifact_ids: Sequence[str], subject_digest: str, run_id: str, gate: str) -> dict[str, Any]:
        """XHITL-01: what would be written, validated exactly as a real write, with no effect."""
        resolved = self._validate(actor=actor, target=target, payload=payload, token=token, artifact_ids=artifact_ids,
                                  subject_digest=subject_digest, run_id=run_id, gate=gate)
        return {"would_write": str(resolved.relative_to(self.output_root)), "bytes": len(payload),
                "sha256": sha256_of(payload), "exists": resolved.exists(), "effect": "none (preview)"}

    def attempt(self, *, actor: Any, target: str, payload: bytes, token: Mapping[str, Any] | None,
                artifact_ids: Sequence[str], subject_digest: str, run_id: str, gate: str) -> WriteReceipt:
        resolved = self._validate(actor=actor, target=target, payload=payload, token=token, artifact_ids=artifact_ids,
                                  subject_digest=subject_digest, run_id=run_id, gate=gate)
        # Consume the nonce only now: a preview must not burn the approval.
        self.service.verify(token, run_id=run_id, gate=gate, artifact_ids=artifact_ids, action="write",
                            scope_digest=self.scope.scope_digest, subject_digest=subject_digest, consume=True)
        atomic_write(resolved, payload)
        receipt = WriteReceipt(str(resolved.relative_to(self.output_root)).replace("\\", "/"), sha256_of(payload),
                               len(payload), token["token_id"], actor.subject)
        if self.ledger is not None:
            self.ledger.append("artifact.write", actor=actor.subject, actor_kind="human", outcome="allowed",
                               subject=receipt.path, authority_ref=token["token_id"], detail=receipt.as_document())
        return receipt

    def attempt_bundle(self, *, actor: Any, files: Sequence[tuple[str, bytes]], token: Mapping[str, Any] | None,
                       artifact_ids: Sequence[str], subject_digest: str, run_id: str, gate: str) -> list[WriteReceipt]:
        """Write every file under ``output_root`` through the same authorization as :meth:`attempt`.

        All paths are confined and all payloads checked before the first byte is
        written. The token is consumed once, after confinement and before any
        write, matching :meth:`attempt`: a crash or I/O failure cannot leave
        persisted files with a still-reusable token. A failure after a partial
        write removes the files this call created; the spent token is not
        resurrected (fail-closed).
        """
        name = getattr(actor, "subject", str(actor))
        if not files:
            raise self._deny("write.empty_payload", "refusing to write an empty bundle", actor=name, target="")
        self._authorize(actor=actor, token=token, artifact_ids=artifact_ids, subject_digest=subject_digest,
                        run_id=run_id, gate=gate)
        planned: list[tuple[str, Path, bytes]] = []
        for target, payload in files:
            if not payload:
                raise self._deny("write.empty_payload", "refusing to write an empty artifact", actor=name, target=target)
            planned.append((target, self._confine(target, actor=name), payload))
        # Consume before the first byte: same fail-closed order as attempt().
        self.service.verify(token, run_id=run_id, gate=gate, artifact_ids=artifact_ids, action="write",
                            scope_digest=self.scope.scope_digest, subject_digest=subject_digest, consume=True)
        written: list[Path] = []
        receipts: list[WriteReceipt] = []
        try:
            for target, resolved, payload in planned:
                atomic_write(resolved, payload)
                written.append(resolved)
                receipts.append(WriteReceipt(str(resolved.relative_to(self.output_root)).replace("\\", "/"),
                                             sha256_of(payload), len(payload), token["token_id"], actor.subject))
        except BaseException:
            for path in reversed(written):
                try:
                    path.unlink()
                except OSError:
                    pass
            raise
        if self.ledger is not None:
            self.ledger.append("artifact.write", actor=actor.subject, actor_kind="human", outcome="allowed",
                               subject=run_id, authority_ref=token["token_id"],
                               detail={"files": [r.as_document() for r in receipts], "bundle": True})
        return receipts
