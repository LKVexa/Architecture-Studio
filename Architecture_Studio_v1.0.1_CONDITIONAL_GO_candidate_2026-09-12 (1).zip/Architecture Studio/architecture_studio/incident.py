"""Rollout switch, emergency stop, revocation, quarantine and incident drill (AUDIT-ADD-26, WF-12).

Flags live in a JSON file, not in code. The store fails closed: unreadable,
malformed, unknown-keyed, duplicate-keyed, mistyped and stale documents all
resolve to *disabled*, and each says which one it was. ``bool("false")`` is
``True`` in Python, so booleans must be JSON booleans or the store refuses.

Writes take an authenticated principal (a string is refused) and an exclusive
lock with a compare-and-set revision; the emergency path keeps its speed — no
revision, no approval — but still an authenticated on-call identity.

The switch is consulted on the execution path by :mod:`architecture_studio.policy`
(``CTRL-KILL-01``) for every consequential action, which is the RCG v1.5.0
lesson: a checker that reads the flag while the runtime does not is a kill
switch that kills nothing. :func:`drill` proves it by probe: after
``emergency_disable`` a run makes zero provider calls, persists no candidate,
and its evidence is preserved; a revoked identity cannot authenticate again.

Adapted from the owner's ``rcg/rollout.py``.
"""
from __future__ import annotations

import os
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping

from .canonical import canonical_bytes, fmt_ts
from .evidence_io import EvidenceError, loads_strict

__all__ = ["FlagError", "FlagState", "FlagStore", "DEFAULTS", "FLAG_TYPES", "MAX_FLAG_AGE", "MODE_ORDER", "drill",
           "Quarantine"]

MODE_ORDER = ("read_only", "draft_only", "modify")
COHORTS = ("none", "canary", "internal", "general")
DEFAULTS: dict[str, Any] = {"as.enabled": True, "as.model_reasoning": False, "as.mode": "draft_only", "as.cohort": "none"}
FLAG_TYPES: dict[str, tuple[type, tuple[Any, ...] | None]] = {
    "as.enabled": (bool, None), "as.model_reasoning": (bool, None), "as.mode": (str, MODE_ORDER), "as.cohort": (str, COHORTS)}
MAX_FLAG_AGE = timedelta(days=7)


class FlagError(RuntimeError):
    pass


@dataclass(frozen=True)
class FlagState:
    flags: dict[str, Any]
    revision: int
    updated_at: str
    ok: bool
    reason: str

    @property
    def enabled(self) -> bool:
        return bool(self.ok and self.flags.get("as.enabled") is True)

    @property
    def model_reasoning(self) -> bool:
        return bool(self.ok and self.flags.get("as.model_reasoning") is True)

    @property
    def mode_ceiling(self) -> str:
        return str(self.flags.get("as.mode", "read_only")) if self.ok else "read_only"

    def as_document(self) -> dict[str, Any]:
        return {"flags": dict(self.flags), "revision": self.revision, "updated_at": self.updated_at, "ok": self.ok,
                "reason": self.reason, "enabled": self.enabled, "model_reasoning": self.model_reasoning,
                "mode_ceiling": self.mode_ceiling}


def _disabled(reason: str) -> FlagState:
    return FlagState(flags={**DEFAULTS, "as.enabled": False}, revision=-1, updated_at="", ok=False, reason=reason)


def _actor_record(actor: Any) -> dict[str, Any]:
    if isinstance(actor, str):
        raise FlagError("a flag write requires an authenticated principal, not a caller-supplied name")
    subject, kind, provider = getattr(actor, "subject", None), getattr(actor, "kind", None), getattr(actor, "identity_provider", None)
    if not subject or kind not in ("human", "service") or not provider:
        raise FlagError("flag writes require an authenticated Principal with subject, kind and issuer")
    return {"subject": subject, "kind": kind, "identity_provider": provider}


class _exclusive:
    def __init__(self, path: Path, timeout: float = 10.0) -> None:
        self.path, self.timeout, self._fd = Path(path), timeout, None

    def __enter__(self) -> "_exclusive":
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                self._fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(self._fd, str(os.getpid()).encode())
                return self
            except FileExistsError:
                try:
                    age = time.time() - self.path.stat().st_mtime
                except OSError:
                    age = 0.0
                if age > self.timeout:
                    try:
                        os.unlink(self.path)
                    except OSError:
                        pass
                    continue
                if time.monotonic() > deadline:
                    raise FlagError("could not acquire the flag-store lock")
                time.sleep(0.01)

    def __exit__(self, *exc: Any) -> None:
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
        try:
            os.unlink(self.path)
        except OSError:
            pass


@dataclass
class FlagStore:
    path: Path
    ledger: Any = None
    max_age: timedelta = MAX_FLAG_AGE
    _lock_path: Path = field(init=False, repr=False, default=None)  # type: ignore[assignment]

    def __post_init__(self) -> None:
        self.path = Path(self.path)
        self._lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        if not self.path.exists():
            self._write(dict(DEFAULTS), reason="initialized from defaults",
                        actor_record={"subject": "system", "kind": "service", "identity_provider": "as.bootstrap"}, revision=0)

    def state(self, *, now: datetime | None = None) -> FlagState:
        moment = now or datetime.now(timezone.utc)
        try:
            raw = self.path.read_bytes()
        except OSError as exc:
            return _disabled(f"flag store is unreadable: {exc}")
        try:
            document = loads_strict(raw)
        except EvidenceError as exc:
            return _disabled(f"flag store is not an unambiguous document: {exc}")
        flags = document.get("flags")
        if not isinstance(flags, dict):
            return _disabled("flag store has no 'flags' object")
        unknown = sorted(set(flags) - set(FLAG_TYPES))
        if unknown:
            return _disabled(f"flag store carries unknown flag(s): {unknown}")
        missing = sorted(set(FLAG_TYPES) - set(flags))
        if missing:
            return _disabled(f"flag store is missing flag(s): {missing}")
        for name, (expected, allowed) in FLAG_TYPES.items():
            value = flags[name]
            if expected is bool and not isinstance(value, bool):
                return _disabled(f"{name} must be a boolean, not {type(value).__name__}; no coercion is performed")
            if expected is str and (not isinstance(value, str) or (allowed and value not in allowed)):
                return _disabled(f"{name} must be one of {allowed}")
        revision = document.get("revision")
        if not isinstance(revision, int) or isinstance(revision, bool) or revision < 0:
            return _disabled("flag store revision must be a non-negative integer")
        updated_at = document.get("updated_at")
        if not isinstance(updated_at, str) or not updated_at:
            return _disabled("flag store has no updated_at timestamp")
        try:
            stamped = datetime.fromisoformat(updated_at.replace("Z", "+00:00"))
        except ValueError:
            return _disabled("flag store updated_at is not a timestamp")
        if stamped.tzinfo is None:
            stamped = stamped.replace(tzinfo=timezone.utc)
        if moment - stamped > self.max_age:
            return _disabled(f"flag store is {moment - stamped} old (bound {self.max_age})")
        if stamped > moment + timedelta(minutes=5):
            return _disabled("flag store is stamped in the future")
        return FlagState(flags=dict(flags), revision=revision, updated_at=updated_at, ok=True, reason="current and well-formed")

    @property
    def enabled(self) -> bool:
        return self.state().enabled

    @property
    def ok(self) -> bool:
        return self.state().ok

    @property
    def reason(self) -> str:
        return self.state().reason

    @property
    def model_reasoning(self) -> bool:
        return self.state().model_reasoning

    def set(self, flag: str, value: Any, *, actor: Any, reason: str, expected_revision: int | None = None) -> FlagState:
        record = _actor_record(actor)
        if flag not in FLAG_TYPES:
            raise FlagError(f"unknown flag {flag!r}")
        expected, allowed = FLAG_TYPES[flag]
        if expected is bool and not isinstance(value, bool):
            raise FlagError(f"{flag} must be a boolean")
        if expected is str and (not isinstance(value, str) or (allowed and value not in allowed)):
            raise FlagError(f"{flag} must be one of {allowed}")
        if flag == "as.model_reasoning" and value is True and record["kind"] != "human":
            raise FlagError("enabling model reasoning is a human decision")
        with _exclusive(self._lock_path):
            current = self.state()
            if not current.ok:
                raise FlagError(f"refusing to write to an unusable flag store: {current.reason}")
            if expected_revision is not None and expected_revision != current.revision:
                raise FlagError(f"stale revision: expected {expected_revision}, store is at {current.revision}")
            flags = dict(current.flags)
            flags[flag] = value
            self._write(flags, reason=reason, actor_record=record, revision=current.revision + 1)
        return self.state()

    def emergency_disable(self, *, actor: Any, reason: str) -> FlagState:
        record = _actor_record(actor)
        with _exclusive(self._lock_path):
            current = self.state()
            flags = dict(current.flags if current.ok else DEFAULTS)
            flags.update({"as.enabled": False, "as.mode": "read_only", "as.cohort": "none", "as.model_reasoning": False})
            self._write(flags, reason=f"EMERGENCY DISABLE: {reason}", actor_record=record,
                        revision=(current.revision + 1) if current.ok else 0)
        return self.state()

    def _write(self, flags: Mapping[str, Any], *, reason: str, actor_record: Mapping[str, Any], revision: int) -> None:
        payload = {"flags": dict(flags), "revision": int(revision), "updated_at": fmt_ts(datetime.now(timezone.utc)),
                   "updated_by": dict(actor_record), "reason": reason}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        handle, tmp = tempfile.mkstemp(dir=str(self.path.parent), prefix=".flags-")
        try:
            with os.fdopen(handle, "wb") as fh:
                fh.write(canonical_bytes(payload))
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, self.path)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
        if self.ledger is not None:
            self.ledger.append("rollout.flag_changed", actor=actor_record["subject"], actor_kind=actor_record["kind"],
                               outcome="recorded", subject=reason, detail=payload)


class Quarantine:
    """Isolate a run's delta and connectors without erasing evidence."""

    def __init__(self, root: Path, *, ledger: Any = None) -> None:
        self.root = Path(root)
        self.ledger = ledger
        self._connectors: set[str] = set()

    def disable_connector(self, source_system: str, *, actor: Any, reason: str) -> None:
        _actor_record(actor)
        self._connectors.add(source_system)
        if self.ledger is not None:
            self.ledger.append("incident.connector_disabled", actor=actor.subject, actor_kind=actor.kind,
                               outcome="recorded", subject=source_system, detail={"reason": reason})

    def connector_disabled(self, source_system: str) -> bool:
        return source_system in self._connectors

    def quarantine_run(self, run_id: str, *, actor: Any, reason: str, artifacts: Mapping[str, bytes]) -> Path:
        _actor_record(actor)
        target = self.root / run_id
        target.mkdir(parents=True, exist_ok=True)
        for name, payload in artifacts.items():
            (target / name).write_bytes(payload)
        (target / "QUARANTINE.txt").write_text(f"run {run_id} quarantined: {reason}\n", encoding="utf-8")
        if self.ledger is not None:
            self.ledger.append("incident.run_quarantined", actor=actor.subject, actor_kind=actor.kind, outcome="recorded",
                               subject=run_id, detail={"reason": reason, "artifacts": sorted(artifacts)})
        return target


def drill(*, flags: FlagStore, identity_provider: Any, ledger: Any, operator: Any, run_probe: Any,
          revoke_subject: str, revoke_secret: str) -> dict[str, Any]:
    """AUDIT-ADD-26 incident drill: stop, revoke, preserve, prove."""
    started = time.perf_counter()
    before_len = ledger.length
    flags.emergency_disable(actor=operator, reason="incident drill")
    stop_ms = round((time.perf_counter() - started) * 1000, 3)
    probe = run_probe()                       # must observe the disabled switch on the execution path
    identity_provider.revoke_subject(revoke_subject)
    reauth = False
    try:
        identity_provider.authenticate(revoke_subject, revoke_secret)
        reauth = True
    except Exception:
        reauth = False
    ok, reason = ledger.verify()
    return {"stopped_within_ms": stop_ms, "switch_disabled": not flags.enabled,
            "provider_calls_after_stop": probe.get("provider_calls", 0), "candidates_persisted_after_stop": probe.get("persisted", 0),
            "run_outcome_after_stop": probe.get("outcome"), "revoked_identity_reusable": reauth,
            "evidence_preserved": ok and ledger.length >= before_len, "ledger_status": reason,
            "passed": (not flags.enabled and probe.get("provider_calls", 0) == 0 and probe.get("persisted", 0) == 0
                       and not reauth and ok)}
