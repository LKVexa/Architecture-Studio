"""Retention, deletion and privacy controls reconciled with the append-only audit (STORE-06, XSEC-06, AUDIT-ADD-17).

The policy is by record class, tenant/project, legal need and audit constraint,
and it says for each class which of four fates is allowed: *delete* (the bytes
and the reference go), *tombstone* (the payload goes, the fact that it existed
stays in the ref log), *anonymize* (identifying fields are replaced), or
*retain* (audit-mandatory; deletion is refused and reported). The ledger and
the provenance facts are ``retain`` and nothing in this module can touch them:
:func:`enforce` refuses protected classes explicitly rather than skipping them
silently, and proves the ledger chain is intact after every run.

Deletion proof: a tombstone carries the digest of what was removed, so an
auditor can confirm the payload is gone without the payload.

Build provenance: adapted from the owner's Embedded Quality Gate ``retention.py``
(the "retention must not unlink the evidence tree" lesson) and ``rcg/versionstore``.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable, Mapping

from .canonical import fmt_ts, parse_ts
from .store import ObjectStore

__all__ = ["RETENTION_POLICY", "RetentionError", "enforce", "policy_for", "POLICY_VERSION", "anonymize"]

POLICY_VERSION = "1.0.0"

#: record class -> (fate, retention_days or None for indefinite, audit_mandatory)
RETENTION_POLICY: dict[str, dict[str, Any]] = {
    "design-state":   {"fate": "tombstone", "days": 365, "audit_mandatory": False},
    "option-events":  {"fate": "retain", "days": None, "audit_mandatory": True},
    "candidates":     {"fate": "tombstone", "days": 365, "audit_mandatory": False},
    "context":        {"fate": "delete", "days": 30, "audit_mandatory": False},
    "model-io":       {"fate": "delete", "days": 30, "audit_mandatory": False},
    "review":         {"fate": "retain", "days": None, "audit_mandatory": True},
    "approvals":      {"fate": "retain", "days": None, "audit_mandatory": True},
    "ledger":         {"fate": "retain", "days": None, "audit_mandatory": True},
    "provenance":     {"fate": "retain", "days": None, "audit_mandatory": True},
    "telemetry":      {"fate": "anonymize", "days": 90, "audit_mandatory": False},
    "case-file":      {"fate": "retain", "days": None, "audit_mandatory": True},
}

PROTECTED_CLASSES = frozenset(k for k, v in RETENTION_POLICY.items() if v["audit_mandatory"])


class RetentionError(RuntimeError):
    pass


def policy_for(record_class: str) -> dict[str, Any]:
    try:
        return dict(RETENTION_POLICY[record_class])
    except KeyError:
        raise RetentionError(f"no retention policy for record class {record_class!r}; refusing to guess") from None


def _class_of(ref: str) -> str:
    parts = ref.split("/")
    return parts[-1] if len(parts) >= 3 else parts[0]


def anonymize(payload: Mapping[str, Any]) -> dict[str, Any]:
    out = dict(payload)
    for key in ("actor", "subject", "approver", "principal", "updated_by"):
        if key in out:
            out[key] = "anonymized"
    return out


def enforce(store: ObjectStore, *, ledger: Any, now: datetime | None = None, actor: Any = None,
            dry_run: bool = False) -> dict[str, Any]:
    """Apply the policy to every ref; refuse protected classes; prove the ledger after."""
    if actor is None or getattr(actor, "kind", None) not in ("human", "service"):
        raise RetentionError("retention enforcement requires an authenticated principal")
    moment = now or datetime.now(timezone.utc)
    report: dict[str, Any] = {"policy_version": POLICY_VERSION, "actions": [], "refused": [], "dry_run": dry_run}
    for ref in store.refs_list():
        record_class = _class_of(ref)
        try:
            policy = policy_for(record_class)
        except RetentionError as exc:
            report["refused"].append({"ref": ref, "reason": str(exc)})
            continue
        head = store.head(ref)
        if head is None or head.lifecycle == "tombstoned":
            continue
        if policy["fate"] == "retain":
            if policy["audit_mandatory"]:
                report["refused"].append({"ref": ref, "reason": f"{record_class} is audit-mandatory; retention never deletes it"})
            continue
        age_days = (moment - parse_ts(head.created_at)).days
        if policy["days"] is not None and age_days < policy["days"]:
            continue
        action = {"ref": ref, "record_class": record_class, "fate": policy["fate"], "age_days": age_days,
                  "original_payload_digest": head.payload_digest}
        if not dry_run:
            if policy["fate"] in ("delete", "tombstone"):
                store.tombstone(ref, reason=f"retention:{policy['fate']}", erase_payload=True)
            elif policy["fate"] == "anonymize":
                payload = store.get_object(head.payload_digest)
                store.commit(ref, anonymize(payload) if isinstance(payload, dict) else payload,
                             expected_parent=head.snapshot_id, metadata={"anonymized": True})
        report["actions"].append(action)
    ok, reason = ledger.verify() if ledger is not None else (True, "no ledger")
    report["ledger_intact_after"] = ok
    report["ledger_status"] = reason
    if ledger is not None and not dry_run:
        ledger.append("retention.enforced", actor=actor.subject, actor_kind=actor.kind, outcome="recorded",
                      subject="store", detail={"actions": report["actions"], "refused": report["refused"]})
    return report
