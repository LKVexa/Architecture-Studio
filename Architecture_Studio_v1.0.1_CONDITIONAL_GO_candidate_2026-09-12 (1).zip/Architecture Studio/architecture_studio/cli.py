"""Command-line entry point (``python -m architecture_studio``).

Read-only by default. The only subcommand that writes outside the working
directory is ``run --export``, and that path goes through the write gate under
a human approval like every other write.

    architecture-studio registry            # requirement registry + acceptance table
    architecture-studio controls            # enforceable controls and stop conditions
    architecture-studio index --classes ... # what the connectors see, with denials
    architecture-studio run --goal "..."    # a full workflow run, stopping at review
    architecture-studio verify <run-dir>    # re-verify a run's ledger and case file
    architecture-studio benchmark           # the offline benchmark report
    architecture-studio gates               # gate evaluation and the production verdict
    architecture-studio conditional-go      # bounded local/test-tenant candidate qualification
    architecture-studio docs --out DIR      # regenerate documentation
    architecture-studio environments        # environment descriptors and smoke tests
    architecture-studio asfw                # 545-item ASFW register (never self-GO)
    architecture-studio asgo                # 150-item ASGO register (never self-GO)
    architecture-studio preflight           # overlay-only corpus contract; fail-closed
    architecture-studio status              # one honest summary of what is and is not in force
"""
from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path
from typing import Any

from . import PACKAGE_VERSION_APPLIED, __version__, version_manifest


def _print(payload: Any) -> None:
    print(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True, default=str))


def _registry(args: argparse.Namespace) -> int:
    from .acceptance import acceptance_map
    from .registry import build_registry, registry_document
    requirements = build_registry()
    _print(registry_document(requirements, acceptance=acceptance_map(requirements)) if args.full else
           {"requirements": len(requirements),
            "by_origin": {origin: sum(1 for r in requirements if r.id_origin == origin)
                          for origin in sorted({r.id_origin for r in requirements})},
            "by_phase": {phase: sum(1 for r in requirements if r.phase == phase)
                         for phase in sorted({r.phase for r in requirements})}})
    return 0


def _controls(_: argparse.Namespace) -> int:
    from .policy import controls_document
    _print(controls_document())
    return 0


def _index(args: argparse.Namespace) -> int:
    from .fixtures import make_index, make_scope
    classes = tuple(args.classes) if args.classes else None
    scope = make_scope(args.run_id, classes=classes) if classes else make_scope(args.run_id)
    index, connectors, _ = make_index(scope)
    _print({"scope_digest": scope.scope_digest, "summary": index.summary(),
            "quarantined": [q.as_document() if hasattr(q, "as_document") else str(q) for q in index.quarantine[:10]]})
    return 0


def _run(args: argparse.Namespace) -> int:
    from .authority import IdentityProvider
    from .fixtures import scope_document
    from .pipeline import Run, RunAborted
    workdir = Path(args.workdir or tempfile.mkdtemp(prefix="as-run-"))
    idp = IdentityProvider()
    idp.enroll(args.subject, "human", args.secret)
    document = scope_document(args.run_id, subject=args.subject,
                              classes=tuple(args.classes) if args.classes else None or ("requirement", "api_operation",
                                                                                        "service", "security_constraint",
                                                                                        "deployment_standard"))
    run = Run(run_id=args.run_id, workdir=workdir, identity=idp, subject=args.subject, secret=args.secret,
              scope_document=document)
    try:
        run.authenticate()
        run.pin()
        run.collect_and_index()
        run.analyze()
        run.generate(goals=[{"text": goal, "derivation": "human"} for goal in args.goal])
        run.verify()
        run.present()
    except RunAborted as exc:
        _print({"outcome": "aborted", "stage": exc.stage, "reason": exc.reason, "state": exc.terminal,
                "summary": run.summary(), "workdir": str(workdir)})
        return 1
    _print({"outcome": "awaiting_human_review", "summary": run.summary(), "workdir": str(workdir),
            "next_step": "a human reviewer must approve or reject; the CLI cannot approve on their behalf"})
    return 0


def _verify(args: argparse.Namespace) -> int:
    from .casefile import inspect_case_file
    result = inspect_case_file(Path(args.case_file))
    _print(result)
    return 0 if result["ok"] else 1


def _benchmark(args: argparse.Namespace) -> int:
    from .benchmark import compare_reports, load_baseline, run_benchmark
    report = run_benchmark()
    comparison = compare_reports(report, load_baseline())
    if args.out:
        Path(args.out).write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    _print({"suite_passed": report["suite_passed"], "failed_cases": report["failed_cases"],
            "by_dimension": report["by_dimension"], "failure_modes": report["failure_modes"],
            "measurements": report["measurements"], "thresholds_status": report["thresholds_status"],
            "targets_verdict": report["targets"]["verdict"], "regression": comparison,
            "report_digest": report["report_digest"]})
    return 0 if report["suite_passed"] else 1


def _gates(args: argparse.Namespace) -> int:
    from .gate_evidence import evaluate_production
    tests_override = None
    if args.skip_tests:
        tests_override = {"all_passed": False, "passed": 0, "total": 0, "skipped": True,
                          "note": "--skip-tests: the suite was not collected in this invocation"}
    payload = evaluate_production(run_benchmark=not args.skip_slow, run_operational=not args.skip_slow,
                                  tests=tests_override)
    report = payload["gates"]
    verdict = payload["production_verdict"]
    output = {"gates": [{k: g[k] for k in ("gate_id", "status", "mechanical", "mechanical_detail", "review")} for g in report["gates"]],
              "counts": report["counts"], "write_authority_scan": payload["write_authority_scan"],
              "evidence_keys": payload["evidence_keys"], "evidence_digest": payload["evidence_digest"],
              "boundary": payload["boundary"], **verdict}
    if args.out:
        from .canonical import canonical_bytes
        from .evidence_io import atomic_write
        atomic_write(Path(args.out), canonical_bytes(output))
    _print(output)
    return 0


def _conditional_go(args: argparse.Namespace) -> int:
    from .canonical import canonical_bytes
    from .corpus import preflight
    from .evidence_io import atomic_write
    from .gate_evidence import evaluate_production
    from .release import build_manifest, conditional_qualify
    from .fixtures import OVERLAY_ROOT

    payload = evaluate_production(run_benchmark=not args.skip_slow, run_operational=not args.skip_slow)
    flight = preflight()
    corpus_digest = f"sha256:{flight['digest']}" if flight.get("digest") else None
    if not flight.get("ok") or not corpus_digest:
        result = {"verdict": "NOT_CONDITIONALLY_QUALIFIED", "hard_blockers": [
            f"corpus preflight failed: {flight.get('detail', 'unknown preflight failure')}"],
                  "production_verdict": "NO_GO", "promotion_authorized": False}
    else:
        manifest = build_manifest(overlay_root=OVERLAY_ROOT, corpus_digest=corpus_digest,
                                  reports={"gate_evidence": payload["evidence_digest"],
                                           "tests": payload["evidence"].get("tests", {}).get("report_digest", "not-digested"),
                                           "benchmark": payload["evidence"].get("benchmark", {}).get("report_digest", "not-digested")},
                                  environment=args.target_environment)
        result = conditional_qualify(manifest=manifest, evidence=payload["evidence"],
                                     gate_report=payload["gates"], target_environment=args.target_environment,
                                     validity_hours=args.validity_hours)
        result["corpus_digest"] = corpus_digest
        result["gate_counts"] = payload["gates"]["counts"]
        result["write_authority_scan"] = payload["write_authority_scan"]

    out = Path(args.out) if args.out else OVERLAY_ROOT / "evidence" / "reports" / "conditional_go.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(out, canonical_bytes(result))
    markdown = out.with_suffix(".md")
    lines = ["# Architecture Studio Conditional GO", "", f"- verdict: `{result.get('verdict')}`",
             f"- production verdict: `{result.get('production_verdict', 'NO_GO')}`",
             f"- target environment: `{result.get('target_environment', args.target_environment)}`",
             f"- issued at: `{result.get('issued_at', 'not issued')}`",
             f"- expires at: `{result.get('expires_at', 'not issued')}`", "",
             "This is a time-bounded local/test-tenant evaluation recommendation. It is not production authorization, independent verification, threshold approval, or promotion.", ""]
    if result.get("hard_blockers"):
        lines.extend(["## Hard blockers", "", *[f"- {item}" for item in result["hard_blockers"]], ""])
    lines.extend(["## Conditions", ""])
    for condition in result.get("conditions", []):
        label = condition.get("control", condition.get("id", "condition"))
        status = condition.get("status", "CONDITION")
        detail = condition.get("requirement") or condition.get("evidence") or "recorded"
        lines.append(f"- `{condition.get('id', 'CG')}` `{status}` — **{label}**: {detail}")
    atomic_write(markdown, ("\n".join(lines) + "\n").encode("utf-8"))
    _print({k: v for k, v in result.items() if k != "manifest"} | {"report": str(out), "report_markdown": str(markdown)})
    return 0 if result.get("verdict") == "CONDITIONAL_GO" else 1


def _docs(args: argparse.Namespace) -> int:
    from .docs import freshness_report, render_all
    from .fixtures import OVERLAY_ROOT
    out = Path(args.out or (OVERLAY_ROOT / "docs"))
    if args.check:
        report = freshness_report(out)
        _print(report)
        return 0 if report["all_current"] else 1
    _print(render_all(out))
    return 0


def _environments(args: argparse.Namespace) -> int:
    from .environments import ENVIRONMENTS, boundary_report, smoke_test, write_descriptors
    from .fixtures import OVERLAY_ROOT, make_scope
    if args.write:
        write_descriptors(OVERLAY_ROOT / "environments")
    scope = make_scope("RUN-cli")
    _print({"boundaries": boundary_report(),
            "smoke_tests": {e.environment_id: smoke_test(e.environment_id, scope) for e in ENVIRONMENTS}})
    return 0


def _status(_: argparse.Namespace) -> int:
    from .authority import IdentityBinding
    from .crypto import NullKeyProvider, status as crypto_status
    from .docs import KNOWN_LIMITATIONS
    from .environments import boundary_report
    from .gate_evidence import evaluate_production
    from .generator import ProviderSlot
    from .sandbox import SandboxPolicy
    from .slo import TARGETS
    from .supply_chain import inventory, policy_check
    from .uncertainty import Thresholds
    from .asfw import register_summary
    from .asgo import register_summary as asgo_summary
    from .roster import RECEIVED_CHAT_OFFER, offer_principal, roster_document
    # Status is a summary. Mechanical gate evaluation still runs operational
    # evidence (scan, drill, recovery, verification, docs, controls). Tests are
    # loaded from the last suite report if present so `status` stays a snapshot.
    from .fixtures import OVERLAY_ROOT
    last = OVERLAY_ROOT / "evidence" / "reports" / "run_all.json"
    tests = None
    if last.is_file():
        try:
            tests = json.loads(last.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            tests = None
    payload = evaluate_production(tests=tests, run_benchmark=True, run_operational=True)
    verdict = payload["production_verdict"]
    asfw = register_summary()
    asgo = asgo_summary()
    offer = offer_principal(RECEIVED_CHAT_OFFER)
    roster = roster_document(offer=RECEIVED_CHAT_OFFER)
    _print({
        "runtime": __version__, "package_applied": PACKAGE_VERSION_APPLIED, "versions": version_manifest(),
        "model_provider": ProviderSlot().describe(),
        "identity_provider": IdentityBinding().describe(),
        "encryption": crypto_status(NullKeyProvider()),
        "thresholds_status": Thresholds().status,
        "approved_targets": [t.target_id for t in TARGETS if t.approved],
        "unresolved_environments": boundary_report()["unresolved_applicability"],
        "supply_chain": policy_check(inventory())["verdict"],
        "sandbox_isolation": getattr(SandboxPolicy(), "isolation_class", "process-level"),
        "known_limitations": [f"{limit['id']}: {limit['statement']}" for limit in KNOWN_LIMITATIONS],
        "gates": payload["gates"]["counts"],
        "write_authority_scan": payload["write_authority_scan"],
        "asfw": {k: asfw[k] for k in ("total", "by_status", "verified", "complete", "production_go",
                                      "source_index_csv", "gate_count_resolution", "dod_resolution")
                 if k in asfw},
        "asgo": {k: asgo[k] for k in ("total", "by_status", "verified", "done", "complete",
                                      "production_go", "product_kind", "package_sha256")
                 if k in asgo},
        "roster": {
            "offered": offer["display_name"],
            "title": offer["title"],
            "organization": offer["organization"],
            "status": offer["status"],
            "independence": offer["independence"]["status"],
            "bound_roles": offer["bound_roles"],
            "eligible_roles": offer["eligible_roles"],
            "required_roles_unset": roster["bound_count"] == 0,
        },
        "production_verdict": verdict["verdict"],
        "blocking_gates": verdict["blocking_gates"],
        "boundary": ("This runtime cannot verify its own work. Every task record awaits an independent "
                     "human verifier. Mechanical evidence is assembled; PASS still requires independent review."),
    })
    return 0


def _asfw(args: argparse.Namespace) -> int:
    from .asfw import export_register, production_go_from_asfw, register_document, register_summary
    from .fixtures import OVERLAY_ROOT
    if args.export:
        payload = export_register(Path(args.export))
        _print(payload)
        return 0
    if args.item:
        document = register_document()
        match = next((item for item in document["items"] if item["item_id"] == args.item
                      or item["implementation_id"] == args.item), None)
        if match is None:
            _print({"error": "unknown_item", "item": args.item})
            return 1
        _print(match)
        return 0
    if args.full:
        document = register_document()
        go = production_go_from_asfw(document)
        compact = [
            {k: item[k] for k in ("item_id", "implementation_id", "status", "execution_class",
                                  "category", "source_text")}
            for item in document["items"]
        ]
        _print({"summary": document["summary"], "package_pin": document["package_pin"],
                "gate_count_resolution": document["gate_count_resolution"],
                "dod_resolution": document["dod_resolution"],
                "production_go_from_asfw": go,
                "items": document["items"] if args.include_items else compact})
        return 0
    summary = register_summary()
    if args.write:
        export_register(OVERLAY_ROOT / "asfw")
    _print(summary)
    return 0


def _asgo(args: argparse.Namespace) -> int:
    from .asgo import (export_register, production_go_from_asgo, build_register, register_summary,
                       write_declared_evidence)
    from .fixtures import OVERLAY_ROOT
    if args.export:
        payload = export_register(Path(args.export))
        _print(payload)
        return 0
    if args.item:
        document = build_register()
        match = next((item for item in document["items"] if item["item_id"] == args.item
                      or item["implementation_id"] == args.item), None)
        if match is None:
            _print({"error": "unknown_item", "item": args.item})
            return 1
        _print(match)
        return 0
    if args.full:
        document = build_register()
        go = production_go_from_asgo(document)
        compact = [
            {k: item[k] for k in ("item_id", "implementation_id", "status", "execution_class",
                                  "wave", "source_text", "block_reason")}
            for item in document["items"]
        ]
        _print({"summary": document["summary"], "package_pin": document["package_pin"],
                "product_contract": document["product_contract"],
                "production_go_from_asgo": go,
                "items": document["items"] if args.include_items else compact})
        return 0
    summary = register_summary()
    if args.write:
        export_register(OVERLAY_ROOT / "asgo")
        write_declared_evidence(overlay=OVERLAY_ROOT)
    _print(summary)
    return 0


def _preflight(args: argparse.Namespace) -> int:
    from .corpus import preflight, product_contract
    flight = preflight(Path(args.root) if args.root else None)
    _print({"preflight": flight, "product_contract": product_contract(),
            "production_go": "NO_GO",
            "note": "preflight ok is not Production GO"})
    return 0 if flight["ok"] else 1


def _roster(args: argparse.Namespace) -> int:
    from .roster import (RECEIVED_CHAT_OFFER, RosterError, export_roster, interpret_as_review,
                         offer_principal, record_source_gap_decision, roster_document)
    offer = offer_principal(RECEIVED_CHAT_OFFER)
    dod = record_source_gap_decision("DOD", "KEEP_UNDEFINED_STILL_BLOCKING", offer=RECEIVED_CHAT_OFFER)
    gate = record_source_gap_decision("GATE_COUNT", "DO_NOT_INFER_STILL_BLOCKING", offer=RECEIVED_CHAT_OFFER)
    document = roster_document(offer=RECEIVED_CHAT_OFFER, dod_decision=dod, gate_decision=gate)
    if args.as_review:
        try:
            interpret_as_review(RECEIVED_CHAT_OFFER, gate_id=args.as_review)
        except RosterError as exc:
            _print({"error": "not_a_review", "detail": str(exc), "production_go": "NO_GO",
                    "offer": offer, "roster": document})
            return 1
    if args.write:
        exported = export_roster(document=document)
        _print({"offer": offer, "roster": document, "exported": exported, "production_go": "NO_GO"})
        return 0
    _print({"offer": offer, "roster": document, "production_go": "NO_GO",
            "note": "chat signature recorded as an unbound offer; no role bound; no review applied"})
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="architecture-studio", description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--version", action="version", version=f"architecture_studio {__version__} ({PACKAGE_VERSION_APPLIED})")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("registry", help="requirement registry")
    p.add_argument("--full", action="store_true", help="emit the whole registry document")
    p.set_defaults(func=_registry)

    sub.add_parser("controls", help="enforceable controls and stop conditions").set_defaults(func=_controls)

    p = sub.add_parser("index", help="what the connectors see under a scope")
    p.add_argument("--run-id", default="RUN-cli")
    p.add_argument("--classes", nargs="*")
    p.set_defaults(func=_index)

    p = sub.add_parser("run", help="run the workflow up to human review")
    p.add_argument("--run-id", default="RUN-cli")
    p.add_argument("--goal", action="append", required=True)
    p.add_argument("--subject", default="architect@example.test")
    p.add_argument("--secret", default="architect-secret")
    p.add_argument("--classes", nargs="*")
    p.add_argument("--workdir")
    p.set_defaults(func=_run)

    p = sub.add_parser("verify", help="inspect an exported case file")
    p.add_argument("case_file")
    p.set_defaults(func=_verify)

    p = sub.add_parser("benchmark", help="run the offline benchmark")
    p.add_argument("--out")
    p.set_defaults(func=_benchmark)

    p = sub.add_parser("gates", help="production gate evaluation from assembled mechanical evidence")
    p.add_argument("--out", help="write the gate report to this path")
    p.add_argument("--skip-slow", action="store_true", help="skip benchmark and operational drills")
    p.add_argument("--skip-tests", action="store_true", help="do not run or load the test suite (reported as missing)")
    p.set_defaults(func=_gates)

    p = sub.add_parser("conditional-go", help="bounded local/test-tenant candidate qualification; never production GO")
    p.add_argument("--out", help="write the JSON qualification record to this path")
    p.add_argument("--target-environment", choices=("local", "test_tenant"), default="local")
    p.add_argument("--validity-hours", type=int, default=72)
    p.add_argument("--skip-slow", action="store_true", help="skip benchmark and operational evidence; qualification will fail closed")
    p.set_defaults(func=_conditional_go)

    p = sub.add_parser("docs", help="generate or check documentation")
    p.add_argument("--out")
    p.add_argument("--check", action="store_true")
    p.set_defaults(func=_docs)

    p = sub.add_parser("environments", help="environment descriptors and smoke tests")
    p.add_argument("--write", action="store_true")
    p.set_defaults(func=_environments)

    p = sub.add_parser("asfw", help="545-item ASFW register; never self-attests GO")
    p.add_argument("--full", action="store_true", help="include compact item rows")
    p.add_argument("--include-items", action="store_true", help="include full item records (large)")
    p.add_argument("--item", help="emit one item by ASFW-TODO-NNNN or ASFW-IMPL-NNNN")
    p.add_argument("--export", help="write derived register artifacts to DIR")
    p.add_argument("--write", action="store_true", help="also export derived artifacts under overlay/asfw")
    p.set_defaults(func=_asfw)

    p = sub.add_parser("asgo", help="150-item ASGO register; never self-attests GO")
    p.add_argument("--full", action="store_true", help="include compact item rows")
    p.add_argument("--include-items", action="store_true", help="include full item records (large)")
    p.add_argument("--item", help="emit one item by ASGO-W.N or ASGO-IMPL-WW.NN")
    p.add_argument("--export", help="write derived register artifacts to DIR")
    p.add_argument("--write", action="store_true", help="also export derived artifacts under overlay/asgo")
    p.set_defaults(func=_asgo)

    p = sub.add_parser("preflight", help="overlay-only corpus contract; fail closed if absent/wrong/digest-mismatch")
    p.add_argument("--root", help="corpus root (default: overlay.parent)")
    p.set_defaults(func=_preflight)

    p = sub.add_parser("roster", help="named-principal intake; a chat signature is not a review")
    p.add_argument("--write", action="store_true", help="write proposal and keep-undefined records")
    p.add_argument("--as-review", metavar="GATE-ID",
                   help="attempt to treat the chat signature as a gate review (refused)")
    p.set_defaults(func=_roster)

    sub.add_parser("status", help="what is and is not in force").set_defaults(func=_status)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    sys.exit(main())
