"""Canonical architecture-candidate model (AUDIT-ADD-05, PAPER-CAP-03, MODEL-04).

One versioned candidate schema is consumed by the generator, the comparer, the
constraint checker, the diagrammer, the reviewer and the provenance ledger.
:func:`build_candidate` is the only constructor; it validates against
``as.candidate/1`` and computes the *structure digest* over the candidate's
material structure with names normalized away, which is what the distinctness
verifier compares (AUDIT-ADD-06).

Build provenance: BUILD_NEW.
"""
from __future__ import annotations

import re
from typing import Any, Iterable, Mapping, Sequence

from .canonical import digest_of
from .ids import candidate_id as make_candidate_id
from .schemas import validate

__all__ = ["CANDIDATE_SCHEMA_VERSION", "build_candidate", "structure_signature", "structure_digest",
           "material_elements", "component", "relationship"]

CANDIDATE_SCHEMA_VERSION = "1.0.0"
_WORD = re.compile(r"[a-z0-9]+")


def component(element_id: str, name: str, kind: str, *, responsibilities: Sequence[str] = (),
              evidence_refs: Sequence[str] = (), derivation: str = "source", catalog_ref: str | None = None,
              replicas: int | None = None) -> dict[str, Any]:
    doc: dict[str, Any] = {"element_id": element_id, "name": name, "kind": kind,
                           "responsibilities": list(responsibilities), "evidence_refs": list(evidence_refs),
                           "derivation": derivation, "catalog_ref": catalog_ref}
    if replicas is not None:
        doc["replicas"] = replicas
    return doc


def relationship(element_id: str, source: str, target: str, kind: str, *, evidence_refs: Sequence[str] = (),
                 derivation: str = "source") -> dict[str, Any]:
    return {"element_id": element_id, "source": source, "target": target, "kind": kind,
            "evidence_refs": list(evidence_refs), "derivation": derivation}


def structure_signature(candidate: Mapping[str, Any]) -> dict[str, Any]:
    """Names normalized away: kinds, responsibility tokens, catalog refs, edge shape, deployment."""
    id_to_kind = {c["element_id"]: c["kind"] for c in candidate.get("components", [])}
    components = sorted(
        (c["kind"], tuple(sorted({t for r in c.get("responsibilities", []) for t in _WORD.findall(str(r).lower())})),
         str(c.get("catalog_ref") or "").lower())
        for c in candidate.get("components", []))
    edges = sorted((id_to_kind.get(r["source"], "?"), r["kind"], id_to_kind.get(r["target"], "?"))
                   for r in candidate.get("relationships", []))
    deployment = candidate.get("deployment") or {}
    return {"components": [list(c[:2]) + [c[2]] for c in components], "edges": [list(e) for e in edges],
            "topology": str(deployment.get("topology", "")).lower(),
            "environments": sorted(deployment.get("environments", [])),
            "constraint_impacts": sorted((ci["constraint_id"], ci["result"]) for ci in candidate.get("constraint_impacts", []))}


def structure_digest(candidate: Mapping[str, Any]) -> str:
    return digest_of(structure_signature(candidate))


def material_elements(candidate: Mapping[str, Any]) -> int:
    return len(candidate.get("components", [])) + len(candidate.get("relationships", [])) + (1 if candidate.get("deployment") else 0)


def build_candidate(*, run_id: str, iteration: int, name: str, style: str, components: Sequence[Mapping[str, Any]],
                    relationships: Sequence[Mapping[str, Any]], deployment: Mapping[str, Any],
                    rationale: Sequence[Mapping[str, Any]], evidence_refs: Iterable[str],
                    uncertainty: Mapping[str, Any], generator: Mapping[str, Any], introduced_by: str,
                    dependencies: Sequence[str] = (), assumptions: Sequence[str] = (),
                    risks: Sequence[Mapping[str, Any]] = (), constraint_impacts: Sequence[Mapping[str, Any]] = (),
                    parent_candidate_id: str | None = None, diagram_mapping: Mapping[str, Any] | None = None
                    ) -> dict[str, Any]:
    draft = {"components": [dict(c) for c in components], "relationships": [dict(r) for r in relationships],
             "deployment": dict(deployment), "constraint_impacts": [dict(ci) for ci in constraint_impacts]}
    digest = structure_digest(draft)
    cid = make_candidate_id(run=run_id, iteration=iteration, structure_digest=digest)
    doc = {
        "schema_id": "as.candidate/1", "candidate_id": cid, "run_id": run_id, "iteration": iteration, "name": name,
        "style": style, "components": draft["components"], "relationships": draft["relationships"],
        "deployment": draft["deployment"], "dependencies": list(dependencies), "assumptions": list(assumptions),
        "rationale": [dict(r) for r in rationale], "risks": [dict(r) for r in risks],
        "evidence_refs": sorted(set(evidence_refs)), "constraint_impacts": draft["constraint_impacts"],
        "uncertainty": dict(uncertainty), "diagram_mapping": dict(diagram_mapping or {}),
        "lifecycle": {"state": "introduced", "introduced_by": introduced_by, "parent_candidate_id": parent_candidate_id,
                      "event_ids": []},
        "structure_digest": digest, "generator": dict(generator), "candidate_schema_version": CANDIDATE_SCHEMA_VERSION,
    }
    ids = [c["element_id"] for c in doc["components"]]
    if len(ids) != len(set(ids)):
        raise ValueError("duplicate component element ids")
    for rel in doc["relationships"]:
        if rel["source"] not in ids or rel["target"] not in ids:
            raise ValueError(f"relationship {rel['element_id']} references an unknown component")
    return validate("as.candidate/1", doc)
