"""Interactive steering surface and accessibility criteria (COMP-07, AUDIT-ADD-22, HUMAN-03, PAPER-GRD-04).

The steering surface is an API: every operation a reviewer can take —
inspect, compare, ask, edit goals or constraints, add evidence, narrow scope,
request more evidence, modify or discard an option, rerun — is a method on
:class:`SteeringSession` that produces a *new design-state version* through the
CAS store and records an option event. Nothing here triggers an external side
effect; the only writes are design-state versions and ledger events.

A static review page is rendered from the same data so a human can read it
without the runtime. Accessibility criteria (AUDIT-ADD-22) are declared as data
and checked mechanically on the rendered page: landmarks, headings, labelled
status text, keyboard-reachable controls, no colour-only status, and a
cognitive-load budget (statements a reviewer must check per screen). Human
usability tests are not something this module can run; the criteria table says
which checks are mechanical and which need people.

Build provenance: BUILD_NEW; the rule families follow accessibility-insights-web
(MIT, Microsoft) as a PATTERN ONLY — no code copied.
"""
from __future__ import annotations

import html
import re
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping, Sequence

from .canonical import fmt_ts
from .design_state import DesignStateStore, STEERING_OPERATIONS
from .scope import ScopeContract

__all__ = ["ACCESSIBILITY_CRITERIA", "SteeringSession", "render_review_page", "check_accessibility"]

#: AUDIT-ADD-22: criteria, with the check kind honest about what a machine can verify.
ACCESSIBILITY_CRITERIA: tuple[dict[str, str], ...] = (
    {"criterion_id": "A11Y-01", "requirement": "keyboard navigation", "check": "mechanical",
     "rule": "every control is a native button or link (keyboard reachable); no click handlers on divs"},
    {"criterion_id": "A11Y-02", "requirement": "screen-reader semantics", "check": "mechanical",
     "rule": "page has main/nav landmarks, one h1, headings in order, every control has an accessible name"},
    {"criterion_id": "A11Y-03", "requirement": "contrast/status communication", "check": "mechanical",
     "rule": "status is conveyed by text, never by colour alone; body text uses the high-contrast palette"},
    {"criterion_id": "A11Y-04", "requirement": "evidence inspection usability", "check": "mechanical",
     "rule": "every material statement links to its evidence reference and the evidence is reachable in one step"},
    {"criterion_id": "A11Y-05", "requirement": "review cognitive load", "check": "mechanical",
     "rule": "statements to check per screen are counted and reported; sections collapse by default beyond the budget"},
    {"criterion_id": "A11Y-06", "requirement": "representative reviewer usability", "check": "human",
     "rule": "a usability session with representative reviewers records task completion and time; not machine-checkable"},
)

_PALETTE = {"text": "#1f2328", "background": "#ffffff", "muted": "#57606a", "border": "#d0d7de"}


class SteeringSession:
    """The steerable session around one run's design state."""

    def __init__(self, store: DesignStateStore, *, scope: ScopeContract, ledger: Any = None) -> None:
        self.store = store
        self.scope = scope
        self.ledger = ledger
        self.session_ref = f"session:{store.run_id}"

    @property
    def operations(self) -> tuple[str, ...]:
        return STEERING_OPERATIONS

    def inspect(self) -> dict[str, Any]:
        state = self.store.load()
        return {"state": state.as_document(), "active_candidates": state.active_candidates(),
                "events": self.store.events(), "history": self.store.history()}

    def compare(self, comparison: Mapping[str, Any]) -> dict[str, Any]:
        return {"comparison_id": comparison["comparison_id"], "differences": comparison["differences"],
                "missing_criteria": comparison["missing_criteria"], "unresolved": comparison["unresolved"]}

    def ask(self, questions: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
        return {"open": [q for q in questions if q["status"] == "open"],
                "material_open": [q["question_id"] for q in questions if q["materiality"] == "material" and q["status"] == "open"]}

    def _human(self, principal: Any) -> None:
        if getattr(principal, "kind", None) != "human":
            raise PermissionError("steering operations that change design state require a human principal")

    def edit_goals(self, *, principal: Any, goals: Sequence[Mapping[str, Any]], rationale: str) -> dict[str, Any]:
        self._human(principal)
        state = self.store.apply("edit_goals", actor=principal.subject, actor_kind="human",
                                 expected_version=self.store.load().version, rationale=rationale, goals=goals)
        return state.as_document()

    def edit_constraints(self, *, principal: Any, constraints: Sequence[Mapping[str, Any]], rationale: str) -> dict[str, Any]:
        self._human(principal)
        state = self.store.apply("edit_constraints", actor=principal.subject, actor_kind="human",
                                 expected_version=self.store.load().version, rationale=rationale, constraints=constraints)
        return state.as_document()

    def add_evidence(self, *, principal: Any, goal_ids: Sequence[str], evidence_refs: Sequence[str], rationale: str) -> dict[str, Any]:
        self._human(principal)
        state = self.store.apply("add_evidence", actor=principal.subject, actor_kind="human",
                                 expected_version=self.store.load().version, rationale=rationale,
                                 evidence_refs=evidence_refs, goal_ids=goal_ids)
        return state.as_document()

    def narrow_scope(self, *, principal: Any, narrowed: ScopeContract, rationale: str) -> dict[str, Any]:
        """HUMAN-03: a new scoped iteration; widening is refused by ScopeContract.narrowed upstream."""
        self._human(principal)
        if narrowed.permissions - self.scope.permissions or narrowed.source_set - self.scope.source_set:
            raise PermissionError("narrowing cannot widen the contract")
        state = self.store.apply("narrow_scope", actor=principal.subject, actor_kind="human",
                                 expected_version=self.store.load().version, rationale=rationale,
                                 scope_digest=narrowed.scope_digest)
        self.scope = narrowed
        return state.as_document()

    def modify_option(self, *, principal: Any, candidate_id: str, replacement_candidate_id: str | None, rationale: str,
                      evidence_refs: Sequence[str] = ()) -> dict[str, Any]:
        self._human(principal)
        state = self.store.apply("modify_option", actor=principal.subject, actor_kind="human",
                                 expected_version=self.store.load().version, rationale=rationale,
                                 evidence_refs=evidence_refs, candidate_id=candidate_id,
                                 replacement_candidate_id=replacement_candidate_id)
        return state.as_document()

    def discard_option(self, *, principal: Any, candidate_id: str, rationale: str, evidence_refs: Sequence[str] = ()) -> dict[str, Any]:
        self._human(principal)
        state = self.store.apply("discard_option", actor=principal.subject, actor_kind="human",
                                 expected_version=self.store.load().version, rationale=rationale,
                                 evidence_refs=evidence_refs, candidate_id=candidate_id)
        return state.as_document()

    def reinstate_option(self, *, principal: Any, candidate_id: str, rationale: str) -> dict[str, Any]:
        self._human(principal)
        state = self.store.apply("reinstate_option", actor=principal.subject, actor_kind="human",
                                 expected_version=self.store.load().version, rationale=rationale, candidate_id=candidate_id)
        return state.as_document()

    def rerun(self, *, principal: Any, rationale: str) -> dict[str, Any]:
        self._human(principal)
        state = self.store.apply("rerun", actor=principal.subject, actor_kind="human",
                                 expected_version=self.store.load().version, rationale=rationale)
        return state.as_document()


# --------------------------------------------------------------------------- #
# Static review page                                                            #
# --------------------------------------------------------------------------- #
def render_review_page(*, package: Mapping[str, Any], candidates: Sequence[Mapping[str, Any]],
                       comparison: Mapping[str, Any] | None, questions: Sequence[Mapping[str, Any]],
                       evidence: Mapping[str, Mapping[str, Any]], statement_budget: int = 25) -> str:
    def esc(value: Any) -> str:
        return html.escape(str(value))
    statements = list(package.get("statements", []))
    lines = [
        "<!doctype html>", "<html lang=\"en\">", "<head><meta charset=\"utf-8\">",
        f"<title>Architecture Studio review — run {esc(package['run_id'])}</title>",
        f"<style>body{{color:{_PALETTE['text']};background:{_PALETTE['background']};font:16px/1.5 system-ui}} "
        f"details{{border:1px solid {_PALETTE['border']};padding:.5rem;margin:.5rem 0}} "
        f".status{{font-weight:600}} table{{border-collapse:collapse}} td,th{{border:1px solid {_PALETTE['border']};padding:.25rem .5rem}}</style>",
        "</head><body>",
        "<nav aria-label=\"Review sections\"><ul>",
        "<li><a href=\"#analyzed\">What was analyzed</a></li><li><a href=\"#statements\">Statements</a></li>",
        "<li><a href=\"#candidates\">Candidates</a></li><li><a href=\"#comparison\">Comparison</a></li>",
        "<li><a href=\"#questions\">Open questions</a></li><li><a href=\"#decision\">Decision</a></li></ul></nav>",
        "<main>",
        f"<h1>Review package for run {esc(package['run_id'])}</h1>",
        f"<p class=\"status\">Status: {esc(package.get('status', 'awaiting human review'))} "
        f"(text, not colour). Subject digest {esc(package.get('subject_digest', ''))}.</p>",
        "<h2 id=\"analyzed\">What was analyzed, and what was not</h2>",
        "<table><caption>Analyzed</caption><tbody>",
    ]
    for key, value in sorted(package.get("analyzed", {}).items()):
        lines.append(f"<tr><th scope=\"row\">{esc(key)}</th><td>{esc(value)}</td></tr>")
    lines.append("</tbody></table><table><caption>Not analyzed</caption><tbody>")
    for key, value in sorted(package.get("not_analyzed", {}).items()):
        lines.append(f"<tr><th scope=\"row\">{esc(key)}</th><td>{esc(value)}</td></tr>")
    lines.append("</tbody></table>")
    lines.append(f"<h2 id=\"statements\">Statements to check ({len(statements)}; budget {statement_budget} per screen)</h2>")
    open_attr = " open" if len(statements) <= statement_budget else ""
    lines.append(f"<details{open_attr}><summary>Show {len(statements)} statement(s)</summary><ol>")
    for statement in statements:
        refs = statement.get("evidence_refs", [])
        link = " ".join(f"<a href=\"#ev-{esc(r)}\">{esc(r[:14])}</a>" for r in refs) or "<span>UNCITED (text label)</span>"
        lines.append(f"<li>[{esc(statement.get('derivation'))}] {esc(statement.get('text'))} — evidence: {link}</li>")
    lines.append("</ol></details>")
    lines.append("<h2 id=\"candidates\">Candidates</h2>")
    for candidate in candidates:
        lines.append(f"<details open><summary>{esc(candidate['name'])} — uncertainty state: "
                     f"{esc(candidate['uncertainty']['state'])}</summary><ul>")
        for component_ in candidate["components"]:
            refs = " ".join(f"<a href=\"#ev-{esc(r)}\">{esc(r[:14])}</a>" for r in component_.get("evidence_refs", []))
            lines.append(f"<li>{esc(component_['name'])} ({esc(component_['kind'])}, {esc(component_['derivation'])}) — evidence: {refs or 'none'}</li>")
        lines.append("</ul></details>")
    lines.append("<h2 id=\"comparison\">Comparison</h2>")
    if comparison:
        lines.append("<table><thead><tr><th scope=\"col\">Dimension</th><th scope=\"col\">Difference</th></tr></thead><tbody>")
        for diff in comparison["differences"]:
            lines.append(f"<tr><td>{esc(diff['dimension'])}</td><td>{esc(diff['statement'])}</td></tr>")
        lines.append("</tbody></table>")
        if comparison["missing_criteria"]:
            lines.append(f"<p class=\"status\">Missing criteria (unknown, not scored): {esc(', '.join(comparison['missing_criteria']))}</p>")
    else:
        lines.append("<p>No comparison was built.</p>")
    lines.append("<h2 id=\"questions\">Open questions</h2><ul>")
    for question in questions:
        lines.append(f"<li>[{esc(question['materiality'])}, priority {esc(question['priority'])}] {esc(question['question'])}</li>")
    lines.append("</ul>")
    lines.append("<h2 id=\"evidence\">Evidence</h2><dl>")
    for ref_id, ref in sorted(evidence.items()):
        lines.append(f"<dt id=\"ev-{esc(ref_id)}\">{esc(ref_id)}</dt><dd>{esc(ref.get('source_system'))}: "
                     f"{esc(ref.get('location'))} {esc(ref.get('span') or '')} @ {esc(ref.get('revision', '')[:19])} "
                     f"({esc(ref.get('evidence_status'))})</dd>")
    lines.append("</dl>")
    lines.append("<h2 id=\"decision\">Decision</h2>")
    lines.append("<form method=\"post\" action=\"#\" aria-describedby=\"accountability\">")
    for action in ("approve", "reject", "edit", "narrow_scope", "request_more_evidence"):
        lines.append(f"<button type=\"submit\" name=\"decision\" value=\"{action}\">{esc(action.replace('_', ' '))}</button>")
    lines.append("</form>")
    lines.append(f"<p id=\"accountability\">{esc(package.get('accountability', ''))}</p>")
    lines.append(f"<p>Rendered {esc(fmt_ts(datetime.now(timezone.utc)))}.</p>")
    lines.append("</main></body></html>")
    return "\n".join(lines)


def check_accessibility(page: str, *, statement_budget: int = 25) -> dict[str, Any]:
    """Mechanical checks for A11Y-01..05; A11Y-06 is reported as needing people."""
    results: dict[str, dict[str, Any]] = {}
    results["A11Y-01"] = {"pass": "onclick" not in page.lower() and "<button" in page and "<div role=\"button\"" not in page,
                          "detail": "controls are native buttons/links"}
    h1 = len(re.findall(r"<h1[ >]", page))
    headings = [int(m) for m in re.findall(r"<h([1-6])[ >]", page)]
    ordered = all(b - a <= 1 for a, b in zip(headings, headings[1:]))
    named_controls = all(re.search(r">\s*\S", m) for m in re.findall(r"<button[^>]*>[^<]*", page))
    results["A11Y-02"] = {"pass": "<main" in page and "<nav" in page and h1 == 1 and ordered and named_controls,
                          "detail": f"landmarks present, h1={h1}, headings ordered={ordered}"}
    results["A11Y-03"] = {"pass": "class=\"status\"" in page and "Status:" in page and _PALETTE["text"] in page,
                          "detail": "status conveyed as text with the high-contrast palette"}
    uncited = page.count("UNCITED")
    links = page.count("href=\"#ev-")
    results["A11Y-04"] = {"pass": links > 0, "detail": f"{links} evidence link(s), {uncited} uncited statement(s) labelled"}
    m = re.search(r"Statements to check \((\d+); budget (\d+)", page)
    count, budget = (int(m.group(1)), int(m.group(2))) if m else (0, statement_budget)
    collapsed = "<details><summary>Show" in page or count <= budget
    results["A11Y-05"] = {"pass": bool(m) and collapsed, "detail": f"{count} statements against a budget of {budget}; collapsed beyond budget={collapsed}"}
    results["A11Y-06"] = {"pass": None, "detail": "requires a usability session with representative reviewers; not machine-checkable"}
    mechanical = [c["criterion_id"] for c in ACCESSIBILITY_CRITERIA if c["check"] == "mechanical"]
    return {"criteria": list(ACCESSIBILITY_CRITERIA), "results": results,
            "mechanical_pass": all(results[c]["pass"] for c in mechanical),
            "human_checks_pending": [c["criterion_id"] for c in ACCESSIBILITY_CRITERIA if c["check"] == "human"]}
