"""Shared, deterministic test/benchmark fixtures.

Everything here builds from the checked-in corpus and fixtures with no network
and no model provider. It exists so tests, the golden-path pipeline scenarios,
the benchmark harness and the evidence builder all start from the *same*
authorised scope and the same normalized index rather than re-inventing them.
Nothing in this module writes outside the directory it is given.

Scope contracts are issued *now* (UTC) with a bounded lifetime. A hardcoded
issue date is a time bomb: after the default window elapses every fixture
fails closed as expired, which is correct policy and a disastrous default for
tests. Callers that need a frozen clock pass ``issued_at`` explicitly.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

from .authority import IdentityProvider, Principal
from .connectors.base import PinnedSourceSet, pin_source_set
from .connectors.normalize import NormalizedIndex, Normalizer
from .connectors.typed import REGISTRY, connector_for_class
from .ledger import Ledger
from .scope import ScopeContract

__all__ = ["OVERLAY_ROOT", "CORPUS_ROOT", "FIXTURES_ROOT", "scope_document", "make_scope", "make_operator",
           "make_index", "ALL_CLASSES", "DEFAULT_CLASSES", "DEFAULT_SCOPE_HOURS", "portable_overlay_path"]

OVERLAY_ROOT = Path(__file__).resolve().parent.parent
CORPUS_ROOT = OVERLAY_ROOT.parent
FIXTURES_ROOT = OVERLAY_ROOT / "fixtures"
ALL_CLASSES = tuple(REGISTRY)
DEFAULT_CLASSES = ("requirement", "api_operation", "service", "security_constraint", "deployment_standard")
DEFAULT_SCOPE_HOURS = 24
_SOURCE_FOR_CLASS = {"requirement": "requirements", "nfr": "nfrs", "adr": "adrs", "api_operation": "api_catalog",
                     "service": "infra_catalog", "diagram": "diagrams", "security_constraint": "security_constraints",
                     "cost_perf_constraint": "cost_performance", "deployment_standard": "deployment_standards"}


def portable_overlay_path(path: Path | str) -> str:
    """ASGO-0.9: exported artifacts name overlay-relative paths, never a sandbox absolute."""
    target = Path(path)
    try:
        return target.resolve().relative_to(OVERLAY_ROOT.resolve()).as_posix()
    except ValueError:
        return target.name


def scope_document(run_id: str, *, subject: str = "operator@example.test", tenant: str = "linearfinance",
                   project: str = "project", classes: Iterable[str] = DEFAULT_CLASSES, mode: str = "draft_only",
                   actions: Iterable[str] = ("read", "analyze", "draft", "write_evidence"), write_authority: str = "draft",
                   issued_at: datetime | None = None, hours: int = DEFAULT_SCOPE_HOURS, **overrides: Any) -> dict[str, Any]:
    classes = list(classes)
    issued = issued_at or datetime.now(timezone.utc)
    if issued.tzinfo is None:
        issued = issued.replace(tzinfo=timezone.utc)
    doc = {
        "schema_id": "as.scope_contract/1", "run_id": run_id, "subject": subject, "tenant": tenant, "project": project,
        "source_set": sorted({_SOURCE_FOR_CLASS[c] for c in classes}), "revision_bounds": {},
        "allowed_artifact_classes": classes, "allowed_actions": sorted(set(actions)), "write_authority": write_authority,
        "reviewer_authority": ["architecture_owner"], "approval_rights": ["human_review_policy_owner"],
        "authorized_paths": ["."], "denied_paths": [".git", "Architecture Studio/evidence"],
        "data_handling_profile": "internal", "issued_at": issued.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "expires_at": (issued + timedelta(hours=hours)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "issuer_ref": f"AUTH-{subject}", "human_authority_ref": f"AUTH-{subject}", "policy_version": "1.0.0", "mode": mode,
    }
    doc.update(overrides)
    return doc


def make_scope(run_id: str, *, target_root: Path | None = None, **kw: Any) -> ScopeContract:
    return ScopeContract.from_document(scope_document(run_id, **kw), target_root=target_root or CORPUS_ROOT)


def make_operator(provider: IdentityProvider | None = None, *, subject: str = "operator@example.test",
                  secret: str = "operator-secret") -> tuple[IdentityProvider, Principal]:
    provider = provider or IdentityProvider()
    provider.enroll(subject, "human", secret)
    return provider, provider.authenticate(subject, secret)


def make_index(scope: ScopeContract, *, ledger: Ledger | None = None, classes: Iterable[str] | None = None,
               corpus_root: Path | None = None, with_pins: bool = False
               ) -> tuple[NormalizedIndex, list[Any], PinnedSourceSet | None]:
    classes = list(classes or scope.allowed_artifact_classes)
    connectors = [connector_for_class(c, corpus_root=corpus_root or CORPUS_ROOT, tenant=scope.tenant, project=scope.project,
                                      fixtures_root=FIXTURES_ROOT, ledger=ledger, sleep=lambda s: None) for c in sorted(classes)]
    normalizer = Normalizer(ledger=ledger)
    index = NormalizedIndex()
    for connector in connectors:
        index = normalizer.ingest([connector.read(scope)], index=index)
    pins = pin_source_set(scope.run_id, connectors, scope) if with_pins else None
    return index, connectors, pins
