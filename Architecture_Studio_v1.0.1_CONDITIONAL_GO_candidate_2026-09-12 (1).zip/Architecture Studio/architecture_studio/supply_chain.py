"""Software supply-chain controls (AUDIT-ADD-18, DOC-06, MODEL-01, STORE-05, XTOOL-06).

Inventory of every dependency, model, tool and connector; an SPDX-2.3 JSON
SBOM generated from that inventory; pinning by content digest; and a policy
check that blocks disallowed components. The runtime package has *zero*
third-party runtime imports — :func:`third_party_runtime_imports` proves it by
scanning the package's import statements against the standard library — and
the two optional extras (``cryptography`` for Ed25519/AES-GCM) are inventoried
as optional with the fail-closed behaviour their absence produces.

Signature/provenance verification of third-party wheels is a host capability:
it is reported as ``NOT_ASSESSED`` here rather than claimed.

Build provenance: BUILD_NEW (the yard's `spdx-simplify` is a license-expression
simplifier, not an SBOM generator; `sbom-tool` is .NET and not runnable here).
"""
from __future__ import annotations

import ast
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from . import __version__, version_manifest
from .canonical import fmt_ts, sha256_hex, sha256_of

__all__ = ["third_party_runtime_imports", "inventory", "sbom", "policy_check", "DISALLOWED", "OPTIONAL_EXTRAS"]

PACKAGE_ROOT = Path(__file__).resolve().parent
OPTIONAL_EXTRAS = {"cryptography": "Ed25519 approval signatures and AES-256-GCM envelope encryption; absence fails closed"}
DISALLOWED: dict[str, str] = {"pickle": "arbitrary code execution on load", "marshal": "unsafe deserialization",
                              "yaml": "unsafe loader by default; not needed", "requests": "network client; the runtime makes no network calls"}
_STDLIB = set(getattr(sys, "stdlib_module_names", set()))


def _imports_of(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                names.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            names.add(node.module.split(".")[0])
    return names


def third_party_runtime_imports(root: Path | None = None) -> dict[str, list[str]]:
    """Top-level non-stdlib, non-local imports per module (optional extras reported separately)."""
    root = root or PACKAGE_ROOT
    out: dict[str, list[str]] = {}
    for path in sorted(root.rglob("*.py")):
        rel = path.relative_to(root).as_posix()
        names = _imports_of(path)
        third = sorted(n for n in names if n not in _STDLIB and n != "architecture_studio" and n not in ("__future__",))
        if third:
            out[rel] = third
    return out


def inventory(root: Path | None = None) -> dict[str, Any]:
    root = root or PACKAGE_ROOT
    files = []
    for path in sorted(root.rglob("*.py")):
        files.append({"path": path.relative_to(root).as_posix(), "sha256": sha256_hex(path.read_bytes()), "bytes": path.stat().st_size})
    third = third_party_runtime_imports(root)
    optional = sorted({n for names in third.values() for n in names if n in OPTIONAL_EXTRAS})
    unexpected = sorted({n for names in third.values() for n in names if n not in OPTIONAL_EXTRAS})
    return {
        "component": "architecture_studio", "version": __version__, "files": files,
        "file_digest": sha256_of("".join(f["sha256"] for f in files)),
        "runtime": {"python": sys.version.split()[0], "implementation": sys.implementation.name},
        "third_party_required": unexpected, "optional_extras": {n: OPTIONAL_EXTRAS[n] for n in optional},
        "vendored": [{"name": "amplifier-bundle-redaction", "path": "vendor/redaction.py", "license": "MIT",
                      "origin": "GitHub Junkyard car amplifier-bundle-redaction"}],
        "models": [{"slot": "ProviderSlot", "bound": False, "note": "no model provider bound; deterministic evidence generator in use"}],
        "tools": [{"name": "constraint_checker", "version": "1.0.0"}, {"name": "retrieval", "version": "1.0.0"},
                  {"name": "analyzers", "version": "1.0.0"}],
        "connectors": ["requirements", "nfrs", "adrs", "api_catalog", "infra_catalog", "diagrams", "security_constraints",
                       "cost_performance", "deployment_standards"],
        "versions": version_manifest(), "generated_at": fmt_ts(datetime.now(timezone.utc)),
    }


def sbom(inv: dict[str, Any] | None = None) -> dict[str, Any]:
    """SPDX-2.3 JSON document from the inventory; provenance/signature verification NOT_ASSESSED."""
    inv = inv or inventory()
    packages = [{
        "SPDXID": "SPDXRef-Package-architecture-studio", "name": "architecture_studio", "versionInfo": inv["version"],
        "downloadLocation": "NOASSERTION", "filesAnalyzed": True, "licenseConcluded": "MIT", "licenseDeclared": "MIT",
        "supplier": "Person: David Paul Russell", "checksums": [{"algorithm": "SHA256", "checksumValue": inv["file_digest"][7:]}],
        "externalRefs": [], "primaryPackagePurpose": "LIBRARY",
    }]
    for vendored in inv["vendored"]:
        packages.append({"SPDXID": "SPDXRef-Package-" + vendored["name"], "name": vendored["name"], "versionInfo": "vendored",
                         "downloadLocation": "NOASSERTION", "filesAnalyzed": False, "licenseConcluded": vendored["license"],
                         "licenseDeclared": vendored["license"], "supplier": "Organization: Microsoft Corporation",
                         "primaryPackagePurpose": "LIBRARY"})
    for name, note in inv["optional_extras"].items():
        packages.append({"SPDXID": "SPDXRef-Package-" + name, "name": name, "versionInfo": "host-provided",
                         "downloadLocation": "NOASSERTION", "filesAnalyzed": False, "licenseConcluded": "NOASSERTION",
                         "licenseDeclared": "NOASSERTION", "supplier": "NOASSERTION", "comment": "optional: " + note,
                         "primaryPackagePurpose": "LIBRARY"})
    relationships = [{"spdxElementId": "SPDXRef-DOCUMENT", "relationshipType": "DESCRIBES",
                      "relatedSpdxElement": "SPDXRef-Package-architecture-studio"}]
    for package in packages[1:]:
        relationships.append({"spdxElementId": "SPDXRef-Package-architecture-studio",
                              "relationshipType": "DEPENDS_ON" if package["name"] in inv["optional_extras"] else "CONTAINS",
                              "relatedSpdxElement": package["SPDXID"]})
    return {
        "spdxVersion": "SPDX-2.3", "dataLicense": "CC0-1.0", "SPDXID": "SPDXRef-DOCUMENT",
        "name": f"architecture_studio-{inv['version']}", "documentNamespace": f"urn:architecture-studio:sbom:{inv['file_digest'][7:23]}",
        "creationInfo": {"created": inv["generated_at"], "creators": ["Tool: architecture_studio.supply_chain-1.0.0"]},
        "packages": packages, "relationships": relationships,
        "annotations": [{"annotationType": "OTHER", "annotator": "Tool: architecture_studio.supply_chain-1.0.0",
                         "annotationDate": inv["generated_at"],
                         "comment": "provenance/signature verification of host-provided packages: NOT_ASSESSED"}],
    }


def policy_check(inv: dict[str, Any] | None = None) -> dict[str, Any]:
    inv = inv or inventory()
    blocked = [n for n in inv["third_party_required"] if n in DISALLOWED]
    imports = third_party_runtime_imports()
    disallowed_used = sorted({n for names in imports.values() for n in names if n in DISALLOWED})
    return {"required_third_party": inv["third_party_required"], "disallowed_present": sorted(set(blocked) | set(disallowed_used)),
            "optional_extras": sorted(inv["optional_extras"]), "pinned": True,
            "verdict": "PASS" if not inv["third_party_required"] and not disallowed_used else "FAIL",
            "signature_verification": "NOT_ASSESSED"}
