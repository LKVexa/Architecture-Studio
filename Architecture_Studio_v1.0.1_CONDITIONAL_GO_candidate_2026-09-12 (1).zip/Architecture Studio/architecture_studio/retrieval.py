"""Authorization-aware, deterministic retrieval (COMP-03, XTOOL-04, XTOOL-05, MODEL-03, PAPER-CAP-02, AUDIT-ADD-12).

Retrieval is lexical and deterministic: a BM25-style scorer over an inverted
index built from the normalized records. No embedding model is involved, so
retrieval is reproducible for a pinned revision and no model decides which
evidence a model gets to see.

Three properties matter more than ranking quality:

* every returned chunk is **source-labelled** with artifact id, revision,
  location, freshness, trust classification and evidence status (MODEL-03);
* the scope contract is enforced **at the query layer** — records from a source
  system or data class the contract does not allow are excluded and counted,
  never returned (XTOOL-04, COMP-03 "never crosses scope/tenant boundaries");
* stale records are **demoted, never hidden** (XTOOL-05), and the context
  package is **bounded** by a token budget with an explicit truncation flag.

Adapted from the owner's Repository Context Graph ``rcg/retrieval.py``.
"""
from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from .canonical import digest_of
from .connectors.normalize import NormalizedIndex
from .scope import ScopeContract

__all__ = ["Chunk", "RetrievalResult", "RetrievalIndex", "TOKEN_RE", "RETRIEVAL_VERSION", "expand"]

RETRIEVAL_VERSION = "1.0.0"
TOKEN_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]{1,}|\d+")
_CAMEL_RE = re.compile(r"[A-Z]+(?![a-z])|[A-Z][a-z0-9]+|[a-z0-9]+")
_K1, _B = 1.5, 0.75


def expand(token: str) -> list[str]:
    lowered = token.lower()
    parts = {lowered}
    for chunk in token.replace(".", "_").split("_"):
        if chunk:
            parts.add(chunk.lower())
            for piece in _CAMEL_RE.findall(chunk):
                if len(piece) > 1:
                    parts.add(piece.lower())
    return sorted(parts)


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    record_id: str
    artifact_id: str
    source_system: str
    data_class: str
    path: str
    revision: str
    source_hash: str
    span: str
    classification: str
    freshness: str
    evidence_ref_id: str
    text: str

    def label(self) -> str:
        return (f"[{self.source_system}/{self.data_class}:{self.path}:{self.span} @{self.revision[:19]} "
                f"{self.source_hash[:19]} class={self.classification} freshness={self.freshness} ev={self.evidence_ref_id}]")

    def as_document(self) -> dict[str, Any]:
        return {"chunk_id": self.chunk_id, "record_id": self.record_id, "artifact_id": self.artifact_id,
                "source_system": self.source_system, "data_class": self.data_class, "path": self.path,
                "revision": self.revision, "source_hash": self.source_hash, "span": self.span,
                "classification": self.classification, "freshness": self.freshness,
                "evidence_ref_id": self.evidence_ref_id, "label": self.label()}


@dataclass
class RetrievalResult:
    chunks: list[Chunk]
    scores: list[float]
    query_terms: list[str]
    total_candidates: int
    truncated: bool
    stale_included: int
    excluded_by_scope: int
    token_budget: int
    tokens_used: int

    def labelled_context(self) -> str:
        return "\n\n".join(f"{c.label()}\n{c.text}" for c in self.chunks)

    def as_document(self) -> dict[str, Any]:
        return {"retrieval_version": RETRIEVAL_VERSION, "query_terms": self.query_terms,
                "total_candidates": self.total_candidates, "returned": len(self.chunks), "truncated": self.truncated,
                "stale_included": self.stale_included, "excluded_by_scope": self.excluded_by_scope,
                "token_budget": self.token_budget, "tokens_used": self.tokens_used,
                "chunks": [c.as_document() for c in self.chunks], "scores": [round(s, 6) for s in self.scores],
                "context_manifest_digest": digest_of([c.chunk_id for c in self.chunks])}


def _record_text(record: Mapping[str, Any]) -> str:
    parts: list[str] = [str(record["record_id"]), str(record["data_class"])]

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for k, v in value.items():
                parts.append(str(k))
                walk(v)
        elif isinstance(value, (list, tuple)):
            for v in value:
                walk(v)
        elif value is not None:
            parts.append(str(value))
    walk(record["payload"])
    return " ".join(parts)


class RetrievalIndex:
    def __init__(self) -> None:
        self._chunks: dict[str, Chunk] = {}
        self._postings: dict[str, set[str]] = defaultdict(set)
        self._lengths: dict[str, int] = {}
        self._term_counts: dict[str, Counter[str]] = {}

    # ---------------------------------------------------------------- build --
    def add_index(self, index: NormalizedIndex) -> int:
        added = 0
        for record_id, record in sorted(index.records.items()):
            text = _record_text(record)
            span = record["provenance"].get("span") or "L0"
            chunk = Chunk(chunk_id=digest_of({"r": record_id, "h": record["source_hash"]}), record_id=record_id,
                          artifact_id=record["artifact_id"], source_system=record["source_system"],
                          data_class=record["data_class"], path=record["path"], revision=record["revision"],
                          source_hash=record["source_hash"], span=span, classification=record["classification"],
                          freshness=record["freshness"], evidence_ref_id=record["provenance_ref_id"], text=text[:2000])
            self._add(chunk)
            added += 1
        return added

    def _add(self, chunk: Chunk) -> None:
        terms: Counter[str] = Counter()
        for raw in TOKEN_RE.findall(chunk.text):
            for part in expand(raw):
                terms[part] += 1
        self._chunks[chunk.chunk_id] = chunk
        self._term_counts[chunk.chunk_id] = terms
        self._lengths[chunk.chunk_id] = sum(terms.values()) or 1
        for term in terms:
            self._postings[term].add(chunk.chunk_id)

    def mark_stale(self, artifact_ids: Iterable[str]) -> int:
        targets = set(artifact_ids)
        changed = 0
        for cid, chunk in list(self._chunks.items()):
            if chunk.artifact_id in targets and chunk.freshness != "STALE":
                self._chunks[cid] = Chunk(**{**chunk.__dict__, "freshness": "STALE"})
                changed += 1
        return changed

    # ---------------------------------------------------------------- query --
    def search(self, query: str, *, scope: ScopeContract, limit: int = 10, token_budget: int = 4000,
               data_classes: Iterable[str] | None = None, min_score: float = 0.0) -> RetrievalResult:
        terms = sorted({part for raw in TOKEN_RE.findall(query) for part in expand(raw)})
        if not terms:
            return RetrievalResult([], [], [], 0, False, 0, 0, token_budget, 0)
        wanted_classes = set(data_classes) if data_classes else None
        total = len(self._chunks) or 1
        avg_len = (sum(self._lengths.values()) / total) if self._lengths else 1.0
        candidates: set[str] = set()
        for term in terms:
            candidates |= self._postings.get(term, set())
        excluded = 0
        scored: list[tuple[float, str]] = []
        for cid in candidates:
            chunk = self._chunks[cid]
            if chunk.source_system not in scope.source_set or chunk.data_class not in scope.allowed_artifact_classes:
                excluded += 1
                continue
            if wanted_classes and chunk.data_class not in wanted_classes:
                continue
            if chunk.classification == "secret":
                excluded += 1
                continue
            counts, length = self._term_counts[cid], self._lengths[cid]
            score = 0.0
            for term in terms:
                freq = counts.get(term, 0)
                if not freq:
                    continue
                df = len(self._postings.get(term, ()))
                idf = math.log(1 + (total - df + 0.5) / (df + 0.5))
                score += idf * (freq * (_K1 + 1)) / (freq + _K1 * (1 - _B + _B * length / avg_len))
            if chunk.freshness == "STALE":
                score *= 0.25
            if score > min_score:
                scored.append((score, cid))
        scored.sort(key=lambda pair: (-pair[0], pair[1]))
        chosen: list[tuple[float, str]] = []
        used = 0
        truncated = False
        for score, cid in scored:
            cost = max(1, len(self._chunks[cid].text) // 4)
            if len(chosen) >= limit or used + cost > token_budget:
                truncated = True
                break
            chosen.append((score, cid))
            used += cost
        chunks = [self._chunks[cid] for _, cid in chosen]
        return RetrievalResult(chunks=chunks, scores=[s for s, _ in chosen], query_terms=terms,
                               total_candidates=len(scored), truncated=truncated or len(scored) > len(chosen),
                               stale_included=sum(1 for c in chunks if c.freshness == "STALE"),
                               excluded_by_scope=excluded, token_budget=token_budget, tokens_used=used)

    @property
    def size(self) -> int:
        return len(self._chunks)
