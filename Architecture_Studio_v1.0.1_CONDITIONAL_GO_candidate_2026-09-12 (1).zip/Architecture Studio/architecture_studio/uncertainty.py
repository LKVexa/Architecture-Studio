"""Uncertainty, abstention and calibration (IMPL-07, API-04, XUNC-01..06, PAPER-CAP-05, XUNC-04).

The seven states are not a confidence scale; they are different kinds of
epistemic position, and collapsing them into a number is the failure XUNC-06
names. ``missing`` is the absence of evidence and must be surfaced rather than
smoothed into a guess (XUNC-03). A numeric confidence may accompany a state
only when it has been calibrated against validation data (XUNC-02); an
uncalibrated score is withheld and the withholding is recorded.

Thresholds (XUNC-04) are configuration with an approval state. The package
supplies no numbers and approves none (EXECUTION_RULES: "No numerical target is
supplied or approved"), so the shipped thresholds are PROPOSED; a run that
needs an approved threshold to *pass* something reports UNKNOWN, while a
proposed threshold is still enough to *abstain* or *route to review*, because
failing closed never needs approval.

Adapted from the owner's Repository Context Graph ``rcg/uncertainty.py``.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Sequence

from .schemas import UNCERTAINTY_STATES, validate

__all__ = ["UncertaintyError", "Assessment", "Thresholds", "Calibration", "assess", "must_abstain",
           "route_for_review", "ABSTENTION_CODES", "PROPOSED", "APPROVED"]

PROPOSED, APPROVED = "PROPOSED", "APPROVED"
ABSTENTION_CODES = ("INSUFFICIENT_EVIDENCE", "OUT_OF_SCOPE", "MISSING_CONTEXT", "CONFLICTING_EVIDENCE",
                    "STALE_CONTEXT", "GENERIC_FALLBACK", "PROVIDER_UNAVAILABLE", "POLICY_STOP",
                    "UNCALIBRATED_SCORE", "HUMAN_DECISION_REQUIRED")


class UncertaintyError(ValueError):
    pass


@dataclass(frozen=True)
class Thresholds:
    """XUNC-04 stop/abstain thresholds with an explicit approval state."""

    min_evidence_refs: int = 1
    min_grounding_coverage: float = 0.75
    max_missing_context: int = 0
    max_conflicts_without_review: int = 0
    abstain_states: tuple[str, ...] = ("missing", "out_of_scope")
    review_states: tuple[str, ...] = ("uncertain", "stale", "inferred")
    high_impact_requires_review: bool = True
    status: str = PROPOSED
    approval_ref: str | None = None
    owner_role: str = "ml_evaluation_owner"

    @classmethod
    def load(cls, path: Path) -> "Thresholds":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        known = set(cls.__dataclass_fields__)
        return cls(**{k: (tuple(v) if isinstance(v, list) else v) for k, v in data.items() if k in known})

    @property
    def approved(self) -> bool:
        return self.status == APPROVED and bool(self.approval_ref)

    def as_document(self) -> dict[str, Any]:
        return {"min_evidence_refs": self.min_evidence_refs, "min_grounding_coverage": self.min_grounding_coverage,
                "max_missing_context": self.max_missing_context,
                "max_conflicts_without_review": self.max_conflicts_without_review,
                "abstain_states": list(self.abstain_states), "review_states": list(self.review_states),
                "high_impact_requires_review": self.high_impact_requires_review, "status": self.status,
                "approval_ref": self.approval_ref, "owner_role": self.owner_role, "approved": self.approved,
                "boundary": "a PROPOSED threshold can abstain or route to review; it cannot make anything pass"}


@dataclass(frozen=True)
class Calibration:
    bins: tuple[tuple[float, float], ...]
    sample_size: int
    corpus_ref: str

    def apply(self, raw: float) -> float:
        for upper, accuracy in self.bins:
            if raw <= upper:
                return accuracy
        return self.bins[-1][1] if self.bins else raw

    def as_document(self) -> dict[str, Any]:
        return {"bins": [list(b) for b in self.bins], "sample_size": self.sample_size, "corpus_ref": self.corpus_ref}


@dataclass
class Assessment:
    state: str
    confidence: float | None
    calibrated: bool
    calibration_ref: str | None
    stale: bool
    missing: bool
    conflict: bool
    abstained: bool
    abstention_code: str | None
    rationale: str | None
    missing_context: list[str]
    requires_human_review: bool

    def as_document(self) -> dict[str, Any]:
        document = {"schema_id": "as.uncertainty/1", "state": self.state, "confidence": self.confidence,
                    "calibrated": self.calibrated, "calibration_ref": self.calibration_ref, "stale": self.stale,
                    "missing": self.missing, "conflict": self.conflict, "abstained": self.abstained,
                    "abstention_code": self.abstention_code, "rationale": self.rationale,
                    "missing_context": list(self.missing_context), "requires_human_review": self.requires_human_review}
        return validate("as.uncertainty/1", document)

    def human_sentence(self) -> str:
        """XUNC-06: never present an unsupported assumption as a fact."""
        if self.abstained:
            return f"Abstained ({self.abstention_code}): {self.rationale}"
        base = {
            "known": "Established from source evidence.",
            "supported": "Supported by evidence; some elements are labelled inference.",
            "inferred": "Inferred, not read from source; labelled as such.",
            "uncertain": "Uncertain; evidence is incomplete or conflicting.",
            "stale": "Based on context that is no longer current.",
            "missing": "Required context is missing.",
            "out_of_scope": "Outside the authorized scope of this run.",
        }[self.state]
        if self.missing_context:
            base += " Missing: " + "; ".join(self.missing_context[:3])
        if self.confidence is not None and self.calibrated:
            base += f" Calibrated confidence {self.confidence:.2f}."
        elif self.confidence is None and not self.calibrated and self.rationale and "withheld" in self.rationale:
            base += " No confidence number is shown because none is calibrated."
        return base


def _abstain(state: str, code: str, rationale: str, missing: list[str], *, stale: bool = False,
             conflict: bool = False) -> Assessment:
    return Assessment(state, None, False, None, stale, state == "missing", conflict, True, code, rationale, missing, True)


def assess(*, evidence_refs: Sequence[str], grounding_coverage: float | None = None,
           missing_context: Sequence[str] = (), stale: bool = False, out_of_scope: bool = False,
           conflicts: int = 0, high_impact: bool = False, generic_fallback: bool = False,
           provider_unavailable: bool = False, policy_stop: bool = False, inferred_fraction: float = 0.0,
           raw_score: float | None = None, calibration: Calibration | None = None,
           thresholds: Thresholds | None = None) -> Assessment:
    """Decide the epistemic state and whether to abstain or escalate. Failing closed needs no approval."""
    thresholds = thresholds or Thresholds()
    missing = list(missing_context)
    if policy_stop:
        return _abstain("out_of_scope", "POLICY_STOP", "a policy stop condition fired", missing)
    if out_of_scope:
        return _abstain("out_of_scope", "OUT_OF_SCOPE", "the request falls outside the authorized scope", missing)
    if provider_unavailable:
        return _abstain("missing", "PROVIDER_UNAVAILABLE", "no bound model provider; deterministic output only", missing)
    if len(evidence_refs) < thresholds.min_evidence_refs:
        missing.append(f"fewer than {thresholds.min_evidence_refs} supporting evidence reference(s)")
        return _abstain("missing", "INSUFFICIENT_EVIDENCE", "insufficient evidence to support a conclusion", missing)
    if generic_fallback or (grounding_coverage is not None and grounding_coverage < thresholds.min_grounding_coverage):
        cov = f"{grounding_coverage:.0%}" if grounding_coverage is not None else "unknown"
        return _abstain("missing", "GENERIC_FALLBACK",
                        f"local grounding coverage {cov} is below the minimum {thresholds.min_grounding_coverage:.0%}; "
                        "generic patterns are not presented as grounded design", missing)
    if len(missing) > thresholds.max_missing_context:
        return _abstain("missing", "MISSING_CONTEXT", f"{len(missing)} required context item(s) unavailable", missing)
    if conflicts > thresholds.max_conflicts_without_review:
        return Assessment("uncertain", None, False, None, stale, False, True, True, "CONFLICTING_EVIDENCE",
                          f"{conflicts} unresolved evidence conflict(s) need a human decision", missing, True)
    if stale:
        return Assessment("stale", None, False, None, True, False, False, False, None,
                          "based on context that is no longer current", missing, True)
    confidence: float | None = None
    calibrated = False
    calibration_ref = None
    rationale = None
    if raw_score is not None:
        if calibration is None:
            rationale = "confidence score withheld: no calibration for this scorer"
            missing.append(rationale)
        else:
            confidence = round(calibration.apply(raw_score), 4)
            calibrated = True
            calibration_ref = calibration.corpus_ref
    if inferred_fraction >= 1.0:
        state = "inferred"
    elif inferred_fraction > 0.0:
        state = "supported"
    else:
        state = "known"
    review = bool(missing) or (high_impact and thresholds.high_impact_requires_review) or state == "inferred"
    return Assessment(state, confidence, calibrated, calibration_ref, False, False, False, False, None, rationale,
                      missing, review)


def must_abstain(assessment: Assessment, thresholds: Thresholds | None = None) -> bool:
    thresholds = thresholds or Thresholds()
    return assessment.abstained or assessment.state in thresholds.abstain_states


def route_for_review(assessment: Assessment, thresholds: Thresholds | None = None) -> bool:
    thresholds = thresholds or Thresholds()
    return assessment.requires_human_review or assessment.state in thresholds.review_states
