"""Clarifying-question materiality (AUDIT-ADD-09, PAPER-CAP-05, XUNC-03).

A gap is *material* when it changes which options are feasible: a missing
deployment target changes every candidate's deployment; a missing cpu-per-
replica number changes whether the envelope check can decide; a conflict
between NFR targets changes the trade-off table; a proposed (not accepted) ADR
a candidate rests on changes whether the candidate is grounded. A nonmaterial
gap is labelled and carried, never allowed to block.

Rules are data (``MATERIALITY_RULES``) so the same gap always gets the same
answer, and unanswered material questions travel with the review package.

Build provenance: BUILD_NEW.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Iterable, Mapping, Sequence

from .canonical import fmt_ts
from .ids import question_id as make_question_id
from .schemas import validate

__all__ = ["MATERIALITY_RULES", "detect_gaps", "raise_questions", "answer_question", "material_open"]

MATERIALITY_RULES: dict[str, dict[str, Any]] = {
    "unknown_constraint_check": {
        "materiality": "material", "priority": 2,
        "rule": "a deterministic check returned unknown for a constraint family the sources state",
        "question": "Which value should the {family} check use for {rule_id}? The pinned sources state none."},
    "nfr_target_conflict": {
        "materiality": "material", "priority": 1,
        "rule": "two pinned NFR targets disagree for the same scope",
        "question": "Which target applies for {scope}? The sources disagree and no candidate can satisfy both."},
    "proposed_adr_reliance": {
        "materiality": "material", "priority": 2,
        "rule": "a candidate rests on an ADR whose status is proposed",
        "question": "Is {adr} accepted? The candidate assumes it; if rejected the option changes."},
    "missing_deployment_environment": {
        "materiality": "material", "priority": 1,
        "rule": "no deployment environment is declared for the candidate",
        "question": "Which environment(s) should the candidate target? None is declared."},
    "diagram_ambiguity": {
        "materiality": "nonmaterial", "priority": 4,
        "rule": "an ingested diagram had parse ambiguities that do not change feasibility",
        "question": "The inventory diagram names {count} suites differently from the folders; confirm the mapping."},
    "open_assumption": {
        "materiality": "nonmaterial", "priority": 3,
        "rule": "a labelled inferred assumption that a reviewer may confirm later",
        "question": "Confirm or reject the assumption: {statement}"},
}


def detect_gaps(*, candidates: Sequence[Mapping[str, Any]], constraint_checks: Mapping[str, Sequence[Mapping[str, Any]]],
                conflicts: Sequence[Mapping[str, Any]], assumptions: Sequence[Mapping[str, Any]],
                diagram_ambiguities: int = 0) -> list[dict[str, Any]]:
    gaps: list[dict[str, Any]] = []
    seen: set[str] = set()
    for cid, checks in constraint_checks.items():
        for check in checks:
            if check["result"] == "unknown" and check["family"] in ("cost_performance", "api"):
                key = f"unknown:{check['rule_id']}"
                if key in seen:
                    continue
                seen.add(key)
                gaps.append({"kind": "unknown_constraint_check", "gap": key, "affected_candidates": [cid],
                             "dimensions": [check["family"]], "params": {"family": check["family"], "rule_id": check["rule_id"]}})
    for conflict in conflicts:
        if conflict["kind"] == "nfr_target_conflict":
            gaps.append({"kind": "nfr_target_conflict", "gap": conflict["conflict_id"], "affected_candidates": [],
                         "dimensions": ["nfr"], "params": {"scope": conflict["description"][:80]}})
    for candidate in candidates:
        if not (candidate.get("deployment") or {}).get("environments"):
            gaps.append({"kind": "missing_deployment_environment", "gap": f"env:{candidate['candidate_id']}",
                         "affected_candidates": [candidate["candidate_id"]], "dimensions": ["deployment"], "params": {}})
        for check in constraint_checks.get(candidate["candidate_id"], []):
            if check["rule_id"] == "RULE-ADR-CUR-01" and "proposed" in check["message"]:
                gaps.append({"kind": "proposed_adr_reliance", "gap": f"adr:{candidate['candidate_id']}",
                             "affected_candidates": [candidate["candidate_id"]], "dimensions": ["policy"],
                             "params": {"adr": check["message"].split("ADR(s)")[-1].split("without")[0].strip()}})
    for assumption in assumptions:
        gaps.append({"kind": "open_assumption", "gap": assumption["assumption_id"],
                     "affected_candidates": list(assumption.get("affected_candidates", [])), "dimensions": [],
                     "params": {"statement": assumption["statement"]}})
    if diagram_ambiguities:
        gaps.append({"kind": "diagram_ambiguity", "gap": "diagram:inventory", "affected_candidates": [], "dimensions": [],
                     "params": {"count": diagram_ambiguities}})
    return gaps


def raise_questions(run_id: str, gaps: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    questions = []
    for gap in gaps:
        rule = MATERIALITY_RULES[gap["kind"]]
        text = rule["question"].format(**gap.get("params", {}))
        doc = {"schema_id": "as.question/1", "question_id": make_question_id(run=run_id, gap=str(gap["gap"])),
               "run_id": run_id, "gap": str(gap["gap"]), "question": text, "materiality": rule["materiality"],
               "materiality_rule": rule["rule"], "affected_candidates": list(gap.get("affected_candidates", [])),
               "affected_dimensions": list(gap.get("dimensions", [])), "priority": rule["priority"],
               "status": "open", "bounded_assumption": None, "answer": None, "answered_by": None,
               "raised_at": fmt_ts(datetime.now(timezone.utc))}
        questions.append(validate("as.question/1", doc))
    return sorted(questions, key=lambda q: (q["priority"], q["question_id"]))


def answer_question(question: Mapping[str, Any], *, answer: str, principal: Any) -> dict[str, Any]:
    if getattr(principal, "kind", None) != "human":
        raise PermissionError("only a human principal can answer a clarifying question")
    if not answer or not answer.strip():
        raise ValueError("an answer must be non-empty")
    updated = dict(question)
    updated.update(status="answered", answer=answer.strip(), answered_by=principal.as_record())
    return validate("as.question/1", updated)


def material_open(questions: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """The questions that pause design progression (PAPER-CAP-05)."""
    return [q for q in questions if q["materiality"] == "material" and q["status"] == "open"]
