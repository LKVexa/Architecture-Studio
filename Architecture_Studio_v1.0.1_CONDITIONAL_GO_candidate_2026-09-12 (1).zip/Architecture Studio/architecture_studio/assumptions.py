"""Assumption registry (PAPER-GRD-02, VERIFY-03, XUNC-06).

Every non-source assertion — an inferred component, a proposed dependency, a
reliance on a proposed ADR, a trade-off claim without a citation — is either
labelled and registered here (inferred / uncertain / proposed / unsupported) or
it causes abstention. Silent requirement invention fails verification: the
verifier in :mod:`architecture_studio.verify` walks every candidate statement
and any assertion that lacks evidence *and* lacks a registry entry is a defect.

Build provenance: BUILD_NEW.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Iterable, Mapping

from .canonical import fmt_ts
from .ids import deterministic_id
from .schemas import validate

__all__ = ["AssumptionRegistry", "STATUSES", "unlabelled_assertions"]

STATUSES = ("inferred", "uncertain", "proposed", "unsupported")


class AssumptionRegistry:
    def __init__(self, run_id: str, *, ledger: Any = None) -> None:
        self.run_id = run_id
        self.ledger = ledger
        self._entries: dict[str, dict[str, Any]] = {}

    def register(self, statement: str, *, status: str, introduced_by: str, evidence_refs: Iterable[str] = (),
                 affected_candidates: Iterable[str] = ()) -> dict[str, Any]:
        if status not in STATUSES:
            raise ValueError(f"assumption status must be one of {STATUSES}")
        if not statement or not statement.strip():
            raise ValueError("an assumption needs a statement")
        doc = {"schema_id": "as.assumption/1",
               "assumption_id": deterministic_id("assumption", run=self.run_id, statement=statement.strip()),
               "run_id": self.run_id, "statement": statement.strip(), "status": status,
               "evidence_refs": sorted(set(evidence_refs)), "introduced_by": introduced_by,
               "affected_candidates": sorted(set(affected_candidates)), "resolution": "open",
               "recorded_at": fmt_ts(datetime.now(timezone.utc))}
        validate("as.assumption/1", doc)
        existing = self._entries.get(doc["assumption_id"])
        if existing:
            existing["affected_candidates"] = sorted(set(existing["affected_candidates"]) | set(doc["affected_candidates"]))
            return existing
        self._entries[doc["assumption_id"]] = doc
        if self.ledger is not None:
            self.ledger.append("assumption.registered", actor=introduced_by, actor_kind="analyzer", outcome="recorded",
                               subject=doc["assumption_id"], detail=doc)
        return doc

    def resolve(self, assumption_id: str, *, resolution: str, principal: Any) -> dict[str, Any]:
        if resolution not in ("confirmed_by_human", "rejected_by_human", "converted_to_question"):
            raise ValueError("unknown resolution")
        if getattr(principal, "kind", None) != "human":
            raise PermissionError("only a human principal can resolve an assumption")
        entry = self._entries[assumption_id]
        entry["resolution"] = resolution
        if self.ledger is not None:
            self.ledger.append("assumption.resolved", actor=principal.subject, actor_kind="human", outcome="recorded",
                               subject=assumption_id, detail={"resolution": resolution})
        return entry

    def entries(self, *, candidate_id: str | None = None) -> list[dict[str, Any]]:
        out = list(self._entries.values())
        if candidate_id is not None:
            out = [e for e in out if candidate_id in e["affected_candidates"]]
        return sorted(out, key=lambda e: e["assumption_id"])

    def statements(self) -> set[str]:
        return {e["statement"] for e in self._entries.values()}

    def covers(self, statement: str) -> bool:
        return statement.strip() in self.statements()


def unlabelled_assertions(candidate: Mapping[str, Any], registry: AssumptionRegistry) -> list[dict[str, Any]]:
    """Statements in a candidate that are neither source-derived with evidence nor registered assumptions."""
    problems: list[dict[str, Any]] = []
    for component in candidate.get("components", []):
        if component.get("derivation") == "source" and not component.get("evidence_refs"):
            problems.append({"element_id": component["element_id"], "kind": "component",
                             "reason": "claims source derivation without evidence"})
        if component.get("derivation") != "source" and not any(
                component["name"] in s or component["element_id"] in s for s in registry.statements()):
            problems.append({"element_id": component["element_id"], "kind": "component",
                             "reason": f"{component['derivation']} component is not in the assumption registry"})
    for entry in candidate.get("rationale", []):
        if entry.get("derivation") == "source" and not entry.get("evidence_refs"):
            problems.append({"element_id": entry["text"][:40], "kind": "rationale", "reason": "source claim without evidence"})
        if entry.get("derivation") in ("model_inference",) and not registry.covers(entry["text"]) and not entry.get("evidence_refs"):
            problems.append({"element_id": entry["text"][:40], "kind": "rationale",
                             "reason": "model inference is neither cited nor registered as an assumption"})
    return problems
