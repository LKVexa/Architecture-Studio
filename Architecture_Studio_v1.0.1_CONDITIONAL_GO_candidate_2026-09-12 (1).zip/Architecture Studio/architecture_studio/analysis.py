"""Deterministic analysis and constraint checking (ARCH-05, COMP-05, XTOOL-01, WF-05).

Analyzers run *before* any probabilistic reasoning and their raw outputs are
preserved separately from model synthesis (XPROV-05). Each constraint check
returns ``pass`` / ``fail`` / ``unknown`` with a rule ID and the evidence it
inspected; an ``unknown`` never becomes a ``pass`` (COMP-05), and a rule whose
inputs are absent says so instead of guessing.

The analyzer order is recorded in a run trace so WF-05 can be proved from the
trace ("deterministic results precede model reasoning") rather than asserted.

Build provenance: BUILD_NEW; the rule shape follows the Scoped PR Builder's
``verification_checks`` (typed verdict + evidence per rule).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Iterable, Mapping

from .canonical import digest_of, fmt_ts
from .connectors.normalize import NormalizedIndex
from .schemas import SchemaError, validate

__all__ = ["ANALYZER_VERSION", "AnalyzerResult", "run_analyzers", "ConstraintChecker", "RULES", "Rule",
           "schema_analyzer", "freshness_analyzer", "graph_analyzer", "diff_analyzer"]

ANALYZER_VERSION = "1.0.0"


@dataclass
class AnalyzerResult:
    analyzer: str
    version: str
    result: str                       # pass | fail | unknown
    findings: list[dict[str, Any]] = field(default_factory=list)
    evidence_refs: list[str] = field(default_factory=list)
    started_at: str = ""
    ended_at: str = ""

    def as_document(self) -> dict[str, Any]:
        return {"analyzer": self.analyzer, "version": self.version, "result": self.result, "findings": self.findings,
                "evidence_refs": self.evidence_refs, "started_at": self.started_at, "ended_at": self.ended_at,
                "derivation": "deterministic_analyzer"}


def schema_analyzer(index: NormalizedIndex, **_: Any) -> AnalyzerResult:
    """Every indexed record still validates; quarantined records are reported, not hidden."""
    failures = []
    for record_id, record in index.records.items():
        try:
            validate("as.connector_record/1", {k: v for k, v in record.items() if k != "provenance_ref_id"})
        except SchemaError as exc:
            failures.append({"record_id": record_id, "error": str(exc)})
    findings = failures + [{"quarantined": q.as_document()} for q in index.quarantine]
    return AnalyzerResult("schema_check", ANALYZER_VERSION, "fail" if failures else "pass", findings,
                          [r["provenance_ref_id"] for r in list(index.records.values())[:50]])


def freshness_analyzer(index: NormalizedIndex, **_: Any) -> AnalyzerResult:
    stale = [r for r in index.records.values() if r["freshness"] == "STALE"]
    unknown = [r for r in index.records.values() if r["freshness"] == "UNKNOWN"]
    result = "fail" if stale else "unknown" if unknown else "pass"
    return AnalyzerResult("freshness_check", ANALYZER_VERSION, result,
                          [{"record_id": r["record_id"], "freshness": r["freshness"]} for r in stale + unknown][:100],
                          [r["provenance_ref_id"] for r in (stale + unknown)[:50]])


def graph_analyzer(index: NormalizedIndex, *, graph: Any = None, **_: Any) -> AnalyzerResult:
    if graph is None:
        return AnalyzerResult("graph_traversal", ANALYZER_VERSION, "unknown", [{"reason": "no graph supplied"}], [])
    stats = graph.stats()
    orphans = [n for n in graph.nodes_of_type("service") if not graph.neighbors(n["node_id"], direction="in")]
    return AnalyzerResult("graph_traversal", ANALYZER_VERSION, "pass",
                          [{"stats": stats, "unconstrained_services": [o["node_id"] for o in orphans][:50]}],
                          [n["evidence_refs"][0] for n in orphans[:20] if n["evidence_refs"]])


def diff_analyzer(index: NormalizedIndex, *, previous_index: NormalizedIndex | None = None, **_: Any) -> AnalyzerResult:
    if previous_index is None:
        return AnalyzerResult("diff", ANALYZER_VERSION, "unknown", [{"reason": "no previous index to diff against"}], [])
    before, after = set(previous_index.records), set(index.records)
    changed = sorted(r for r in before & after if previous_index.records[r]["source_hash"] != index.records[r]["source_hash"])
    return AnalyzerResult("diff", ANALYZER_VERSION, "pass",
                          [{"added": sorted(after - before)[:100], "removed": sorted(before - after)[:100],
                            "changed": changed[:100]}], [])


ANALYZERS: tuple[Callable[..., AnalyzerResult], ...] = (schema_analyzer, freshness_analyzer, graph_analyzer, diff_analyzer)


def run_analyzers(index: NormalizedIndex, *, trace: Any = None, **kw: Any) -> list[AnalyzerResult]:
    """WF-05: run every applicable deterministic analyzer, in a fixed order, recording spans."""
    results = []
    for analyzer in ANALYZERS:
        started = fmt_ts(datetime.now(timezone.utc))
        if trace is not None:
            with trace.span(f"analyzer.{analyzer.__name__}", derivation="deterministic_analyzer"):
                result = analyzer(index, **kw)
        else:
            result = analyzer(index, **kw)
        result.started_at, result.ended_at = started, fmt_ts(datetime.now(timezone.utc))
        results.append(result)
    return results


# --------------------------------------------------------------------------- #
# Constraint checker (COMP-05)                                                  #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Rule:
    rule_id: str
    family: str
    title: str
    check: Callable[[Mapping[str, Any], NormalizedIndex], tuple[str, str, list[str], str]]


def _index_refs(records: Iterable[Mapping[str, Any]], limit: int = 5) -> list[str]:
    return [r["provenance_ref_id"] for r in list(records)[:limit]]


def _rule_sec_network(candidate: Mapping[str, Any], index: NormalizedIndex):
    denials = [r for r in index.by_class("security_constraint")
               if r["payload"].get("verb") == "deny" and "network" in str(r["payload"].get("rule"))]
    if not denials:
        return "unknown", "no network policy is stated in the pinned security constraints", [], "network-policy"
    externals = [c for c in candidate.get("components", []) if c.get("kind") == "external"]
    outbound = [r for r in candidate.get("relationships", []) if r.get("kind") == "calls"
                and any(c["element_id"] == r["target"] and c.get("kind") == "external" for c in candidate.get("components", []))]
    if externals or outbound:
        return ("fail", f"{len(externals)} external component(s) / {len(outbound)} outbound call(s) contradict "
                        f"'deny network.* by default' in {len(denials)} pinned policy rule(s)", _index_refs(denials), "network-policy")
    return "pass", f"no external component or outbound call; {len(denials)} network-deny rule(s) honoured", _index_refs(denials), "network-policy"


def _rule_dep_target(candidate: Mapping[str, Any], index: NormalizedIndex):
    standards = [r for r in index.by_class("deployment_standard") if r["payload"].get("rule") in ("target", "environment")]
    if not standards:
        return "unknown", "no deployment target/environment standard is pinned", [], "deployment-target"
    targets = {str(r["payload"]["value"]) for r in standards if r["payload"]["rule"] == "target"}
    environments = {str(r["payload"]["value"]) for r in standards if r["payload"]["rule"] == "environment"}
    deployment = candidate.get("deployment") or {}
    envs = set(deployment.get("environments", []))
    topology = str(deployment.get("topology", ""))
    if not envs:
        return "unknown", "candidate declares no deployment environments", _index_refs(standards), "deployment-target"
    if not envs <= environments:
        return ("fail", f"deployment environments {sorted(envs - environments)} are not among the pinned standards "
                        f"{sorted(environments)}", _index_refs(standards), "deployment-target")
    if targets and not any(t in topology for t in targets):
        return ("fail", f"topology {topology!r} names none of the pinned targets {sorted(targets)}",
                _index_refs(standards), "deployment-target")
    return "pass", f"environments {sorted(envs)} and target are within the pinned standards", _index_refs(standards), "deployment-target"


def _rule_api_auth(candidate: Mapping[str, Any], index: NormalizedIndex):
    operations = index.by_class("api_operation")
    if not operations:
        return "unknown", "no API catalog is pinned", [], "api-auth"
    by_service = {}
    for r in operations:
        by_service.setdefault(str(r["payload"].get("service")).lower(), []).append(r)
    unauthenticated = []
    checked = 0
    for rel in candidate.get("relationships", []):
        if rel.get("kind") != "calls":
            continue
        target = next((c for c in candidate.get("components", []) if c["element_id"] == rel["target"]), None)
        if target is None or not target.get("catalog_ref"):
            continue
        ops = by_service.get(str(target["catalog_ref"]).lower(), [])
        if not ops:
            continue
        checked += 1
        if any(op["payload"].get("auth_requirement") in (None, "unspecified") for op in ops):
            unauthenticated.append(target["catalog_ref"])
    if checked == 0:
        return "unknown", "no relationship targets a cataloged service; auth requirements could not be checked", [], "api-auth"
    if unauthenticated:
        return "fail", f"calls target service(s) with unspecified auth: {sorted(set(unauthenticated))}", _index_refs(operations), "api-auth"
    return "pass", f"{checked} cataloged call target(s) all declare an auth capability", _index_refs(operations), "api-auth"


def _rule_infra_catalog(candidate: Mapping[str, Any], index: NormalizedIndex):
    services = index.by_class("service")
    if not services:
        return "unknown", "no infrastructure catalog is pinned", [], "infra-catalog"
    names = {str(r["payload"].get("service")).lower() for r in services} | {str(r["payload"].get("workspace")).lower() for r in services}
    unmapped = [c["name"] for c in candidate.get("components", [])
                if c.get("kind") not in ("external", "policy_point") and c.get("derivation") == "source"
                and (not c.get("catalog_ref") or str(c["catalog_ref"]).lower() not in names)]
    proposed = [c["name"] for c in candidate.get("components", []) if c.get("derivation") != "source" and not c.get("catalog_ref")]
    if unmapped:
        return ("fail", f"source-derived component(s) {unmapped} map to no cataloged service and are not labelled "
                        "as proposed assumptions", _index_refs(services), "infra-catalog")
    return ("pass", f"every source-derived component maps to a cataloged service; {len(proposed)} component(s) are "
                    "explicitly labelled proposed", _index_refs(services), "infra-catalog")


def _rule_cost_envelope(candidate: Mapping[str, Any], index: NormalizedIndex):
    constraints = [r for r in index.by_class("cost_perf_constraint") if r["payload"].get("metric") in ("cpu", "memory")]
    if not constraints:
        return "unknown", "no cost/performance envelope is pinned", [], "cost-envelope"
    cpu = max((float(r["payload"]["target"]) for r in constraints if r["payload"]["metric"] == "cpu"), default=None)
    replicas = sum(int(c.get("replicas", 1) or 1) for c in candidate.get("components", []) if c.get("kind") in ("service", "worker"))
    if cpu is None:
        return "unknown", "no cpu envelope stated", _index_refs(constraints), "cost-envelope"
    per = candidate.get("deployment", {}).get("cpu_per_replica")
    if per is None:
        return ("unknown", f"candidate states no cpu per replica; envelope is {cpu:g} vcpu and cannot be compared "
                           "without inventing a number", _index_refs(constraints), "cost-envelope")
    if replicas * float(per) > cpu:
        return "fail", f"{replicas} replica(s) × {per} vcpu exceed the pinned envelope of {cpu:g} vcpu", _index_refs(constraints), "cost-envelope"
    return "pass", f"{replicas} replica(s) × {per} vcpu fit the pinned envelope of {cpu:g} vcpu", _index_refs(constraints), "cost-envelope"


def _rule_adr_superseded(candidate: Mapping[str, Any], index: NormalizedIndex):
    adrs = {r["provenance_ref_id"]: r for r in index.by_class("adr")}
    by_record = {r["record_id"]: r for r in adrs.values()}
    cited = []
    for element in list(candidate.get("components", [])) + list(candidate.get("rationale", [])):
        for ref in element.get("evidence_refs", []):
            record = adrs.get(ref) or by_record.get(ref)
            if record is not None:
                cited.append(record)
    if not adrs:
        return "unknown", "no ADRs are pinned", [], "adr-currency"
    superseded = [r for r in cited if r["payload"].get("status") == "superseded" or r["payload"].get("superseded_by")]
    proposed = [r for r in cited if r["payload"].get("status") == "proposed"]
    if superseded:
        return ("fail", f"candidate relies on superseded ADR(s) {sorted({r['payload']['adr_id'] for r in superseded})}",
                _index_refs(superseded), "adr-currency")
    if proposed and not any(a for a in candidate.get("assumptions", []) if any(r["payload"]["adr_id"] in a for r in proposed)):
        return ("fail", f"candidate relies on proposed ADR(s) {sorted({r['payload']['adr_id'] for r in proposed})} "
                        "without labelling the assumption", _index_refs(proposed), "adr-currency")
    return "pass", f"{len(cited)} cited ADR(s) are current", _index_refs(cited or list(adrs.values())), "adr-currency"


def _rule_governance_separation(candidate: Mapping[str, Any], index: NormalizedIndex):
    adr = next((r for r in index.by_class("adr") if r["payload"].get("adr_id") == "ADR-003"), None)
    if adr is None:
        return "unknown", "ADR-003 (governance ensemble) is not pinned", [], "governance-separation"
    roles = ("judgment", "validation", "application", "explanation", "evidence")
    merged = []
    for component in candidate.get("components", []):
        held = {role for role in roles if any(role in str(x).lower() for x in component.get("responsibilities", []))}
        if {"validation", "application"} <= held or len(held) >= 3:
            merged.append(component["name"])
    if merged:
        return "fail", f"component(s) {merged} merge governance responsibilities ADR-003 keeps separate", [adr["provenance_ref_id"]], "governance-separation"
    return "pass", "no component merges validation with application", [adr["provenance_ref_id"]], "governance-separation"


def _rule_requirement_trace(candidate: Mapping[str, Any], index: NormalizedIndex):
    requirements = index.by_class("requirement")
    refs = {r["provenance_ref_id"] for r in requirements} | {r["record_id"] for r in requirements}
    if not refs:
        return "unknown", "no requirements are pinned", [], "requirement-trace"
    cited = sorted({ref for c in candidate.get("components", []) for ref in c.get("evidence_refs", [])} & refs)
    # The evidence for either verdict is the requirement set that was examined, plus whatever the candidate cited.
    examined = cited or _index_refs(requirements[:6])
    untraced = [c["name"] for c in candidate.get("components", []) if not (set(c.get("evidence_refs", [])) & refs)
                and c.get("derivation") == "source"]
    if untraced:
        return "fail", f"source-derived component(s) {untraced} cite no requirement", examined, "requirement-trace"
    return "pass", "every source-derived component cites at least one requirement", examined, "requirement-trace"


def _rule_nfr_latency(candidate: Mapping[str, Any], index: NormalizedIndex):
    nfrs = [r for r in index.by_class("nfr") if r["payload"].get("category") == "latency"]
    if not nfrs:
        return "unknown", "no latency NFR is pinned", [], "nfr-latency"
    calls = [r for r in candidate.get("relationships", []) if r.get("kind") == "calls"]
    chained = max((_chain_depth(candidate, c["source"]) for c in calls), default=0)
    if chained > 3:
        return "fail", f"a call chain of depth {chained} cannot meet per-call deadlines stated in {len(nfrs)} NFR(s) without a budget", _index_refs(nfrs), "nfr-latency"
    return "pass", f"call chains are at most depth {chained} against {len(nfrs)} stated deadline(s)", _index_refs(nfrs), "nfr-latency"


def _chain_depth(candidate: Mapping[str, Any], start: str, seen: frozenset[str] = frozenset()) -> int:
    if start in seen:
        return 0
    nxt = [r["target"] for r in candidate.get("relationships", []) if r.get("kind") == "calls" and r["source"] == start]
    if not nxt:
        return 0
    return 1 + max(_chain_depth(candidate, t, seen | {start}) for t in nxt)


RULES: tuple[Rule, ...] = (
    Rule("RULE-SEC-NET-01", "security", "Network access matches the pinned deny-by-default policy", _rule_sec_network),
    Rule("RULE-DEP-TGT-01", "deployment", "Deployment environments and target are pinned standards", _rule_dep_target),
    Rule("RULE-API-AUTH-01", "api", "Every cataloged call target declares an auth capability", _rule_api_auth),
    Rule("RULE-INFRA-CAT-01", "infrastructure", "Source-derived components map to cataloged services", _rule_infra_catalog),
    Rule("RULE-COST-ENV-01", "cost_performance", "Replica footprint fits the pinned resource envelope", _rule_cost_envelope),
    Rule("RULE-ADR-CUR-01", "policy", "No reliance on superseded or unlabelled proposed ADRs", _rule_adr_superseded),
    Rule("RULE-GOV-SEP-01", "policy", "Governance responsibilities stay separated (ADR-003)", _rule_governance_separation),
    Rule("RULE-REQ-TRC-01", "requirement", "Source-derived components trace to requirements", _rule_requirement_trace),
    Rule("RULE-NFR-LAT-01", "nfr", "Call-chain depth is compatible with stated deadlines", _rule_nfr_latency),
)


class ConstraintChecker:
    version = ANALYZER_VERSION

    def __init__(self, index: NormalizedIndex, *, ledger: Any = None) -> None:
        self.index = index
        self.ledger = ledger

    def check(self, candidate: Mapping[str, Any], *, families: Iterable[str] | None = None) -> list[dict[str, Any]]:
        wanted = set(families) if families else None
        checks: list[dict[str, Any]] = []
        for rule in RULES:
            if wanted and rule.family not in wanted:
                continue
            result, message, refs, constraint_id = rule.check(candidate, self.index)
            doc = {"schema_id": "as.constraint_check/1", "rule_id": rule.rule_id, "family": rule.family,
                   "candidate_id": candidate["candidate_id"], "constraint_id": constraint_id, "result": result,
                   "message": message, "evidence_refs": refs, "analyzer": "constraint_checker",
                   "analyzer_version": self.version, "checked_at": fmt_ts(datetime.now(timezone.utc))}
            checks.append(validate("as.constraint_check/1", doc))
        if self.ledger is not None:
            self.ledger.append("analysis.constraints", actor="constraint_checker", actor_kind="analyzer",
                               outcome="recorded", subject=candidate["candidate_id"],
                               detail={"results": {c["rule_id"]: c["result"] for c in checks},
                                       "digest": digest_of(checks)})
        return checks

    @staticmethod
    def summarize(checks: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
        checks = list(checks)
        counts = {k: sum(1 for c in checks if c["result"] == k) for k in ("pass", "fail", "unknown")}
        return {"total": len(checks), **counts, "all_pass": counts["fail"] == 0 and counts["unknown"] == 0 and bool(checks),
                "unknown_is_not_pass": True}
