"""Identity, authentication and recorded human authority (XAUTH-01, XAUTH-05, XAUTH-07, WF-01).

Two identity kinds exist and are never conflated: a *human* principal, who can
hold accountability and grant authority, and a *service* principal, which
cannot. A model is neither — it is an instrument operated under a principal's
authority, which is why :class:`Principal` has no ``model`` kind and why
:func:`assert_not_self_attested` exists (XHITL-05, HUMAN-07, SEC-07).

Credentials issued here are narrowly scoped and short-lived (XAUTH-05): a lease
names one permission set, one path scope and one expiry, and it cannot be
renewed — a longer job takes a new lease, which produces a new audit record.

The provider here is the offline reference implementation. A real deployment
binds :class:`Principal` from the host identity provider through
:class:`IdentityBinding`; until one is bound, ``authenticate`` on the binding
fails closed and says so (this is the XAUTH-01 blocker, stated as code).

Adapted from the owner's Repository Context Graph runtime (``rcg/authority.py``).
"""
from __future__ import annotations

import hmac
import os
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable

from .canonical import canonical_bytes, fmt_ts, sha256_hex, sha256_of

__all__ = ["Principal", "AuthenticationError", "AuthorityError", "AuthorityRecord", "CredentialLease",
           "IdentityProvider", "IdentityBinding", "assert_not_self_attested", "MAX_LEASE_SECONDS",
           "DenialLog", "principal_from_record"]

MAX_LEASE_SECONDS = 900


class AuthenticationError(PermissionError):
    """Identity could not be established. Fail closed."""


class AuthorityError(PermissionError):
    """A privileged action lacks a recorded human authority."""


@dataclass(frozen=True)
class Principal:
    subject: str
    kind: str                      # "human" | "service"
    identity_provider: str
    authentication_method: str
    authenticated_at: datetime
    attributes: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.kind not in ("human", "service"):
            raise AuthenticationError(f"principal kind must be human or service, not {self.kind!r}")
        if not self.subject or self.subject != self.subject.strip():
            raise AuthenticationError("principal subject must be a non-empty, unpadded string")
        if self.subject.upper().startswith("REPLACE_") or any(ord(c) < 32 for c in self.subject):
            raise AuthenticationError("placeholder or control-character subject refused")

    @property
    def can_hold_accountability(self) -> bool:
        return self.kind == "human"

    def as_record(self) -> dict[str, Any]:
        return {"subject": self.subject, "kind": self.kind, "identity_provider": self.identity_provider,
                "authentication_method": self.authentication_method,
                "asserted_at": fmt_ts(self.authenticated_at)}


def principal_from_record(record: dict[str, Any]) -> Principal:
    return Principal(subject=record["subject"], kind=record["kind"], identity_provider=record["identity_provider"],
                     authentication_method=record["authentication_method"],
                     authenticated_at=datetime.fromisoformat(record["asserted_at"].replace("Z", "+00:00")))


@dataclass(frozen=True)
class CredentialLease:
    lease_id: str
    principal: str
    permissions: frozenset[str]
    path_scope: tuple[str, ...]
    external_systems: frozenset[str]
    issued_at: datetime
    expires_at: datetime
    _secret: bytes = field(repr=False, default=b"")

    def is_valid(self, now: datetime | None = None) -> bool:
        moment = now or datetime.now(timezone.utc)
        return self.issued_at <= moment < self.expires_at

    def authorizes(self, permission: str, now: datetime | None = None) -> bool:
        return self.is_valid(now) and permission in self.permissions

    def binding_digest(self) -> str:
        return sha256_of(canonical_bytes({
            "lease_id": self.lease_id, "principal": self.principal, "permissions": sorted(self.permissions),
            "path_scope": list(self.path_scope), "external_systems": sorted(self.external_systems),
            "issued_at": fmt_ts(self.issued_at), "expires_at": fmt_ts(self.expires_at)}))


@dataclass(frozen=True)
class AuthorityRecord:
    """XAUTH-07: the human authority under which a privileged action occurred."""

    authority_id: str
    human_principal: dict[str, Any]
    granted_permissions: tuple[str, ...]
    scope_digest: str
    granted_at: datetime
    expires_at: datetime
    grant_reference: str
    accountability_statement: str

    def is_current(self, now: datetime | None = None) -> bool:
        moment = now or datetime.now(timezone.utc)
        return self.granted_at <= moment < self.expires_at

    def covers(self, permission: str, scope_digest: str, now: datetime | None = None) -> bool:
        return (self.is_current(now) and permission in self.granted_permissions
                and hmac.compare_digest(self.scope_digest, scope_digest))

    def as_record(self) -> dict[str, Any]:
        return {"authority_id": self.authority_id, "human_principal": self.human_principal,
                "granted_permissions": list(self.granted_permissions), "scope_digest": self.scope_digest,
                "granted_at": fmt_ts(self.granted_at), "expires_at": fmt_ts(self.expires_at),
                "grant_reference": self.grant_reference,
                "accountability_statement": self.accountability_statement}


class DenialLog:
    """XAUTH-01: every authentication or authorization denial is recorded, never swallowed."""

    def __init__(self) -> None:
        self.entries: list[dict[str, Any]] = []

    def record(self, *, kind: str, subject: str | None, reason: str, resource: str | None = None,
               action: str | None = None) -> dict[str, Any]:
        entry = {"kind": kind, "subject": subject, "reason": reason, "resource": resource,
                 "action": action, "at": fmt_ts(datetime.now(timezone.utc))}
        self.entries.append(entry)
        return entry


class IdentityProvider:
    """Offline reference identity provider: constant-time secret comparison, no enumeration leak."""

    def __init__(self, name: str = "as.local", *, denials: DenialLog | None = None) -> None:
        self.name = name
        self.denials = denials or DenialLog()
        self._subjects: dict[str, tuple[str, str]] = {}
        self._leases: dict[str, CredentialLease] = {}
        self._revoked: set[str] = set()

    def enroll(self, subject: str, kind: str, secret: str) -> None:
        if kind not in ("human", "service"):
            raise AuthenticationError("kind must be human or service")
        self._subjects[subject] = (kind, sha256_hex(secret))

    def authenticate(self, subject: str, secret: str, *, method: str = "shared_secret",
                     now: datetime | None = None) -> Principal:
        record = self._subjects.get(subject)
        expected = record[1] if record else sha256_hex(os.urandom(32).hex())
        ok = hmac.compare_digest(expected, sha256_hex(secret))
        if not record or not ok or subject in self._revoked:
            self.denials.record(kind="authentication", subject=subject,
                                reason="unknown subject, bad secret or revoked identity")
            raise AuthenticationError(f"authentication failed for subject {subject!r}")
        return Principal(subject=subject, kind=record[0], identity_provider=self.name,
                         authentication_method=method, authenticated_at=now or datetime.now(timezone.utc))

    def revoke_subject(self, subject: str) -> None:
        """AUDIT-ADD-26: a revoked identity cannot authenticate again and its leases die."""
        self._revoked.add(subject)
        for lease_id, lease in list(self._leases.items()):
            if lease.principal == subject:
                del self._leases[lease_id]

    def issue_lease(self, principal: Principal, permissions: Iterable[str], *, path_scope: Iterable[str] = (),
                    external_systems: Iterable[str] = (), seconds: int = 300,
                    now: datetime | None = None) -> CredentialLease:
        if seconds > MAX_LEASE_SECONDS:
            raise AuthorityError(f"lease exceeds the {MAX_LEASE_SECONDS}s maximum")
        if principal.subject in self._revoked:
            raise AuthorityError("revoked principal cannot receive a lease")
        moment = now or datetime.now(timezone.utc)
        lease = CredentialLease(
            lease_id="LSE-" + secrets.token_hex(10), principal=principal.subject,
            permissions=frozenset(permissions), path_scope=tuple(path_scope),
            external_systems=frozenset(external_systems), issued_at=moment,
            expires_at=moment + timedelta(seconds=seconds), _secret=secrets.token_bytes(32))
        self._leases[lease.lease_id] = lease
        return lease

    def revoke_lease(self, lease_id: str) -> None:
        self._leases.pop(lease_id, None)

    def lease(self, lease_id: str) -> CredentialLease | None:
        return self._leases.get(lease_id)


class IdentityBinding:
    """The slot a real host identity provider occupies. Empty by default; fails closed."""

    def __init__(self) -> None:
        self._provider: IdentityProvider | None = None
        self._binding_ref: str | None = None

    def bind(self, provider: IdentityProvider, *, binding_ref: str) -> None:
        if not binding_ref or not binding_ref.strip():
            raise AuthorityError("binding an identity provider requires a reference to the human decision")
        self._provider = provider
        self._binding_ref = binding_ref.strip()

    @property
    def bound(self) -> bool:
        return self._provider is not None

    def describe(self) -> dict[str, Any]:
        return {"bound": self.bound, "provider": self._provider.name if self._provider else None,
                "binding_ref": self._binding_ref,
                "blocker": None if self.bound else
                "XAUTH-01: no infrastructure identity provider is bound; authentication fails closed"}

    def authenticate(self, subject: str, secret: str, **kw: Any) -> Principal:
        if self._provider is None:
            raise AuthenticationError("no identity provider is bound; refusing to establish identity")
        return self._provider.authenticate(subject, secret, **kw)


def assert_not_self_attested(actor_kind: str, gate: str) -> None:
    """XHITL-05 / SEC-07: the system may not approve or attest to its own work."""
    if actor_kind != "human":
        raise AuthorityError(f"gate {gate!r} requires a human approver; a {actor_kind} principal "
                             "cannot approve or attest")
