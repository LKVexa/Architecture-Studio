"""Named-principal roster and source-gap decision intake (ASFW-TODO-0001, 0007, 0008).

A display name typed in the implementer chat is an *offer*, not a binding, not a
review, and not Production GO. Binding a role requires an IdP subject, a
distinct independent counterpart, and a role the offered title may actually
hold. One person cannot occupy every independent review slot.

Source-gap decisions may only *keep undefined* or *refuse to invent*. They
cannot mint ``DOD-02/04/05/08/09`` text or a ninth ``GATE-PROD`` gate, and a
recorded keep-undefined decision still blocks GO.
"""
from __future__ import annotations

import json
from typing import Any, Mapping

from .canonical import digest_of, now_iso
from .evidence_io import atomic_write
from .fixtures import OVERLAY_ROOT
from .gates import GATES
from .asfw import ASFW_IMPLEMENTER_SUBJECTS, EXECUTABLE_GATE_IDS, MISSING_DOD_IDS, PDF_GATE_RANGE_CLAIM

__all__ = [
    "ROSTER_VERSION",
    "REQUIRED_ROLES",
    "INDEPENDENT_ROLES",
    "OWNER_ROLES",
    "INDEPENDENCE_PAIRS",
    "RosterError",
    "offer_principal",
    "bind_role",
    "interpret_as_review",
    "record_source_gap_decision",
    "roster_document",
    "export_roster",
    "TITLE_ELIGIBLE_ROLES",
    "RECEIVED_CHAT_OFFER",
    "CHAT_IMPLEMENTER_SESSION",
]

ROSTER_VERSION = "1.0.0"
CHAT_IMPLEMENTER_SESSION = "grok_chat_implementer_session"

#: Display-name offer received in the implementer chat on 2026-09-11. Not a binding.
RECEIVED_CHAT_OFFER: dict[str, Any] = {
    "display_name": "RUSSELL PHILIP SMITHSON",
    "title": "Research Specialist",
    "organization": "LK/Vexa",
    "channel": CHAT_IMPLEMENTER_SESSION,
    "idp_subject": None,
    "signature_text": "RUSSELL PHILIP SMITHSON – Research Specialist – LK/Vexa",
}

OWNER_ROLES: tuple[str, ...] = (
    "product_owner",
    "security_privacy_owner",
    "architecture_owner",
    "ml_evaluation_owner",
    "incident_response_owner",
    "human_review_policy_owner",
    "release_owner",
    "identity_owner",
    "crypto_owner",
)
INDEPENDENT_ROLES: tuple[str, ...] = (
    "independent_security_reviewer",
    "independent_architecture_reviewer",
    "independent_evaluation_reviewer",
    "independent_operations_reviewer",
    "independent_verifier",
)
CONSULTED_ROLES: tuple[str, ...] = ("research_specialist",)
REQUIRED_ROLES: tuple[str, ...] = OWNER_ROLES + INDEPENDENT_ROLES

INDEPENDENCE_PAIRS: tuple[tuple[str, str], ...] = (
    ("security_privacy_owner", "independent_security_reviewer"),
    ("architecture_owner", "independent_architecture_reviewer"),
    ("ml_evaluation_owner", "independent_evaluation_reviewer"),
    ("incident_response_owner", "independent_operations_reviewer"),
    ("release_owner", "independent_verifier"),
    ("product_owner", "independent_verifier"),
)

#: Title → roles this intake will even *propose*. Everything else is refused.
TITLE_ELIGIBLE_ROLES: dict[str, tuple[str, ...]] = {
    "research specialist": CONSULTED_ROLES,
}

ALLOWED_GAP_DECISIONS = frozenset({
    "KEEP_UNDEFINED_STILL_BLOCKING",
    "DO_NOT_INFER_STILL_BLOCKING",
    "REFUSE_TO_INVENT_STILL_BLOCKING",
})
FORBIDDEN_GAP_DECISIONS = frozenset({
    "INVENT_DOD_TEXT",
    "ADD_NINTH_GATE",
    "MARK_RESOLVED",
    "ACCEPT_RISK_AS_PASS",
    "UNBLOCK_GO",
})


class RosterError(PermissionError):
    """The roster refuses the requested authority act."""


def _norm(value: str) -> str:
    return " ".join(str(value or "").strip().lower().split())


def _subject_key(offer: Mapping[str, Any]) -> str:
    idp = offer.get("idp_subject")
    if idp:
        return str(idp).strip()
    name = _norm(str(offer.get("display_name") or ""))
    org = _norm(str(offer.get("organization") or ""))
    return f"unbound:{name}|{org}" if name else "unbound:anonymous"


def independence_of_offer(offer: Mapping[str, Any]) -> dict[str, Any]:
    """A same-session chat signature is not independent of the implementer."""
    channel = str(offer.get("channel") or CHAT_IMPLEMENTER_SESSION)
    idp = offer.get("idp_subject")
    same_session = channel == CHAT_IMPLEMENTER_SESSION
    return {
        "channel": channel,
        "idp_bound": bool(idp),
        "idp_subject": idp or None,
        "same_session_as_implementer": same_session,
        "identity_proof": "idp_subject" if idp else "display_name_only",
        "independent_of_implementer": bool(idp) and not same_session,
        "status": "ESTABLISHED" if (idp and not same_session) else "NOT_ESTABLISHED",
    }


def eligible_roles_for_title(title: str) -> tuple[str, ...]:
    return TITLE_ELIGIBLE_ROLES.get(_norm(title), ())


def offer_principal(offer: Mapping[str, Any]) -> dict[str, Any]:
    """Record a named human as a proposal. Does not bind roles or review anything."""
    display_name = str(offer.get("display_name") or "").strip()
    if not display_name:
        raise RosterError("an offer requires a display name")
    title = str(offer.get("title") or "").strip()
    organization = str(offer.get("organization") or "").strip()
    eligible = list(eligible_roles_for_title(title))
    refused = {
        role: "title does not qualify this person for an accountable or independent production role"
        for role in REQUIRED_ROLES
        if role not in eligible
    }
    independence = independence_of_offer(offer)
    subject = _subject_key(offer)
    if subject in ASFW_IMPLEMENTER_SUBJECTS or display_name in ASFW_IMPLEMENTER_SUBJECTS:
        raise RosterError("the implementer/runtime cannot be offered as a roster principal")
    record = {
        "schema_id": "as.roster_offer/1",
        "record_kind": "principal_offer",
        "roster_version": ROSTER_VERSION,
        "status": "PROPOSED_UNBOUND",
        "unblocks_go": False,
        "display_name": display_name,
        "title": title,
        "organization": organization,
        "subject_key": subject,
        "signature_text": offer.get("signature_text") or f"{display_name} – {title} – {organization}",
        "independence": independence,
        "eligible_roles": eligible,
        "refused_roles": refused,
        "bound_roles": [],
        "offered_at": offer.get("offered_at") or now_iso(),
        "note": (
            "A chat signature is an offer of identity, not an IdP binding, not a gate review, "
            "and not independent verification. Named persons stay UNSET on ASFW items until bind_role succeeds."
        ),
    }
    record["digest"] = digest_of({k: record[k] for k in record if k != "digest"})
    return record


def bind_role(role: str, offer: Mapping[str, Any], *, already_bound: Mapping[str, str] | None = None) -> dict[str, Any]:
    """Bind one role to a principal. Fail-closed on independence, title, and collisions."""
    already_bound = dict(already_bound or {})
    if role not in REQUIRED_ROLES and role not in CONSULTED_ROLES:
        raise RosterError(f"unknown role {role!r}")
    offer_record = offer_principal(offer) if "schema_id" not in offer else dict(offer)
    independence = offer_record.get("independence") or independence_of_offer(offer)
    if not independence.get("idp_bound"):
        raise RosterError("role binding requires an IdP subject; a display name is not a binding")
    if not independence.get("independent_of_implementer"):
        raise RosterError("role binding requires a principal independent of the implementer session")
    subject = str(independence.get("idp_subject") or offer_record["subject_key"])
    if subject in ASFW_IMPLEMENTER_SUBJECTS:
        raise RosterError("the implementer cannot bind a roster role")
    title = str(offer_record.get("title") or offer.get("title") or "")
    eligible = eligible_roles_for_title(title)
    if role in REQUIRED_ROLES and role not in eligible:
        raise RosterError(
            f"title {title!r} is not eligible for {role}; eligible={list(eligible) or ['none']}"
        )
    if role in INDEPENDENT_ROLES:
        for owner_role, independent_role in INDEPENDENCE_PAIRS:
            if independent_role == role and already_bound.get(owner_role) == subject:
                raise RosterError(f"{subject} already holds {owner_role} and cannot be {role}")
    if role in OWNER_ROLES:
        for owner_role, independent_role in INDEPENDENCE_PAIRS:
            if owner_role == role and already_bound.get(independent_role) == subject:
                raise RosterError(f"{subject} already holds {independent_role} and cannot be {role}")
    held = [r for r, s in already_bound.items() if s == subject]
    if role in INDEPENDENT_ROLES and any(r in INDEPENDENT_ROLES for r in held):
        raise RosterError("one person cannot occupy multiple independent review roles")
    if role in OWNER_ROLES and any(r in OWNER_ROLES for r in held):
        raise RosterError("one person cannot occupy multiple accountable owner roles")
    return {
        "role": role,
        "subject": subject,
        "status": "BOUND",
        "independence": independence["status"],
    }


def interpret_as_review(offer: Mapping[str, Any], *, gate_id: str | None = None,
                        item_id: str | None = None) -> None:
    """A chat signature is never a gate or ASFW review."""
    independence = independence_of_offer(offer)
    target = gate_id or item_id or "unspecified"
    raise RosterError(
        f"chat signature from {offer.get('display_name')!r} is not a review of {target}: "
        f"independence={independence['status']}, idp_bound={independence['idp_bound']}, "
        "evidence_digest missing, reviewer_kind not independently attested"
    )


def record_source_gap_decision(kind: str, decision: str, *, offer: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Record keep-undefined / do-not-infer. Never invents missing source content."""
    if decision in FORBIDDEN_GAP_DECISIONS:
        raise RosterError(f"forbidden source-gap decision {decision!r}")
    if decision not in ALLOWED_GAP_DECISIONS:
        raise RosterError(f"unknown source-gap decision {decision!r}")
    offer_record = offer_principal(offer) if offer else None
    if kind == "DOD":
        body = {
            "decision_id": "DEC-ASFW-0007",
            "asfw_items": ["ASFW-TODO-0007"],
            "missing_ids": list(MISSING_DOD_IDS),
            "invented_definitions": False,
            "definitions": {dod: None for dod in MISSING_DOD_IDS},
            "instruction": "do not invent DOD text",
        }
    elif kind == "GATE_COUNT":
        body = {
            "decision_id": "DEC-ASFW-0008",
            "asfw_items": ["ASFW-TODO-0008", "ASFW-TODO-0311"],
            "pdf_claim": PDF_GATE_RANGE_CLAIM,
            "executable_gates": list(EXECUTABLE_GATE_IDS),
            "executable_count": len(EXECUTABLE_GATE_IDS),
            "ninth_gate_invented": False,
            "ninth_gate_id": None,
            "instruction": "do not invent a ninth production gate",
            "registry_and_pdf_agree": False,
        }
    else:
        raise RosterError(f"unknown source-gap kind {kind!r}")
    record = {
        "schema_id": "as.source_completeness_decision/1",
        "record_kind": "source_completeness_decision",
        "kind": kind,
        "decision": decision,
        "status": decision,
        "unblocks_go": False,
        "authority_binding": (offer_record or {}).get("independence", {}).get("status", "NOT_ESTABLISHED"),
        "offered_by": offer_record,
        "gates_named_in_runtime": [g.gate_id for g in GATES],
        **body,
        "recorded_at": now_iso(),
        "note": (
            "This records the fail-closed instruction. It is not Architecture Authority sign-off "
            "and it does not make Production GO representable."
        ),
    }
    record["digest"] = digest_of({k: record[k] for k in record if k != "digest"})
    return record


def roster_document(*, offer: Mapping[str, Any] | None = None,
                    dod_decision: Mapping[str, Any] | None = None,
                    gate_decision: Mapping[str, Any] | None = None) -> dict[str, Any]:
    offer_record = offer_principal(offer) if offer else None
    rows = []
    for role in REQUIRED_ROLES:
        rows.append({
            "role": role,
            "subject": None,
            "status": "UNSET",
            "eligible_for_offered_title": bool(
                offer_record and role in offer_record["eligible_roles"]
            ),
        })
    consulted = []
    if offer_record:
        for role in offer_record["eligible_roles"]:
            consulted.append({
                "role": role,
                "subject_key": offer_record["subject_key"],
                "display_name": offer_record["display_name"],
                "status": "PROPOSED_UNBOUND",
            })
    return {
        "schema_id": "as.roster/1",
        "roster_version": ROSTER_VERSION,
        "production_go": "NO_GO",
        "bound_count": 0,
        "required_roles": list(REQUIRED_ROLES),
        "rows": rows,
        "consulted_proposed": consulted,
        "offer": offer_record,
        "source_gaps": {
            "dod": dod_decision,
            "gate_count": gate_decision,
        },
        "unblocks_go": False,
        "note": (
            "Every required role is UNSET. The offered principal is proposed as consulted "
            "research_specialist only. Independent review slots stay empty."
        ),
    }


def export_roster(directory=None, *, document: Mapping[str, Any] | None = None) -> dict[str, Any]:
    directory = OVERLAY_ROOT / "evidence" / "reviews" if directory is None else directory
    directory.mkdir(parents=True, exist_ok=True)
    document = dict(document) if document is not None else roster_document()
    written = []
    payload = json.dumps(document, indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8")
    atomic_write(directory / "roster-proposal.json", payload)
    written.append("roster-proposal.json")
    offer = document.get("offer")
    if offer:
        atomic_write(
            directory / "principal-offer.json",
            json.dumps(offer, indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8"),
        )
        written.append("principal-offer.json")
    gaps = document.get("source_gaps") or {}
    if gaps.get("dod"):
        atomic_write(
            directory / "DEC-ASFW-0007.json",
            json.dumps(gaps["dod"], indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8"),
        )
        written.append("DEC-ASFW-0007.json")
    if gaps.get("gate_count"):
        atomic_write(
            directory / "DEC-ASFW-0008.json",
            json.dumps(gaps["gate_count"], indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8"),
        )
        written.append("DEC-ASFW-0008.json")
    return {
        "directory": str(directory),
        "written": written,
        "production_go": "NO_GO",
        "note": "proposal and keep-undefined records only; no gate PASS files were written",
    }
