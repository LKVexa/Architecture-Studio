"""Canonical schema registry and validator (IMPL-02, API-01..08, XTOOL-02, MODEL-04, AUDIT-ADD-05).

Every payload that crosses a trust boundary — connector output, normalized
artifact, tool call and result, model output, candidate, comparison, question,
review decision, approval token, audit event, error envelope — is validated
here before it is used. Validation is structural and total: unknown keys are a
failure, not a warning, so a connector cannot smuggle a field past the identity
layer and a model cannot introduce a field the schema did not ask for.

The validator is dependency-free on purpose: the product must keep working in
the air-gapped sandbox profile where no third-party package is installable
(ENV-01/ENV-06), and on the owner's device (CPython 3.10, jsonschema 3.2.0)
where the sealed package's own checker cannot run.

Adapted from the owner's Repository Context Graph runtime (``rcg/schemas.py``);
the registered contracts are this package's.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

__all__ = ["SchemaError", "Schema", "REGISTRY", "validate", "schema_versions", "register",
           "SCHEMA_REGISTRY_VERSION", "export_schemas", "is_registered"]

SCHEMA_REGISTRY_VERSION = "1.0.0"

_ISO = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$")
_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")
_ID = re.compile(r"^[A-Z]{2,4}-[0-9a-f]{20}$")


class SchemaError(ValueError):
    def __init__(self, schema_id: str, path: str, message: str) -> None:
        self.schema_id = schema_id
        self.path = path
        super().__init__(f"{schema_id}{path}: {message}")


@dataclass(frozen=True)
class Schema:
    schema_id: str
    version: str
    fields: dict[str, dict[str, Any]]
    description: str = ""

    def required(self) -> tuple[str, ...]:
        return tuple(k for k, spec in self.fields.items() if spec.get("required", True))


REGISTRY: dict[str, Schema] = {}


def register(schema: Schema) -> Schema:
    if schema.schema_id in REGISTRY:
        raise ValueError(f"duplicate schema id {schema.schema_id!r}")
    REGISTRY[schema.schema_id] = schema
    return schema


def is_registered(schema_id: str) -> bool:
    return schema_id in REGISTRY


_TYPES: dict[str, type | tuple[type, ...]] = {
    "string": str, "integer": int, "number": (int, float), "boolean": bool,
    "object": dict, "array": list,
}


def _check_value(schema_id: str, path: str, spec: dict[str, Any], value: Any) -> None:
    kind = spec["type"]
    if value is None:
        if spec.get("nullable"):
            return
        raise SchemaError(schema_id, path, "null is not permitted")
    if kind == "any":
        return
    expected = _TYPES[kind]
    if kind in ("integer", "number") and isinstance(value, bool):
        raise SchemaError(schema_id, path, f"expected {kind}, got boolean")
    if not isinstance(value, expected):
        raise SchemaError(schema_id, path, f"expected {kind}, got {type(value).__name__}")
    if "const" in spec and value != spec["const"]:
        raise SchemaError(schema_id, path, f"must equal {spec['const']!r}")
    if kind == "string":
        if "enum" in spec and value not in spec["enum"]:
            raise SchemaError(schema_id, path, f"{value!r} not in {sorted(spec['enum'])}")
        fmt = spec.get("format")
        if fmt == "timestamp" and not _ISO.match(value):
            raise SchemaError(schema_id, path, "not a timezone-qualified ISO-8601 timestamp")
        if fmt == "digest" and not _DIGEST.match(value):
            raise SchemaError(schema_id, path, "not a sha256:<hex> digest")
        if fmt == "id" and not _ID.match(value):
            raise SchemaError(schema_id, path, "not a deterministic identifier")
        if "pattern" in spec and not re.match(spec["pattern"], value):
            raise SchemaError(schema_id, path, f"does not match {spec['pattern']}")
        if spec.get("min_length") and len(value) < spec["min_length"]:
            raise SchemaError(schema_id, path, f"shorter than {spec['min_length']}")
        if spec.get("max_length") and len(value) > spec["max_length"]:
            raise SchemaError(schema_id, path, f"longer than {spec['max_length']}")
    if kind in ("integer", "number"):
        if "minimum" in spec and value < spec["minimum"]:
            raise SchemaError(schema_id, path, f"below minimum {spec['minimum']}")
        if "maximum" in spec and value > spec["maximum"]:
            raise SchemaError(schema_id, path, f"above maximum {spec['maximum']}")
    if kind == "array":
        item = spec.get("items")
        if spec.get("min_items") and len(value) < spec["min_items"]:
            raise SchemaError(schema_id, path, f"needs at least {spec['min_items']} items")
        if spec.get("max_items") is not None and len(value) > spec["max_items"]:
            raise SchemaError(schema_id, path, f"more than {spec['max_items']} items")
        if spec.get("unique_items"):
            seen = []
            for element in value:
                if element in seen:
                    raise SchemaError(schema_id, path, "items must be unique")
                seen.append(element)
        if item:
            for i, element in enumerate(value):
                _check_value(schema_id, f"{path}[{i}]", item, element)
    if kind == "object" and "properties" in spec:
        _check_object(schema_id, path, spec["properties"], value, spec.get("additional", False))


def _check_object(schema_id: str, path: str, fields: dict[str, dict[str, Any]], payload: Any,
                  additional: bool) -> None:
    if not isinstance(payload, dict):
        raise SchemaError(schema_id, path, f"expected object, got {type(payload).__name__}")
    for name, spec in fields.items():
        if name not in payload:
            if spec.get("required", True):
                raise SchemaError(schema_id, f"{path}.{name}", "required field missing")
            continue
        _check_value(schema_id, f"{path}.{name}", spec, payload[name])
    if not additional:
        unknown = sorted(set(payload) - set(fields))
        if unknown:
            raise SchemaError(schema_id, path, f"unknown field(s): {', '.join(unknown)}")


def validate(schema_id: str, payload: Any) -> dict[str, Any]:
    """Validate and return the payload, or raise :class:`SchemaError`."""
    try:
        schema = REGISTRY[schema_id]
    except KeyError:
        raise SchemaError(schema_id, "", "no such schema registered") from None
    _check_object(schema_id, "", schema.fields, payload, additional=False)
    declared = payload.get("schema_id")
    if declared is not None and declared != schema_id:
        raise SchemaError(schema_id, ".schema_id", f"payload declares {declared!r}")
    return payload


def schema_versions() -> dict[str, str]:
    return {sid: s.version for sid, s in sorted(REGISTRY.items())}


def export_schemas() -> dict[str, Any]:
    """A JSON projection of every registered contract (DOC-07/DOC-08 inputs)."""
    return {
        "registry_version": SCHEMA_REGISTRY_VERSION,
        "schemas": {sid: {"version": s.version, "description": s.description, "fields": s.fields}
                    for sid, s in sorted(REGISTRY.items())},
    }


# --------------------------------------------------------------------------- #
# Shared fragments                                                              #
# --------------------------------------------------------------------------- #
_S = "string"
DERIVATIONS = ("source", "deterministic_analyzer", "model_inference", "human")
EVIDENCE_STATES = ("current", "stale", "missing", "conflict", "unverifiable")
UNCERTAINTY_STATES = ("known", "supported", "inferred", "uncertain", "stale", "missing", "out_of_scope")
DATA_CLASSES = ("requirement", "nfr", "adr", "api_operation", "service", "diagram",
                "security_constraint", "cost_perf_constraint", "deployment_standard", "document")
CLASSIFICATIONS = ("public", "internal", "confidential", "secret")
PERMISSIONS = ("read", "analyze", "draft", "modify", "commit", "approve", "deploy", "communicate",
               "install", "network_read", "network_write", "credential_use", "write_evidence")
DECISIONS = ("approve", "reject", "edit", "narrow_scope", "request_more_evidence")
OPTION_EVENTS = ("introduced", "modified", "forked", "compared", "discarded", "selected_for_review",
                 "reinstated", "annotated")
VALUE_KINDS = ("qualitative", "quantitative", "unknown", "not_applicable")

_TS = {"type": _S, "format": "timestamp"}
_DG = {"type": _S, "format": "digest"}
_STR_LIST = {"type": "array", "items": {"type": _S}}

_EVIDENCE_REF_FIELDS = {
    "schema_id": {"type": _S, "const": "as.evidence_ref/1"},
    "artifact_id": {"type": _S, "min_length": 1},
    "source_system": {"type": _S, "min_length": 1},
    "revision": {"type": _S, "min_length": 1},
    "source_hash": _DG,
    "location": {"type": _S, "nullable": True},
    "span": {"type": _S, "nullable": True},
    "retrieval_event": {"type": _S, "nullable": True},
    "transformation_chain": _STR_LIST,
    "evidence_status": {"type": _S, "enum": list(EVIDENCE_STATES)},
    "derivation": {"type": _S, "enum": list(DERIVATIONS)},
    "analyzer": {"type": _S, "nullable": True},
    "observed_at": _TS,
}

_UNCERTAINTY_FIELDS = {
    "schema_id": {"type": _S, "const": "as.uncertainty/1"},
    "state": {"type": _S, "enum": list(UNCERTAINTY_STATES)},
    "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0, "nullable": True},
    "calibrated": {"type": "boolean"},
    "calibration_ref": {"type": _S, "nullable": True},
    "stale": {"type": "boolean"},
    "missing": {"type": "boolean"},
    "conflict": {"type": "boolean"},
    "abstained": {"type": "boolean"},
    "abstention_code": {"type": _S, "nullable": True, "enum": [
        "INSUFFICIENT_EVIDENCE", "OUT_OF_SCOPE", "MISSING_CONTEXT", "CONFLICTING_EVIDENCE",
        "STALE_CONTEXT", "GENERIC_FALLBACK", "PROVIDER_UNAVAILABLE", "POLICY_STOP",
        "UNCALIBRATED_SCORE", "HUMAN_DECISION_REQUIRED"]},
    "rationale": {"type": _S, "nullable": True},
    "missing_context": _STR_LIST,
    "requires_human_review": {"type": "boolean"},
}

_PRINCIPAL_FIELDS = {
    "subject": {"type": _S, "min_length": 1},
    "kind": {"type": _S, "enum": ["human", "service"]},
    "identity_provider": {"type": _S, "min_length": 1},
    "authentication_method": {"type": _S, "min_length": 1},
    "asserted_at": _TS,
}

# --------------------------------------------------------------------------- #
# Registered contracts                                                          #
# --------------------------------------------------------------------------- #
register(Schema("as.scope_contract/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.scope_contract/1"},
    "run_id": {"type": _S, "min_length": 1},
    "subject": {"type": _S, "min_length": 1},
    "tenant": {"type": _S, "min_length": 1},
    "project": {"type": _S, "min_length": 1},
    "source_set": {"type": "array", "items": {"type": _S}, "min_items": 1, "unique_items": True},
    "revision_bounds": {"type": "object", "additional": True, "properties": {}},
    "allowed_artifact_classes": {"type": "array", "items": {"type": _S, "enum": list(DATA_CLASSES)}},
    "allowed_actions": {"type": "array", "items": {"type": _S, "enum": list(PERMISSIONS)}, "unique_items": True},
    "write_authority": {"type": _S, "enum": ["none", "draft", "modify"]},
    "reviewer_authority": _STR_LIST,
    "approval_rights": _STR_LIST,
    "authorized_paths": _STR_LIST,
    "denied_paths": _STR_LIST,
    "data_handling_profile": {"type": _S, "enum": list(CLASSIFICATIONS)},
    "issued_at": _TS,
    "expires_at": _TS,
    "issuer_ref": {"type": _S, "min_length": 1},
    "human_authority_ref": {"type": _S, "min_length": 1},
    "policy_version": {"type": _S, "min_length": 1},
    "mode": {"type": _S, "enum": ["read_only", "draft_only", "modify"]},
}, "IMPL-01 machine-readable scope contract; API-02 scope/authority schema."))

register(Schema("as.evidence_ref/1", "1.0.0", dict(_EVIDENCE_REF_FIELDS),
                "API-03 evidence/provenance reference."))

register(Schema("as.uncertainty/1", "1.0.0", dict(_UNCERTAINTY_FIELDS),
                "API-04 uncertainty/confidence and abstention reason."))

register(Schema("as.review_decision/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.review_decision/1"},
    "decision_id": {"type": _S, "format": "id"},
    "run_id": {"type": _S, "min_length": 1},
    "gate": {"type": _S, "min_length": 1},
    "decision": {"type": _S, "enum": list(DECISIONS)},
    "approver_identity": {"type": "object", "properties": dict(_PRINCIPAL_FIELDS)},
    "approved_scope_digest": _DG,
    "subject_digest": _DG,
    "artifact_ids": _STR_LIST,
    "decided_at": _TS,
    "rationale": {"type": _S, "nullable": True},
    "requested_changes": _STR_LIST,
    "requested_evidence": _STR_LIST,
    "narrowed_scope": {"type": "object", "nullable": True, "additional": True, "properties": {}},
    "policy_version": {"type": _S, "min_length": 1},
    "accountability": {"type": _S, "min_length": 1},
    "supersedes": {"type": _S, "nullable": True},
}, "API-05 human review decision and approver identity; HUMAN-06; STORE-04."))

register(Schema("as.connector_record/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.connector_record/1"},
    "artifact_id": {"type": _S, "format": "id"},
    "source_system": {"type": _S, "min_length": 1},
    "data_class": {"type": _S, "enum": list(DATA_CLASSES)},
    "tenant": {"type": _S, "min_length": 1},
    "project": {"type": _S, "min_length": 1},
    "path": {"type": _S, "min_length": 1},
    "revision": {"type": _S, "min_length": 1},
    "source_hash": _DG,
    "classification": {"type": _S, "enum": list(CLASSIFICATIONS)},
    "freshness": {"type": _S, "enum": ["CURRENT", "STALE", "UNKNOWN"]},
    "observed_at": _TS,
    "record_id": {"type": _S, "min_length": 1},
    "payload": {"type": "object", "additional": True, "properties": {}},
    "provenance": {"type": "object", "properties": dict(_EVIDENCE_REF_FIELDS)},
    "schema_version": {"type": _S, "min_length": 1},
}, "IMPL-02 / WF-04 normalized connector record; DATA-01..09 share this envelope."))

register(Schema("as.tool_call/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.tool_call/1"},
    "tool": {"type": _S, "pattern": r"^[a-z][a-z0-9_.]{1,63}$"},
    "tool_version": {"type": _S, "min_length": 1},
    "arguments": {"type": "object", "additional": True, "properties": {}},
    "requested_permission": {"type": _S, "enum": list(PERMISSIONS)},
    "requested_paths": _STR_LIST,
    "requested_source_systems": _STR_LIST,
    "external_system": {"type": _S, "nullable": True},
    "actor_kind": {"type": _S, "enum": ["human", "service", "model", "analyzer", "system"]},
    "idempotency_key": {"type": _S, "nullable": True},
}, "XTOOL-02 / SEC-02 tool-call argument contract."))

register(Schema("as.tool_result/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.tool_result/1"},
    "tool": {"type": _S, "min_length": 1},
    "tool_version": {"type": _S, "min_length": 1},
    "status": {"type": _S, "enum": ["ok", "denied", "failed", "timeout", "truncated", "unavailable"]},
    "result": {"type": "any"},
    "diagnostics": _STR_LIST,
    "duration_ms": {"type": "integer", "minimum": 0},
    "fallback_used": {"type": "boolean"},
}, "XTOOL-02 / XTOOL-07 tool-result contract with typed failure states."))

register(Schema("as.error/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.error/1"},
    "code": {"type": _S, "pattern": r"^[A-Z][A-Z0-9_.]{2,80}$"},
    "message": {"type": _S, "min_length": 1},
    "boundary": {"type": _S, "min_length": 1},
    "retriable": {"type": "boolean"},
    "detail_digest": {"type": _S, "format": "digest", "nullable": True},
    "occurred_at": _TS,
}, "IMPL-02 / API-01 typed, auditable error envelope; values are never echoed."))

register(Schema("as.audit_event/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.audit_event/1"},
    "sequence": {"type": "integer", "minimum": 0},
    "run_id": {"type": _S, "min_length": 1},
    "event_type": {"type": _S, "min_length": 1},
    "actor": {"type": _S, "min_length": 1},
    "actor_kind": {"type": _S, "enum": ["human", "service", "model", "analyzer", "system"]},
    "authority_ref": {"type": _S, "nullable": True},
    "subject": {"type": _S, "nullable": True},
    "outcome": {"type": _S, "enum": ["allowed", "denied", "failed", "abstained", "recorded"]},
    "detail_digest": _DG,
    "occurred_at": _TS,
    "previous_digest": {"type": _S, "nullable": True},
    "writer": {"type": _S, "min_length": 1},
}, "IMPL-09 / STORE-07 / XPROV-06 append-only audit event."))

register(Schema("as.model_output/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.model_output/1"},
    "kind": {"type": _S, "enum": ["candidates", "comparison", "questions", "assumptions",
                                  "review_summary", "abstention"]},
    "statements": {"type": "array", "items": {"type": "object", "properties": {
        "text": {"type": _S, "min_length": 1},
        "derivation": {"type": _S, "enum": list(DERIVATIONS)},
        "evidence_refs": _STR_LIST,
        "impact": {"type": _S, "enum": ["low", "medium", "high"]},
    }}},
    "payload": {"type": "object", "additional": True, "properties": {}},
    "uncertainty": {"type": "object", "properties": dict(_UNCERTAINTY_FIELDS)},
    "model": {"type": "object", "properties": {
        "provider": {"type": _S, "min_length": 1},
        "model_id": {"type": _S, "min_length": 1},
        "model_version": {"type": _S, "min_length": 1},
        "prompt_id": {"type": _S, "min_length": 1},
        "prompt_version": {"type": _S, "min_length": 1},
        "decoding_digest": _DG,
        "context_manifest_digest": _DG,
    }},
}, "MODEL-04 structured, schema-validated model output; MODEL-05 evidence refs; MODEL-01 pinning."))

_COMPONENT = {"type": "object", "properties": {
    "element_id": {"type": _S, "min_length": 1},
    "name": {"type": _S, "min_length": 1},
    "kind": {"type": _S, "enum": ["service", "store", "queue", "gateway", "worker", "ui", "external",
                                  "library", "job", "sandbox", "policy_point"]},
    "responsibilities": _STR_LIST,
    "evidence_refs": _STR_LIST,
    "derivation": {"type": _S, "enum": list(DERIVATIONS)},
    "catalog_ref": {"type": _S, "nullable": True},
    "replicas": {"type": "integer", "minimum": 0, "nullable": True, "required": False},
}}
_RELATIONSHIP = {"type": "object", "properties": {
    "element_id": {"type": _S, "min_length": 1},
    "source": {"type": _S, "min_length": 1},
    "target": {"type": _S, "min_length": 1},
    "kind": {"type": _S, "enum": ["calls", "reads", "writes", "publishes", "subscribes", "deploys_to",
                                  "depends_on", "guards", "isolates"]},
    "evidence_refs": _STR_LIST,
    "derivation": {"type": _S, "enum": list(DERIVATIONS)},
}}

register(Schema("as.candidate/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.candidate/1"},
    "candidate_id": {"type": _S, "format": "id"},
    "run_id": {"type": _S, "min_length": 1},
    "iteration": {"type": "integer", "minimum": 0},
    "name": {"type": _S, "min_length": 1},
    "style": {"type": _S, "min_length": 1},
    "components": {"type": "array", "items": _COMPONENT, "min_items": 1},
    "relationships": {"type": "array", "items": _RELATIONSHIP},
    "deployment": {"type": "object", "properties": {
        "topology": {"type": _S, "min_length": 1},
        "environments": _STR_LIST,
        "standard_refs": _STR_LIST,
        "evidence_refs": _STR_LIST,
    }},
    "dependencies": _STR_LIST,
    "assumptions": _STR_LIST,
    "rationale": {"type": "array", "items": {"type": "object", "properties": {
        "text": {"type": _S, "min_length": 1},
        "derivation": {"type": _S, "enum": list(DERIVATIONS)},
        "evidence_refs": _STR_LIST,
    }}},
    "risks": {"type": "array", "items": {"type": "object", "properties": {
        "text": {"type": _S, "min_length": 1},
        "severity": {"type": _S, "enum": ["low", "medium", "high"]},
        "evidence_refs": _STR_LIST,
    }}},
    "evidence_refs": _STR_LIST,
    "constraint_impacts": {"type": "array", "items": {"type": "object", "properties": {
        "constraint_id": {"type": _S, "min_length": 1},
        "result": {"type": _S, "enum": ["pass", "fail", "unknown"]},
        "rule_id": {"type": _S, "min_length": 1},
        "evidence_refs": _STR_LIST,
    }}},
    "uncertainty": {"type": "object", "properties": dict(_UNCERTAINTY_FIELDS)},
    "diagram_mapping": {"type": "object", "additional": True, "properties": {}},
    "lifecycle": {"type": "object", "properties": {
        "state": {"type": _S, "enum": ["introduced", "modified", "discarded", "selected_for_review",
                                       "superseded"]},
        "introduced_by": {"type": _S, "min_length": 1},
        "parent_candidate_id": {"type": _S, "nullable": True},
        "event_ids": _STR_LIST,
    }},
    "structure_digest": _DG,
    "generator": {"type": "object", "properties": {
        "generator_id": {"type": _S, "min_length": 1},
        "generator_version": {"type": _S, "min_length": 1},
        "model": {"type": "object", "nullable": True, "additional": True, "properties": {}},
    }},
    "candidate_schema_version": {"type": _S, "min_length": 1},
}, "AUDIT-ADD-05 canonical architecture-candidate model consumed by generator, comparer, checker, "
   "diagrammer, reviewer and ledger."))

register(Schema("as.comparison/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.comparison/1"},
    "comparison_id": {"type": _S, "format": "id"},
    "run_id": {"type": _S, "min_length": 1},
    "candidate_ids": {"type": "array", "items": {"type": _S}, "min_items": 2, "unique_items": True},
    "taxonomy_version": {"type": _S, "min_length": 1},
    "dimensions": {"type": "array", "items": {"type": _S}, "min_items": 1},
    "cells": {"type": "array", "items": {"type": "object", "properties": {
        "candidate_id": {"type": _S, "min_length": 1},
        "dimension": {"type": _S, "min_length": 1},
        "value_kind": {"type": _S, "enum": list(VALUE_KINDS)},
        "value": {"type": "any", "nullable": True},
        "unit": {"type": _S, "nullable": True},
        "derivation": {"type": _S, "enum": list(DERIVATIONS)},
        "evidence_refs": _STR_LIST,
        "statement": {"type": _S, "min_length": 1},
    }}},
    "differences": {"type": "array", "items": {"type": "object", "properties": {
        "dimension": {"type": _S, "min_length": 1},
        "statement": {"type": _S, "min_length": 1},
        "derivation": {"type": _S, "enum": list(DERIVATIONS)},
        "evidence_refs": _STR_LIST,
    }}},
    "unresolved": _STR_LIST,
    "missing_criteria": _STR_LIST,
    "weights": {"type": "object", "nullable": True, "additional": True, "properties": {}},
    "weight_authority_ref": {"type": _S, "nullable": True},
    "uncertainty": {"type": "object", "properties": dict(_UNCERTAINTY_FIELDS)},
    "built_at": _TS,
}, "PAPER-CAP-04 / COMP-06 / AUDIT-ADD-10 structured trade-off comparison; no invented weights."))

register(Schema("as.question/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.question/1"},
    "question_id": {"type": _S, "format": "id"},
    "run_id": {"type": _S, "min_length": 1},
    "gap": {"type": _S, "min_length": 1},
    "question": {"type": _S, "min_length": 1},
    "materiality": {"type": _S, "enum": ["material", "nonmaterial"]},
    "materiality_rule": {"type": _S, "min_length": 1},
    "affected_candidates": _STR_LIST,
    "affected_dimensions": _STR_LIST,
    "priority": {"type": "integer", "minimum": 1, "maximum": 5},
    "status": {"type": _S, "enum": ["open", "answered", "withdrawn", "assumed_bounded"]},
    "bounded_assumption": {"type": _S, "nullable": True},
    "answer": {"type": _S, "nullable": True},
    "answered_by": {"type": "object", "nullable": True, "properties": dict(_PRINCIPAL_FIELDS)},
    "raised_at": _TS,
}, "PAPER-CAP-05 / AUDIT-ADD-09 clarifying question with materiality."))

register(Schema("as.option_event/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.option_event/1"},
    "event_id": {"type": _S, "format": "id"},
    "run_id": {"type": _S, "min_length": 1},
    "sequence": {"type": "integer", "minimum": 0},
    "candidate_id": {"type": _S, "min_length": 1},
    "kind": {"type": _S, "enum": list(OPTION_EVENTS)},
    "actor": {"type": _S, "min_length": 1},
    "actor_kind": {"type": _S, "enum": ["human", "service", "model", "analyzer", "system"]},
    "rationale": {"type": _S, "min_length": 1},
    "evidence_refs": _STR_LIST,
    "prior_state_digest": {"type": _S, "format": "digest", "nullable": True},
    "new_state_digest": _DG,
    "at": _TS,
}, "PAPER-CAP-06 / COMP-08 option lifecycle event."))

register(Schema("as.design_state/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.design_state/1"},
    "run_id": {"type": _S, "min_length": 1},
    "version": {"type": "integer", "minimum": 0},
    "iteration": {"type": "integer", "minimum": 0},
    "goals": {"type": "array", "items": {"type": "object", "properties": {
        "goal_id": {"type": _S, "min_length": 1}, "text": {"type": _S, "min_length": 1},
        "evidence_refs": _STR_LIST, "derivation": {"type": _S, "enum": list(DERIVATIONS)}}}},
    "constraints": {"type": "array", "items": {"type": "object", "properties": {
        "constraint_id": {"type": _S, "min_length": 1}, "text": {"type": _S, "min_length": 1},
        "family": {"type": _S, "min_length": 1}, "evidence_refs": _STR_LIST,
        "derivation": {"type": _S, "enum": list(DERIVATIONS)}}}},
    "open_questions": _STR_LIST,
    "candidates": _STR_LIST,
    "comparisons": _STR_LIST,
    "assumptions": _STR_LIST,
    "exploration_events": _STR_LIST,
    "review_state": {"type": _S, "min_length": 1},
    "scope_digest": _DG,
    "updated_at": _TS,
    "updated_by": {"type": _S, "min_length": 1},
}, "PAPER-CAP-01 / COMP-01 explicit design state."))

register(Schema("as.diagram/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.diagram/1"},
    "diagram_id": {"type": _S, "format": "id"},
    "candidate_id": {"type": _S, "min_length": 1},
    "notation": {"type": _S, "const": "as-component-lite/1"},
    "elements": {"type": "array", "items": {"type": "object", "properties": {
        "element_id": {"type": _S, "min_length": 1}, "label": {"type": _S, "min_length": 1},
        "kind": {"type": _S, "min_length": 1}, "candidate_element_id": {"type": _S, "min_length": 1}}}},
    "relations": {"type": "array", "items": {"type": "object", "properties": {
        "element_id": {"type": _S, "min_length": 1}, "source": {"type": _S, "min_length": 1},
        "target": {"type": _S, "min_length": 1}, "label": {"type": _S, "min_length": 1},
        "candidate_element_id": {"type": _S, "min_length": 1}}}},
    "layout_hints": {"type": "object", "additional": True, "properties": {}},
    "provenance_digest": _DG,
    "semantics_version": {"type": _S, "min_length": 1},
}, "AUDIT-ADD-11 / COMP-09 diagram semantics with layout separated."))

register(Schema("as.assumption/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.assumption/1"},
    "assumption_id": {"type": _S, "format": "id"},
    "run_id": {"type": _S, "min_length": 1},
    "statement": {"type": _S, "min_length": 1},
    "status": {"type": _S, "enum": ["inferred", "uncertain", "proposed", "unsupported"]},
    "evidence_refs": _STR_LIST,
    "introduced_by": {"type": _S, "min_length": 1},
    "affected_candidates": _STR_LIST,
    "resolution": {"type": _S, "enum": ["open", "confirmed_by_human", "rejected_by_human", "converted_to_question"]},
    "recorded_at": _TS,
}, "PAPER-GRD-02 / VERIFY-03 assumption registry entry."))

register(Schema("as.conflict/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.conflict/1"},
    "conflict_id": {"type": _S, "format": "id"},
    "run_id": {"type": _S, "min_length": 1},
    "kind": {"type": _S, "enum": ["requirement_vs_requirement", "nfr_target_conflict", "adr_superseded",
                                  "catalog_mismatch", "security_vs_design", "stale_revision"]},
    "artifact_ids": {"type": "array", "items": {"type": _S}, "min_items": 1},
    "description": {"type": _S, "min_length": 1},
    "affected_candidates": _STR_LIST,
    "evidence_refs": {"type": "array", "items": {"type": _S}, "min_items": 1},
    "resolution_path": {"type": _S, "const": "human_decision_required"},
    "status": {"type": _S, "enum": ["open", "resolved_by_human"]},
    "detected_at": _TS,
}, "AUDIT-ADD-08 explicit conflict state; never silently resolved."))

register(Schema("as.constraint_check/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.constraint_check/1"},
    "rule_id": {"type": _S, "min_length": 1},
    "family": {"type": _S, "enum": ["requirement", "nfr", "security", "deployment", "api",
                                    "infrastructure", "policy", "cost_performance"]},
    "candidate_id": {"type": _S, "min_length": 1},
    "constraint_id": {"type": _S, "min_length": 1},
    "result": {"type": _S, "enum": ["pass", "fail", "unknown"]},
    "message": {"type": _S, "min_length": 1},
    "evidence_refs": _STR_LIST,
    "analyzer": {"type": _S, "min_length": 1},
    "analyzer_version": {"type": _S, "min_length": 1},
    "checked_at": _TS,
}, "COMP-05 / ARCH-05 deterministic constraint check; unknown never becomes pass."))

register(Schema("as.approval_token/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.approval_token/1"},
    "token_id": {"type": _S, "min_length": 1},
    "issuer": {"type": _S, "min_length": 1},
    "approver": {"type": "object", "properties": dict(_PRINCIPAL_FIELDS)},
    "run_id": {"type": _S, "min_length": 1},
    "gate": {"type": _S, "min_length": 1},
    "artifact_ids": {"type": "array", "items": {"type": _S}, "min_items": 1},
    "action": {"type": _S, "min_length": 1},
    "scope_digest": _DG,
    "subject_digest": _DG,
    "nonce": {"type": _S, "min_length": 16},
    "issued_at": _TS,
    "expires_at": _TS,
    "algorithm": {"type": _S, "enum": ["hmac-sha256", "ed25519"]},
    "signature": {"type": _S, "pattern": r"^(hmac-sha256:[0-9a-f]{64}|ed25519:[0-9a-f]{128})$"},
    "key_id": {"type": _S, "min_length": 1},
}, "SEC-07 / HUMAN-06 approval token bound to approver, scope, run/artifact, action, expiry, nonce."))

register(Schema("as.workflow_state/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.workflow_state/1"},
    "version": {"type": _S, "min_length": 1},
    "run_id": {"type": _S, "min_length": 1},
    "state": {"type": _S, "min_length": 1},
    "terminal": {"type": "boolean"},
    "allowed_events": _STR_LIST,
    "history": {"type": "array", "items": {"type": "object", "additional": True, "properties": {}}},
    "state_id": {"type": _S, "format": "id"},
    "checkpoint": {"type": "object", "additional": True, "properties": {}},
}, "IMPL-03 / STORE-01 / XSTATE-03 versioned workflow state snapshot."))

register(Schema("as.case_file/1", "1.0.0", {
    "schema_id": {"type": _S, "const": "as.case_file/1"},
    "case_file_version": {"type": _S, "min_length": 1},
    "run_id": {"type": _S, "min_length": 1},
    "scope_digest": _DG,
    "source_manifest": {"type": "array", "items": {"type": "object", "additional": True, "properties": {}}},
    "analyzer_results": {"type": "array", "items": {"type": "object", "additional": True, "properties": {}}},
    "versions": {"type": "object", "additional": True, "properties": {}},
    "candidates": {"type": "array", "items": {"type": "object", "additional": True, "properties": {}}},
    "comparisons": {"type": "array", "items": {"type": "object", "additional": True, "properties": {}}},
    "verification": {"type": "object", "additional": True, "properties": {}},
    "uncertainty": {"type": "object", "additional": True, "properties": {}},
    "questions": {"type": "array", "items": {"type": "object", "additional": True, "properties": {}}},
    "assumptions": {"type": "array", "items": {"type": "object", "additional": True, "properties": {}}},
    "review_history": {"type": "array", "items": {"type": "object", "additional": True, "properties": {}}},
    "approvals": {"type": "array", "items": {"type": "object", "additional": True, "properties": {}}},
    "ledger": {"type": "object", "additional": True, "properties": {}},
    "hashes": {"type": "object", "additional": True, "properties": {}},
    "exported_at": _TS,
}, "AUDIT-ADD-23 / XPROV-07 / WF-11 portable auditable case-file manifest."))
