"""Measurable acceptance criteria, one per requirement (AUDIT-ADD-04).

The rule the source demands is that no requirement can be marked done by a
narrative assertion. So every one of the 227 requirements is bound here to a
criterion of exactly one kind:

``test``
    An automated check in this repository asserts the behaviour. The reference
    is the test file that owns the requirement's canonical control family, and
    the evidence artifact is that suite's report.
``inspection``
    The artifact exists, is generated from authoritative configuration, and its
    freshness digest matches — checked mechanically by ``docs.freshness_report``
    or an equivalent generator check, but the *content* judgement is a reading,
    not an assertion.
``human_evidence``
    The criterion can only be satisfied by a record a human principal signs:
    an independent review, an approval, a risk acceptance. No mechanical check
    can produce it, and this pass produces none.
``external_measurement``
    The criterion depends on a host or an environment this pass does not
    provision (a KMS, an IdP, a staging deployment, production telemetry).
    Measurement happens outside this repository.

Choosing a kind is not choosing a verdict: a ``test`` criterion still fails
until its suite passes, and ``human_evidence`` / ``external_measurement``
criteria are exactly the ones this pass reports as UNKNOWN with a named
blocker rather than as satisfied.
"""
from __future__ import annotations

from typing import Any, Mapping

from .registry import CONTROL_OWNERSHIP, Requirement, build_registry

__all__ = ["ACCEPTANCE_VERSION", "acceptance_map", "KIND_OVERRIDES", "criterion_for"]

ACCEPTANCE_VERSION = "1.0.0"

#: Requirements whose criterion cannot be an automated test in this repository,
#: with the reason. Everything not listed here is a ``test`` criterion owned by
#: its control family's suite.
KIND_OVERRIDES: dict[str, tuple[str, str, str]] = {}


def _doc_ids() -> dict[str, tuple[str, str, str]]:
    return {f"DOC-{i:02d}": ("inspection", f"architecture_studio.docs.freshness_report -> DOC-{i:02d}",
                             f"Architecture Studio/docs/INDEX.md") for i in range(1, 13)}


def _env_ids() -> dict[str, tuple[str, str, str]]:
    provisioned = {"ENV-01": "local", "ENV-06": "test_tenant"}
    out: dict[str, tuple[str, str, str]] = {}
    for i in range(1, 7):
        rid = f"ENV-{i:02d}"
        if rid in provisioned:
            out[rid] = ("test", "tests/test_environments_release.py::test_environment_smoke_tests",
                        "environments/{}.json".format(provisioned[rid]))
        else:
            out[rid] = ("external_measurement", f"host provisioning record for {rid} + environments/{rid.lower()}.json descriptor",
                        "environments/INDEX.json")
    return out


def _gate_ids() -> dict[str, tuple[str, str, str]]:
    return {f"GATE-PROD-{i:02d}": ("human_evidence",
                                   f"architecture_studio.gates.GATE-PROD-{i:02d} mechanical evidence check "
                                   f"plus an independent human review record",
                                   "release evidence bundle (gates report + review record)") for i in range(1, 9)}


#: Requirements that name a human act, a host capability, or a document, rather than a behaviour a test can assert.
_EXPLICIT: dict[str, tuple[str, str, str]] = {
    "XAUTH-01": ("external_measurement", "host identity provider bound to architecture_studio.authority.IdentityBinding",
                 "identity provider binding record"),
    "XAUTH-05": ("test", "tests/test_authority_scope.py::test_credential_leases_are_short_lived_and_scoped", "test report"),
    "MODEL-01": ("external_measurement", "a pinned model provider bound into architecture_studio.generator.ProviderSlot by a human",
                 "provider binding record"),
    "SEC-07": ("human_evidence", "an independent human reviewer confirms no non-human principal can approve; "
               "tests/test_approvals_review.py demonstrates the refusal mechanically",
               "independent review record + test report"),
    "SEC-08": ("human_evidence", "an independent human reviewer confirms approval-token binding and replay resistance",
               "independent review record + test report"),
    "HUMAN-06": ("human_evidence", "an authenticated human approval recorded through architecture_studio.approvals",
                 "approval record"),
    "HUMAN-07": ("human_evidence", "an independent human reviewer confirms accountability language and ownership",
                 "independent review record"),
    "WF-10": ("human_evidence", "a real human decision gates a real state change in an observed run",
              "case file with an approval record"),
    "XSEC-04": ("external_measurement", "a host KMS occupies architecture_studio.crypto.KeyProvider; the local provider is the offline reference",
                "KMS binding record + tests/test_security.py report"),
    "ENV-03": ("external_measurement", "staging provisioning record from the host operator", "environments/staging.json + provisioning record"),
    "AUDIT-ADD-25": ("human_evidence", "an approved pilot exit criteria record and a pilot report meeting it",
                     "PILOT-EXIT-01 approval + pilot report"),
    "XEVAL-06": ("external_measurement", "a pilot deployment run under read-only/draft-only in a provisioned environment",
                 "pilot report"),
    "XEVAL-07": ("human_evidence", "documented acceptance criteria approved by a human plus an exercised rollback",
                 "ACCEPT-RELEASE-01 approval + recovery exercise result"),
    "AUDIT-ADD-13": ("human_evidence", "SLO/NFR targets approved by their owner roles; architecture_studio.slo declares them PROPOSED",
                     "approved target set"),
    "AUDIT-ADD-04": ("inspection", "this module: every requirement carries a testable criterion of a declared kind",
                     "tests/test_registry.py::test_acceptance_criteria_are_testable"),
    "AUDIT-ADD-24": ("inspection", "architecture_studio.registry.raci_document() names one accountable role per activity",
                     "tests/test_registry.py::test_raci_and_escalation_name_roles_not_people"),
    "AUDIT-ADD-22": ("test", "tests/test_registry.py::test_accessibility_criteria_are_declared_and_checked",
                     "accessibility report (A11Y-06 is human-verified and never self-reports PASS)"),
    "AUDIT-ADD-18": ("inspection", "architecture_studio.docs DOC-06 model/tool inventory generated from the runtime",
                     "Architecture Studio/docs/DOC-06-model-tool-inventory.md"),
    "AUDIT-ADD-21": ("test", "tests/test_environments_release.py::test_release_manifest_and_rollback", "test report"),
}


def criterion_for(requirement: Requirement) -> dict[str, Any]:
    rid = requirement.requirement_id
    table: dict[str, tuple[str, str, str]] = {**_doc_ids(), **_env_ids(), **_gate_ids(), **_EXPLICIT, **KIND_OVERRIDES}
    if rid in table:
        kind, reference, evidence = table[rid]
    else:
        family = requirement.canonical_family
        control = CONTROL_OWNERSHIP.get(_family_key(family))
        tests = control["tests"] if control else "tests/run_all.py"
        kind, reference, evidence = "test", tests, f"{tests} report"
    return {"kind": kind, "reference": reference, "evidence": evidence,
            "criterion_text": requirement.done_when, "owner_role": requirement.owner_role,
            "verification_class": requirement.verification_class}


_FAMILY_TO_KEY = {
    "Backlog governance": "backlog_governance",
    "Mission, governance, scope, authority, and guardrails": "authorization",
    "Authority / scope / guardrails": "authorization",
    "Canonical schemas, contracts, identity, and API foundations": "schema_validation",
    "State, persistence, versioning, provenance, and reproducibility": "state_and_reproducibility",
    "State / versioning / reproducibility": "state_and_reproducibility",
    "Provenance / evidence": "provenance",
    "Evidence ingestion / retrieval / grounding": "revision_pinning",
    "Deterministic analysis, constraints, and policy checks": "deterministic_analysis",
    "Model orchestration / uncertainty": "candidate_generation",
    "Trade-offs / diagrams / steering": "candidate_generation",
    "Human review / approval": "human_approval",
    "Human review, decision recording, and approval": "human_approval",
    "Security / privacy": "classification_and_secrets",
    "Observability / resilience / operations": "observability",
    "Verification / evaluation": "verification_program",
    "Deployment / release / pilot": "environments_and_release",
    "Documentation / handoff": "documentation",
    "Production readiness gate": "verification_program",
}


def _family_key(family: str) -> str:
    return _FAMILY_TO_KEY.get(family, "verification_program")


def acceptance_map(requirements: Any = None) -> dict[str, dict[str, Any]]:
    """The AUDIT-ADD-04 table: requirement id -> criterion. Every requirement is covered."""
    reqs = list(requirements if requirements is not None else build_registry())
    return {r.requirement_id: criterion_for(r) for r in reqs}
