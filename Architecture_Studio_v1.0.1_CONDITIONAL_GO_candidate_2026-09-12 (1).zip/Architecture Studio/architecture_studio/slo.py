"""Runtime NFR/SLO targets, resource ceilings and the proposed/approved distinction (AUDIT-ADD-13, AUDIT-ADD-19, AUDIT-ADD-12).

The package supplies no numerical targets and approves none; neither does this
module. Every target here is ``PROPOSED`` with an owner role, and a measurement
is compared against a target only to report ``met`` / ``not_met`` /
``insufficient_data`` *under a proposed target* — never as a pass. Resource
ceilings (max run time, tokens, retrieval size, parallelism, retries, spend) are
enforced as caps regardless of approval, because a cap can only narrow.

Adapted from the SPB ``hard_limits.effective_caps`` (composition may only narrow)
and the owner's ``rcg/observability.slo_report``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

__all__ = ["TARGETS", "CEILINGS", "Target", "evaluate_targets", "effective_ceilings", "TARGETS_VERSION"]

TARGETS_VERSION = "1.0.0"


@dataclass(frozen=True)
class Target:
    target_id: str
    metric: str
    comparator: str                 # "<=" | ">=" | "=="
    value: float
    unit: str
    environment: str
    owner_role: str
    status: str = "PROPOSED"
    approval_ref: str | None = None
    denominator: str = ""

    @property
    def approved(self) -> bool:
        return self.status == "APPROVED" and bool(self.approval_ref)

    def as_document(self) -> dict[str, Any]:
        return {"target_id": self.target_id, "metric": self.metric, "comparator": self.comparator, "value": self.value,
                "unit": self.unit, "environment": self.environment, "owner_role": self.owner_role, "status": self.status,
                "approval_ref": self.approval_ref, "denominator": self.denominator, "approved": self.approved}


#: AUDIT-ADD-13 (runtime NFR/SLO) and AUDIT-ADD-12 (retrieval quality/freshness) — all PROPOSED.
TARGETS: tuple[Target, ...] = (
    Target("SLO-RUN-LATENCY-01", "run.duration_seconds.p95", "<=", 120.0, "s", "local", "operations_owner", denominator="completed runs"),
    Target("SLO-RETRIEVAL-LATENCY-01", "retrieval.search_ms.p95", "<=", 500.0, "ms", "local", "operations_owner", denominator="queries"),
    Target("SLO-AVAIL-01", "availability.rate", ">=", 0.99, "fraction", "staging", "operations_owner", denominator="authorized runs"),
    Target("SLO-COST-01", "cost.tokens_per_run", "<=", 50000.0, "tokens", "any", "operations_owner", denominator="runs"),
    Target("SLO-RECOVERY-01", "recovery.rto_minutes", "<=", 60.0, "min", "staging", "operations_owner", denominator="drills"),
    Target("SLO-RECOVERY-02", "recovery.rpo_minutes", "<=", 15.0, "min", "staging", "operations_owner", denominator="drills"),
    Target("SLO-WORKLOAD-01", "workload.max_evidence_records", "<=", 50000.0, "records", "any", "architecture_owner"),
    Target("SLO-CONCURRENCY-01", "workload.max_concurrent_reviewers", "<=", 8.0, "reviewers", "any", "architecture_owner"),
    Target("RET-RECALL-01", "retrieval.recall_at_10", ">=", 0.80, "fraction", "any", "ml_evaluation_owner", denominator="benchmark queries"),
    Target("RET-PRECISION-01", "retrieval.precision_at_10", ">=", 0.50, "fraction", "any", "ml_evaluation_owner", denominator="benchmark queries"),
    Target("RET-STALE-01", "retrieval.stale_outranks_current.rate", "<=", 0.0, "fraction", "any", "ml_evaluation_owner", denominator="stale-vs-current pairs"),
    Target("GROUND-COV-01", "grounding.coverage_min", ">=", 0.75, "fraction", "any", "ml_evaluation_owner", denominator="candidates"),
    Target("FP-INJECTION-01", "injection.false_positive_rate", "<=", 0.05, "fraction", "any", "security_privacy_owner", denominator="benign controls"),
    Target("REC-INJECTION-01", "injection.recall", ">=", 0.80, "fraction", "any", "security_privacy_owner", denominator="attack cases"),
)

#: AUDIT-ADD-19 / AUDIT-ADD-13 hard ceilings, enforced whether or not anything is approved.
CEILINGS: dict[str, dict[str, Any]] = {
    "local": {"max_run_seconds": 300, "max_context_tokens": 8000, "max_retrieval_records": 50000, "max_parallel": 2,
              "max_retries": 3, "max_spend_units": 0, "max_file_bytes": 4 * 1024 * 1024},
    "ci": {"max_run_seconds": 600, "max_context_tokens": 8000, "max_retrieval_records": 50000, "max_parallel": 4,
           "max_retries": 3, "max_spend_units": 0, "max_file_bytes": 4 * 1024 * 1024},
    "staging": {"max_run_seconds": 900, "max_context_tokens": 16000, "max_retrieval_records": 200000, "max_parallel": 8,
                "max_retries": 3, "max_spend_units": 1000, "max_file_bytes": 8 * 1024 * 1024},
    "production_read_only": {"max_run_seconds": 900, "max_context_tokens": 16000, "max_retrieval_records": 200000,
                             "max_parallel": 8, "max_retries": 2, "max_spend_units": 1000, "max_file_bytes": 8 * 1024 * 1024},
}


def effective_ceilings(environment: str, *requested: Mapping[str, Any]) -> dict[str, Any]:
    """Composition may only narrow: a requested cap above the environment ceiling is clamped, never honoured."""
    base = dict(CEILINGS.get(environment) or CEILINGS["local"])
    dropped = []
    for request in requested:
        for key, value in request.items():
            if key in base and isinstance(value, (int, float)) and not isinstance(value, bool):
                if value > base[key]:
                    dropped.append({"cap": key, "requested": value, "kept": base[key]})
                else:
                    base[key] = value
    return {"environment": environment, "ceilings": base, "narrowed_only": True, "requests_clamped": dropped}


def evaluate_targets(measurements: Mapping[str, Any]) -> dict[str, Any]:
    """Compare measurements against targets; a PROPOSED target never yields a pass."""
    rows = []
    for target in TARGETS:
        measured = measurements.get(target.metric)
        if measured is None:
            state, detail = "insufficient_data", "no measurement"
        else:
            value = measured["value"] if isinstance(measured, Mapping) else measured
            n = measured.get("denominator") if isinstance(measured, Mapping) else None
            if n == 0:
                state, detail = "insufficient_data", "zero denominator"
            else:
                ok = {"<=": value <= target.value, ">=": value >= target.value, "==": value == target.value}[target.comparator]
                state = ("met" if ok else "not_met") + ("" if target.approved else "_under_proposed_target")
                detail = f"{value} {target.comparator} {target.value} {target.unit}"
        rows.append({**target.as_document(), "state": state, "detail": detail})
    return {"targets_version": TARGETS_VERSION, "rows": rows,
            "approved_targets": [r["target_id"] for r in rows if r["approved"]],
            "verdict": "NO_APPROVED_TARGETS" if not any(r["approved"] for r in rows) else "EVALUATED",
            "boundary": "a met-under-proposed-target row is a measurement, not a pass"}
