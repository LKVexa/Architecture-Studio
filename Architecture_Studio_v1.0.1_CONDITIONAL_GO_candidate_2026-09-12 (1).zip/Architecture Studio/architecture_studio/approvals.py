"""Approval tokens and the human-decision gate (SEC-07, HUMAN-06, WF-10, API-05, XHITL-02).

Tokens are issued only by an :class:`ApprovalService` holding a signing key the
model-facing surfaces never see, and only for an authenticated **human**
principal. Every token is bound to approver, scope digest, run, artifact ids,
action, expiry and a nonce; the signature covers all of them in canonical
ASCII bytes, so a forged, replayed, altered, expired or model-authored token is
refused with a typed reason. The nonce store makes replay a first-class refusal,
not a side effect of expiry.

Two algorithms, labelled in the signature and never downgraded (rule from the
shop's Scoped PR Builder ``crypto_identity``): ``hmac-sha256`` is the offline
identity every host can verify; ``ed25519`` is used when ``cryptography`` is
present and a token that names an algorithm this host cannot verify is refused,
not treated as HMAC.

The truth table lives in the tests: one genuine positive with every input
real, then twelve single-omission negatives, each NO. That is what "cannot be
fabricated" means here, and it is the lesson the v1.7.0 RCG pass recorded.

Build provenance: adapted from ``_YARDOFFICE/spb`` ``adapters/approval_adapter.py``
and ``crypto_identity.py`` (owner's own work).
"""
from __future__ import annotations

import hmac
import hashlib
import os
import secrets
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from .authority import Principal, assert_not_self_attested
from .canonical import canonical_bytes, fmt_ts, parse_ts, sha256_of
from .schemas import validate

__all__ = ["ApprovalError", "ApprovalService", "VerificationResult", "ed25519_available", "ALG_HMAC", "ALG_ED25519",
           "MAX_TOKEN_SECONDS", "NonceStore"]

ALG_HMAC = "hmac-sha256"
ALG_ED25519 = "ed25519"
MAX_TOKEN_SECONDS = 24 * 3600
_TOOL_WORDS = ("bot", "agent", "model", "assistant", "gpt", "claude", "llm", "automation", "service-account", "pipeline")


class ApprovalError(PermissionError):
    def __init__(self, code: str, message: str) -> None:
        self.code = code
        super().__init__(f"{code}: {message}")


def ed25519_available() -> bool:
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # noqa: F401
    except Exception:
        return False
    return True


def _ed25519():
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives import serialization
    return ed25519, serialization


@dataclass(frozen=True)
class VerificationResult:
    valid: bool
    code: str
    reason: str

    def as_document(self) -> dict[str, Any]:
        return {"valid": self.valid, "code": self.code, "reason": self.reason}


class NonceStore:
    """Nonces already consumed; a token verifies at most once (replay refusal)."""

    def __init__(self, path: Path | None = None) -> None:
        self.path = Path(path) if path else None
        self._seen: set[str] = set()
        if self.path and self.path.exists():
            self._seen = set(self.path.read_text(encoding="utf-8").split())

    def consume(self, nonce: str) -> bool:
        if nonce in self._seen:
            return False
        self._seen.add(nonce)
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(nonce + "\n")
        return True

    def seen(self, nonce: str) -> bool:
        return nonce in self._seen


def _token_payload(token: Mapping[str, Any]) -> bytes:
    """The bytes a signature covers: every binding field, canonical ASCII, no signature."""
    fields = {k: token[k] for k in ("schema_id", "token_id", "issuer", "approver", "run_id", "gate", "artifact_ids",
                                    "action", "scope_digest", "subject_digest", "nonce", "issued_at", "expires_at",
                                    "algorithm", "key_id")}
    return canonical_bytes(fields)


class ApprovalService:
    """Trusted issuer. Holds the key; model-facing code receives only :meth:`verify`."""

    def __init__(self, *, key: bytes, issuer: str, key_id: str, algorithm: str = ALG_HMAC,
                 nonces: NonceStore | None = None, ledger: Any = None) -> None:
        if algorithm not in (ALG_HMAC, ALG_ED25519):
            raise ApprovalError("approval.algorithm_unknown", f"unknown algorithm {algorithm!r}")
        if algorithm == ALG_ED25519 and not ed25519_available():
            raise ApprovalError("crypto.unavailable", "refusing to configure Ed25519 on a host that cannot verify it")
        if len(key) < 32:
            raise ApprovalError("approval.key_invalid", "signing key must be at least 32 bytes")
        self._key = bytes(key)
        self.issuer = issuer
        self.key_id = key_id
        self.algorithm = algorithm
        self.nonces = nonces or NonceStore()
        self.ledger = ledger

    # ------------------------------------------------------------- signing --
    def _sign(self, payload: bytes) -> str:
        if self.algorithm == ALG_HMAC:
            return ALG_HMAC + ":" + hmac.new(self._key, payload, hashlib.sha256).hexdigest()
        ed25519, _ = _ed25519()
        return ALG_ED25519 + ":" + ed25519.Ed25519PrivateKey.from_private_bytes(self._key[:32]).sign(payload).hex()

    def _verify_signature(self, payload: bytes, signature: str) -> tuple[bool, str]:
        algorithm, _, hexsig = signature.partition(":")
        if algorithm != self.algorithm:
            return False, "approval.signature_algorithm_mismatch"
        if algorithm == ALG_HMAC:
            expected = hmac.new(self._key, payload, hashlib.sha256).hexdigest()
            return hmac.compare_digest(expected, hexsig), "approval.signature_invalid"
        if not ed25519_available():
            return False, "approval.signature_unverifiable"
        ed25519, serialization = _ed25519()
        public = ed25519.Ed25519PrivateKey.from_private_bytes(self._key[:32]).public_key()
        try:
            public.verify(bytes.fromhex(hexsig), payload)
            return True, "ok"
        except Exception:
            return False, "approval.signature_invalid"

    def public_identity(self) -> dict[str, Any]:
        if self.algorithm == ALG_ED25519:
            ed25519, serialization = _ed25519()
            pub = ed25519.Ed25519PrivateKey.from_private_bytes(self._key[:32]).public_key().public_bytes(
                encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
            return {"issuer": self.issuer, "key_id": self.key_id, "algorithm": self.algorithm, "public_key": pub.hex()}
        return {"issuer": self.issuer, "key_id": self.key_id, "algorithm": self.algorithm, "public_key": None,
                "note": "shared-secret identity: anyone holding the key can mint tokens; keep it outside model reach"}

    # -------------------------------------------------------------- issue --
    def issue(self, *, approver: Principal, run_id: str, gate: str, artifact_ids: Sequence[str], action: str,
              scope_digest: str, subject_digest: str, seconds: int = 3600, channel: str = "interactive",
              now: datetime | None = None) -> dict[str, Any]:
        """Issue a token for an authenticated human. Everything else is refused before signing."""
        if not isinstance(approver, Principal):
            raise ApprovalError("approval.principal_required", "a token is issued to an authenticated Principal, not a name")
        assert_not_self_attested(approver.kind, gate)
        if channel != "interactive":
            raise ApprovalError("approval.channel_automated", "a human decision cannot arrive over an automated channel")
        lowered = approver.subject.lower()
        if any(word in lowered for word in _TOOL_WORDS):
            raise ApprovalError("approval.issuer_reads_as_tool", f"approver subject {approver.subject!r} reads as a tool identity")
        if not artifact_ids:
            raise ApprovalError("approval.unbound", "a token must name the artifact(s) it approves")
        if seconds <= 0 or seconds > MAX_TOKEN_SECONDS:
            raise ApprovalError("approval.expiry_invalid", f"token lifetime must be within 1..{MAX_TOKEN_SECONDS} seconds")
        moment = now or datetime.now(timezone.utc)
        token = {
            "schema_id": "as.approval_token/1", "token_id": "TOK-" + secrets.token_hex(10), "issuer": self.issuer,
            "approver": approver.as_record(), "run_id": run_id, "gate": gate, "artifact_ids": sorted(set(artifact_ids)),
            "action": action, "scope_digest": scope_digest, "subject_digest": subject_digest,
            "nonce": secrets.token_hex(16), "issued_at": fmt_ts(moment), "expires_at": fmt_ts(moment + timedelta(seconds=seconds)),
            "algorithm": self.algorithm, "key_id": self.key_id,
        }
        token["signature"] = self._sign(_token_payload(token))
        validate("as.approval_token/1", token)
        if self.ledger is not None:
            self.ledger.append("approval.issued", actor=approver.subject, actor_kind="human", outcome="recorded",
                               subject=gate, authority_ref=token["token_id"],
                               detail={k: v for k, v in token.items() if k != "signature"})
        return token

    # ------------------------------------------------------------- verify --
    def verify(self, token: Mapping[str, Any], *, run_id: str, gate: str, artifact_ids: Sequence[str], action: str,
               scope_digest: str, subject_digest: str, now: datetime | None = None, consume: bool = True) -> VerificationResult:
        """Fail closed on every mismatch; say which one."""
        moment = now or datetime.now(timezone.utc)
        try:
            validate("as.approval_token/1", dict(token))
        except Exception as exc:
            return self._refuse("approval.malformed", f"token does not match the schema: {exc}", token)
        if token["issuer"] != self.issuer or token["key_id"] != self.key_id:
            return self._refuse("approval.issuer_mismatch", "token was not issued by this service/key", token)
        ok, code = self._verify_signature(_token_payload(token), token["signature"])
        if not ok:
            return self._refuse(code, "signature does not verify over the bound fields", token)
        if token["approver"]["kind"] != "human":
            return self._refuse("approval.not_human", "approver is not a human principal", token)
        if token["run_id"] != run_id:
            return self._refuse("approval.run_mismatch", "token belongs to a different run", token)
        if token["gate"] != gate:
            return self._refuse("approval.gate_mismatch", "token belongs to a different gate", token)
        if token["action"] != action:
            return self._refuse("approval.action_mismatch", "token approves a different action", token)
        if set(token["artifact_ids"]) != set(artifact_ids):
            return self._refuse("approval.artifact_mismatch", "token approves different artifacts", token)
        if not hmac.compare_digest(token["scope_digest"], scope_digest):
            return self._refuse("approval.scope_changed", "the scope contract changed after approval", token)
        if not hmac.compare_digest(token["subject_digest"], subject_digest):
            return self._refuse("approval.subject_changed", "material change since approval: the subject digest moved", token)
        issued, expires = parse_ts(token["issued_at"]), parse_ts(token["expires_at"])
        if moment < issued - timedelta(seconds=300):
            return self._refuse("approval.not_yet_valid", "token is stamped in the future", token)
        if moment >= expires:
            return self._refuse("approval.expired", "token has expired", token)
        if self.nonces.seen(token["nonce"]):
            return self._refuse("approval.replayed", "token nonce was already consumed", token)
        if consume:
            self.nonces.consume(token["nonce"])
        if self.ledger is not None:
            self.ledger.append("approval.verified", actor=token["approver"]["subject"], actor_kind="human",
                               outcome="allowed", subject=gate, authority_ref=token["token_id"],
                               detail={"token_id": token["token_id"], "action": action})
        return VerificationResult(True, "ok", "token is genuine, current, unused and bound to this exact subject")

    def _refuse(self, code: str, reason: str, token: Mapping[str, Any]) -> VerificationResult:
        if self.ledger is not None:
            self.ledger.append("approval.refused", actor="approval_service", actor_kind="service", outcome="denied",
                               subject=str(token.get("gate")), detail={"code": code, "reason": reason,
                                                                       "token_id": token.get("token_id")})
        return VerificationResult(False, code, reason)


def load_or_create_key(path: Path, *, create: bool = True) -> bytes:
    """32-byte key stored hex with 0600 permissions, outside any run directory."""
    path = Path(path)
    if path.exists():
        raw = bytes.fromhex(path.read_text(encoding="utf-8").strip())
        if len(raw) < 32:
            raise ApprovalError("approval.key_invalid", "key is too short")
        return raw
    if not create:
        raise ApprovalError("approval.key_missing", f"no key at {path}")
    key = secrets.token_bytes(32)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(key.hex() + "\n")
    return key
