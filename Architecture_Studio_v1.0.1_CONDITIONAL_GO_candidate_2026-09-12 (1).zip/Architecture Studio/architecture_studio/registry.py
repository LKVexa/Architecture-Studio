"""Requirement registry, metadata schema, control ownership map and RACI (P0, AUDIT-ADD-24).

Covers AUDIT-ADD-01 (stable IDs for every checkbox, with source line/section
provenance), AUDIT-ADD-02 (backlog metadata fields), AUDIT-ADD-03 (one owning
control per recurring family, every alias resolving to it), AUDIT-ADD-04
(testable acceptance criterion per requirement) and AUDIT-ADD-24 (accountable
role owners and escalation; no critical decision assigned to the model).

The registry is *generated* from the two pinned source documents and the
package's traceability matrix — never retyped — after their SHA-256 digests
are checked against ``SOURCE_LOCK_v1.4.0.json``. Identifiers that the audit
assigned to originally anonymous checkboxes are marked ``id_origin =
"audit-assigned"`` and are never presented as paper/source IDs
(EXECUTION_RULES: source preservation and controlled interpretation).

Adapted from the owner's Repository Context Graph runtime (``rcg/governance.py``):
the generate-from-baseline rule and the alias table travelled; the parsing,
families and controls are this package's.
"""
from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping

from .canonical import digest_of, sha256_hex
from .evidence_io import load_strict

__all__ = [
    "RegistryError", "Requirement", "REQUIREMENT_FIELDS", "SOURCE_DIR", "load_source_lock",
    "verify_sources", "parse_checkboxes", "build_registry", "registry_document",
    "CONTROL_OWNERSHIP", "control_for", "RACI", "ESCALATION_PATH", "raci_document",
    "acceptance_table", "STATUS_VOCABULARY",
]

SOURCE_DIR = Path(__file__).resolve().parents[1] / "source"
_REQ_FILE = "06_architecture_studio_requirements_to_design_v1.0.0.md"
_TODO_FILE = "Architecture_Studio_Requirements_to_Design_Audited_Master_TODO_v1.0.0.md"
_LOCK_FILE = "SOURCE_LOCK_v1.4.0.json"
_MATRIX = "manifests/TRACEABILITY_MATRIX_v1.4.0.csv"
_ORDER = "manifests/APPLICATION_ORDER_v1.4.0.csv"

#: AUDIT-ADD-02: the metadata every requirement record carries.
REQUIREMENT_FIELDS: tuple[str, ...] = (
    "requirement_id", "id_origin", "source_id_original", "title", "text", "source_file",
    "source_line", "source_section", "audited_todo_line", "phase", "priority", "owner_role",
    "status", "dependencies", "implementation_artifact", "test_or_evidence", "risk",
    "target_phase", "change_history", "canonical_family", "owning_control", "verification_class",
    "applicability_policy", "non_waivable", "contract_sha256", "implement", "done_when",
    "source_item_kind",
)

#: Recommended Status Vocabulary (source §9), retained verbatim as the status set.
STATUS_VOCABULARY: tuple[str, ...] = (
    "NOT_STARTED", "READY", "IN_PROGRESS", "IMPLEMENTED", "VERIFIED", "ACCEPTED", "BLOCKED",
)


class RegistryError(ValueError):
    pass


@dataclass(frozen=True)
class Requirement:
    requirement_id: str
    id_origin: str                 # "paper" | "source" | "audit-assigned" | "audit-addition"
    source_id_original: str | None
    title: str
    text: str
    source_file: str
    source_line: int | None
    source_section: str
    audited_todo_line: int | None
    phase: str
    priority: str
    owner_role: str
    status: str
    dependencies: tuple[str, ...]
    implementation_artifact: str
    test_or_evidence: str
    risk: str
    target_phase: str
    change_history: tuple[dict[str, str], ...]
    canonical_family: str
    owning_control: str
    verification_class: str
    applicability_policy: str
    non_waivable: bool
    contract_sha256: str
    implement: str
    done_when: str
    source_item_kind: str = "checkbox"   # "checkbox" | "workflow_step" | "audit_todo"

    def as_document(self) -> dict[str, Any]:
        doc = {name: getattr(self, name) for name in REQUIREMENT_FIELDS}
        doc["dependencies"] = list(self.dependencies)
        doc["change_history"] = [dict(c) for c in self.change_history]
        return doc


# --------------------------------------------------------------------------- #
# Sources                                                                       #
# --------------------------------------------------------------------------- #
def load_source_lock(source_dir: Path | None = None) -> dict[str, Any]:
    return load_strict((source_dir or SOURCE_DIR) / _LOCK_FILE)


def verify_sources(source_dir: Path | None = None) -> dict[str, Any]:
    """Check both pinned sources against the lock; refuse to build on a mismatch."""
    root = source_dir or SOURCE_DIR
    lock = load_source_lock(root)
    report = {"package_version": lock.get("package_version"), "sources": [], "ok": True}
    for entry in lock["sources"]:
        path = root / Path(entry["path"]).name
        data = path.read_bytes()
        actual = sha256_hex(data)
        ok = actual == entry["sha256"] and len(data) == entry["bytes"]
        report["sources"].append({"role": entry["role"], "path": path.name, "expected": entry["sha256"],
                                  "actual": actual, "bytes": len(data), "ok": ok})
        report["ok"] = report["ok"] and ok
    if not report["ok"]:
        raise RegistryError("pinned source digest mismatch; the registry cannot be generated from "
                            "a source that differs from the lock")
    return report


_CHECKBOX = re.compile(r"^\s*-\s\[[ xX]\]\s+(?P<body>.+?)\s*$")
_BOLD_ID = re.compile(r"^\*\*(?P<id>[A-Z][A-Z0-9]+(?:-[A-Z0-9]+)*)\*\*\s+—\s+(?P<text>.+)$")
_NUMBERED = re.compile(r"^\s*(?P<n>\d+)\.\s+\*\*(?P<text>.+?)\*\*\s*$")


def parse_checkboxes(source_dir: Path | None = None) -> list[dict[str, Any]]:
    """Every checkbox and numbered workflow step in the original requirements, with provenance."""
    root = source_dir or SOURCE_DIR
    lines = (root / _REQ_FILE).read_text(encoding="utf-8").splitlines()
    items: list[dict[str, Any]] = []
    section = ""
    subsection = ""
    for number, raw in enumerate(lines, start=1):
        if raw.startswith("## "):
            section, subsection = raw[3:].strip(), ""
            continue
        if raw.startswith("### "):
            subsection = raw[4:].strip()
            continue
        m = _CHECKBOX.match(raw)
        if m:
            body = m.group("body")
            ident = _BOLD_ID.match(body)
            items.append({
                "source_line": number, "source_section": subsection or section,
                "parent_section": section, "kind": "checkbox",
                "source_id_original": ident.group("id") if ident else None,
                "text": (ident.group("text") if ident else body).strip(),
            })
            continue
        n = _NUMBERED.match(raw)
        if n and section == "Core Workflow":
            items.append({
                "source_line": number, "source_section": section, "parent_section": section,
                "kind": "workflow_step", "source_id_original": None,
                "text": n.group("text").strip(), "step": int(n.group("n")),
            })
    return items


def _read_csv(path: Path) -> list[dict[str, str]]:
    raw = path.read_text(encoding="utf-8-sig")
    return list(csv.DictReader(io.StringIO(raw)))


# --------------------------------------------------------------------------- #
# Canonical control ownership (AUDIT-ADD-03)                                    #
# --------------------------------------------------------------------------- #
#: family -> (owning module.symbol, the tests that prove it, requirement aliases).
#: Every recurring concern has exactly one owner; an alias never gets a second,
#: competing implementation. ``control_for`` resolves an ID to its owner.
CONTROL_OWNERSHIP: dict[str, dict[str, Any]] = {
    "authorization": {
        "control_id": "CTRL-AUTHZ", "owner": "architecture_studio.scope.ScopeContract.check",
        "tests": "tests/test_authority_scope.py",
        "aliases": ["XAUTH-01", "XAUTH-02", "XAUTH-03", "XAUTH-04", "XAUTH-05", "XAUTH-06", "XAUTH-07",
                    "IMPL-01", "API-02", "WF-01", "WF-03", "MODEL-06", "GATE-PROD-03"]},
    "guardrail_enforcement": {
        "control_id": "CTRL-POLICY", "owner": "architecture_studio.policy.evaluate",
        "tests": "tests/test_policy.py",
        "aliases": ["ARCH-07", "IMPL-06", "PAPER-GRD-01", "PAPER-GRD-03", "GATE-PROD-01"]},
    "provenance": {
        "control_id": "CTRL-PROV", "owner": "architecture_studio.provenance.ProvenanceGraph",
        "tests": "tests/test_provenance.py",
        "aliases": ["IMPL-04", "API-03", "ARCH-08", "COMP-10", "STORE-03", "XPROV-01", "XPROV-02",
                    "XPROV-03", "XPROV-04", "XPROV-05", "XPROV-07", "MODEL-03", "MODEL-05", "VERIFY-01",
                    "VERIFY-04", "GATE-PROD-04", "AUDIT-ADD-23", "WF-11"]},
    "revision_pinning": {
        "control_id": "CTRL-PIN", "owner": "architecture_studio.connectors.base.pin_source_set",
        "tests": "tests/test_connectors.py",
        "aliases": ["IMPL-05", "WF-02", "XSTATE-01", "STORE-02", "ARCH-02"]},
    "schema_validation": {
        "control_id": "CTRL-SCHEMA", "owner": "architecture_studio.schemas.validate",
        "tests": "tests/test_schemas_contracts.py",
        "aliases": ["IMPL-02", "API-01", "API-04", "API-06", "API-07", "API-08", "XTOOL-02", "MODEL-04",
                    "SEC-02", "AUDIT-ADD-05", "WF-04"]},
    "human_approval": {
        "control_id": "CTRL-APPROVE", "owner": "architecture_studio.approvals.ApprovalService.verify",
        "tests": "tests/test_approvals_review.py",
        "aliases": ["API-05", "SEC-07", "HUMAN-06", "HUMAN-07", "WF-10", "XHITL-01", "XHITL-02", "XHITL-03",
                    "XHITL-04", "XHITL-05", "VERIFY-05", "ARCH-09", "IMPL-08", "WF-09", "HUMAN-01", "HUMAN-02",
                    "HUMAN-03", "HUMAN-04", "HUMAN-05", "GATE-PROD-05", "STORE-04", "COMP-08", "PAPER-CAP-06"]},
    "model_tool_versions": {
        "control_id": "CTRL-VERSIONS", "owner": "architecture_studio.version_manifest",
        "tests": "tests/test_generator.py",
        "aliases": ["MODEL-01", "STORE-05", "XTOOL-06", "XSTATE-02", "AUDIT-ADD-21", "AUDIT-ADD-18"]},
    "audit_integrity": {
        "control_id": "CTRL-AUDIT", "owner": "architecture_studio.ledger.Ledger.append",
        "tests": "tests/test_ledger_store.py",
        "aliases": ["STORE-07", "SEC-08", "IMPL-09", "XPROV-06", "AUDIT-ADD-17", "STORE-06", "XSEC-06"]},
    "fail_closed_writes": {
        "control_id": "CTRL-WRITE", "owner": "architecture_studio.writes.WriteGate.attempt",
        "tests": "tests/test_security.py",
        "aliases": ["SEC-05", "WF-12", "XOBS-04", "WF-07"]},
    "classification_and_secrets": {
        "control_id": "CTRL-DATA", "owner": "architecture_studio.security.classify",
        "tests": "tests/test_security.py",
        "aliases": ["AUDIT-ADD-16", "SEC-03", "SEC-06", "XSEC-01", "XSEC-02", "XSEC-05", "XSEC-04",
                    "XSEC-03", "SEC-04", "SEC-01", "XSEC-07", "XTOOL-03", "XTOOL-04", "GATE-PROD-07"]},
    "uncertainty_and_abstention": {
        "control_id": "CTRL-UNC", "owner": "architecture_studio.uncertainty.assess",
        "tests": "tests/test_uncertainty_grounding.py",
        "aliases": ["IMPL-07", "XUNC-01", "XUNC-02", "XUNC-03", "XUNC-04", "XUNC-05", "XUNC-06",
                    "PAPER-CAP-05", "AUDIT-ADD-07", "AUDIT-ADD-08", "AUDIT-ADD-09", "PAPER-GRD-02",
                    "VERIFY-03", "XTOOL-07"]},
    "state_and_reproducibility": {
        "control_id": "CTRL-STATE", "owner": "architecture_studio.store.ObjectStore.commit",
        "tests": "tests/test_ledger_store.py",
        "aliases": ["ARCH-03", "IMPL-03", "STORE-01", "XSTATE-03", "XSTATE-04", "XSTATE-05", "AUDIT-ADD-15",
                    "PAPER-CAP-01", "COMP-01", "VERIFY-06", "PAPER-GRD-04", "AUDIT-ADD-20", "AUDIT-ADD-26"]},
    "deterministic_analysis": {
        "control_id": "CTRL-DET", "owner": "architecture_studio.analysis.ConstraintChecker.check",
        "tests": "tests/test_analysis.py",
        "aliases": ["ARCH-05", "COMP-05", "XTOOL-01", "WF-05", "COMP-02", "ARCH-04", "COMP-03", "XTOOL-05",
                    "PAPER-CAP-02", "AUDIT-ADD-12", "ARCH-01", "AUDIT-ADD-14", "DATA-01", "DATA-02", "DATA-03",
                    "DATA-04", "DATA-05", "DATA-06", "DATA-07", "DATA-08", "DATA-09"]},
    "candidate_generation": {
        "control_id": "CTRL-GEN", "owner": "architecture_studio.generator.Generator.generate",
        "tests": "tests/test_generator.py",
        "aliases": ["COMP-04", "PAPER-CAP-03", "ARCH-06", "WF-06", "MODEL-02", "MODEL-07", "AUDIT-ADD-06",
                    "VERIFY-02", "COMP-06", "PAPER-CAP-04", "AUDIT-ADD-10", "COMP-09", "AUDIT-ADD-11",
                    "COMP-07", "AUDIT-ADD-22", "WF-08"]},
    "observability": {
        "control_id": "CTRL-OBS", "owner": "architecture_studio.observability.Telemetry",
        "tests": "tests/test_observability_ops.py",
        "aliases": ["ARCH-10", "XOBS-01", "XOBS-02", "XOBS-03", "XOBS-05", "AUDIT-ADD-13", "AUDIT-ADD-19",
                    "GATE-PROD-06"]},
    "verification_program": {
        "control_id": "CTRL-VERIFY", "owner": "architecture_studio.benchmark.RegressionRunner.run",
        "tests": "tests/test_benchmark_evaluation.py",
        "aliases": ["IMPL-10", "XEVAL-01", "XEVAL-02", "XEVAL-03", "XEVAL-04", "XEVAL-05", "XEVAL-06",
                    "XEVAL-07", "TEST-UNIT-01", "TEST-INT-01", "TEST-ADV-01", "TEST-ADV-02", "TEST-ADV-03",
                    "TEST-ADV-04", "TEST-ADV-05", "TEST-ADV-06", "TEST-ADV-07", "TEST-E2E-01", "TEST-E2E-02",
                    "TEST-E2E-03", "TEST-E2E-04", "TEST-E2E-05", "TEST-E2E-06", "GATE-PROD-02", "AUDIT-ADD-25"]},
    "environments_and_release": {
        "control_id": "CTRL-ENV", "owner": "architecture_studio.environments.smoke_test",
        "tests": "tests/test_environments_release.py",
        "aliases": ["ENV-01", "ENV-02", "ENV-03", "ENV-04", "ENV-05", "ENV-06"]},
    "documentation": {
        "control_id": "CTRL-DOC", "owner": "architecture_studio.docs.generate_all",
        "tests": "tests/test_docs_gates.py",
        "aliases": ["DOC-01", "DOC-02", "DOC-03", "DOC-04", "DOC-05", "DOC-06", "DOC-07", "DOC-08", "DOC-09",
                    "DOC-10", "DOC-11", "DOC-12", "GATE-PROD-08"]},
    "backlog_governance": {
        "control_id": "CTRL-BACKLOG", "owner": "architecture_studio.registry.build_registry",
        "tests": "tests/test_registry.py",
        "aliases": ["AUDIT-ADD-01", "AUDIT-ADD-02", "AUDIT-ADD-03", "AUDIT-ADD-04", "AUDIT-ADD-24"]},
    "asfw_governance": {
        "control_id": "CTRL-ASFW", "owner": "architecture_studio.asfw.build_register",
        "tests": "tests/test_asfw.py",
        "aliases": ["ASFW-0001", "ASFW-0002", "ASFW-0003", "ASFW-0004", "ASFW-0005", "ASFW-0006",
                    "ASFW-0007", "ASFW-0008", "ASFW-0545"]},
    "asgo_governance": {
        "control_id": "CTRL-ASGO", "owner": "architecture_studio.asgo.build_register",
        "tests": "tests/test_asgo.py",
        "aliases": ["ASGO-0.1", "ASGO-0.2", "ASGO-0.3", "ASGO-0.5", "ASGO-0.6", "ASGO-0.7",
                    "ASGO-0.8", "ASGO-0.9", "ASGO-0.10", "ASGO-0.12", "ASGO-0.14", "ASGO-0.15",
                    "ASGO-7.11", "ASGO-10.11", "ASGO-10.12"]},
}


def control_for(requirement_id: str) -> dict[str, Any]:
    """Resolve an alias to its single owning control; raise if it has none or two."""
    owners = [(family, entry) for family, entry in CONTROL_OWNERSHIP.items()
              if requirement_id in entry["aliases"]]
    if not owners:
        raise RegistryError(f"{requirement_id} has no owning control")
    if len(owners) > 1:
        raise RegistryError(f"{requirement_id} is claimed by {[f for f, _ in owners]}; a requirement "
                            "must resolve to exactly one owning control")
    family, entry = owners[0]
    return {"family": family, **{k: v for k, v in entry.items() if k != "aliases"}}


# --------------------------------------------------------------------------- #
# RACI and escalation (AUDIT-ADD-24) — roles, never names                       #
# --------------------------------------------------------------------------- #
RACI: dict[str, dict[str, Any]] = {
    "architecture": {"accountable": "architecture_owner", "responsible": "implementer",
                     "consulted": ["security_privacy_owner", "operations_owner"], "informed": ["human_review_policy_owner"]},
    "security_privacy": {"accountable": "security_privacy_owner", "responsible": "implementer",
                         "consulted": ["architecture_owner"], "informed": ["incident_response_owner"]},
    "source_systems": {"accountable": "source_systems_owner", "responsible": "environment_operator",
                       "consulted": ["security_privacy_owner"], "informed": ["architecture_owner"]},
    "ml_evaluation": {"accountable": "ml_evaluation_owner", "responsible": "evaluator",
                      "consulted": ["architecture_owner"], "informed": ["production_acceptance_owner"]},
    "operations": {"accountable": "operations_owner", "responsible": "environment_operator",
                   "consulted": ["incident_response_owner"], "informed": ["architecture_owner"]},
    "human_review_policy": {"accountable": "human_review_policy_owner", "responsible": "independent_reviewer",
                            "consulted": ["security_privacy_owner"], "informed": ["implementer"]},
    "incident_response": {"accountable": "incident_response_owner", "responsible": "incident_commander",
                          "consulted": ["operations_owner", "security_privacy_owner"], "informed": ["architecture_owner"]},
    "production_acceptance": {"accountable": "production_acceptance_owner", "responsible": "release_approver",
                              "consulted": ["security_privacy_owner", "operations_owner", "ml_evaluation_owner"],
                              "informed": ["architecture_owner"]},
}

ESCALATION_PATH: tuple[dict[str, str], ...] = (
    {"level": "1", "from": "implementer", "to": "the accountable owner of the affected area",
     "when": "a control cannot be satisfied, a threshold is missing, or evidence conflicts"},
    {"level": "2", "from": "accountable owner", "to": "production_acceptance_owner",
     "when": "the disagreement crosses areas or a gate would need a risk acceptance"},
    {"level": "3", "from": "production_acceptance_owner", "to": "release_approver + security_privacy_owner (two-person rule)",
     "when": "a non-waivable control is at issue; risk acceptance is recorded, never a pass"},
)

#: Decisions that a model may never own; each names the human role that owns it.
CRITICAL_DECISIONS: dict[str, str] = {
    "final_architecture_selection": "architecture_owner",
    "approval_or_rejection_of_a_candidate": "independent_reviewer",
    "scope_narrowing_or_widening": "human_review_policy_owner",
    "applicability_of_ENV-04_or_ENV-05": "operations_owner",
    "numeric_targets_and_thresholds": "ml_evaluation_owner",
    "risk_acceptance": "production_acceptance_owner",
    "production_release": "release_approver",
    "emergency_stop_and_revocation": "incident_commander",
}


def raci_document() -> dict[str, Any]:
    return {
        "schema_id": "as.raci/1", "roles_are_names": False,
        "boundary": "Roles are unbound: this table names responsibilities, not people. Binding a role "
                    "to a person is a human act recorded through architecture_studio.approvals.",
        "raci": RACI, "escalation_path": list(ESCALATION_PATH),
        "critical_decisions": CRITICAL_DECISIONS,
        "model_owns_any_critical_decision": False,
    }


# --------------------------------------------------------------------------- #
# Owner-role and risk derivation                                                #
# --------------------------------------------------------------------------- #
_FAMILY_OWNER = {
    "authorization": "security_privacy_owner", "guardrail_enforcement": "architecture_owner",
    "provenance": "architecture_owner", "revision_pinning": "source_systems_owner",
    "schema_validation": "architecture_owner", "human_approval": "human_review_policy_owner",
    "model_tool_versions": "ml_evaluation_owner", "audit_integrity": "security_privacy_owner",
    "fail_closed_writes": "security_privacy_owner", "classification_and_secrets": "security_privacy_owner",
    "uncertainty_and_abstention": "ml_evaluation_owner", "state_and_reproducibility": "operations_owner",
    "deterministic_analysis": "architecture_owner", "candidate_generation": "architecture_owner",
    "observability": "operations_owner", "verification_program": "ml_evaluation_owner",
    "environments_and_release": "operations_owner", "documentation": "architecture_owner",
    "backlog_governance": "production_acceptance_owner",
}


def _risk(row: Mapping[str, str]) -> str:
    if row["non_waivable"] == "true":
        return "non-waivable control: failure blocks production regardless of risk acceptance"
    if row["priority"] == "Blocker":
        return "blocker: downstream tasks cannot start until independently verified"
    if row["verification_class"].startswith("V3"):
        return "requires a distinct trusted principal to verify"
    return "standard"


def _artifact_for(family: str) -> str:
    return CONTROL_OWNERSHIP[family]["owner"].rsplit(".", 1)[0]


# --------------------------------------------------------------------------- #
# Build                                                                         #
# --------------------------------------------------------------------------- #
def build_registry(source_dir: Path | None = None, *, acceptance: Mapping[str, Mapping[str, Any]] | None = None
                   ) -> list[Requirement]:
    """Generate the registry from the pinned sources and the traceability matrix."""
    root = source_dir or SOURCE_DIR
    verify_sources(root)
    matrix = {r["todo_id"]: r for r in _read_csv(root / _MATRIX)}
    order = {r["todo_id"]: r for r in _read_csv(root / _ORDER)}
    if set(matrix) != set(order) or len(matrix) != 227:
        raise RegistryError("traceability matrix and application order disagree or are not 227 tasks")
    checkboxes = parse_checkboxes(root)
    by_line = {c["source_line"]: c for c in checkboxes}
    requirements: list[Requirement] = []
    for todo_id, row in order.items():
        trace = matrix[todo_id]
        line = int(trace["source_line"]) if trace["source_line"] else None
        original = trace["source_id_original"] or None
        if trace["source_kind"] == "audit-addition":
            origin = "audit-addition"
        elif original:
            origin = "paper" if trace["source_kind"] == "paper-stated" else "source"
        else:
            origin = "audit-assigned"
        source_item = by_line.get(line) if line else None
        text = source_item["text"] if source_item else row["title"]
        control = control_for(todo_id)
        acc = (acceptance or {}).get(todo_id, {})
        requirements.append(Requirement(
            requirement_id=todo_id, id_origin=origin, source_id_original=original,
            title=row["title"], text=text,
            source_file=_REQ_FILE if line else _TODO_FILE,
            source_line=line, source_section=trace["source_section"],
            audited_todo_line=int(trace["audited_todo_line"]) if trace["audited_todo_line"] else None,
            phase=row["phase"], priority=row["priority"],
            owner_role=_FAMILY_OWNER[control["family"]],
            status="NOT_STARTED",
            dependencies=tuple(x for x in row["hard_task_dependencies"].split(";") if x),
            implementation_artifact=_artifact_for(control["family"]),
            test_or_evidence=str(acc.get("reference") or control["tests"]),
            risk=_risk(row), target_phase=row["phase"],
            change_history=({"version": "1.0.0", "change": "generated from pinned sources"},),
            canonical_family=trace["canonical_family"], owning_control=control["control_id"],
            verification_class=row["verification_class"], applicability_policy=row["applicability_policy"],
            non_waivable=row["non_waivable"] == "true", contract_sha256=row["contract_sha256"],
            implement=row["implement"], done_when=row["done_when_evidence"],
            source_item_kind=(source_item["kind"] if source_item else "audit_todo"),
        ))
    _assert_complete(requirements, checkboxes)
    return requirements


def _assert_complete(requirements: list[Requirement], checkboxes: list[dict[str, Any]]) -> None:
    """AUDIT-ADD-01: every checkbox and workflow step in the source has a stable ID."""
    covered = {r.source_line for r in requirements if r.source_line}
    uncovered = [c for c in checkboxes if c["source_line"] not in covered]
    if uncovered:
        raise RegistryError(f"{len(uncovered)} source checkbox(es) have no stable ID: "
                            f"lines {[c['source_line'] for c in uncovered][:10]}")
    ids = [r.requirement_id for r in requirements]
    if len(ids) != len(set(ids)):
        raise RegistryError("duplicate requirement IDs")


def acceptance_table(requirements: Iterable[Requirement],
                     acceptance: Mapping[str, Mapping[str, Any]]) -> list[dict[str, Any]]:
    """AUDIT-ADD-04: one testable criterion per requirement; narrative-only is refused."""
    rows = []
    for req in requirements:
        entry = acceptance.get(req.requirement_id)
        if not entry or entry.get("kind") not in ("test", "inspection", "human_evidence", "external_measurement"):
            raise RegistryError(f"{req.requirement_id} has no testable acceptance criterion")
        rows.append({
            "requirement_id": req.requirement_id, "done_when": req.done_when,
            "kind": entry["kind"], "reference": entry["reference"],
            "owner_role": req.owner_role, "evidence_artifact": entry.get("evidence", req.test_or_evidence),
            "narrative_only": False,
        })
    return rows


def registry_document(requirements: Iterable[Requirement], *, source_dir: Path | None = None,
                      acceptance: Mapping[str, Mapping[str, Any]] | None = None) -> dict[str, Any]:
    reqs = list(requirements)
    lock = load_source_lock(source_dir)
    doc: dict[str, Any] = {
        "schema_id": "as.requirement_registry/1",
        "registry_version": "1.0.0",
        "source_lock": lock,
        "requirement_count": len(reqs),
        "anonymous_checkboxes_assigned": sum(1 for r in reqs if r.id_origin == "audit-assigned"
                                             and r.source_item_kind == "checkbox"),
        "workflow_steps_assigned": sum(1 for r in reqs if r.id_origin == "audit-assigned"
                                       and r.source_item_kind == "workflow_step"),
        "audit_additions": sum(1 for r in reqs if r.id_origin == "audit-addition"),
        "original_ids": sum(1 for r in reqs if r.id_origin in ("paper", "source")),
        "metadata_fields": list(REQUIREMENT_FIELDS),
        "status_vocabulary": list(STATUS_VOCABULARY),
        "requirements": [r.as_document() for r in reqs],
        "control_ownership": {f: {k: v for k, v in e.items()} for f, e in CONTROL_OWNERSHIP.items()},
        "raci": raci_document(),
    }
    if acceptance is not None:
        doc["acceptance_criteria"] = acceptance_table(reqs, acceptance)
    doc["registry_digest"] = digest_of({k: v for k, v in doc.items() if k != "registry_digest"})
    return doc
