# Architecture Studio for Requirements-to-Design v1.0.1

A governed, evidence-first runtime that turns requirements into **candidate** architectures — and never
into a decision. It is the ASRTD v1.4.0 prompt/workflow package (227 tasks, 16 phases, evidence protocol
`ASRTD/*/3`) applied as working code, installed as a single overlay directory on top of a generic project
repository that it treats as read-only local evidence.

Standard library only. No required third-party runtime dependency. No network access at run time.

```
architecture-studio status        # what is and is not in force, including every blocker
architecture-studio preflight     # overlay-only corpus contract; fail-closed
architecture-studio run --goal "consolidate the governance services"
architecture-studio asfw          # 545-item ASFW register; never self-attests GO
architecture-studio asgo          # 150-item ASGO register; never self-attests GO
architecture-studio verify <case-file-dir>
architecture-studio conditional-go # bounded local/test-tenant Conditional GO
python3 tests/run_all.py          # tests across control classes, including ASFW and ASGO
```

## What it actually does

A run walks the workflow in one direction and records every step in an append-only, hash-chained ledger:

```
WF-01 authenticate + load the scope contract   →  fails closed before any source is read
WF-02 pin every source artifact by content hash →  a later source change cannot silently change the run
WF-03 collect through authorized connectors     →  denials logged; nothing outside scope enters the index
WF-04 normalize, validate, classify, index      →  malformed input is quarantined, not indexed
WF-05 deterministic analysis first              →  parsers, schema checks, graph traversal, 9 constraint rules
WF-06/07 bounded generation under policy        →  source-labelled context only; output schema-validated
WF-08 independent verification                  →  a separate pass, recorded separately, that can block
WF-09 review package                            →  what was considered *and* what was not
WF-10 human decision                            →  token-bound; nothing proceeds without it
WF-11 auditable case file                       →  independently inspectable, ledger re-verifiable
WF-12 rollback/abort                            →  every fault path ends in an explicit safe terminal
```

The nine typed connectors read the corpus that ships beneath the overlay — `.jasp` service contracts,
`.jaops` workspace definitions, `.jasec` policies, suite READMEs, the module inventory — plus MADR and
Mermaid fixtures. On the checked-in corpus that is ~9,500 indexed records, zero quarantined, pins
reproducible.

## The things it refuses to do

These are design properties with tests behind them, not aspirations:

- **The model never decides.** No provider is bound by default; the slot is empty and binding is a recorded
  human act. With no provider, candidates come from a deterministic evidence generator and are labelled
  `deterministic_analyzer` — never presented as model output.
- **The model holds no permissions and cannot approve.** A service or model principal is refused before an
  approval token is signed. Approval tokens bind approver, run, gate, artifacts, action, scope digest,
  subject digest, expiry and nonce; a replayed, forged, expired, or foreign token is refused with a code.
- **One write path.** Every side effect goes through a single fail-closed write gate that requires an
  approved workflow state, a verified token, a confined path and a non-empty payload. The truth table of
  single omissions is a test.
- **Nothing passes on a proposed threshold.** Every numeric threshold in the system is `PROPOSED`. A
  measurement that meets one is reported as `met_under_proposed_target`, which is a measurement, not a pass.
- **A rate without a denominator is not a rate.** Zero observations report `INSUFFICIENT_DATA`, never `1.0`.
- **The kill switch is on the execution path.** A disabled or unreadable rollout store denies everything,
  and the incident drill proves zero provider calls and zero persisted candidates after the stop.
- **It cannot verify itself.** See below.

## Status of this pass — read this before believing anything

The runtime is built and the checks run. The **protocol status is a separate question**, and the honest
answer is that nothing here is verified:

| | |
|---|---|
| Tests | 165/165 passing across 20 control classes |
| Benchmark | suite passes; every MODEL-07 failure mode detected; all thresholds `PROPOSED` |
| Task records | 227 written; **1 IMPLEMENTED**, **226 BLOCKED**, 0 VERIFIED, 0 ACCEPTED |
| ASFW register | 545 items ingested; **416 IMPLEMENTED**, **129 BLOCKED**, **0 VERIFIED**, **0 complete** |
| Source INDEX.csv | **ABSENT** (derived index is not the source of truth) |
| DOD-02/04/05/08/09 | **UNRESOLVED** — not inferred |
| P15 gate count | PDF `GATE-PROD-01-09` vs executable `GATE-PROD-01..08` — **UNRESOLVED** |
| Verifier | `null` on every record |
| Production gates | 0 PASS, 6 AWAITING_INDEPENDENT_REVIEW, 1 FAIL (GATE-PROD-02, proposed thresholds), 1 NO_EVIDENCE (GATE-PROD-07, no security review) |
| Production verdict | **NO_GO** |

### Conditional GO boundary

This candidate is eligible for a **time-bounded `CONDITIONAL_GO`** recommendation
for the local checkout or synthetic test tenant after the complete mechanical
evidence collection passes. That status is narrower than Production GO: it
allows only `read`, `analyze`, `draft`, and `write_evidence` under
`draft_only`/`read_only`, with no production data, live connectors, external
writes, model provider, host IdP, KMS, CI, staging, or privileged execution.
It never authorizes promotion and it never changes the production verdict from
`NO_GO`.

Generate the current, expiring record with:

```
PYTHONPATH=. python3 -m architecture_studio conditional-go
```

The JSON and Markdown records are written under `evidence/reports/`. They name
the evidence digest, expiry, pending independent reviews, and every condition
that must close before a broader rollout.

Protocol v3 requires every prerequisite of an active record to be satisfied by an *independently VERIFIED*
upstream record, and every final status to name a verifier execution distinct from the implementer (a
distinct trusted principal for V3 tasks). This pass implemented the work and ran the checks; it did not and
cannot verify itself. Exactly one task — `AUDIT-ADD-01`, the first task of P0, which has no prerequisites —
is `IMPLEMENTED`. Every other record is `BLOCKED` with its blocker named precisely, and carries the real
implementation evidence anyway: the checks that ran, their outputs, and the net worktree delta.

`GATE-PROD-01..08` evaluate their evidence mechanically but reach `PASS` only with an independent human
review record. None exists. A documented risk acceptance shows as `ACCEPTED_RISK`, which the verdict still
counts as not-`PASS`.

The 2026-09-11 production-readiness audit is recorded in:

- [`AUDIT_NO_GO_REPORT.md`](AUDIT_NO_GO_REPORT.md) / [`AUDIT_NO_GO_REPORT.json`](AUDIT_NO_GO_REPORT.json)
- [`REMEDIATION_PLAN.md`](REMEDIATION_PLAN.md)
- [`PRODUCTION_READINESS_MATRIX.csv`](PRODUCTION_READINESS_MATRIX.csv)
- [`EVIDENCE_LEDGER.json`](EVIDENCE_LEDGER.json)
- [`INDEPENDENT_VERIFICATION_REPORT.md`](INDEPENDENT_VERIFICATION_REPORT.md)
- [`PRODUCTION_GO_TODO.md`](PRODUCTION_GO_TODO.md) — sequenced remaining work to a real GO
- [`handoff/`](handoff/) — packages for the external authorities this runtime cannot impersonate

The full list of what is not in force lives in
[`docs/DOC-12-known-limitations.md`](docs/DOC-12-known-limitations.md) — no bound model provider, no host
identity provider, no KMS, unprovisioned CI/staging, `ENV-04`/`ENV-05` applicability unresolved, and
process-level (not container) sandbox isolation.

## Layout

```
Architecture Studio/
  architecture_studio/     the runtime (stdlib only; connectors/ and vendor/ inside)
  tests/                   17 modules, run per control class by tests/run_all.py
  docs/                    DOC-01..12, generated from the runtime with a freshness digest
  environments/            ENV-01..06 descriptors (declared ≠ provisioned)
  fixtures/                ADRs, diagrams, and verbatim BIPIA/llmail adversarial corpora
  schemas/                 exported contract registry
  source/                  the pinned ASRTD v1.4.0 inputs + SOURCE_LOCK + manifests
  evidence/                generated: 227 task records, check outputs, PROGRAM_STATE.json
  tools/                   verify_corpus.py, build_evidence.py
  ci/                      workflow + local runner
```

The corpus beneath this directory is never modified. `tools/verify_corpus.py` and
`tests/test_e2e.py::test_the_generic_corpus_is_untouched` both assert its exact digest.

## Regenerating the evidence

```
python3 tools/build_evidence.py --package /path/to/ASRTD_v1.4.0
python3 /path/to/ASRTD_v1.4.0/tools/validate_record.py --kind execution \
    --root /path/to/ASRTD_v1.4.0 --evidence-root "Architecture Studio/evidence" \
    "Architecture Studio/evidence/records/AUDIT-ADD-01.json"
```

The sealed checker returns `authenticity: NOT_ASSESSED` and `production_verdict: NO_GO` by construction. So
does this pass.

## Licensing

Apache License 2.0 (`LICENSE`). Donor attributions and the verbatim/adapted/pattern breakdown are in
[`THIRD-PARTY-NOTICES.md`](THIRD-PARTY-NOTICES.md).
