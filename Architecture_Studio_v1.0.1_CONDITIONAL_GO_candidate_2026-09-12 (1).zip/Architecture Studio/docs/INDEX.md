# Generated documentation index

| id | title | file | owner role |
|---|---|---|---|
| DOC-01 | Architecture diagram | [DOC-01-architecture-diagram.md](DOC-01-architecture-diagram.md) | architecture_owner |
| DOC-02 | Data-flow and trust-boundary diagram | [DOC-02-data-flow-trust-boundaries.md](DOC-02-data-flow-trust-boundaries.md) | security_privacy_owner |
| DOC-03 | Source/connector inventory | [DOC-03-source-connector-inventory.md](DOC-03-source-connector-inventory.md) | data_owner |
| DOC-04 | Permission matrix | [DOC-04-permission-matrix.md](DOC-04-permission-matrix.md) | security_privacy_owner |
| DOC-05 | Threat model | [DOC-05-threat-model.md](DOC-05-threat-model.md) | security_privacy_owner |
| DOC-06 | Model/tool inventory | [DOC-06-model-tool-inventory.md](DOC-06-model-tool-inventory.md) | ml_evaluation_owner |
| DOC-07 | Provenance schema | [DOC-07-provenance-schema.md](DOC-07-provenance-schema.md) | architecture_owner |
| DOC-08 | Run-state schema | [DOC-08-run-state-schema.md](DOC-08-run-state-schema.md) | architecture_owner |
| DOC-09 | Human approval policy | [DOC-09-human-approval-policy.md](DOC-09-human-approval-policy.md) | human_review_policy_owner |
| DOC-10 | Evaluation plan and benchmark corpus description | [DOC-10-evaluation-plan.md](DOC-10-evaluation-plan.md) | ml_evaluation_owner |
| DOC-11 | Incident/rollback runbook | [DOC-11-incident-rollback-runbook.md](DOC-11-incident-rollback-runbook.md) | incident_response_owner |
| DOC-12 | Known limitations and non-goals | [DOC-12-known-limitations.md](DOC-12-known-limitations.md) | documentation_owner |
