# Architecture Studio v1.0.1 — updated candidate (CONDITIONAL_GO)

This archive is the **overlay candidate** after the 2026-09-11 production-readiness
audit remediations, the ASFW 545-item register, the fail-closed roster intake,
and the 2026-09-12 ASGO 150-item ingest.

**Candidate verdict: `CONDITIONAL_GO` for local/synthetic test-tenant evaluation only.**
**Production verdict: `NO_GO`.** This package does not authorize promotion or
production use.

## Layout (ASGO-0.5)

```
_archive/                         # wrappers; not corpus
  SHA256SUMS.txt
  CANDIDATE_README.md
  CANDIDATE_MANIFEST.json
Architecture Studio/              # this overlay
```

Extract next to the 612-file generic corpus so `Architecture Studio/` is a
**child** of the corpus root. The overlay never includes that corpus.

## What this is

- Runtime `1.0.1` applying ASRTD v1.4.0 as an overlay-only product
- ASFW 545-item register pinned to
  `c94ed9bd6f41bd034cc0136183010f9f7ddb1823fcdb25c55a7c138a026048d2`
- ASGO 150-item register pinned to
  `41209097b7b6d7fdaf905a7d52776be8557214049741ad4df5c89bf1982971b9`
- Overlay tests via `python3 tests/run_all.py` **with sibling corpus**; a green
  count taken from this zip alone is invalid (ASGO-0.12). Live count is whatever
  `tests/run_all.py` reports (165/165 in this sandbox with the sibling corpus).
- The 612-file generic corpus is **not** in this zip and was **not** modified
  (digest `16b9800f326777dcd5f6e4d58aeb97cc99ceb3a972abbbce37b0d48f1289d4e2`)
- Conditional qualification is restricted to `local` or synthetic `test_tenant`,
  `draft_only`/`read_only`, and the permissions `read`, `analyze`, `draft`, and
  `write_evidence`. It expires and must be regenerated; it is not a human
  approval, independent verification, or Production GO.

## What this is not

- Not independently verified (`verifier` is `null`)
- Not a bound IdP or KMS
- Not approved thresholds
- Not a filled roster (RUSSELL PHILIP SMITHSON is a `PROPOSED_UNBOUND` research-specialist offer only)
- Not recovered `INDEX.csv`, `DOD-02/04/05/08/09`, or a ninth `GATE-PROD` gate
- Not a signed overlay-vs-self-contained product decision (status `PROPOSED`)

## Start here

| File | Why |
|---|---|
| `asgo/ASGO_REGISTER.md` | 150-item ASGO register (NO_GO) |
| `PRODUCTION_GO_TODO.md` | Human/host path still open |
| `AUDIT_NO_GO_REPORT.md` | Audit that reproduced NO_GO |
| `asfw/ASFW_REGISTER.md` | 545-item register summary |
| `handoff/HANDOFF-ASGO.md` | What this pass did and did not do |
| `handoff/ROSTER.md` | Named humans still UNSET |
| `docs/DOC-12-known-limitations.md` | Published blockers including LIM-14 |
| `CONDITIONAL_GO.md` | Conditional qualification boundary and release conditions |

```
PYTHONPATH=. python3 -m architecture_studio preflight
PYTHONPATH=. python3 tests/run_all.py
PYTHONPATH=. python3 -m architecture_studio status
PYTHONPATH=. python3 -m architecture_studio gates
PYTHONPATH=. python3 -m architecture_studio asfw
PYTHONPATH=. python3 -m architecture_studio asgo
PYTHONPATH=. python3 -m architecture_studio roster
PYTHONPATH=. python3 -m architecture_studio conditional-go
```

Implementers `builder:architecture-studio-audit-2026-09-11`,
`builder:architecture-studio-asfw-2026-09-11`, and
`builder:architecture-studio-asgo-2026-09-12` cannot mark `PASS`, `VERIFIED`,
`DONE`, or `GO`.

The qualification command writes `evidence/reports/conditional_go.json` and
`evidence/reports/conditional_go.md`. A successful record still reports
`production_verdict: NO_GO` and `promotion_authorized: false`.
