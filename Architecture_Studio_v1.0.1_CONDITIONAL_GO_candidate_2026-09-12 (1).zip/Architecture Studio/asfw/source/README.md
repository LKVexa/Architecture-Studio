# ASFW source pin

Immutable copy of `MASTER_PROMPT_WORKFLOW_PACKAGE.md` recovered for ASGO-0.7.

- sha256: `c94ed9bd6f41bd034cc0136183010f9f7ddb1823fcdb25c55a7c138a026048d2`
- items: `545`

`INDEX.csv` is **ABSENT** and must not be invented here. `asfw/INDEX.derived.csv` is labelled derived and is not the source of truth.
