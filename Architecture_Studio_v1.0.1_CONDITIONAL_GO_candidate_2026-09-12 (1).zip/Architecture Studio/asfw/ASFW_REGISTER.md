# ASFW 545-item register

**Production GO from ASFW:** `NO_GO`

This register is the implementer's intake of the master prompt/workflow package. `IMPLEMENTED` means machinery or overlay coverage exists. It is **not** `VERIFIED`. Source `INDEX.csv` was **not** in the received attachment set. Missing DOD definitions and the eight-vs-nine production-gate question are **unresolved**; they were not inferred.

- package sha256: `c94ed9bd6f41bd034cc0136183010f9f7ddb1823fcdb25c55a7c138a026048d2`
- items: 545
- verified: 0
- complete: 0
- source INDEX.csv: ABSENT
- executable gates: GATE-PROD-01, GATE-PROD-02, GATE-PROD-03, GATE-PROD-04, GATE-PROD-05, GATE-PROD-06, GATE-PROD-07, GATE-PROD-08
- PDF claim: `GATE-PROD-01-09` — resolution `UNRESOLVED`
- missing DOD: DOD-02, DOD-04, DOD-05, DOD-08, DOD-09 — resolution `UNRESOLVED`

## Counts by status

| status | n |
|---|---|
| BLOCKED | 129 |
| IMPLEMENTED | 416 |

## Counts by execution class

| class | n |
|---|---|
| governance_machinery | 7 |
| host_binding | 6 |
| human_authority | 53 |
| in_repo_capability | 409 |
| missing_source_artifact | 1 |
| release_or_post_go | 39 |
| source_ambiguity | 29 |
| unresolved_product_boundary | 1 |

## Source-ambiguity blockers (do not infer)

- `ASFW-TODO-0007` Recover or explicitly approve the missing definitions for `DOD-02`, `DOD-04`, `DOD-05`, `DOD-08`, and `DOD-09`; the PDF announces `DOD-01` through `DOD-09` but visibly lists only four entries.
- `ASFW-TODO-0008` Resolve whether `P15` contains eight or nine production gates. The PDF says `GATE-PROD-01-09`; the visible gate range and any executable gate registry must agree before sign-off.
- `ASFW-TODO-0311` Resolve whether the release has eight or nine production gates; define the ninth if required or correct the source/register under formal change control.
- `ASFW-TODO-0437` Locate the authoritative definition of `DOD-02` in the source package, cited literature, or prior approved specification.
- `ASFW-TODO-0438` If found, copy the exact definition with citation, version, and digest into the master register.
- `ASFW-TODO-0439` If not found, open a formal decision record rather than inventing a definition.
- `ASFW-TODO-0440` Assign an owner and define measurable acceptance criteria, test evidence, reviewer, and gate dependency.
- `ASFW-TODO-0441` Obtain Architecture Authority and Product Authority sign-off.
- `ASFW-TODO-0442` Add the resolved item to the phase/gate map and update the PDF-derived checklist version.
- `ASFW-TODO-0451` Recover the authoritative `DOD-04` definition or create a formal decision record to resolve it.
- `ASFW-TODO-0452` Define observable acceptance criteria, test cases, owner, reviewer, evidence, dependencies, and failure disposition.
- `ASFW-TODO-0453` Map the item to the appropriate phase, lifecycle steps, metric, and production gate.
- `ASFW-TODO-0454` Add regression coverage and a release-blocking rule if the missing definition affects safety, authority, provenance, or output correctness.
- `ASFW-TODO-0455` Obtain human approval and independent verification.
- `ASFW-TODO-0456` Recover or formally resolve `DOD-05`.
- `ASFW-TODO-0457` Identify whether it governs implementation, evidence, UX, operations, or release quality.
- `ASFW-TODO-0458` Define measurable pass/fail criteria and required evidence.
- `ASFW-TODO-0459` Assign accountable and independent reviewers.
- `ASFW-TODO-0460` Add it to the traceability matrix, phase plan, and release gate.
- `ASFW-TODO-0477` Recover or formally resolve `DOD-08`.
- `ASFW-TODO-0478` Do not infer its meaning from numbering or neighboring items; retain the ambiguity until an authority approves it.
- `ASFW-TODO-0479` Define owner, acceptance criteria, test evidence, lifecycle placement, gate impact, review, and expiry.
- `ASFW-TODO-0480` Add the item to the release packet and regression suite.
- `ASFW-TODO-0481` Recover or formally resolve `DOD-09`.
- `ASFW-TODO-0482` Determine whether it is a final release criterion, operational criterion, or omitted design requirement.
- `ASFW-TODO-0483` Define measurable evidence and a blocking/non-blocking policy with Architecture and Release Authorities.
- `ASFW-TODO-0484` Add it to the gate registry and final sign-off form.
- `ASFW-TODO-0485` Independently verify closure and update the source-completeness note.
- `ASFW-TODO-0507` Resolved source-completeness record for missing DOD definitions and P15 gate count.

## Governance items 0001–0006

- `ASFW-TODO-0001` `IMPLEMENTED` complete=False — Assign an owner, implementer, independent reviewer, target environment, due date, and evidence location to every checkbox.
- `ASFW-TODO-0002` `IMPLEMENTED` complete=False — Preserve the source identifiers exactly: `BLK-*`, `DEC-*`, `P*`, `FLOW-*`, metric names, and `DOD-*`.
- `ASFW-TODO-0003` `IMPLEMENTED` complete=False — Add a unique implementation task ID beneath every expanded checkbox when the work is entered into the project tracker.
- `ASFW-TODO-0004` `IMPLEMENTED` complete=False — Link each completed item to code/configuration, tests, raw results, reviewer decision, artifact digest, and the exact release candidate.
- `ASFW-TODO-0005` `IMPLEMENTED` complete=False — Treat `PROPOSED`, `IMPLEMENTED`, `AWAITING_CONFIRMATION`, and `ACCEPTED_RISK` as incomplete until their required human review is complete.
- `ASFW-TODO-0006` `IMPLEMENTED` complete=False — Keep the original PDF and this expanded checklist immutable once used as the release baseline; issue a new version when requirements change.

Independent review is outstanding on every item. This file is not a Production GO.
