#!/usr/bin/env python3
"""ASGO-0.14 / 0.15: recut portable inventory after source and code changes.

Not a release. Not Production GO. Does not write GATE-PROD review files.
"""
from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
OVERLAY = HERE.parent
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))

from architecture_studio.asfw import export_register as export_asfw  # noqa: E402
from architecture_studio.asgo import (  # noqa: E402
    export_register as export_asgo, overlay_tree_report, write_declared_evidence,
)
from architecture_studio import __version__  # noqa: E402
from architecture_studio.canonical import now_iso, sha256_hex  # noqa: E402
from architecture_studio.corpus import EXPECTED_DIGEST, preflight  # noqa: E402
from architecture_studio.evidence_io import atomic_write  # noqa: E402
from architecture_studio.release import build_manifest  # noqa: E402

SKIP_PARTS = {"__pycache__", ".git", ".pytest_cache"}
SKIP_SUFFIX = {".pyc", ".pyo"}


def iter_files(root: Path):
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        rel = path.relative_to(root)
        if any(part in SKIP_PARTS for part in rel.parts):
            continue
        if path.suffix in SKIP_SUFFIX:
            continue
        yield rel, path


def write_sha256sums(root: Path) -> int:
    lines = []
    for rel, path in iter_files(root):
        if rel.as_posix() == "SHA256SUMS.txt":
            continue
        lines.append(f"{sha256_hex(path.read_bytes())}  {rel.as_posix()}\n")
    payload = "".join(lines).encode("utf-8")
    atomic_write(root / "SHA256SUMS.txt", payload)
    return len(lines)


def recut_ledger(root: Path, tree: dict) -> None:
    path = root / "EVIDENCE_LEDGER.json"
    doc = json.loads(path.read_text(encoding="utf-8"))
    for art in doc.get("artifacts", []):
        target = root / art["path"]
        if target.is_file():
            data = target.read_bytes()
            art["bytes"] = len(data)
            art["sha256"] = sha256_hex(data)
            art["status"] = "OBSERVED"
    digest = tree["digest"]
    doc["worktree_manifest_sha256"] = digest.split(":", 1)[-1]
    doc["asgo_recut"] = {
        "at": now_iso(),
        "implementer": "builder:architecture-studio-asgo-2026-09-12",
        "production_go": "NO_GO",
        "overlay_tree": tree,
        "note": "Inventory recut. Protocol verified remains 0. Not a release.",
    }
    atomic_write(path, json.dumps(doc, indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8") + b"\n")


def recut_manifest(root: Path, tree: dict) -> dict:
    tests = json.loads((root / "evidence" / "reports" / "run_all.json").read_text(encoding="utf-8"))
    manifest = build_manifest(
        overlay_root=root,
        corpus_digest="sha256:" + EXPECTED_DIGEST,
        reports={
            "tests": "evidence/reports/run_all.json",
            "gates": "evidence/reports/gates.json",
            "conditional_go": "evidence/reports/conditional_go.json",
        },
        environment="local",
        changelog_ref="CHANGELOG.md",
    )
    manifest["note"] = (
        "This manifest is reproducible and NOT_QUALIFIED for production. "
        "It is not a release. ACCEPTANCE_RULE status is PROPOSED. "
        "GATE-PROD-* are not PASS. ASGO done=0. Conditional GO is local/test-tenant only. "
        "Promotion is a human act."
    )
    manifest["production_verdict"] = "NO_GO"
    manifest["overlay_tree"] = tree
    manifest["qualification"] = {
        "production_read_only": {
            "acceptance_rule": "ACCEPT-RELEASE-01",
            "acceptance_rule_status": "PROPOSED",
            "promotion_is_a_human_act": True,
            "reasons": [
                "GATE-PROD-01 is AWAITING_INDEPENDENT_REVIEW, not PASS",
                "GATE-PROD-02 is FAIL, not PASS",
                "GATE-PROD-03 is AWAITING_INDEPENDENT_REVIEW, not PASS",
                "GATE-PROD-04 is AWAITING_INDEPENDENT_REVIEW, not PASS",
                "GATE-PROD-05 is AWAITING_INDEPENDENT_REVIEW, not PASS",
                "GATE-PROD-06 is AWAITING_INDEPENDENT_REVIEW, not PASS",
                "GATE-PROD-07 is NO_EVIDENCE, not PASS",
                "GATE-PROD-08 is AWAITING_INDEPENDENT_REVIEW, not PASS",
                "benchmark thresholds are PROPOSED; production qualification requires APPROVED thresholds",
                "promotion to production_read_only must come from staging, not local",
            ],
            "release": __version__,
            "target_environment": "production_read_only",
            "verdict": "NOT_QUALIFIED",
            "tests_observed": {"passed": tests.get("passed"), "total": tests.get("total"),
                               "all_passed": tests.get("all_passed")},
        }
    }
    conditional_path = root / "evidence" / "reports" / "conditional_go.json"
    if conditional_path.is_file():
        conditional = json.loads(conditional_path.read_text(encoding="utf-8"))
        manifest["qualification"]["conditional_local"] = {
            key: conditional.get(key) for key in (
                "schema_id", "release", "manifest_digest", "target_environment", "issued_at", "expires_at", "validity_hours",
                "verdict", "production_verdict", "promotion_authorized", "hard_blockers", "conditions",
                "pending_independent_reviews", "evidence_digest", "corpus_digest", "gate_counts", "scope",
            )
        }
        conditional["manifest_digest"] = manifest["manifest_digest"]
        atomic_write(conditional_path, json.dumps(conditional, indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8") + b"\n")
        manifest["qualification"]["conditional_local"]["manifest_digest"] = manifest["manifest_digest"]
    atomic_write(root / "RELEASE_MANIFEST.json",
                 json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8") + b"\n")
    return manifest


def main() -> int:
    flight = preflight()
    if not flight["ok"]:
        print(json.dumps({"error": "preflight_failed", "preflight": flight}, indent=2))
        return 1
    export_asfw(OVERLAY / "asfw")
    export_asgo(OVERLAY / "asgo")
    notes = write_declared_evidence(overlay=OVERLAY)
    tree = overlay_tree_report(OVERLAY)
    manifest = recut_manifest(OVERLAY, tree)
    recut_ledger(OVERLAY, tree)
    n_sums = write_sha256sums(OVERLAY)
    gate_review = list((OVERLAY / "evidence" / "reviews").glob("GATE-PROD-*.json"))
    payload = {
        "production_go": "NO_GO",
        "preflight": {"ok": flight["ok"], "files": flight["files"], "digest": flight["digest"]},
        "overlay_tree": tree,
        "sha256sums_entries": n_sums,
        "declared_notes": notes["written"],
        "gate_prod_review_files_written": [p.name for p in gate_review],
        "release_manifest_verdict": manifest["qualification"]["production_read_only"]["verdict"],
        "cut_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    print(json.dumps(payload, indent=2))
    if gate_review:
        print("refusing to finish: GATE-PROD review files present", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
