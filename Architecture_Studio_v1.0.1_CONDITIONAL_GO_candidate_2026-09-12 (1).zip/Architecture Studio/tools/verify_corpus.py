#!/usr/bin/env python3
"""Assert the generic project corpus beneath this overlay is untouched.

The overlay is additive by contract: it lives in one directory and never writes
outside it. Archive wrappers (``_archive/``, top-level ``SHA256SUMS.txt``) are
not corpus members (ASGO-0.5). This script recomputes the corpus digest and
exits non-zero if a single byte moved.

A missing, wrong-root, or digest-mismatched corpus fails closed with an
actionable code (ASGO-0.6). This is not a Production GO.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
OVERLAY = HERE.parent
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))

from architecture_studio.corpus import (  # noqa: E402
    EXPECTED_DIGEST, EXPECTED_FILES, corpus_digest, preflight,
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, help="write the full file manifest here")
    parser.add_argument("--expect", default=EXPECTED_DIGEST)
    parser.add_argument("--root", type=Path, default=None, help="corpus root (default: overlay.parent)")
    args = parser.parse_args()
    flight = preflight(args.root)
    if args.json:
        full = corpus_digest(Path(flight["root"]))
        args.json.write_text(json.dumps(full, indent=2, sort_keys=True), encoding="utf-8")
    payload = {
        "ok": flight["ok"],
        "code": flight["code"],
        "detail": flight["detail"],
        "files": flight.get("files", 0),
        "expected_files": EXPECTED_FILES,
        "digest": flight.get("digest"),
        "expected_digest": args.expect,
        "untouched": bool(flight["ok"] and flight.get("digest") == args.expect),
    }
    print(json.dumps(payload, indent=2))
    if not flight["ok"]:
        print(flight["detail"], file=sys.stderr)
        return 1
    if flight.get("digest") != args.expect:
        print("the corpus changed: the overlay must never modify the repository it sits on", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
