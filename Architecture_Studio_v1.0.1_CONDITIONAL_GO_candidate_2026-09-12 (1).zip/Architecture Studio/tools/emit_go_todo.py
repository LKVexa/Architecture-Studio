#!/usr/bin/env python3
"""Emit the Production GO to-do list from the current fail-closed state.

This script does not mark GO. DONE items are only in-repo work this implementer
already performed. Everything that needs a distinct human or host stays OPEN.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

OVERLAY = Path(__file__).resolve().parent.parent

IMPLEMENTERS = [
    "builder:architecture-studio-audit-2026-09-11",
    "builder:architecture-studio-asfw-2026-09-11",
    "builder:architecture-studio-asgo-2026-09-12",
]


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def item(iid: str, title: str, status: str, owner: str, *,
         blocked_by: str | None = None, handoff: str | None = None,
         note: str | None = None) -> dict:
    row = {"id": iid, "title": title, "status": status, "owner_role": owner}
    if blocked_by:
        row["blocked_by"] = blocked_by
    if handoff:
        row["handoff"] = handoff
    if note:
        row["note"] = note
    return row


def wave(wid: str, title: str, status: str, owner: str, summary: str, items: list[dict]) -> dict:
    open_n = sum(1 for i in items if i["status"] == "OPEN")
    done_n = sum(1 for i in items if i["status"] == "DONE")
    return {
        "id": wid, "title": title, "status": status, "owner_role": owner,
        "summary": summary, "open": open_n, "done": done_n, "items": items,
    }


WAVES = [
    wave("W0", "In-repo work already on disk", "DONE", "implementer",
         "Overlay remediations, ASFW register, ASGO 150-item ingest, unbound chat-offer intake. Not verification.",
         [
             item("GO-0.1", "Now-relative fixture issued_at", "DONE", "implementer"),
             item("GO-0.2", "CLI gates assemble mechanical evidence", "DONE", "implementer"),
             item("GO-0.3", "WriteGate bundle; consume-before-write", "DONE", "implementer"),
             item("GO-0.4", "Path confinement", "DONE", "implementer"),
             item("GO-0.5", "Control-to-test mapping", "DONE", "implementer"),
             item("GO-0.6", "Write-authority scan clean", "DONE", "implementer"),
             item("GO-0.7", "DOC-12 / LIM-08 / LIM-13 / LIM-14 state remaining blockers", "DONE", "implementer"),
             item("GO-0.8", "On-disk review loader; implementer signatures refused", "DONE", "implementer"),
             item("GO-0.9", "ASFW package pinned; 545 items ingested; source INDEX.csv recorded ABSENT", "DONE", "implementer"),
             item("GO-0.10", "ASFW-TODO-0001..0006 governance machinery (roles, unique IDs, evidence links, incomplete-until-review)", "DONE", "implementer"),
             item("GO-0.11", "ASFW-TODO-0007/0008 not inferred; keep-undefined records written", "DONE", "implementer"),
             item("GO-0.12", "CTRL-ASFW-01 denies self-attested GO, invented DOD, invented ninth gate", "DONE", "implementer"),
             item("GO-0.13", "Chat signature RUSSELL PHILIP SMITHSON recorded as PROPOSED_UNBOUND research_specialist only", "DONE", "implementer"),
             item("GO-0.14", "Overlay tests with sibling corpus; digest 16b9800f… untouched. 150/150 was pre-ASGO; live count is tests/run_all.py", "DONE", "implementer"),
             item("GO-0.15", "ASGO 150-item package pinned (41209097…); overlay-only contract; preflight fail-closed; archive wrappers skipped", "DONE", "implementer"),
             item("GO-0.16", "CTRL-ASGO-01 denies self-attested GO, invented INDEX.csv, invented ninth gate, DONE-by-implementer", "DONE", "implementer"),
             item("GO-0.17", "ASGO evidence written to package-declared paths; GATE-PROD-*.json reserved for independent reviewers", "DONE", "implementer"),
             item("GO-0.18", "Portable overlay-relative pins/manifests; hygiene scan; overlay tree digest recut after changes", "DONE", "implementer"),
         ]),
    wave("W1", "Source completeness — do not invent", "OPEN", "architecture_owner",
         "PDF gaps still block GO. Keep-undefined records exist and do not unblock.",
         [
             item("GO-1.1", "Recover source INDEX.csv from the package owner, or sign that its absence remains a GO blocker",
                  "OPEN", "data_owner", handoff="handoff/HANDOFF-ASFW-0007-0008-SOURCE-AMBIGUITY.md",
                  note="Derived INDEX.derived.csv is not the source of truth"),
             item("GO-1.2", "Recover DOD-02 from the source PDF with exact text, citation, version, digest",
                  "OPEN", "architecture_owner", blocked_by="missing source PDF"),
             item("GO-1.3", "Recover DOD-04 the same way", "OPEN", "architecture_owner"),
             item("GO-1.4", "Recover DOD-05 the same way", "OPEN", "architecture_owner"),
             item("GO-1.5", "Recover DOD-08 the same way", "OPEN", "architecture_owner"),
             item("GO-1.6", "Recover DOD-09 the same way", "OPEN", "architecture_owner"),
             item("GO-1.7", "If a DOD definition cannot be found, Architecture + Product Authority sign KEEP_UNDEFINED as still blocking — do not invent text",
                  "OPEN", "product_owner",
                  note="DEC-ASFW-0007 is an implementer keep-undefined record, not that sign-off"),
             item("GO-1.8", "Resolve 8 vs 9 gates from the PDF: produce GATE-PROD-09 definition OR sign that the PDF range is in error and executable GATE-PROD-01..08 is complete",
                  "OPEN", "architecture_owner",
                  note="Do not add a ninth gate by inference. DEC-ASFW-0008 does not unblock."),
             item("GO-1.9", "Confirm cited literature version, section numbers, retrieval date, source digest (ASFW-TODO-0010)",
                  "OPEN", "data_owner"),
             item("GO-1.10", "Reconcile Architecture Studio vs Design-to-Sprint / Design Analyzer / Decision Context / Full-Loop ownership (ASFW-TODO-0011)",
                  "OPEN", "architecture_owner"),
         ]),
    wave("W2", "Name distinct humans (IdP subjects)", "OPEN", "product_owner",
         "A chat display name is not a filled row. One person cannot occupy independent slots.",
         [
             item("GO-2.1", "Name product_owner (IdP subject)", "OPEN", "product_owner", handoff="handoff/ROSTER.md"),
             item("GO-2.2", "Name security_privacy_owner", "OPEN", "product_owner"),
             item("GO-2.3", "Name independent_security_reviewer ≠ security owner", "OPEN", "product_owner"),
             item("GO-2.4", "Name architecture_owner", "OPEN", "product_owner"),
             item("GO-2.5", "Name independent_architecture_reviewer ≠ architecture owner", "OPEN", "product_owner"),
             item("GO-2.6", "Name ml_evaluation_owner", "OPEN", "product_owner"),
             item("GO-2.7", "Name independent_evaluation_reviewer ≠ ml eval owner", "OPEN", "product_owner"),
             item("GO-2.8", "Name incident_response_owner", "OPEN", "product_owner"),
             item("GO-2.9", "Name independent_operations_reviewer ≠ incident owner", "OPEN", "product_owner"),
             item("GO-2.10", "Name human_review_policy_owner", "OPEN", "product_owner"),
             item("GO-2.11", "Name release_owner", "OPEN", "product_owner"),
             item("GO-2.12", "Name independent_verifier — distinct trusted principal, not this chat, not either implementer id",
                  "OPEN", "product_owner"),
             item("GO-2.13", "Name identity_owner (IdP bind)", "OPEN", "product_owner"),
             item("GO-2.14", "Name crypto_owner (KMS bind)", "OPEN", "product_owner"),
             item("GO-2.15", "If RUSSELL PHILIP SMITHSON is to be consulted research_specialist, bind via host IdP on a channel independent of the implementer session — still not an independent reviewer",
                  "OPEN", "identity_owner",
                  note="Title does not qualify for architecture/security/release/verifier"),
             item("GO-2.16", "Confirm unique humans; no independent_* equals the corresponding owner; none of the implementer subjects",
                  "OPEN", "product_owner"),
             item("GO-2.17", "Write evidence/reviews/roster.json from the filled ROSTER.md", "OPEN", "product_owner"),
         ]),
    wave("W3", "Host identity and keys", "OPEN", "identity_owner",
         "Local reference IdP/KEK are not production authentication or encryption.",
         [
             item("GO-3.1", "Bind host identity provider into IdentityBinding with a human binding_ref",
                  "OPEN", "identity_owner", handoff="handoff/HANDOFF-IDP-BINDING.md", blocked_by="W2"),
             item("GO-3.2", "Re-prove placeholder identities refused and service principals cannot approve against the bound IdP",
                  "OPEN", "identity_owner"),
             item("GO-3.3", "Bind host KMS into the KeyProvider slot; do not store plaintext while reporting encrypted",
                  "OPEN", "crypto_owner", handoff="handoff/HANDOFF-KMS-BINDING.md"),
             item("GO-3.4", "Install optional cryptography extra in the production image if Ed25519/AES-GCM must be in force",
                  "OPEN", "crypto_owner"),
             item("GO-3.5", "Record rotation and revocation runbooks for IdP and KMS", "OPEN", "incident_response_owner"),
         ]),
    wave("W4", "Provision environments", "OPEN", "incident_response_owner",
         "Declared descriptors are not provisioned hosts. ENV-04/05 remain UNRESOLVED.",
         [
             item("GO-4.1", "Provision CI that runs the overlay suite on every change",
                  "OPEN", "incident_response_owner", handoff="handoff/HANDOFF-ENV-PROVISIONING.md", blocked_by="W2"),
             item("GO-4.2", "Provision staging with the same fail-closed policy", "OPEN", "incident_response_owner"),
             item("GO-4.3", "product_owner signs ENV-04 production_read_only: APPLICABLE+provision or NOT_APPLICABLE+rationale",
                  "OPEN", "product_owner"),
             item("GO-4.4", "security_privacy_owner signs ENV-05 privileged_execution the same way",
                  "OPEN", "security_privacy_owner"),
             item("GO-4.5", "Re-run incident drill and recovery on provisioned hosts; attach host evidence",
                  "OPEN", "incident_response_owner"),
         ]),
    wave("W5", "Approve numbers, model, pilot, release rule", "OPEN", "ml_evaluation_owner",
         "Nothing passes on a PROPOSED threshold. This implementer will not flip the flags.",
         [
             item("GO-5.1", "ml_evaluation_owner approves or refuses every numeric threshold; unlisted stay PROPOSED",
                  "OPEN", "ml_evaluation_owner", handoff="handoff/HANDOFF-THRESHOLD-APPROVAL.md", blocked_by="W2"),
             item("GO-5.2", "Set Thresholds.status=APPROVED only for approved ids with approval_ref; re-run benchmark so GATE-PROD-02 mechanical can become EVIDENCE_PASS",
                  "OPEN", "ml_evaluation_owner"),
             item("GO-5.3", "Bind a real model provider as a recorded human act, or sign that this deployment ships the deterministic generator only",
                  "OPEN", "product_owner"),
             item("GO-5.4", "Run or formally defer the pilot (XEVAL-06 / AUDIT-ADD-25)", "OPEN", "ml_evaluation_owner"),
             item("GO-5.5", "release_owner approves the release acceptance rule (currently PROPOSED)",
                  "OPEN", "release_owner"),
         ]),
    wave("W6", "Independent security / privacy review", "OPEN", "independent_security_reviewer",
         "GATE-PROD-07 is NO_EVIDENCE because the runtime cannot review itself.",
         [
             item("GO-6.1", "Independent security reviewer writes evidence/reviews/GATE-PROD-07-security.json",
                  "OPEN", "independent_security_reviewer",
                  handoff="handoff/HANDOFF-SECURITY-PRIVACY-REVIEW.md", blocked_by="W2"),
             item("GO-6.2", "Review DOC-05 vs controls, write authority, approval tokens, classification, channel isolation, process-level sandbox, unbound-or-bound IdP/KMS, corpus-only connectors",
                  "OPEN", "independent_security_reviewer"),
             item("GO-6.3", "State whether LIM-04/05/06 are accepted for this production target or remain blockers",
                  "OPEN", "independent_security_reviewer"),
         ]),
    wave("W7", "Independent review of GATE-PROD-01..08", "OPEN", "independent_security_reviewer",
         "Mechanical EVIDENCE_PASS is not PASS. One JSON file per gate. Chat signatures are refused.",
         [
             item("GO-7.1", "GATE-PROD-01 review by independent_security_reviewer (evidence already mechanical PASS)",
                  "OPEN", "independent_security_reviewer", handoff="handoff/HANDOFF-INDEPENDENT-REVIEW.md", blocked_by="W2"),
             item("GO-7.2", "GATE-PROD-03 review by independent_security_reviewer", "OPEN", "independent_security_reviewer"),
             item("GO-7.3", "GATE-PROD-04 review by independent_architecture_reviewer", "OPEN", "independent_architecture_reviewer"),
             item("GO-7.4", "GATE-PROD-05 review by independent_security_reviewer", "OPEN", "independent_security_reviewer"),
             item("GO-7.5", "GATE-PROD-06 review by independent_operations_reviewer (host drill from W4.5 preferred)",
                  "OPEN", "independent_operations_reviewer"),
             item("GO-7.6", "GATE-PROD-08 review by product_owner", "OPEN", "product_owner"),
             item("GO-7.7", "GATE-PROD-02 review by independent_evaluation_reviewer after W5.2 mechanical PASS",
                  "OPEN", "independent_evaluation_reviewer", blocked_by="W5.2"),
             item("GO-7.8", "GATE-PROD-07 review by independent_security_reviewer after W6 mechanical PASS",
                  "OPEN", "independent_security_reviewer", blocked_by="W6.1"),
         ]),
    wave("W8", "Independent review of the 545 ASFW items", "OPEN", "independent_verifier",
         "416 IMPLEMENTED and 129 BLOCKED. Complete==0. Implementer cannot sign.",
         [
             item("GO-8.1", "Appoint ASFW independent reviewers distinct from both implementer ids and from the unbound chat offer",
                  "OPEN", "product_owner", handoff="handoff/HANDOFF-ASFW-INDEPENDENT-REVIEW.md", blocked_by="W2"),
             item("GO-8.2", "Independently review each of the 416 IMPLEMENTED items; attach evidence_digest + decision per item",
                  "OPEN", "independent_verifier"),
             item("GO-8.3", "Disposition the 129 BLOCKED items: remain BLOCKED until W1/W2/W3/W4/W5 close, or NOT_APPLICABLE with signed authority — never silently VERIFIED",
                  "OPEN", "independent_verifier"),
             item("GO-8.4", "Refuse any review file signed by architecture_studio, runtime, generator, or either implementer builder id",
                  "OPEN", "independent_verifier"),
             item("GO-8.5", "ASFW GO requires verified==545 and complete==545; keep-undefined DOD/gate-count still block until W1 closes",
                  "OPEN", "independent_verifier", blocked_by="W1"),
         ]),
    wave("W9", "Independent verification of 227 protocol tasks", "OPEN", "independent_verifier",
         "Protocol v3: 1 IMPLEMENTED, 226 BLOCKED, 0 VERIFIED, verifier=null.",
         [
             item("GO-9.1", "Appoint independent_verifier (W2.12). Not this session. Not either builder id.",
                  "OPEN", "product_owner", handoff="handoff/HANDOFF-INDEPENDENT-VERIFICATION.md", blocked_by="W2"),
             item("GO-9.2", "Verifier obtains ASRTD v1.4.0 independently; tools/build_evidence.py is not the sealed checker",
                  "OPEN", "independent_verifier"),
             item("GO-9.3", "Recompute corpus digest (612 files, 16b9800f…) and overlay tree digest; re-run suite and gates on the verifier machine",
                  "OPEN", "independent_verifier"),
             item("GO-9.4", "Verify records in application order; do not verify a task whose prerequisites are not VERIFIED",
                  "OPEN", "independent_verifier"),
             item("GO-9.5", "Close phases P0→P14 only after required tasks are VERIFIED; P15 last (the eight GATE-PROD tasks, after W7)",
                  "OPEN", "independent_verifier", blocked_by="W7"),
             item("GO-9.6", "V3 tasks require a distinct trusted principal, not a second process of the same implementer",
                  "OPEN", "independent_verifier"),
             item("GO-9.7", "Rewrite INDEPENDENT_VERIFICATION_REPORT.md as the verifier (today NOT_PERFORMED)",
                  "OPEN", "independent_verifier"),
         ]),
    wave("W10", "Qualify and promote", "OPEN", "release_owner",
         "qualify() never promotes. ACCEPTED_RISK never counts as PASS.",
         [
             item("GO-10.1", "Re-cut RELEASE_MANIFEST.json from the verified tree (today NOT_QUALIFIED)",
                  "OPEN", "release_owner", handoff="handoff/HANDOFF-ASFW-RELEASE.md", blocked_by="W7,W8,W9"),
             item("GO-10.2", "qualify(..., production_read_only) returns QUALIFIED with empty reasons",
                  "OPEN", "release_owner"),
             item("GO-10.3", "release_owner records promotion through the approval gate after the independent verifier has signed",
                  "OPEN", "release_owner"),
             item("GO-10.4", "Attach rollback plan + host recovery evidence from W4.5", "OPEN", "incident_response_owner"),
             item("GO-10.5", "Stamp Production GO only if W7 PASS==8, W8 ASFW verified==545, W9 protocol verified==227, and W1 source gaps closed — all on the same digest",
                  "OPEN", "release_owner"),
         ]),
]


def build() -> dict:
    items = [i for w in WAVES for i in w["items"]]
    return {
        "schema": "as.production_go_todo/2",
        "generated_at": now(),
        "verdict_now": "NO_GO",
        "implementers": IMPLEMENTERS,
        "offered_unbound": {
            "display_name": "RUSSELL PHILIP SMITHSON",
            "title": "Research Specialist",
            "organization": "LK/Vexa",
            "status": "PROPOSED_UNBOUND",
            "independence": "NOT_ESTABLISHED",
            "eligible_roles": ["research_specialist"],
            "fills_roster": False,
            "may_review_gates": False,
        },
        "definition_of_go": [
            "all overlay tests PASS with sibling corpus present and preflight ok (a 150/150 taken from an overlay-only zip without corpus is invalid)",
            "ASGO 150 items independently complete (done==150, verified==150); IMPLEMENTED is not DONE",
            "corpus digest unchanged (612 files, 16b9800f326777dcd5f6e4d58aeb97cc99ceb3a972abbbce37b0d48f1289d4e2)",
            "docs freshness all_current",
            "source INDEX.csv PRESENT or a signed SoT decision that its absence is accepted as still-blocking is replaced by recovery",
            "DOD-02/04/05/08/09 recovered from the PDF or signed KEEP_UNDEFINED still-blocking is replaced by recovered definitions",
            "PDF GATE-PROD-01-09 and executable GATE-PROD-01..08 agree without inventing a ninth gate",
            "GATE-PROD-01..08 all PASS (not ACCEPTED_RISK) with independent human reviews",
            "ASFW 545 items independently VERIFIED (complete==545)",
            "protocol_status.verified == 227 with verifier distinct from both implementer ids",
            "release qualify QUALIFIED for production_read_only",
            "human release_owner records promotion after the verifier signs",
        ],
        "forbidden": [
            "dummy IdP or KMS",
            "self-review or chat-signature review",
            "one person occupying every independent role",
            "inventing missing DOD text",
            "inventing GATE-PROD-09",
            "treating derived INDEX.derived.csv as source INDEX.csv",
            "flipping thresholds_status from the implementer",
            "marking 226 protocol records or 545 ASFW items VERIFIED without a distinct verifier",
            "counting ACCEPTED_RISK as PASS",
            "treating the local test suite as GO",
            "citing 150/150 from an overlay-only zip without the sibling corpus",
            "marking ASGO items DONE or VERIFIED from this session",
            "assigning RUSSELL PHILIP SMITHSON to independent_verifier or architecture_owner from this chat",
        ],
        "current": {
            "tests": "163/163 with sibling corpus and preflight ok; overlay-only zip without corpus is not this count",
            "asgo": {"total": 150, "verified": 0, "done": 0, "complete": 0, "production_go": "NO_GO"},
            "asfw": {"total": 545, "implemented": 416, "blocked": 129, "verified": 0, "complete": 0},
            "gates": {"PASS": 0, "AWAITING_INDEPENDENT_REVIEW": 6, "FAIL": 1, "NO_EVIDENCE": 1},
            "protocol": {"implemented": 1, "blocked": 226, "verified": 0, "verifier": None},
            "roster_bound": 0,
            "source_index_csv": "ABSENT",
            "dod_resolution": "RECORDED_UNDEFINED_STILL_BLOCKING",
            "gate_count_resolution": "RECORDED_DISAGREEMENT_STILL_BLOCKING",
        },
        "waves": WAVES,
        "counts": {
            "total": len(items),
            "done": sum(1 for i in items if i["status"] == "DONE"),
            "open": sum(1 for i in items if i["status"] == "OPEN"),
        },
        "parallelism": (
            "W0 is done. W1 (source PDF) and W2 (roster) first. "
            "W3, W4, W5, W6 in parallel after W2. "
            "W7.1–W7.6 after W2 (mechanical evidence already PASS). "
            "W7.7 waits on W5; W7.8 waits on W6. "
            "W8 after W2 and W1. W9 after W7. W10 last."
        ),
    }


def render_md(doc: dict) -> str:
    lines = [
        "# Production GO — to-do list",
        "",
        f"**Current verdict: `{doc['verdict_now']}`.** Crossing an item off by editing a label is forbidden.",
        "",
        f"Generated {doc['generated_at']}. Implementers: " + ", ".join(f"`{i}`" for i in doc["implementers"]) + ".",
        "Verifier `null`. Overlay `1.0.0` / ASRTD v1.4.0 / ASFW 545 pin `c94ed9bd…`.",
        "",
        f"Progress: **{doc['counts']['done']} done / {doc['counts']['open']} open / {doc['counts']['total']} total.**",
        "",
        "## Definition of Production GO (all must be true together)",
        "",
    ]
    for i, rule in enumerate(doc["definition_of_go"], 1):
        lines.append(f"{i}. {rule}")
    lines += [
        "",
        "## Forbidden shortcuts",
        "",
    ]
    for f in doc["forbidden"]:
        lines.append(f"- {f}")
    cur = doc["current"]
    lines += [
        "",
        "## Snapshot now",
        "",
        "| Axis | State |",
        "|---|---|",
        f"| Tests | {cur['tests']} (not GO) |",
        f"| ASGO | {cur['asgo']['done']} DONE / {cur['asgo']['verified']} VERIFIED of {cur['asgo']['total']} · {cur['asgo']['production_go']} |",
        f"| ASFW | {cur['asfw']['implemented']} IMPLEMENTED / {cur['asfw']['blocked']} BLOCKED / {cur['asfw']['verified']} VERIFIED of {cur['asfw']['total']} |",
        f"| Gates | PASS {cur['gates']['PASS']} · AWAITING {cur['gates']['AWAITING_INDEPENDENT_REVIEW']} · FAIL {cur['gates']['FAIL']} · NO_EVIDENCE {cur['gates']['NO_EVIDENCE']} |",
        f"| Protocol | {cur['protocol']['implemented']} IMPLEMENTED / {cur['protocol']['blocked']} BLOCKED / {cur['protocol']['verified']} VERIFIED |",
        f"| Roster bound | {cur['roster_bound']} |",
        f"| INDEX.csv | {cur['source_index_csv']} |",
        f"| Missing DOD | {cur['dod_resolution']} |",
        f"| 8 vs 9 gates | {cur['gate_count_resolution']} |",
        "",
        "Chat offer `RUSSELL PHILIP SMITHSON` is `PROPOSED_UNBOUND` consulted research_specialist. "
        "It does not fill the roster and cannot review gates.",
        "",
        f"## Parallelism",
        "",
        doc["parallelism"],
        "",
    ]
    for w in doc["waves"]:
        mark = "DONE" if w["status"] == "DONE" else "OPEN"
        lines += [
            f"## {w['id']} — {w['title']} ({mark}: {w['done']} done, {w['open']} open)",
            "",
            w["summary"],
            "",
        ]
        for it in w["items"]:
            box = "[x]" if it["status"] == "DONE" else "[ ]"
            extra = []
            if it.get("owner_role"):
                extra.append(f"owner `{it['owner_role']}`")
            if it.get("blocked_by"):
                extra.append(f"blocked by {it['blocked_by']}")
            if it.get("handoff"):
                extra.append(f"→ `{it['handoff']}`")
            suffix = f" — {'; '.join(extra)}" if extra else ""
            lines.append(f"- {box} **{it['id']}** {it['title']}{suffix}")
            if it.get("note"):
                lines.append(f"  - {it['note']}")
        lines.append("")
    lines += [
        "## How to check progress",
        "",
        "Progress is: W1 source gaps closed from the PDF, roster bound to distinct IdP subjects, "
        "`GATE-PROD` PASS rising 0 → 8, ASFW verified 0 → 545, protocol verified 0 → 227 under a "
        "distinct verifier, then a human release_owner promotes. Anything else is not GO.",
        "",
    ]
    return "\n".join(lines)


def main() -> int:
    doc = build()
    (OVERLAY / "PRODUCTION_GO_TODO.json").write_text(
        json.dumps(doc, indent=2, sort_keys=True, ensure_ascii=True) + "\n", encoding="utf-8")
    (OVERLAY / "PRODUCTION_GO_TODO.md").write_text(render_md(doc), encoding="utf-8")
    print(json.dumps({"verdict": doc["verdict_now"], **doc["counts"], "waves": len(doc["waves"])}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
