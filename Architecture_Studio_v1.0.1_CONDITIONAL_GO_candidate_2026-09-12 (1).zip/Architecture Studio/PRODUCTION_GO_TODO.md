# Production GO — to-do list

**Current verdict: `NO_GO`.** Crossing an item off by editing a label is forbidden.

Generated 2026-09-12T02:52:36Z. Implementers: `builder:architecture-studio-audit-2026-09-11`, `builder:architecture-studio-asfw-2026-09-11`, `builder:architecture-studio-asgo-2026-09-12`.
Verifier `null`. Overlay `1.0.0` / ASRTD v1.4.0 / ASFW 545 pin `c94ed9bd…`.

Progress: **18 done / 70 open / 88 total.**

## Definition of Production GO (all must be true together)

1. all overlay tests PASS with sibling corpus present and preflight ok (a 150/150 taken from an overlay-only zip without corpus is invalid)
2. ASGO 150 items independently complete (done==150, verified==150); IMPLEMENTED is not DONE
3. corpus digest unchanged (612 files, 16b9800f326777dcd5f6e4d58aeb97cc99ceb3a972abbbce37b0d48f1289d4e2)
4. docs freshness all_current
5. source INDEX.csv PRESENT or a signed SoT decision that its absence is accepted as still-blocking is replaced by recovery
6. DOD-02/04/05/08/09 recovered from the PDF or signed KEEP_UNDEFINED still-blocking is replaced by recovered definitions
7. PDF GATE-PROD-01-09 and executable GATE-PROD-01..08 agree without inventing a ninth gate
8. GATE-PROD-01..08 all PASS (not ACCEPTED_RISK) with independent human reviews
9. ASFW 545 items independently VERIFIED (complete==545)
10. protocol_status.verified == 227 with verifier distinct from both implementer ids
11. release qualify QUALIFIED for production_read_only
12. human release_owner records promotion after the verifier signs

## Forbidden shortcuts

- dummy IdP or KMS
- self-review or chat-signature review
- one person occupying every independent role
- inventing missing DOD text
- inventing GATE-PROD-09
- treating derived INDEX.derived.csv as source INDEX.csv
- flipping thresholds_status from the implementer
- marking 226 protocol records or 545 ASFW items VERIFIED without a distinct verifier
- counting ACCEPTED_RISK as PASS
- treating the local test suite as GO
- citing 150/150 from an overlay-only zip without the sibling corpus
- marking ASGO items DONE or VERIFIED from this session
- assigning RUSSELL PHILIP SMITHSON to independent_verifier or architecture_owner from this chat

## Snapshot now

| Axis | State |
|---|---|
| Tests | 163/163 with sibling corpus and preflight ok; overlay-only zip without corpus is not this count (not GO) |
| ASGO | 0 DONE / 0 VERIFIED of 150 · NO_GO |
| ASFW | 416 IMPLEMENTED / 129 BLOCKED / 0 VERIFIED of 545 |
| Gates | PASS 0 · AWAITING 6 · FAIL 1 · NO_EVIDENCE 1 |
| Protocol | 1 IMPLEMENTED / 226 BLOCKED / 0 VERIFIED |
| Roster bound | 0 |
| INDEX.csv | ABSENT |
| Missing DOD | RECORDED_UNDEFINED_STILL_BLOCKING |
| 8 vs 9 gates | RECORDED_DISAGREEMENT_STILL_BLOCKING |

Chat offer `RUSSELL PHILIP SMITHSON` is `PROPOSED_UNBOUND` consulted research_specialist. It does not fill the roster and cannot review gates.

## Parallelism

W0 is done. W1 (source PDF) and W2 (roster) first. W3, W4, W5, W6 in parallel after W2. W7.1–W7.6 after W2 (mechanical evidence already PASS). W7.7 waits on W5; W7.8 waits on W6. W8 after W2 and W1. W9 after W7. W10 last.

## W0 — In-repo work already on disk (DONE: 18 done, 0 open)

Overlay remediations, ASFW register, ASGO 150-item ingest, unbound chat-offer intake. Not verification.

- [x] **GO-0.1** Now-relative fixture issued_at — owner `implementer`
- [x] **GO-0.2** CLI gates assemble mechanical evidence — owner `implementer`
- [x] **GO-0.3** WriteGate bundle; consume-before-write — owner `implementer`
- [x] **GO-0.4** Path confinement — owner `implementer`
- [x] **GO-0.5** Control-to-test mapping — owner `implementer`
- [x] **GO-0.6** Write-authority scan clean — owner `implementer`
- [x] **GO-0.7** DOC-12 / LIM-08 / LIM-13 / LIM-14 state remaining blockers — owner `implementer`
- [x] **GO-0.8** On-disk review loader; implementer signatures refused — owner `implementer`
- [x] **GO-0.9** ASFW package pinned; 545 items ingested; source INDEX.csv recorded ABSENT — owner `implementer`
- [x] **GO-0.10** ASFW-TODO-0001..0006 governance machinery (roles, unique IDs, evidence links, incomplete-until-review) — owner `implementer`
- [x] **GO-0.11** ASFW-TODO-0007/0008 not inferred; keep-undefined records written — owner `implementer`
- [x] **GO-0.12** CTRL-ASFW-01 denies self-attested GO, invented DOD, invented ninth gate — owner `implementer`
- [x] **GO-0.13** Chat signature RUSSELL PHILIP SMITHSON recorded as PROPOSED_UNBOUND research_specialist only — owner `implementer`
- [x] **GO-0.14** Overlay tests with sibling corpus; digest 16b9800f… untouched. 150/150 was pre-ASGO; live count is tests/run_all.py — owner `implementer`
- [x] **GO-0.15** ASGO 150-item package pinned (41209097…); overlay-only contract; preflight fail-closed; archive wrappers skipped — owner `implementer`
- [x] **GO-0.16** CTRL-ASGO-01 denies self-attested GO, invented INDEX.csv, invented ninth gate, DONE-by-implementer — owner `implementer`
- [x] **GO-0.17** ASGO evidence written to package-declared paths; GATE-PROD-*.json reserved for independent reviewers — owner `implementer`
- [x] **GO-0.18** Portable overlay-relative pins/manifests; hygiene scan; overlay tree digest recut after changes — owner `implementer`

## W1 — Source completeness — do not invent (OPEN: 0 done, 10 open)

PDF gaps still block GO. Keep-undefined records exist and do not unblock.

- [ ] **GO-1.1** Recover source INDEX.csv from the package owner, or sign that its absence remains a GO blocker — owner `data_owner`; → `handoff/HANDOFF-ASFW-0007-0008-SOURCE-AMBIGUITY.md`
  - Derived INDEX.derived.csv is not the source of truth
- [ ] **GO-1.2** Recover DOD-02 from the source PDF with exact text, citation, version, digest — owner `architecture_owner`; blocked by missing source PDF
- [ ] **GO-1.3** Recover DOD-04 the same way — owner `architecture_owner`
- [ ] **GO-1.4** Recover DOD-05 the same way — owner `architecture_owner`
- [ ] **GO-1.5** Recover DOD-08 the same way — owner `architecture_owner`
- [ ] **GO-1.6** Recover DOD-09 the same way — owner `architecture_owner`
- [ ] **GO-1.7** If a DOD definition cannot be found, Architecture + Product Authority sign KEEP_UNDEFINED as still blocking — do not invent text — owner `product_owner`
  - DEC-ASFW-0007 is an implementer keep-undefined record, not that sign-off
- [ ] **GO-1.8** Resolve 8 vs 9 gates from the PDF: produce GATE-PROD-09 definition OR sign that the PDF range is in error and executable GATE-PROD-01..08 is complete — owner `architecture_owner`
  - Do not add a ninth gate by inference. DEC-ASFW-0008 does not unblock.
- [ ] **GO-1.9** Confirm cited literature version, section numbers, retrieval date, source digest (ASFW-TODO-0010) — owner `data_owner`
- [ ] **GO-1.10** Reconcile Architecture Studio vs Design-to-Sprint / Design Analyzer / Decision Context / Full-Loop ownership (ASFW-TODO-0011) — owner `architecture_owner`

## W2 — Name distinct humans (IdP subjects) (OPEN: 0 done, 17 open)

A chat display name is not a filled row. One person cannot occupy independent slots.

- [ ] **GO-2.1** Name product_owner (IdP subject) — owner `product_owner`; → `handoff/ROSTER.md`
- [ ] **GO-2.2** Name security_privacy_owner — owner `product_owner`
- [ ] **GO-2.3** Name independent_security_reviewer ≠ security owner — owner `product_owner`
- [ ] **GO-2.4** Name architecture_owner — owner `product_owner`
- [ ] **GO-2.5** Name independent_architecture_reviewer ≠ architecture owner — owner `product_owner`
- [ ] **GO-2.6** Name ml_evaluation_owner — owner `product_owner`
- [ ] **GO-2.7** Name independent_evaluation_reviewer ≠ ml eval owner — owner `product_owner`
- [ ] **GO-2.8** Name incident_response_owner — owner `product_owner`
- [ ] **GO-2.9** Name independent_operations_reviewer ≠ incident owner — owner `product_owner`
- [ ] **GO-2.10** Name human_review_policy_owner — owner `product_owner`
- [ ] **GO-2.11** Name release_owner — owner `product_owner`
- [ ] **GO-2.12** Name independent_verifier — distinct trusted principal, not this chat, not either implementer id — owner `product_owner`
- [ ] **GO-2.13** Name identity_owner (IdP bind) — owner `product_owner`
- [ ] **GO-2.14** Name crypto_owner (KMS bind) — owner `product_owner`
- [ ] **GO-2.15** If RUSSELL PHILIP SMITHSON is to be consulted research_specialist, bind via host IdP on a channel independent of the implementer session — still not an independent reviewer — owner `identity_owner`
  - Title does not qualify for architecture/security/release/verifier
- [ ] **GO-2.16** Confirm unique humans; no independent_* equals the corresponding owner; none of the implementer subjects — owner `product_owner`
- [ ] **GO-2.17** Write evidence/reviews/roster.json from the filled ROSTER.md — owner `product_owner`

## W3 — Host identity and keys (OPEN: 0 done, 5 open)

Local reference IdP/KEK are not production authentication or encryption.

- [ ] **GO-3.1** Bind host identity provider into IdentityBinding with a human binding_ref — owner `identity_owner`; blocked by W2; → `handoff/HANDOFF-IDP-BINDING.md`
- [ ] **GO-3.2** Re-prove placeholder identities refused and service principals cannot approve against the bound IdP — owner `identity_owner`
- [ ] **GO-3.3** Bind host KMS into the KeyProvider slot; do not store plaintext while reporting encrypted — owner `crypto_owner`; → `handoff/HANDOFF-KMS-BINDING.md`
- [ ] **GO-3.4** Install optional cryptography extra in the production image if Ed25519/AES-GCM must be in force — owner `crypto_owner`
- [ ] **GO-3.5** Record rotation and revocation runbooks for IdP and KMS — owner `incident_response_owner`

## W4 — Provision environments (OPEN: 0 done, 5 open)

Declared descriptors are not provisioned hosts. ENV-04/05 remain UNRESOLVED.

- [ ] **GO-4.1** Provision CI that runs the overlay suite on every change — owner `incident_response_owner`; blocked by W2; → `handoff/HANDOFF-ENV-PROVISIONING.md`
- [ ] **GO-4.2** Provision staging with the same fail-closed policy — owner `incident_response_owner`
- [ ] **GO-4.3** product_owner signs ENV-04 production_read_only: APPLICABLE+provision or NOT_APPLICABLE+rationale — owner `product_owner`
- [ ] **GO-4.4** security_privacy_owner signs ENV-05 privileged_execution the same way — owner `security_privacy_owner`
- [ ] **GO-4.5** Re-run incident drill and recovery on provisioned hosts; attach host evidence — owner `incident_response_owner`

## W5 — Approve numbers, model, pilot, release rule (OPEN: 0 done, 5 open)

Nothing passes on a PROPOSED threshold. This implementer will not flip the flags.

- [ ] **GO-5.1** ml_evaluation_owner approves or refuses every numeric threshold; unlisted stay PROPOSED — owner `ml_evaluation_owner`; blocked by W2; → `handoff/HANDOFF-THRESHOLD-APPROVAL.md`
- [ ] **GO-5.2** Set Thresholds.status=APPROVED only for approved ids with approval_ref; re-run benchmark so GATE-PROD-02 mechanical can become EVIDENCE_PASS — owner `ml_evaluation_owner`
- [ ] **GO-5.3** Bind a real model provider as a recorded human act, or sign that this deployment ships the deterministic generator only — owner `product_owner`
- [ ] **GO-5.4** Run or formally defer the pilot (XEVAL-06 / AUDIT-ADD-25) — owner `ml_evaluation_owner`
- [ ] **GO-5.5** release_owner approves the release acceptance rule (currently PROPOSED) — owner `release_owner`

## W6 — Independent security / privacy review (OPEN: 0 done, 3 open)

GATE-PROD-07 is NO_EVIDENCE because the runtime cannot review itself.

- [ ] **GO-6.1** Independent security reviewer writes evidence/reviews/GATE-PROD-07-security.json — owner `independent_security_reviewer`; blocked by W2; → `handoff/HANDOFF-SECURITY-PRIVACY-REVIEW.md`
- [ ] **GO-6.2** Review DOC-05 vs controls, write authority, approval tokens, classification, channel isolation, process-level sandbox, unbound-or-bound IdP/KMS, corpus-only connectors — owner `independent_security_reviewer`
- [ ] **GO-6.3** State whether LIM-04/05/06 are accepted for this production target or remain blockers — owner `independent_security_reviewer`

## W7 — Independent review of GATE-PROD-01..08 (OPEN: 0 done, 8 open)

Mechanical EVIDENCE_PASS is not PASS. One JSON file per gate. Chat signatures are refused.

- [ ] **GO-7.1** GATE-PROD-01 review by independent_security_reviewer (evidence already mechanical PASS) — owner `independent_security_reviewer`; blocked by W2; → `handoff/HANDOFF-INDEPENDENT-REVIEW.md`
- [ ] **GO-7.2** GATE-PROD-03 review by independent_security_reviewer — owner `independent_security_reviewer`
- [ ] **GO-7.3** GATE-PROD-04 review by independent_architecture_reviewer — owner `independent_architecture_reviewer`
- [ ] **GO-7.4** GATE-PROD-05 review by independent_security_reviewer — owner `independent_security_reviewer`
- [ ] **GO-7.5** GATE-PROD-06 review by independent_operations_reviewer (host drill from W4.5 preferred) — owner `independent_operations_reviewer`
- [ ] **GO-7.6** GATE-PROD-08 review by product_owner — owner `product_owner`
- [ ] **GO-7.7** GATE-PROD-02 review by independent_evaluation_reviewer after W5.2 mechanical PASS — owner `independent_evaluation_reviewer`; blocked by W5.2
- [ ] **GO-7.8** GATE-PROD-07 review by independent_security_reviewer after W6 mechanical PASS — owner `independent_security_reviewer`; blocked by W6.1

## W8 — Independent review of the 545 ASFW items (OPEN: 0 done, 5 open)

416 IMPLEMENTED and 129 BLOCKED. Complete==0. Implementer cannot sign.

- [ ] **GO-8.1** Appoint ASFW independent reviewers distinct from both implementer ids and from the unbound chat offer — owner `product_owner`; blocked by W2; → `handoff/HANDOFF-ASFW-INDEPENDENT-REVIEW.md`
- [ ] **GO-8.2** Independently review each of the 416 IMPLEMENTED items; attach evidence_digest + decision per item — owner `independent_verifier`
- [ ] **GO-8.3** Disposition the 129 BLOCKED items: remain BLOCKED until W1/W2/W3/W4/W5 close, or NOT_APPLICABLE with signed authority — never silently VERIFIED — owner `independent_verifier`
- [ ] **GO-8.4** Refuse any review file signed by architecture_studio, runtime, generator, or either implementer builder id — owner `independent_verifier`
- [ ] **GO-8.5** ASFW GO requires verified==545 and complete==545; keep-undefined DOD/gate-count still block until W1 closes — owner `independent_verifier`; blocked by W1

## W9 — Independent verification of 227 protocol tasks (OPEN: 0 done, 7 open)

Protocol v3: 1 IMPLEMENTED, 226 BLOCKED, 0 VERIFIED, verifier=null.

- [ ] **GO-9.1** Appoint independent_verifier (W2.12). Not this session. Not either builder id. — owner `product_owner`; blocked by W2; → `handoff/HANDOFF-INDEPENDENT-VERIFICATION.md`
- [ ] **GO-9.2** Verifier obtains ASRTD v1.4.0 independently; tools/build_evidence.py is not the sealed checker — owner `independent_verifier`
- [ ] **GO-9.3** Recompute corpus digest (612 files, 16b9800f…) and overlay tree digest; re-run suite and gates on the verifier machine — owner `independent_verifier`
- [ ] **GO-9.4** Verify records in application order; do not verify a task whose prerequisites are not VERIFIED — owner `independent_verifier`
- [ ] **GO-9.5** Close phases P0→P14 only after required tasks are VERIFIED; P15 last (the eight GATE-PROD tasks, after W7) — owner `independent_verifier`; blocked by W7
- [ ] **GO-9.6** V3 tasks require a distinct trusted principal, not a second process of the same implementer — owner `independent_verifier`
- [ ] **GO-9.7** Rewrite INDEPENDENT_VERIFICATION_REPORT.md as the verifier (today NOT_PERFORMED) — owner `independent_verifier`

## W10 — Qualify and promote (OPEN: 0 done, 5 open)

qualify() never promotes. ACCEPTED_RISK never counts as PASS.

- [ ] **GO-10.1** Re-cut RELEASE_MANIFEST.json from the verified tree (today NOT_QUALIFIED) — owner `release_owner`; blocked by W7,W8,W9; → `handoff/HANDOFF-ASFW-RELEASE.md`
- [ ] **GO-10.2** qualify(..., production_read_only) returns QUALIFIED with empty reasons — owner `release_owner`
- [ ] **GO-10.3** release_owner records promotion through the approval gate after the independent verifier has signed — owner `release_owner`
- [ ] **GO-10.4** Attach rollback plan + host recovery evidence from W4.5 — owner `incident_response_owner`
- [ ] **GO-10.5** Stamp Production GO only if W7 PASS==8, W8 ASFW verified==545, W9 protocol verified==227, and W1 source gaps closed — all on the same digest — owner `release_owner`

## How to check progress

Progress is: W1 source gaps closed from the PDF, roster bound to distinct IdP subjects, `GATE-PROD` PASS rising 0 → 8, ASFW verified 0 → 545, protocol verified 0 → 227 under a distinct verifier, then a human release_owner promotes. Anything else is not GO.
