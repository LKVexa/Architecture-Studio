# Handoff — bind a host identity provider (XAUTH-01)

## Why this is blocked

`IdentityBinding` is empty. `status.identity_provider.bound` is false. Authentication **fails closed**
when the slot is empty. Tests enroll principals on a local reference `IdentityProvider` — that is not
a host IdP.

## Who must act

Host security / identity owner.

## What to produce

1. A binding record naming the IdP (OIDC/SAML/etc.), issuer, audience, required claims, tenant mapping.
2. Occupancy of the `IdentityBinding` slot via the runtime's binding API (a recorded human act).
3. Proof that placeholder identities are still refused and service principals still cannot approve.
4. Rotation / revocation runbook.

Until then, production authentication is not in force. Do not disable fail-closed to make tests greener.
