# Handoff — independent human review of production gates

## Why this is blocked

`architecture_studio.gates.evaluate_gates` sets `PASS` only when mechanical evidence is `EVIDENCE_PASS`
**and** a review record exists whose:

- `reviewer_kind` is `human`
- `reviewer_subject` is **not** in `builder_subjects ∪ {architecture_studio, runtime, generator}`
- `decision` is `PASS`
- `evidence_digest` names the digest that was reviewed

This pass assembled mechanical evidence for GATE-PROD-01, 03, 04, 05, 06, 08. No review record exists.
Self-review is tested and refused (`tests/test_docs_gates.py`).

Current evidence digest (CLI `gates`): see `evidence/reports/gates.json` field `evidence_digest`.
At generation of this handoff the digest was recorded in that file.

## Who must act

The `review_role` on each gate (never the implementer):

| Gate | review_role |
|---|---|
| GATE-PROD-01 | independent_security_reviewer |
| GATE-PROD-03 | independent_security_reviewer |
| GATE-PROD-04 | independent_architecture_reviewer |
| GATE-PROD-05 | independent_security_reviewer |
| GATE-PROD-06 | independent_operations_reviewer |
| GATE-PROD-08 | product_owner |

## What to produce

One JSON object per gate, stored as `evidence/reviews/<GATE-ID>.json`, using
`templates/independent_review_record.json`.

Then re-run:

```
python3 -m architecture_studio gates
```

The runtime still will not PASS a gate whose mechanical check FAILs (GATE-PROD-02) or has NO_EVIDENCE
(GATE-PROD-07), even with a review. Reviews of failing evidence must `decision` other than `PASS`.

## Forbidden

- Reviewer subject `architecture_studio`, `runtime`, `generator`, `builder:architecture-studio-audit-2026-09-11`
- A review that does not name `evidence_digest`
- Copying this handoff into `security_review` to satisfy GATE-PROD-07 (use the security-review handoff)
