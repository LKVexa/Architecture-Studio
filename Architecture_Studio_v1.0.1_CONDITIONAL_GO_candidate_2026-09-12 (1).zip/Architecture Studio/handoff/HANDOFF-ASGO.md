# Handoff — ASGO 150-item Production GO package

This implementer (`builder:architecture-studio-asgo-2026-09-12`) ingested the
ASGO prompt/workflow package and applied **in-repo** upgrades only.

**Production GO from ASGO: `NO_GO`.** Prompts authorize work; they do not grant authority.

## What this pass did

- Pinned the package by SHA-256 `41209097b7b6d7fdaf905a7d52776be8557214049741ad4df5c89bf1982971b9`.
- Declared Architecture Studio **overlay-only**. The 612-file corpus is a sibling of the overlay directory, never shipped inside the overlay zip.
- Added fail-closed preflight (`architecture-studio preflight`) for absent / wrong-root / digest-mismatch corpora.
- Stopped archive wrappers (`_archive/`, top-level `SHA256SUMS.txt`) from being counted as corpus files.
- Encoded `CTRL-ASGO-01` so this runtime cannot stamp GO, invent `INDEX.csv`, invent `GATE-PROD-09`, or mark ASGO items `DONE`.
- Wrote incomplete implementer notes. Reviewer fields are `null`.
- Landed those notes at the package-declared paths (`evidence/reports/package/`,
  `evidence/reports/source/`, …). Did **not** write `evidence/reviews/GATE-PROD-*.json`.
- Made package pins, product contract, and overlay tree digest portable (no sandbox
  absolute paths). Package lookup no longer hard-depends on `/workspace/attachments`.

## What this pass did not do (still BLOCKED)

| Item | Why |
|---|---|
| ASGO-0.4 | Self-contained packaging is N/A while product_kind is overlay_only and the overlay decision is unsigned |
| ASGO-0.8, 1.1 | Source `INDEX.csv` ABSENT; derived index is not a substitute |
| ASGO-1.3..1.9 | Missing DOD text and 8-vs-9 gates; not inferred |
| ASGO-3.11..3.14 | Human sandbox/limitation acceptance and independent security review |
| Waves 4–6 except 4.3 | IdP, KMS, environments, thresholds, model-provider binding |
| Waves 7–10 except 7.11/7.14/8.11/10.12 | Independent reviews, verification, promotion |

## Independent reviewer

Must be a distinct IdP-bound human, not this session, not either prior builder subject, not `architecture_studio` / `runtime` / `generator`, and not the chat signature RUSSELL PHILIP SMITHSON.

Same-session signatures are refused as reviews.
