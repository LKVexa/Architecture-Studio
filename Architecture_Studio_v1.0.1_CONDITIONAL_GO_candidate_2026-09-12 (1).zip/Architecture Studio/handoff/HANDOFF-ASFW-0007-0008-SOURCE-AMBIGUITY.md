# Handoff — ASFW source completeness (do not infer)

## Why this is blocked

The ASFW package itself names two source gaps and forbids inference:

1. **ASFW-TODO-0007** — The PDF announces `DOD-01` through `DOD-09` but visibly lists only four entries (`DOD-01`, `DOD-03`, `DOD-06`, `DOD-07`). Missing: `DOD-02`, `DOD-04`, `DOD-05`, `DOD-08`, `DOD-09`. Related items `ASFW-TODO-0437..0442`, `0451..0460`, `0477..0485` stay `BLOCKED`.
2. **ASFW-TODO-0008** / **ASFW-TODO-0311** — The PDF says `GATE-PROD-01-09`. The executable registry is `GATE-PROD-01`..`GATE-PROD-08` (eight gates). A ninth gate was not invented. Related item `ASFW-TODO-0507` stays `BLOCKED`.
3. **Source `INDEX.csv`** — named by the package as the machine-readable source of truth. It was **not** in the received attachment set. `asfw/INDEX.derived.csv` is a derived file from the markdown and is **not** a substitute source of truth.

This pass recorded the gaps. It did not fill them.

## Who must act

| Role | Action |
|---|---|
| data_owner (Data and provenance owner) | Recover the missing DOD text from an authoritative source **or** open a signed decision record that the IDs are omitted, with expiry and independent review. |
| architecture_owner | Confirm whether P15 is eight or nine gates. If nine, publish the ninth gate's evidence owner, review role, required artifacts, and tests. If eight, issue a versioned correction of the PDF range claim. |
| independent_data_reviewer | Review the recovery or the omission decision against the source PDF. Distinct from the implementer. |
| product_owner | Sign the resulting source-completeness record before any Production GO. |

## What to produce

Place signed JSON (not authored by `builder:architecture-studio-asfw-2026-09-11`, `architecture_studio`, `runtime`, or `generator`) at:

- `evidence/asfw/ASFW-TODO-0007/review.json`
- `evidence/asfw/ASFW-TODO-0008/review.json`
- `evidence/reviews/source-completeness.json`

Required fields: `item_id`, `reviewer`, `reviewer_kind=human`, `decision` (`PASS` only if the definition or gate is recovered **or** an authorized omission is signed), `evidence_digest`, `source_citation`, `expiry`.

A `PASS` that invents DOD text or a ninth gate without citation is a `FAIL`.

## Stop conditions already enforced in code

- `architecture_studio.asfw.classify` marks these items `BLOCKED` / `source_ambiguity`.
- `CTRL-ASFW-01` denies `inferred_missing_dod` and `inferred_ninth_gate`.
- `production_go_from_asfw` returns `NO_GO` while `dod_resolution` or `gate_count_resolution` is `UNRESOLVED`.
