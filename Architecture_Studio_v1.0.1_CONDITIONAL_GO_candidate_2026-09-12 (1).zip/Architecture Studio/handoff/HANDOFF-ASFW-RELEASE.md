# Handoff — ASFW release and post-GO items (0505–0544)

## Why this is blocked

Release items require a frozen candidate, all upstream ASFW items independently `VERIFIED`, every `GATE-PROD-*` `PASS` (not `ACCEPTED_RISK`), a distinct independent verifier signature, and only then a `release_owner` promotion.

None of those authorities exist in this checkout. Thresholds remain `PROPOSED`. Host IdP/KMS/environments are unbound. Source completeness is unresolved.

ASFW-TODO-0545 (automatic NO_GO on authority violation) **is** implemented in `architecture_studio.asfw.production_go_from_asfw` and `CTRL-ASFW-01`. It is still incomplete until reviewed.

## Who must act

Independent verifier first, then release_owner. See `HANDOFF-INDEPENDENT-VERIFICATION.md`.

## What not to do

Do not convert these items to `GO` by editing a status field. Do not ask the release owner to sign before the verifier.
