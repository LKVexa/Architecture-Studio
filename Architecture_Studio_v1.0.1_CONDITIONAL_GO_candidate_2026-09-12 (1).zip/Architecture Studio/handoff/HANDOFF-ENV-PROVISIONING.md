# Handoff — provision environments and resolve applicability

## Why this is blocked

| Environment | Smoke status | Notes |
|---|---|---|
| local | PASS | this checkout |
| test_tenant | PASS | isolated fixture tenant |
| ci | NOT_PROVISIONED | descriptor only (`environments/ci.json`) |
| staging | NOT_PROVISIONED | descriptor only |
| production_read_only | NOT_APPLICABLE_YET | applicability UNRESOLVED |
| privileged_execution | NOT_APPLICABLE_YET | applicability UNRESOLVED |

Declared ≠ provisioned. Promotion chain is `local → ci → staging → production_read_only`.
Nothing here promotes.

## Who must act

Operations owner (provision CI/staging). Product owner (ENV-04 applicability). Security owner
(ENV-05 applicability).

## What to produce

1. Real CI that runs `ci/run_local.sh` / `ci/architecture-studio.yml` semantics.
2. A staging instance with the same fail-closed policy, **not** a weakened copy.
3. A signed applicability decision for ENV-04 and ENV-05: `APPLICABLE` with a provisioned
   descriptor, or `NOT_APPLICABLE` with rationale. Leaving them unresolved is honest; inventing
   `PASS` is not.
4. Re-run `python3 -m architecture_studio environments` against the real hosts.

Incident drill and recovery evidence today is `TemporaryDirectory`. It does not qualify a host.
