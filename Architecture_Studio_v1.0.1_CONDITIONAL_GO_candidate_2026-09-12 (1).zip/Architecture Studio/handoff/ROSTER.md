# Named principals for Production GO

Fill every row with a real human (IdP subject after Wave 2). Independent roles
must not equal the corresponding owner. None may be
`builder:architecture-studio-audit-2026-09-11`, `architecture_studio`,
`runtime`, `generator`, or `builder:architecture-studio-asfw-2026-09-11`.

A display name typed in the implementer chat is **not** a filled row.

## Received chat offer — PROPOSED, UNBOUND, not independent

| Field | Value |
|---|---|
| Display name | RUSSELL PHILIP SMITHSON |
| Title | Research Specialist |
| Organization | LK/Vexa |
| Channel | grok chat, same session as the implementer |
| IdP subject | *none* |
| Independence | **NOT_ESTABLISHED** |
| Eligible role | `research_specialist` (consulted only) |
| Bound roles | none |
| Gate reviews signed | none |
| Production GO | **NO_GO** |

This offer is on file as `evidence/reviews/principal-offer.json`. It does **not**
fill the table below. One person cannot occupy every independent review slot.
A Research Specialist title does not qualify for Architecture Authority,
Security Authority, Release Owner, or Independent Verifier.

## Required roles (all UNSET)

| Role | Subject (email / IdP) | Organization | Named on | Signature / ticket |
|---|---|---|---|---|
| product_owner | | | | |
| security_privacy_owner | | | | |
| independent_security_reviewer | | | | |
| architecture_owner | | | | |
| independent_architecture_reviewer | | | | |
| ml_evaluation_owner | | | | |
| independent_evaluation_reviewer | | | | |
| incident_response_owner | | | | |
| independent_operations_reviewer | | | | |
| human_review_policy_owner | | | | |
| release_owner | | | | |
| independent_verifier | | | | |
| identity_owner (IdP bind) | | | | |
| crypto_owner (KMS bind) | | | | |

Copy a completed roster to `evidence/reviews/roster.json` only after IdP
subjects exist and independent roles are **different people**.
