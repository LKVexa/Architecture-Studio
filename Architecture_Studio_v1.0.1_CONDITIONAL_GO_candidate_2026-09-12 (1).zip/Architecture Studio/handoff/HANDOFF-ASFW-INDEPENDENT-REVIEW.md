# Handoff — independent review of ASFW items

## Why this is blocked

`IMPLEMENTED` means the overlay contains machinery or a mapping. Per ASFW-TODO-0005, `PROPOSED`, `IMPLEMENTED`, `AWAITING_CONFIRMATION`, and `ACCEPTED_RISK` are **incomplete** until independent human review.

This pass is `builder:architecture-studio-asfw-2026-09-11`. It cannot mark `VERIFIED`, `PASS`, `GO`, or `DONE`. Self-review is refused.

Named persons and due dates are `UNSET` until `handoff/ROSTER.md` is filled with real, distinct humans.

## Who must act

For every ASFW item, the `independent_reviewer_role` on the item (never the `owner_role`, never the implementer). Governance items 0001–0006 are the first review packet.

## What to produce

One `evidence/asfw/<ASFW-TODO-NNNN>/review.json` per item using the fields in `handoff/templates/independent_review_record.json`, plus:

- `item_id`
- `implementation_id`
- `source_text` (must match the register exactly)
- `reviewer` (IdP subject)
- `reviewer_kind`: `human`
- `decision`: `PASS` \| `FAIL` \| `BLOCKED`
- `evidence_digest` of the implementation/export reviewed
- `limitations`

Then re-run `python3 -m architecture_studio asfw` and confirm `verified` only increases for files whose reviewer is not in `ASFW_IMPLEMENTER_SUBJECTS`.
