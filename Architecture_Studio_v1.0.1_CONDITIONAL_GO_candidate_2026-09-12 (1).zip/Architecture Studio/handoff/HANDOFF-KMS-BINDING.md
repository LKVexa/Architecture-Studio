# Handoff — bind a host KMS (XSEC-04)

## Why this is blocked

`KeyProvider` slot is empty (`NullKeyProvider`). `encryption.at_rest.in_force` is false.
`backend_available` for AES-256-GCM is false in this environment (optional `cryptography` extra
not installed). Absence is labelled; it is not a silent downgrade.

Encryption in transit is a host responsibility and is not claimed (LIM-05).

## Who must act

Host cryptography owner.

## What to produce

1. Occupancy of the KMS slot with a non-null `KeyProvider`.
2. If AES-GCM / Ed25519 are required in production, install and pin `cryptography>=42` as a
   **deliberate** extra — that is an architecture change and must be documented, tested, and approved.
3. Key ceremony / rotation notes.
4. Confirmation that `NullKeyProvider` remains the fail-closed default when unbound.

Do not claim at-rest encryption is in force while the slot is empty.
