# Handoff — approve or refuse numeric thresholds (GATE-PROD-02)

## Why this is blocked

GATE-PROD-02 requires `benchmark.thresholds_status == "APPROVED"` and a passing suite.
Every numeric threshold in this runtime is `PROPOSED` (`uncertainty.Thresholds`, SLO targets,
benchmark targets, burden limits, pilot exit criteria, release acceptance rule).

A measurement that meets a proposed target is reported as `met_under_proposed_target`, **not** PASS.
This is deliberate. This audit will not flip the flag.

## Who must act

`ml_evaluation_owner` (approval) and `independent_evaluation_reviewer` (review).

## What to produce

1. A signed threshold-approval record (`templates/threshold_approval.json`) listing **each** threshold
   being approved, the evidence considered (benchmark report digest, BIPIA/llmail results, false-positive
   behaviour), the production environment the numbers apply to, and an expiry.
2. A code/config change **by a human owner**, not this implementer, setting `status` to `APPROVED`
   only for the thresholds actually approved. Unapproved thresholds stay `PROPOSED`.
3. Re-run the benchmark and `python3 -m architecture_studio gates`.
4. Independent review of GATE-PROD-02 after mechanical EVIDENCE_PASS.

## Current mechanical evidence (not an approval)

- Benchmark suite_passed: true
- All seven MODEL-07 failure modes detected
- Guardrail/workflow bypass cases pass
- Thresholds_status: **PROPOSED**
- Pilot exit criteria: cannot be met by this pass
- BIPIA recall is partial; llmail control false positives are zero (LIM-10)

Approving weak numbers to obtain GO is a different defect. Refuse if the bar is not acceptable.
