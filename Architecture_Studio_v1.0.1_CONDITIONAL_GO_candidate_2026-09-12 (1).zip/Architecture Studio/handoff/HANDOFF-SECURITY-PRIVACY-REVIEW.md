# Handoff — security/privacy review (GATE-PROD-07)

## Why this is blocked

GATE-PROD-07 requires `evidence.security_review` with `reviewer_kind == "human"` and `independent == true`.
`collect_gate_evidence` **deliberately omits** that key: the runtime cannot review itself.
Tests assert GATE-PROD-07 stays `NO_EVIDENCE` without a human record.

DOC-05 (threat model) and the write-authority scan are inputs to a review. They are not the review.

## Who must act

An independent human `independent_security_reviewer` who is not `builder:architecture-studio-audit-2026-09-11` and not the evidence owner
acting alone.

## Scope the reviewer must cover

- Threat model DOC-05 vs implemented controls (DOC-04, `policy.CONTROLS`)
- Write authority (scan allowlist in `write_scan._APPROVED`, bundle consume-before-write)
- Approval token binding, replay, expiry, scope, service-approver refusal
- Classification matrix, secret redaction, channel isolation (not heuristic detection)
- Sandbox isolation_class `process-level` — accept or demand containers
- Empty IdP and KMS slots — production authentication/encryption are **not** in force
- Connector surface (corpus-only)
- Residual risks in `AUDIT_NO_GO_REPORT.md` §10

## What to produce

`evidence/reviews/GATE-PROD-07-security.json` using `templates/security_review.json`.

A PASS review that ignores unbound IdP/KMS and process-level isolation is not automatically valid;
the reviewer must say whether those are accepted as out of scope for *this* production target or
are blockers.

Do not reuse the implementer's words as the review body without independent analysis.
