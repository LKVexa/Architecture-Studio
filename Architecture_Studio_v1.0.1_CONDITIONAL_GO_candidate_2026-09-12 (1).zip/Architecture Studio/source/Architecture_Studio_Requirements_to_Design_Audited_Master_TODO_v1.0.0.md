# Architecture Studio for Requirements-to-Design — Audited Master TODO

**TODO package version:** 1.0.0  
**Audited source:** `06_architecture_studio_requirements_to_design.md` — source version 1.0.0  
**Scope:** Convert every source checklist requirement plus all 12 core workflow steps into a traceable, phased implementation backlog, then add clearly separated audit-hardening items needed to make the backlog executable.

> **Important:** `AUDIT-ADD-*` items are audit recommendations added for implementation completeness. They are not represented as paper-stated requirements. Source requirements are preserved without silently changing their meaning.

## 1. Audit Summary

- Source checkboxes: **189**
- Source checkboxes with existing stable IDs: **92**
- Source checkboxes without IDs: **97**
- Core workflow steps normalized into IDs: **12**
- Total source-derived actionable records in this TODO: **201**
- Audit-hardening additions: **26**
- Total actionable records including audit additions: **227**

### Audit conclusion

The source is a strong requirements and governance specification. It is especially mature around human ownership, provenance, authorized evidence, least privilege, abstention, auditability, and fail-closed behavior. It is **not yet an implementation-ready work breakdown structure** because traceability metadata, canonical control ownership, measurable acceptance thresholds, several domain semantics, runtime SLOs, and release/pilot governance are not fully defined.

## 2. Audit Findings

- **F-01 — Traceability is incomplete.** 97 of 189 checkbox requirements have no stable requirement ID. This makes implementation ownership, testing, change control, and prompt/workflow decomposition fragile.
- **F-02 — The document is a requirements foundation, not an executable backlog.** It states what must exist but generally does not assign owners, priorities, dependencies, artifacts, test evidence, or measurable completion criteria.
- **F-03 — Cross-cutting controls intentionally repeat, but ownership is ambiguous.** Authorization, provenance, version pinning, schema validation, human approval, audit, and fail-closed behavior recur in multiple sections. They should map to canonical controls rather than be implemented independently.
- **F-04 — Several acceptance terms are undefined.** Examples include “materially distinct,” “acceptable grounding,” “high-impact conclusions,” “where applicable,” and “where feasible.” These need operational definitions before they can gate releases.
- **F-05 — Architecture candidate semantics are not fully specified.** The document requires generation, comparison, constraint checking, rationale tracking, and diagrams, but does not define one canonical candidate object shared by those subsystems.
- **F-06 — Conflicting evidence handling is under-specified.** Missing/stale/conflicting evidence is tested, but the persistent conflict model, precedence rules, and human resolution flow are not defined.
- **F-07 — Runtime NFR/SLO targets are absent.** The system consumes cost/performance constraints and measures latency/cost, but no platform-level workload, latency, availability, concurrency, recovery, or cost limits are stated.
- **F-08 — Security coverage is strong but policy taxonomies need concretization.** The document requires classification, privacy, secret handling, tenant isolation, and append-only audit, but does not define the classification matrix or reconcile deletion with immutable audit records.
- **F-09 — Testing breadth is strong but qualification thresholds are missing.** Unit, integration, adversarial, E2E, offline evaluation, and fail-closed validation are present, but release-blocking metric thresholds and performance/load/soak tests are not defined.
- **F-10 — Deployment stages are named but promotion governance is incomplete.** Local, CI, staging, production read-only, privileged path, and isolated test tenant are required, but release versioning, pilot exit criteria, emergency revocation, and promotion/rollback ownership need explicit definition.
- **F-11 — Human ownership is well protected.** The source repeatedly prevents the AI from settling the architecture, fabricating approval, expanding permissions, or claiming final accountability. These are strong design invariants and should become architecture-level enforcement points.
- **F-12 — The core workflow is structurally sound and fail-closed.** Its authenticate → pin → collect → normalize → deterministic analysis → model reasoning → bounded generation → independent verification → human review/approval → audit → rollback sequence is a strong control spine; implementation must preserve this ordering.

## 3. Canonical Control Consolidation Map

| Control family | Source requirement aliases | Recommended owning implementation |
|---|---|---|
| Authority & scope | PAPER-GRD-01; IMPL-01; IMPL-06; API-02; MODEL-06; XAUTH-*; WF-01/WF-10 | Policy/authority service + workflow guards |
| Provenance & evidence | PAPER-CAP-06; COMP-10; ARCH-08; IMPL-04; API-03; STORE-03; XPROV-*; WF-11 | Canonical provenance ledger |
| Revision pinning & reproducibility | IMPL-05; STORE-02/05; XSTATE-*; MODEL-01; XTOOL-06; WF-02 | Artifact/version manifest + run reconstruction |
| Schema validation | IMPL-02; API-*; MODEL-04; SEC-02; XTOOL-02; WF-04/WF-07 | Boundary schema registry/validator |
| Human approval | PAPER-GRD-01; VERIFY-05; API-05; HUMAN-*; SEC-07; XHITL-*; WF-09/WF-10 | Trusted review/approval service |
| Audit immutability | IMPL-09; STORE-07; SEC-08; XPROV-06; XOBS-*; WF-11 | Append-only/tamper-evident audit service |
| Uncertainty & abstention | PAPER-GRD-02; IMPL-07; API-04; COMP-10; XUNC-*; MODEL-02/05 | Uncertainty policy + structured abstention |
| Local grounding | PAPER-CAP-02; PAPER-GRD-03; COMP-03; VERIFY-01/04; MODEL-03/05; XTOOL-04/05 | Authorized retrieval + grounding verifier |
| Fail-closed writes | SEC-05; XAUTH-*; XHITL-*; XEVAL-05; WF-10/WF-12 | Independent authorization boundary + safe terminal states |

## 4. Global Definition of Done

- [ ] Requirement has a stable ID and source provenance.
- [ ] Accountable owner and implementation artifact(s) are recorded.
- [ ] Interfaces/schemas/policies are versioned where applicable.
- [ ] Positive, negative, boundary, and failure-path tests exist where automatable.
- [ ] Authorization is enforced outside model text wherever the item affects data/tool/state authority.
- [ ] Material output includes resolvable evidence/provenance or an explicit inference/uncertainty state.
- [ ] No model-generated value can fabricate human approval or expand permissions.
- [ ] Failure behavior is typed, observable, and fail closed for scope/authority/verification violations.
- [ ] Operational telemetry and audit evidence are emitted without exposing secrets or disallowed sensitive data.
- [ ] Documentation and migration/rollback notes are updated before the item is marked Verified.

## 5. Phased Execution Order

| Phase | Objective | Exit criterion | Source tasks | Audit additions |
|---|---|---|---:|---:|
| **P0** | Backlog normalization and audit closure | All requirements have stable IDs/metadata; duplicate control families have canonical owners; acceptance criteria are testable. | 0 | 4 |
| **P1** | Mission, governance, scope, authority, and guardrails | Identity, scope, authority, guardrails, least privilege, and human-accountability policy are executable and fail closed. | 11 | 1 |
| **P2** | Canonical schemas, contracts, identity, and API foundations | Canonical identities, schemas, API contracts, idempotency, and migration/version rules are approved and enforced at trust boundaries. | 10 | 0 |
| **P3** | State, persistence, versioning, provenance, and reproducibility | Run/design state, provenance, version metadata, audit-critical records, revision pinning, and reconstruction are durable and traceable. | 30 | 2 |
| **P4** | Evidence sources, connectors, ingestion, and normalization | Authorized evidence sources can be ingested, normalized, classified, pinned, and handled consistently under connector failures. | 12 | 1 |
| **P5** | Requirement graph, retrieval, indexing, and local grounding | Requirement/constraint graph and retrieval produce authorized, locally grounded, source-labeled context with explicit stale/conflict behavior. | 7 | 3 |
| **P6** | Deterministic analysis, constraints, and policy checks | Applicable deterministic checks execute before model reasoning and return typed pass/fail/unknown evidence. | 5 | 0 |
| **P7** | Model orchestration and architecture candidate generation | Pinned-model orchestration generates structured, bounded, evidence-bearing candidates and abstains/asks when evidence is insufficient. | 20 | 1 |
| **P8** | Trade-offs, diagrams, and interactive steering | Candidates can be compared, diagrammed, and iteratively steered with explicit assumptions, trade-offs, and preserved history. | 6 | 4 |
| **P9** | Human review, decision recording, and approval | Human review can inspect evidence and control approval/rejection/scope/evidence requests; model cannot own or fabricate final decisions. | 19 | 0 |
| **P10** | Security, privacy, isolation, and fail-closed enforcement | Security/privacy controls withstand prompt/tool/scope/tenant/secret/approval/audit attacks and all unauthorized writes fail closed. | 16 | 3 |
| **P11** | Observability, resilience, and operations | Runs are observable, bounded, recoverable, incident-controllable, and operational failures have safe fallback/abort behavior. | 9 | 3 |
| **P12** | Verification, testing, benchmark, and evaluation | Unit, integration, adversarial, E2E, regression, grounding, provenance, distinctness, and guardrail evaluations pass documented thresholds. | 30 | 2 |
| **P13** | Deployment environments, pilot, and release qualification | All minimum environments exist; promotion is controlled; a read-only/draft-only pilot meets explicit exit criteria before broader rollout. | 6 | 2 |
| **P14** | Documentation and operational handoff | Architecture, trust, permissions, threat, model/tool, provenance, state, approval, evaluation, incident, and limitations docs are current. | 12 | 0 |
| **P15** | Production-readiness gate | Every production-readiness gate has current evidence and explicit PASS; otherwise production remains blocked. | 8 | 0 |

### Critical dependency chain

`P0 → (P1 + P2) → (P3 + P4) → P5 → P6 → P7 → P8 → P9 → (P10 + P11) → P12 → P13 → P14 → P15`

P10 security/privacy work should start during P1–P4 design and continue continuously; the sequence above indicates the point at which the phase must be fully closed, not when security first begins.

## 6. Audit-Hardening TODOs

### P0 — Backlog normalization and audit closure

- [ ] **AUDIT-ADD-01 — Assign IDs to every anonymous checklist item**  
  **Priority:** Blocker  
  **Implement:** Promote the 97 currently unnumbered checklist requirements into stable requirement IDs and retain the original source line/section as provenance.  
  **Done when / evidence:** Requirement registry contains one stable ID for every checkbox; no requirement is addressable only by prose or line number.

- [ ] **AUDIT-ADD-02 — Create requirement metadata/backlog schema**  
  **Priority:** Blocker  
  **Implement:** Add owner, priority, status, dependencies, implementation artifact, test/evidence, risk, target phase, and change-history fields to the requirement registry.  
  **Done when / evidence:** Every source requirement can be tracked from pending through verified with accountable ownership and evidence links.

- [ ] **AUDIT-ADD-03 — Create canonical control ownership and deduplication map**  
  **Priority:** Blocker  
  **Implement:** Map recurring requirements—authorization, provenance, pinning, validation, approval, model/tool versions, audit, fail-closed behavior—to one canonical control implementation plus all requirement aliases.  
  **Done when / evidence:** No duplicated requirement is implemented by conflicting independent controls; each alias resolves to a single owning control and its tests.

- [ ] **AUDIT-ADD-04 — Define measurable acceptance criteria**  
  **Priority:** Blocker  
  **Implement:** Replace qualitative-only completion claims with testable pass/fail criteria, including owners and evidence artifacts, without weakening paper guardrails.  
  **Done when / evidence:** No requirement can be marked done solely by narrative assertion; each has a test, inspection, or explicitly approved evidence criterion.

### P1 — Mission, governance, scope, authority, and guardrails

- [ ] **AUDIT-ADD-24 — Create RACI and escalation ownership**  
  **Priority:** High  
  **Implement:** Assign accountable owners for architecture, security/privacy, source systems, ML evaluation, operations, human-review policy, incident response, and production acceptance.  
  **Done when / evidence:** Every gate/control has a named role owner and a documented escalation path; no critical decision is assigned to the model.

### P3 — State, persistence, versioning, provenance, and reproducibility

- [ ] **AUDIT-ADD-15 — Define concurrent-edit and conflict behavior**  
  **Priority:** High  
  **Implement:** Specify optimistic locking/version checks or equivalent for design-state updates, reviews, scope changes, and approvals so parallel users cannot overwrite each other silently.  
  **Done when / evidence:** Concurrent-update tests detect stale writes and preserve both auditability and legal state transitions.

- [ ] **AUDIT-ADD-23 — Specify auditable case-file export**  
  **Priority:** High  
  **Implement:** Define a portable export manifest containing scope, pinned sources/references, analyzer results, model/tool versions, candidates, verification, uncertainty, review history, approvals, and hashes/signatures as applicable.  
  **Done when / evidence:** A case file can be independently inspected and lineage references validate against exported manifests or authorized source locators.

### P4 — Evidence sources, connectors, ingestion, and normalization

- [ ] **AUDIT-ADD-14 — Define connector capability and failure contract**  
  **Priority:** High  
  **Implement:** Standardize connector read/write capabilities, revision semantics, pagination, rate limits, retries, backoff, partial results, health, and degradation behavior.  
  **Done when / evidence:** All connectors pass a common contract test and expose consistent failure/status metadata to the workflow.

### P5 — Requirement graph, retrieval, indexing, and local grounding

- [ ] **AUDIT-ADD-07 — Define local-grounding sufficiency**  
  **Priority:** Blocker  
  **Implement:** Define evidence coverage expectations for candidate elements and trade-off claims, required source classes where applicable, and behavior when local evidence is absent.  
  **Done when / evidence:** Grounding evaluation distinguishes source-supported design from generic fallback and routes insufficiently grounded cases to clarification or abstention.

- [ ] **AUDIT-ADD-08 — Define conflicting-evidence semantics**  
  **Priority:** High  
  **Implement:** Add a conflict model for contradictory requirements, NFRs, ADRs, catalogs, security constraints, and stale revisions; prohibit automatic silent conflict resolution.  
  **Done when / evidence:** Conflict fixtures produce explicit conflict state, affected candidates, evidence links, and a human-resolution path.

- [ ] **AUDIT-ADD-12 — Set retrieval quality and freshness acceptance targets**  
  **Priority:** High  
  **Implement:** Define measurable retrieval recall/precision or task-grounding proxies, stale-source behavior, ranking evaluation, maximum authorized context behavior, and failure thresholds.  
  **Done when / evidence:** Offline retrieval benchmark and stale-source tests produce release-gating metrics against documented targets.

### P7 — Model orchestration and architecture candidate generation

- [ ] **AUDIT-ADD-05 — Define canonical architecture-candidate model**  
  **Priority:** Blocker  
  **Implement:** Specify candidate component, relationship, deployment, dependency, assumption, rationale, risk, evidence, constraint impact, uncertainty, diagram mapping, and lifecycle fields.  
  **Done when / evidence:** Generator, comparer, checker, diagrammer, reviewer, and provenance ledger consume the same versioned candidate schema.

### P8 — Trade-offs, diagrams, and interactive steering

- [ ] **AUDIT-ADD-09 — Define clarifying-question materiality rules**  
  **Priority:** High  
  **Implement:** Specify when missing information is material enough to pause, when a bounded assumption is permissible, how questions are prioritized, and how answers update design state.  
  **Done when / evidence:** Evaluation cases show consistent pause/continue behavior and preserve unanswered material questions in the review package.

- [ ] **AUDIT-ADD-10 — Define trade-off taxonomy and scoring policy**  
  **Priority:** High  
  **Implement:** Define source-derived comparison dimensions, qualitative/quantitative representation, weighting authority, uncertainty treatment, and rules against false numerical precision.  
  **Done when / evidence:** Trade-off reports are consistent, evidence-linked, and do not invent weights or scores absent human/source authority.

- [ ] **AUDIT-ADD-11 — Standardize diagram semantics**  
  **Priority:** High  
  **Implement:** Choose supported canonical diagram semantics/notation, stable element IDs, layout-vs-semantics separation, versioning, and import/export/round-trip expectations.  
  **Done when / evidence:** Diagram fixtures map unambiguously to candidate model elements and preserve provenance across regeneration.

- [ ] **AUDIT-ADD-22 — Add accessibility and review-usability requirements**  
  **Priority:** Medium  
  **Implement:** Define keyboard navigation, screen-reader semantics, contrast/status communication, evidence inspection usability, and review cognitive-load criteria for the steering/review surfaces.  
  **Done when / evidence:** Accessibility checks and representative reviewer usability tests pass documented acceptance criteria.

### P10 — Security, privacy, isolation, and fail-closed enforcement

- [ ] **AUDIT-ADD-16 — Define data-classification and destination policy matrix**  
  **Priority:** Blocker  
  **Implement:** Create classification levels and explicit rules for source ingestion, model access, logging, storage, display, export, retention, and cross-boundary movement.  
  **Done when / evidence:** Security tests can assert policy decisions by data class and destination instead of relying on undefined 'sensitive' labels.

- [ ] **AUDIT-ADD-17 — Reconcile deletion requirements with immutable audit**  
  **Priority:** Blocker  
  **Implement:** Define which fields/records may be deleted, tombstoned, anonymized, cryptographically erased, or retained when privacy deletion obligations intersect append-only audit requirements.  
  **Done when / evidence:** Retention/deletion tests and legal/security review show privacy controls do not silently break audit integrity or vice versa.

- [ ] **AUDIT-ADD-18 — Add software supply-chain controls**  
  **Priority:** High  
  **Implement:** Inventory dependencies/models/tools/connectors, produce SBOM or equivalent inventory, pin artifacts, verify provenance/signatures where available, and scan dependencies/build outputs.  
  **Done when / evidence:** Release evidence identifies third-party components and blocks known disallowed/critical dependency risks under policy.

### P11 — Observability, resilience, and operations

- [ ] **AUDIT-ADD-13 — Define runtime NFR/SLO targets**  
  **Priority:** High  
  **Implement:** Specify supported workload size, latency, throughput/concurrency, availability, cost budget, recovery objectives, and maximum run/resource limits by environment.  
  **Done when / evidence:** Performance and resilience tests have explicit pass/fail targets instead of subjective readiness judgments.

- [ ] **AUDIT-ADD-20 — Add backup, restore, and disaster-recovery procedures**  
  **Priority:** High  
  **Implement:** Define backup scope, recovery-point/recovery-time objectives, restore validation, key/secrets dependencies, and recovery of state/provenance/audit stores.  
  **Done when / evidence:** A recovery exercise restores a representative run and verifies state, lineage, and audit integrity.

- [ ] **AUDIT-ADD-26 — Add emergency stop, revocation, and incident-control path**  
  **Priority:** Blocker  
  **Implement:** Implement operator kill switch, credential/approval revocation, connector disablement, run quarantine, evidence preservation, and incident notification/escalation.  
  **Done when / evidence:** Incident drill proves active risky workflows can be stopped quickly without erasing evidence and revoked authority cannot be reused.

### P12 — Verification, testing, benchmark, and evaluation

- [ ] **AUDIT-ADD-06 — Operationalize material distinctness**  
  **Priority:** Blocker  
  **Implement:** Define what makes two architecture options materially different and an evaluation method that avoids treating renamed or cosmetically rearranged options as distinct.  
  **Done when / evidence:** A benchmark contains positive/negative distinctness pairs and the verifier reliably rejects near-duplicates under the approved rule.

- [ ] **AUDIT-ADD-19 — Add performance, load, soak, and resource-exhaustion tests**  
  **Priority:** High  
  **Implement:** Test large evidence sets, many candidate iterations, concurrent reviewers, oversized/hostile artifacts, context pressure, connector slowness, and bounded-resource behavior.  
  **Done when / evidence:** The platform stays within defined limits or fails safely without privilege expansion, corruption, or uncontrolled cost.

### P13 — Deployment environments, pilot, and release qualification

- [ ] **AUDIT-ADD-21 — Define release/version/changelog process**  
  **Priority:** High  
  **Implement:** Version application, schemas, policies, prompts, models/tools, migrations, benchmark baselines, and documentation together with a documented promotion/rollback process.  
  **Done when / evidence:** A release candidate can be reproduced from tagged inputs and rolled back without orphaning stored state or provenance.

- [ ] **AUDIT-ADD-25 — Define pilot exit criteria**  
  **Priority:** Blocker  
  **Implement:** Specify read-only/draft-only pilot cohort, duration or sample basis, metrics, guardrail thresholds, human-review burden limits, incident tolerance, and criteria for broader permission rollout.  
  **Done when / evidence:** Broader rollout cannot occur until an explicit pilot report meets the approved exit criteria.

## 7. Master Source-Derived Implementation TODO

> Source items that originally lacked IDs receive `TEST-*`, `GATE-PROD-*`, `X*`, `ENV-*`, or `DOC-*` audit-assigned IDs here. The source wording and source line are retained so these IDs can later be written back into a version-bumped requirements document if desired.

### P1 — Mission, governance, scope, authority, and guardrails

- [ ] **ARCH-07 — Policy/authority enforcement layer**  
  **Source:** line 63 | Section: Required Reference Architecture | Source ID: `ARCH-07`  
  **Priority:** Required  
  **Implement:** Implement policy/authority enforcement as an independent boundary around sources, tools, workflow transitions, writes, approvals, and exports.  
  **Done when / evidence:** Denied actions fail closed and are logged; changing prompt text cannot expand permissions.

- [ ] **IMPL-01 — Define a machine-readable scope contract for the Architecture Studio for Requirements-to-Design workflow.**  
  **Source:** line 70 | Section: Additional Implementation Requirements | Source ID: `IMPL-01`  
  **Priority:** Blocker  
  **Implement:** Specify a machine-readable scope contract covering project/tenant, sources, revisions, allowed artifact classes, allowed actions, write authority, reviewer authority, and expiration.  
  **Done when / evidence:** Every run starts only with a valid scope contract; policy checks consume the same contract and out-of-scope access is denied.

- [ ] **IMPL-06 — Create a policy layer that converts paper guardrails into enforceable permissions and stop conditions.**  
  **Source:** line 75 | Section: Additional Implementation Requirements | Source ID: `IMPL-06`  
  **Priority:** Blocker  
  **Implement:** Translate every paper guardrail into executable policy rules, transition guards, permission checks, and stop conditions with stable control IDs.  
  **Done when / evidence:** Each guardrail has positive and negative tests, including model attempts to bypass or redefine it.

- [ ] **WF-01 — Authenticate and establish authority.**  
  **Source:** line 83 | Section: Core Workflow | Source ID: `WF-01`  
  **Priority:** Required  
  **Implement:** Authenticate the initiating user/service, resolve project/tenant context, load the scope/authority contract, and create a run only after authorization succeeds.  
  **Done when / evidence:** Unauthenticated, expired, or insufficiently authorized starts fail closed before any source access; run records capture the authority basis.

- [ ] **XAUTH-01 — Authenticate human users and service identities.**  
  **Source:** line 198 | Section: Identity, Authorization, and Least Privilege | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement infrastructure-backed identity/authorization control to authenticate human users and service identities; define principals, resources, actions, policy rules, and denial logging.  
  **Done when / evidence:** Positive/negative authorization tests prove least privilege and show model/prompt content cannot expand effective permissions.

- [ ] **XAUTH-02 — Authorize every data source and action independently.**  
  **Source:** line 199 | Section: Identity, Authorization, and Least Privilege | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement infrastructure-backed identity/authorization control to authorize every data source and action independently; define principals, resources, actions, policy rules, and denial logging.  
  **Done when / evidence:** Positive/negative authorization tests prove least privilege and show model/prompt content cannot expand effective permissions.

- [ ] **XAUTH-03 — Separate read, analyze, draft, modify, commit, approve, deploy, and communicate permissions.**  
  **Source:** line 200 | Section: Identity, Authorization, and Least Privilege | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement infrastructure-backed identity/authorization control to separate read, analyze, draft, modify, commit, approve, deploy, and communicate permissions; define principals, resources, actions, policy rules, and denial logging.  
  **Done when / evidence:** Positive/negative authorization tests prove least privilege and show model/prompt content cannot expand effective permissions.

- [ ] **XAUTH-04 — Default to read-only access where the paper requires it.**  
  **Source:** line 201 | Section: Identity, Authorization, and Least Privilege | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement infrastructure-backed identity/authorization control to default to read-only access where the paper requires it; define principals, resources, actions, policy rules, and denial logging.  
  **Done when / evidence:** Positive/negative authorization tests prove least privilege and show model/prompt content cannot expand effective permissions.

- [ ] **XAUTH-05 — Use narrowly scoped, short-lived credentials where execution is unavoidable.**  
  **Source:** line 202 | Section: Identity, Authorization, and Least Privilege | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement infrastructure-backed identity/authorization control to use narrowly scoped, short-lived credentials where execution is unavoidable; define principals, resources, actions, policy rules, and denial logging.  
  **Done when / evidence:** Positive/negative authorization tests prove least privilege and show model/prompt content cannot expand effective permissions.

- [ ] **XAUTH-06 — Enforce repository/service/data boundaries in infrastructure, not only in model prompts.**  
  **Source:** line 203 | Section: Identity, Authorization, and Least Privilege | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement infrastructure-backed identity/authorization control to enforce repository/service/data boundaries in infrastructure, not only in model prompts; define principals, resources, actions, policy rules, and denial logging.  
  **Done when / evidence:** Positive/negative authorization tests prove least privilege and show model/prompt content cannot expand effective permissions.

- [ ] **XAUTH-07 — Record the human authority under which every privileged action occurs.**  
  **Source:** line 204 | Section: Identity, Authorization, and Least Privilege | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement infrastructure-backed identity/authorization control to record the human authority under which every privileged action occurs; define principals, resources, actions, policy rules, and denial logging.  
  **Done when / evidence:** Positive/negative authorization tests prove least privilege and show model/prompt content cannot expand effective permissions.

### P2 — Canonical schemas, contracts, identity, and API foundations

- [ ] **ARCH-02 — Canonical artifact and identity layer**  
  **Source:** line 58 | Section: Required Reference Architecture | Source ID: `ARCH-02`  
  **Priority:** Required  
  **Implement:** Define canonical artifact identity, version, content hash, source locator, tenant/project scope, type, timestamps, and relationship semantics.  
  **Done when / evidence:** The same pinned source resolves to the same canonical identity and downstream provenance references remain stable.

- [ ] **IMPL-02 — Define canonical input/output schemas and validate all connector/tool payloads.**  
  **Source:** line 71 | Section: Additional Implementation Requirements | Source ID: `IMPL-02`  
  **Priority:** Required  
  **Implement:** Publish canonical schemas for connector inputs, normalized artifacts, tool calls/results, candidate outputs, review decisions, and errors; validate at every trust boundary.  
  **Done when / evidence:** Malformed or version-incompatible payloads fail before execution and produce typed, auditable errors.

- [ ] **API-01 — Versioned API contracts for all inbound and outbound integrations.**  
  **Source:** line 107 | Section: API / Schema Requirements | Source ID: `API-01`  
  **Priority:** Required  
  **Implement:** Version every inbound/outbound contract; publish compatibility policy, error envelopes, capability negotiation where needed, and contract tests for supported versions.  
  **Done when / evidence:** CI blocks incompatible contract changes unless accompanied by an approved migration/version change.

- [ ] **API-02 — Explicit schema for scope/authority.**  
  **Source:** line 108 | Section: API / Schema Requirements | Source ID: `API-02`  
  **Priority:** Required  
  **Implement:** Define the scope/authority schema with subject, project/tenant, source set, revision bounds, allowed actions, approval rights, expiration, and policy version.  
  **Done when / evidence:** Scope schema validation is mandatory at run start and policy enforcement consumes the validated object.

- [ ] **API-03 — Explicit schema for evidence/provenance references.**  
  **Source:** line 109 | Section: API / Schema Requirements | Source ID: `API-03`  
  **Priority:** Required  
  **Implement:** Define provenance-reference schema for source/artifact ID, revision/hash, location/span, retrieval event, transformation chain, and evidence status.  
  **Done when / evidence:** Every material output can carry a machine-resolvable provenance reference validated by schema.

- [ ] **API-04 — Explicit schema for uncertainty/confidence and abstention reason.**  
  **Source:** line 110 | Section: API / Schema Requirements | Source ID: `API-04`  
  **Priority:** Required  
  **Implement:** Define uncertainty schema covering evidence state, confidence only where calibrated, stale/missing/conflict flags, abstention code, and human-readable rationale.  
  **Done when / evidence:** All uncertainty-bearing outputs validate, and uncalibrated confidence numbers are prohibited.

- [ ] **API-05 — Explicit schema for human review decision and approver identity.**  
  **Source:** line 111 | Section: API / Schema Requirements | Source ID: `API-05`  
  **Priority:** Required  
  **Implement:** Define review-decision schema for authenticated approver identity, decision, scope, artifact/run IDs, timestamp, rationale, requested changes/evidence, and policy version.  
  **Done when / evidence:** Approval/rejection events are immutable, attributable, scope-bounded, and replayable in audit views.

- [ ] **API-06 — Idempotency support for retried workflow steps.**  
  **Source:** line 112 | Section: API / Schema Requirements | Source ID: `API-06`  
  **Priority:** Required  
  **Implement:** Define idempotency keys and replay semantics for retryable workflow steps, connector calls, persistence operations, and approval side effects.  
  **Done when / evidence:** Duplicate/retried requests do not duplicate state-changing effects; tests cover retry after partial failure.

- [ ] **API-07 — Immutable run ID and artifact IDs.**  
  **Source:** line 113 | Section: API / Schema Requirements | Source ID: `API-07`  
  **Priority:** Required  
  **Implement:** Generate immutable run and artifact IDs at trusted boundaries; define collision resistance, namespace/scope, and immutability rules.  
  **Done when / evidence:** IDs cannot be replaced by model output and remain stable across storage, provenance, logs, and review.

- [ ] **API-08 — Backward-compatible versioning or migration plan.**  
  **Source:** line 114 | Section: API / Schema Requirements | Source ID: `API-08`  
  **Priority:** Required  
  **Implement:** Publish schema/API versioning and migration rules including deprecation windows, readers/writers compatibility, stored-state migration, and rollback.  
  **Done when / evidence:** Upgrade/downgrade or migration tests demonstrate supported compatibility paths without corrupting provenance or run state.

### P3 — State, persistence, versioning, provenance, and reproducibility

- [ ] **PAPER-CAP-01 — Create explicit design state: goals, constraints, open questions, and exploration history.**  
  **Source:** line 16 | Section: Paper-Stated Capability Requirements | Source ID: `PAPER-CAP-01`  
  **Priority:** Required  
  **Implement:** Define the DesignState domain model and persistence API for goals, constraints, open questions, candidates, and exploration history; wire it into every workflow transition.  
  **Done when / evidence:** A multi-iteration session can be reconstructed and all state changes are attributable and versioned.

- [ ] **COMP-01 — Design-state store**  
  **Source:** line 44 | Section: Required System Components | Source ID: `COMP-01`  
  **Priority:** Required  
  **Implement:** Implement the design-state store for goals, constraints, open questions, candidates, selected comparisons, exploration events, and review state; expose versioned read/write APIs.  
  **Done when / evidence:** A run can stop and resume with identical state; history is immutable/versioned enough to reconstruct every iteration.

- [ ] **COMP-10 — Provenance and uncertainty service**  
  **Source:** line 53 | Section: Required System Components | Source ID: `COMP-10`  
  **Priority:** Required  
  **Implement:** Implement a service that attaches provenance, evidence status, uncertainty class, confidence where calibrated, freshness, and abstention reasons to outputs.  
  **Done when / evidence:** All material outputs can be queried for evidence and uncertainty; unsupported or stale claims are visibly differentiated.

- [ ] **ARCH-03 — Persistent state/context store**  
  **Source:** line 59 | Section: Required Reference Architecture | Source ID: `ARCH-03`  
  **Priority:** Required  
  **Implement:** Implement persistent state/context storage with explicit transactional boundaries for run state, design state, artifact metadata, and resumability.  
  **Done when / evidence:** Interrupted workflows reconstruct from persisted state without silently re-fetching unpinned data.

- [ ] **ARCH-08 — Provenance/evidence ledger**  
  **Source:** line 64 | Section: Required Reference Architecture | Source ID: `ARCH-08`  
  **Priority:** Required  
  **Implement:** Implement the provenance/evidence ledger with append-only records for source use, transformations, analyzer results, model generations, reviews, and approvals.  
  **Done when / evidence:** A material output can be walked backward to pinned source artifacts and forward to later decisions.

- [ ] **IMPL-03 — Create a versioned workflow state machine with explicit start, analysis, review, approval, and terminal states.**  
  **Source:** line 72 | Section: Additional Implementation Requirements | Source ID: `IMPL-03`  
  **Priority:** Required  
  **Implement:** Define the versioned workflow state machine, allowed transitions, transition guards, retry/idempotency rules, pause/resume semantics, approval state, and terminal outcomes.  
  **Done when / evidence:** Transition tests prove illegal jumps and approval bypasses are impossible through supported interfaces.

- [ ] **IMPL-04 — Create a provenance model linking generated outputs to source artifacts, analyzer results, and human approvals.**  
  **Source:** line 73 | Section: Additional Implementation Requirements | Source ID: `IMPL-04`  
  **Priority:** Required  
  **Implement:** Define provenance entities/edges linking sources, normalized artifacts, analyzer results, context bundles, model outputs, generated artifacts, reviewer actions, and approvals.  
  **Done when / evidence:** Automated traceability tests reconstruct the lineage of every material candidate and review artifact.

- [ ] **IMPL-05 — Implement source freshness and revision pinning so analyses can be reproduced.**  
  **Source:** line 74 | Section: Additional Implementation Requirements | Source ID: `IMPL-05`  
  **Priority:** Required  
  **Implement:** Record source revision/content hash/freshness at ingestion and require pinned revisions for reproducible analysis; define stale-source behavior.  
  **Done when / evidence:** Re-running from recorded inputs uses the same source revisions or explicitly reports that reproduction is impossible.

- [ ] **WF-02 — Pin the target artifacts and revisions.**  
  **Source:** line 84 | Section: Core Workflow | Source ID: `WF-02`  
  **Priority:** Required  
  **Implement:** Resolve each target artifact to a canonical ID plus immutable revision/content hash and freeze that target set into the run.  
  **Done when / evidence:** Later source changes do not silently change the run; any repin creates an explicit new revision/iteration.

- [ ] **WF-11 — Record the full evidence and decision trail.**  
  **Source:** line 93 | Section: Core Workflow | Source ID: `WF-11`  
  **Priority:** Required  
  **Implement:** Persist the source manifest, analyzer outputs, model/tool calls, generated artifacts, verification results, reviewer actions, approvals, and transition history.  
  **Done when / evidence:** An exported case file can reconstruct the evidentiary and decision trail of the run.

- [ ] **STORE-01 — Persistent workflow/run state.**  
  **Source:** line 118 | Section: Storage Requirements | Source ID: `STORE-01`  
  **Priority:** Required  
  **Implement:** Create durable records for workflow state, transition history, retries, errors, pause/resume checkpoints, and terminal outcomes.  
  **Done when / evidence:** A killed process can reconstruct a run from storage and continue only from a legal state.

- [ ] **STORE-02 — Versioned artifact metadata and source pointers.**  
  **Source:** line 119 | Section: Storage Requirements | Source ID: `STORE-02`  
  **Priority:** Required  
  **Implement:** Store versioned artifact metadata including canonical ID, source locator, content hash/revision, type, project/tenant, timestamps, and derived-artifact links.  
  **Done when / evidence:** Pinned artifact versions remain addressable and can be traced to all dependent outputs.

- [ ] **STORE-03 — Evidence/provenance records.**  
  **Source:** line 120 | Section: Storage Requirements | Source ID: `STORE-03`  
  **Priority:** Required  
  **Implement:** Persist provenance/evidence entities and edges separately from narrative model output, including retrieval and deterministic analyzer results.  
  **Done when / evidence:** Lineage queries return complete machine-readable paths and detect dangling or unverifiable references.

- [ ] **STORE-04 — Human approval/rejection history.**  
  **Source:** line 121 | Section: Storage Requirements | Source ID: `STORE-04`  
  **Priority:** Required  
  **Implement:** Persist immutable human review decisions, rejection reasons, requested changes/evidence, approval scope, identity, timestamp, and supersession relationships.  
  **Done when / evidence:** Review history survives reruns and clearly distinguishes current from superseded decisions.

- [ ] **STORE-05 — Model/tool version metadata.**  
  **Source:** line 122 | Section: Storage Requirements | Source ID: `STORE-05`  
  **Priority:** Required  
  **Implement:** Persist exact model, prompt, tool, analyzer, policy, connector, and schema versions associated with each run and artifact.  
  **Done when / evidence:** A run record contains enough version metadata to diagnose behavioral changes and support reproduction.

- [ ] **STORE-06 — Retention, deletion, and privacy controls.**  
  **Source:** line 123 | Section: Storage Requirements | Source ID: `STORE-06`  
  **Priority:** Required  
  **Implement:** Define retention/deletion/privacy policy by record class, tenant/project, legal need, and audit constraints; implement deletion workflows and proof of deletion where applicable.  
  **Done when / evidence:** Retention tests prove protected records expire/delete as configured while mandatory audit integrity is preserved according to policy.

- [ ] **STORE-07 — Append-only audit trail for privileged actions.**  
  **Source:** line 124 | Section: Storage Requirements | Source ID: `STORE-07`  
  **Priority:** Required  
  **Implement:** Implement append-only or equivalently tamper-evident storage for privileged actions with restricted writers and integrity verification.  
  **Done when / evidence:** Model-facing identities cannot update/delete historical privileged audit events; integrity verification detects tampering.

- [ ] **XPROV-01 — Assign stable identity/version metadata to every source artifact.**  
  **Source:** line 207 | Section: Provenance and Evidence | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement provenance/evidence handling to assign stable identity/version metadata to every source artifact; define stable schema fields, storage behavior, and propagation through retrieval, analysis, generation, review, and export.  
  **Done when / evidence:** Traceability tests resolve sampled material outputs back to exact source revisions and preserve separation between source facts, analyzer output, and model inference.

- [ ] **XPROV-02 — Preserve source revision, timestamp, and freshness metadata.**  
  **Source:** line 208 | Section: Provenance and Evidence | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement provenance/evidence handling to preserve source revision, timestamp, and freshness metadata; define stable schema fields, storage behavior, and propagation through retrieval, analysis, generation, review, and export.  
  **Done when / evidence:** Traceability tests resolve sampled material outputs back to exact source revisions and preserve separation between source facts, analyzer output, and model inference.

- [ ] **XPROV-03 — Link every material AI finding to supporting evidence.**  
  **Source:** line 209 | Section: Provenance and Evidence | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement provenance/evidence handling to link every material ai finding to supporting evidence; define stable schema fields, storage behavior, and propagation through retrieval, analysis, generation, review, and export.  
  **Done when / evidence:** Traceability tests resolve sampled material outputs back to exact source revisions and preserve separation between source facts, analyzer output, and model inference.

- [ ] **XPROV-04 — Distinguish source-derived facts from model inference.**  
  **Source:** line 210 | Section: Provenance and Evidence | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement provenance/evidence handling to distinguish source-derived facts from model inference; define stable schema fields, storage behavior, and propagation through retrieval, analysis, generation, review, and export.  
  **Done when / evidence:** Traceability tests resolve sampled material outputs back to exact source revisions and preserve separation between source facts, analyzer output, and model inference.

- [ ] **XPROV-05 — Preserve deterministic analyzer output separately from model synthesis.**  
  **Source:** line 211 | Section: Provenance and Evidence | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement provenance/evidence handling to preserve deterministic analyzer output separately from model synthesis; define stable schema fields, storage behavior, and propagation through retrieval, analysis, generation, review, and export.  
  **Done when / evidence:** Traceability tests resolve sampled material outputs back to exact source revisions and preserve separation between source facts, analyzer output, and model inference.

- [ ] **XPROV-06 — Maintain an immutable or append-only activity/evidence log.**  
  **Source:** line 212 | Section: Provenance and Evidence | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement provenance/evidence handling to maintain an immutable or append-only activity/evidence log; define stable schema fields, storage behavior, and propagation through retrieval, analysis, generation, review, and export.  
  **Done when / evidence:** Traceability tests resolve sampled material outputs back to exact source revisions and preserve separation between source facts, analyzer output, and model inference.

- [ ] **XPROV-07 — Support export of an auditable case file for human review.**  
  **Source:** line 213 | Section: Provenance and Evidence | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement provenance/evidence handling to support export of an auditable case file for human review; define stable schema fields, storage behavior, and propagation through retrieval, analysis, generation, review, and export.  
  **Done when / evidence:** Traceability tests resolve sampled material outputs back to exact source revisions and preserve separation between source facts, analyzer output, and model inference.

- [ ] **XSTATE-01 — Pin repository/data revisions used for analysis.**  
  **Source:** line 231 | Section: State, Versioning, and Reproducibility | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement version/state metadata and persistence needed to pin repository/data revisions used for analysis; include IDs, revisions, dependency versions, migration behavior, and replay/reconstruction support.  
  **Done when / evidence:** A recorded run can be reconstructed from stored inputs/versions to the documented reproducibility level, and version changes are explicit rather than silent.

- [ ] **XSTATE-02 — Version prompts, models, tools, policies, and schemas.**  
  **Source:** line 232 | Section: State, Versioning, and Reproducibility | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement version/state metadata and persistence needed to version prompts, models, tools, policies, and schemas; include IDs, revisions, dependency versions, migration behavior, and replay/reconstruction support.  
  **Done when / evidence:** A recorded run can be reconstructed from stored inputs/versions to the documented reproducibility level, and version changes are explicit rather than silent.

- [ ] **XSTATE-03 — Store workflow state so an interrupted run can be reconstructed.**  
  **Source:** line 233 | Section: State, Versioning, and Reproducibility | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement version/state metadata and persistence needed to store workflow state so an interrupted run can be reconstructed; include IDs, revisions, dependency versions, migration behavior, and replay/reconstruction support.  
  **Done when / evidence:** A recorded run can be reconstructed from stored inputs/versions to the documented reproducibility level, and version changes are explicit rather than silent.

- [ ] **XSTATE-04 — Make generated artifacts reproducible from recorded inputs where feasible.**  
  **Source:** line 234 | Section: State, Versioning, and Reproducibility | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement version/state metadata and persistence needed to make generated artifacts reproducible from recorded inputs where feasible; include IDs, revisions, dependency versions, migration behavior, and replay/reconstruction support.  
  **Done when / evidence:** A recorded run can be reconstructed from stored inputs/versions to the documented reproducibility level, and version changes are explicit rather than silent.

- [ ] **XSTATE-05 — Use deterministic IDs for runs, artifacts, findings, and approvals.**  
  **Source:** line 235 | Section: State, Versioning, and Reproducibility | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement version/state metadata and persistence needed to use deterministic ids for runs, artifacts, findings, and approvals; include IDs, revisions, dependency versions, migration behavior, and replay/reconstruction support.  
  **Done when / evidence:** A recorded run can be reconstructed from stored inputs/versions to the documented reproducibility level, and version changes are explicit rather than silent.

- [ ] **XTOOL-06 — Track model/tool versions for every run.**  
  **Source:** line 252 | Section: Model and Tooling Controls | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement orchestration/tool controls to track model/tool versions for every run; define the deterministic boundary, schema/policy checks, sandbox/resource limits, fallback behavior, and version capture as applicable.  
  **Done when / evidence:** Integration/adversarial tests prove the control operates independently of model cooperation and produces typed, observable failure behavior.

### P4 — Evidence sources, connectors, ingestion, and normalization

- [ ] **DATA-01 — Requirements**  
  **Source:** line 32 | Section: Required Data and Context | Source ID: `DATA-01`  
  **Priority:** Required  
  **Implement:** Define a canonical requirement record with stable ID, source pointer, text, priority/status metadata, relationships, and revision; add ingestion/validation fixtures.  
  **Done when / evidence:** Authorized requirements import without loss; invalid records are rejected; every normalized requirement resolves back to its exact source/revision.

- [ ] **DATA-02 — NFRs**  
  **Source:** line 33 | Section: Required Data and Context | Source ID: `DATA-02`  
  **Priority:** Required  
  **Implement:** Define an NFR schema for category, target, unit, scope, priority, evidence, and conflict state; normalize qualitative and quantitative NFRs.  
  **Done when / evidence:** NFRs can be queried and linked to candidate decisions; units/targets are validated; conflicting or missing targets are surfaced rather than invented.

- [ ] **DATA-03 — ADRs**  
  **Source:** line 34 | Section: Required Data and Context | Source ID: `DATA-03`  
  **Priority:** Required  
  **Implement:** Implement ADR ingestion preserving ADR ID, status, context, decision, consequences, supersession links, owner, and revision.  
  **Done when / evidence:** Retrieved ADR facts cite the pinned ADR revision; superseded ADRs are marked and cannot silently ground a current decision.

- [ ] **DATA-04 — API catalogs**  
  **Source:** line 35 | Section: Required Data and Context | Source ID: `DATA-04`  
  **Priority:** Required  
  **Implement:** Implement API-catalog ingestion for service/operation identity, versions, schemas, auth requirements, owners, lifecycle state, and source revision.  
  **Done when / evidence:** Architecture candidates can reference valid API capabilities with provenance; unknown/deprecated operations are labeled or blocked according to policy.

- [ ] **DATA-05 — Infrastructure/service catalogs**  
  **Source:** line 36 | Section: Required Data and Context | Source ID: `DATA-05`  
  **Priority:** Required  
  **Implement:** Implement infrastructure/service catalog ingestion for service identity, environments, region, quotas, capabilities, ownership, constraints, and revision.  
  **Done when / evidence:** Candidate components map only to cataloged/authorized services or are explicitly labeled as proposed assumptions.

- [ ] **DATA-06 — Existing architecture diagrams**  
  **Source:** line 37 | Section: Required Data and Context | Source ID: `DATA-06`  
  **Priority:** Required  
  **Implement:** Define supported architecture-diagram inputs and a canonical component/relationship projection while retaining the original diagram as evidence.  
  **Done when / evidence:** The system can ingest a supported diagram, preserve its source, resolve components/edges, and surface any parse ambiguity.

- [ ] **DATA-07 — Security constraints**  
  **Source:** line 38 | Section: Required Data and Context | Source ID: `DATA-07`  
  **Priority:** Required  
  **Implement:** Represent security constraints as typed, scoped controls linked to source policy, trust boundary, data class, and enforcement status.  
  **Done when / evidence:** Security constraints participate in candidate checking; violations are explicit, source-linked, and cannot be waived by model text.

- [ ] **DATA-08 — Cost/performance constraints**  
  **Source:** line 39 | Section: Required Data and Context | Source ID: `DATA-08`  
  **Priority:** Required  
  **Implement:** Represent cost and performance constraints with metric, unit, target/range, workload scope, environment, source, and confidence/freshness.  
  **Done when / evidence:** Trade-off analysis can compare candidates against recorded cost/performance targets without fabricating missing numbers.

- [ ] **DATA-09 — Deployment standards**  
  **Source:** line 40 | Section: Required Data and Context | Source ID: `DATA-09`  
  **Priority:** Required  
  **Implement:** Ingest deployment standards as versioned constraints for environments, regions, runtime/platform, release process, networking, and policy.  
  **Done when / evidence:** Candidate deployment views identify compliance or conflicts against the pinned standard revision.

- [ ] **ARCH-01 — Connector/adaptor layer for authorized source systems**  
  **Source:** line 57 | Section: Required Reference Architecture | Source ID: `ARCH-01`  
  **Priority:** Required  
  **Implement:** Define connector/adaptor interfaces for auth, discovery, read, revision pinning, normalization, errors, rate limits, and capability declarations; implement reference connectors.  
  **Done when / evidence:** Every connector advertises capabilities and enforces granted scope; connector contract tests cover authorization and failure behavior.

- [ ] **WF-03 — Collect only authorized evidence.**  
  **Source:** line 85 | Section: Core Workflow | Source ID: `WF-03`  
  **Priority:** Required  
  **Implement:** Retrieve evidence only through authorized connectors and policy-filtered queries; log each retrieval and denial.  
  **Done when / evidence:** Tests prove the evidence set contains no source outside the run scope and all included evidence has provenance metadata.

- [ ] **WF-04 — Normalize and index the evidence.**  
  **Source:** line 86 | Section: Core Workflow | Source ID: `WF-04`  
  **Priority:** Required  
  **Implement:** Normalize retrieved evidence into canonical schemas, validate it, classify it, attach identity/revision metadata, and index only validated records.  
  **Done when / evidence:** Malformed/unclassified inputs are quarantined or rejected; indexed records trace back to raw pinned sources.

### P5 — Requirement graph, retrieval, indexing, and local grounding

- [ ] **PAPER-CAP-02 — Retrieve local context from ADRs and API/infrastructure catalogs.**  
  **Source:** line 17 | Section: Paper-Stated Capability Requirements | Source ID: `PAPER-CAP-02`  
  **Priority:** Required  
  **Implement:** Connect authorized ADR and API/infrastructure sources to the retrieval layer; normalize, index, filter by scope/revision, and return source-labeled evidence.  
  **Done when / evidence:** A candidate-generation run can retrieve relevant local records with stable provenance and no cross-scope leakage.

- [ ] **PAPER-GRD-03 — Must not fall back to generic patterns without local grounding.**  
  **Source:** line 27 | Section: Paper-Stated Constraints and Guardrails | Source ID: `PAPER-GRD-03`  
  **Priority:** Blocker  
  **Implement:** Require local evidence coverage for material candidate elements and trade-off claims; block or label generic fallback patterns that lack source grounding.  
  **Done when / evidence:** Grounding verifier detects unsupported generic recommendations and routes them to clarification/abstention.

- [ ] **COMP-02 — Requirement/constraint graph**  
  **Source:** line 45 | Section: Required System Components | Source ID: `COMP-02`  
  **Priority:** Required  
  **Implement:** Implement a typed requirement/constraint graph connecting requirements, NFRs, ADRs, APIs, services, candidate elements, assumptions, conflicts, and evidence.  
  **Done when / evidence:** Graph queries can answer why a candidate element exists, what constrains it, and which sources support or conflict with it.

- [ ] **COMP-03 — Context retrieval layer**  
  **Source:** line 46 | Section: Required System Components | Source ID: `COMP-03`  
  **Priority:** Required  
  **Implement:** Implement authorization-aware retrieval over normalized artifacts with source ranking, revision/freshness filters, bounded context assembly, and provenance labels.  
  **Done when / evidence:** Retrieval never crosses scope/tenant boundaries; returned chunks carry stable source IDs/revisions and stale-state metadata.

- [ ] **ARCH-04 — Retrieval/graph/query layer as appropriate**  
  **Source:** line 60 | Section: Required Reference Architecture | Source ID: `ARCH-04`  
  **Priority:** Required  
  **Implement:** Implement the retrieval/graph/query layer and choose index/graph mechanisms based on supported query patterns, not model convenience.  
  **Done when / evidence:** Required traceability and local-context queries meet functional tests and enforce authorization filters at the data/query layer.

- [ ] **XTOOL-04 — Bound token/context retrieval to authorized material.**  
  **Source:** line 250 | Section: Model and Tooling Controls | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement orchestration/tool controls to bound token/context retrieval to authorized material; define the deterministic boundary, schema/policy checks, sandbox/resource limits, fallback behavior, and version capture as applicable.  
  **Done when / evidence:** Integration/adversarial tests prove the control operates independently of model cooperation and produces typed, observable failure behavior.

- [ ] **XTOOL-05 — Implement retrieval/source ranking and stale-source detection.**  
  **Source:** line 251 | Section: Model and Tooling Controls | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement orchestration/tool controls to implement retrieval/source ranking and stale-source detection; define the deterministic boundary, schema/policy checks, sandbox/resource limits, fallback behavior, and version capture as applicable.  
  **Done when / evidence:** Integration/adversarial tests prove the control operates independently of model cooperation and produces typed, observable failure behavior.

### P6 — Deterministic analysis, constraints, and policy checks

- [ ] **COMP-05 — Constraint checker**  
  **Source:** line 48 | Section: Required System Components | Source ID: `COMP-05`  
  **Priority:** Required  
  **Implement:** Implement deterministic constraint checking across requirements, NFRs, security, deployment, API, infrastructure, and policy constraints.  
  **Done when / evidence:** Each check returns pass/fail/unknown with rule ID and evidence; unknown evidence does not become pass.

- [ ] **ARCH-05 — Deterministic analysis/tool layer**  
  **Source:** line 61 | Section: Required Reference Architecture | Source ID: `ARCH-05`  
  **Priority:** Required  
  **Implement:** Define deterministic analyzers and tool interfaces for schema checks, constraint checks, graph traversals, diffing, freshness, and verification.  
  **Done when / evidence:** Applicable deterministic checks execute before model reasoning and their raw outputs are preserved separately.

- [ ] **WF-05 — Run deterministic analysis first where applicable.**  
  **Source:** line 87 | Section: Core Workflow | Source ID: `WF-05`  
  **Priority:** Required  
  **Implement:** Execute applicable deterministic parsers, schema checks, graph analyses, constraint rules, freshness checks, and policy checks before any probabilistic synthesis.  
  **Done when / evidence:** Run traces show deterministic results precede model reasoning and remain independently inspectable.

- [ ] **XTOOL-01 — Use deterministic analyzers before probabilistic reasoning where applicable.**  
  **Source:** line 247 | Section: Model and Tooling Controls | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement orchestration/tool controls to use deterministic analyzers before probabilistic reasoning where applicable; define the deterministic boundary, schema/policy checks, sandbox/resource limits, fallback behavior, and version capture as applicable.  
  **Done when / evidence:** Integration/adversarial tests prove the control operates independently of model cooperation and produces typed, observable failure behavior.

- [ ] **XTOOL-02 — Validate tool inputs and outputs against schemas.**  
  **Source:** line 248 | Section: Model and Tooling Controls | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement orchestration/tool controls to validate tool inputs and outputs against schemas; define the deterministic boundary, schema/policy checks, sandbox/resource limits, fallback behavior, and version capture as applicable.  
  **Done when / evidence:** Integration/adversarial tests prove the control operates independently of model cooperation and produces typed, observable failure behavior.

### P7 — Model orchestration and architecture candidate generation

- [ ] **PAPER-CAP-03 — Generate distinct architecture candidates.**  
  **Source:** line 18 | Section: Paper-Stated Capability Requirements | Source ID: `PAPER-CAP-03`  
  **Priority:** Required  
  **Implement:** Define the architecture-candidate schema and generation protocol; generate multiple candidates under the same pinned state and run an independent distinctness check before display.  
  **Done when / evidence:** Presented candidates differ materially under the approved distinctness criteria and each remains grounded in the same local evidence set.

- [ ] **PAPER-GRD-02 — Must not silently invent requirements or assumptions.**  
  **Source:** line 26 | Section: Paper-Stated Constraints and Guardrails | Source ID: `PAPER-GRD-02`  
  **Priority:** Blocker  
  **Implement:** Create an explicit assumption registry and require every non-source assertion to be labeled inferred/uncertain/proposed with evidence status.  
  **Done when / evidence:** Unsupported facts are either labeled as assumptions or cause abstention; silent requirement invention fails verification.

- [ ] **COMP-04 — Architecture option generator**  
  **Source:** line 47 | Section: Required System Components | Source ID: `COMP-04`  
  **Priority:** Required  
  **Implement:** Implement a candidate generator that consumes design state plus grounded context and emits structured architecture candidates with components, relationships, assumptions, evidence, and rationale.  
  **Done when / evidence:** Generated candidates validate against schema, are traceable to context, and pass the distinctness verifier before presentation.

- [ ] **ARCH-06 — Model reasoning/orchestration layer**  
  **Source:** line 62 | Section: Required Reference Architecture | Source ID: `ARCH-06`  
  **Priority:** Required  
  **Implement:** Implement orchestration that assembles only authorized provenance-bearing context, invokes version-pinned models, validates structured outputs, and handles retries/abstention.  
  **Done when / evidence:** Model calls are reproducible to the recorded configuration and cannot bypass policy/tool boundaries.

- [ ] **IMPL-07 — Implement an uncertainty/abstention mechanism for insufficient evidence and out-of-scope requests.**  
  **Source:** line 76 | Section: Additional Implementation Requirements | Source ID: `IMPL-07`  
  **Priority:** Blocker  
  **Implement:** Define evidence sufficiency states, abstention reasons, stop thresholds, escalation paths, and UI representation for missing/stale/conflicting/out-of-scope context.  
  **Done when / evidence:** Insufficient evidence produces a structured abstention or clarifying-question state rather than an unsupported design claim.

- [ ] **WF-06 — Run model reasoning only over authorized, provenance-bearing context.**  
  **Source:** line 88 | Section: Core Workflow | Source ID: `WF-06`  
  **Priority:** Required  
  **Implement:** Construct a bounded context package containing only authorized, source-labeled, provenance-bearing evidence plus deterministic findings; invoke the pinned model under policy.  
  **Done when / evidence:** Unauthorized or unlabeled context cannot enter the model call and the exact context manifest is recorded.

- [ ] **WF-07 — Generate a bounded draft/recommendation/artifact.**  
  **Source:** line 89 | Section: Core Workflow | Source ID: `WF-07`  
  **Priority:** Required  
  **Implement:** Generate only the artifact types and scope permitted by the run contract; validate structure, assumptions, evidence links, and output bounds before persistence.  
  **Done when / evidence:** Out-of-scope or malformed outputs are rejected/abstained and cannot trigger a state-changing action.

- [ ] **MODEL-01 — Model choice is version-pinned and recorded per run.**  
  **Source:** line 139 | Section: Model Requirements | Source ID: `MODEL-01`  
  **Priority:** Required  
  **Implement:** Pin model provider/model/version or immutable deployment identifier per run and persist configuration relevant to reproducibility.  
  **Done when / evidence:** Every run and generated artifact resolves to an exact recorded model configuration.

- [ ] **MODEL-02 — System prompts encode scope, evidence, uncertainty, and abstention rules.**  
  **Source:** line 140 | Section: Model Requirements | Source ID: `MODEL-02`  
  **Priority:** Required  
  **Implement:** Version system prompts containing scope, evidence, provenance, uncertainty, abstention, permission, and human-ownership rules; keep policy enforcement independent of prompts.  
  **Done when / evidence:** Prompt regression tests cover overreach and guardrail cases; prompt changes are versioned and reviewable.

- [ ] **MODEL-03 — Retrieval context is source-labeled.**  
  **Source:** line 141 | Section: Model Requirements | Source ID: `MODEL-03`  
  **Priority:** Required  
  **Implement:** Assemble retrieval context in structured source-labeled blocks with artifact ID, revision, location, freshness, trust classification, and evidence status.  
  **Done when / evidence:** Generated citations/provenance can be resolved to the exact supplied context and unlabeled context is rejected.

- [ ] **MODEL-04 — Structured outputs are schema-validated.**  
  **Source:** line 142 | Section: Model Requirements | Source ID: `MODEL-04`  
  **Priority:** Required  
  **Implement:** Require structured model outputs for candidates, comparisons, questions, assumptions, and review summaries and validate them before downstream use.  
  **Done when / evidence:** Invalid model output cannot enter persistent state or trigger tools without successful schema validation/repair under policy.

- [ ] **MODEL-05 — High-impact conclusions require supporting evidence references.**  
  **Source:** line 143 | Section: Model Requirements | Source ID: `MODEL-05`  
  **Priority:** Required  
  **Implement:** Define high-impact conclusion classes and require each to include supporting evidence references plus uncertainty state.  
  **Done when / evidence:** A high-impact conclusion lacking valid support fails verification or is converted to abstention/request-more-evidence.

- [ ] **MODEL-06 — Model cannot directly grant itself additional permissions.**  
  **Source:** line 144 | Section: Model Requirements | Source ID: `MODEL-06`  
  **Priority:** Required  
  **Implement:** Ensure permissions are derived exclusively from trusted authority/policy services; ignore permission-like claims in model output or retrieved content.  
  **Done when / evidence:** Tests prove the model cannot expand source access, tool capability, write authority, or approval rights.

- [ ] **MODEL-07 — Evaluation includes hallucination, overreach, and stale-context cases.**  
  **Source:** line 145 | Section: Model Requirements | Source ID: `MODEL-07`  
  **Priority:** Required  
  **Implement:** Add evaluation cases for hallucination, fabricated requirements, overreach, stale context, conflicting evidence, generic fallback, and fabricated provenance.  
  **Done when / evidence:** Release benchmark reports these failure modes separately and gates regressions against documented thresholds.

- [ ] **XUNC-01 — Represent known, supported, inferred, uncertain, stale, missing, and out-of-scope states.**  
  **Source:** line 216 | Section: Uncertainty and Abstention | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement the uncertainty policy needed to represent known, supported, inferred, uncertain, stale, missing, and out-of-scope states; encode states/reasons in schema, workflow transitions, model instructions, verification, and UI.  
  **Done when / evidence:** Seeded missing/stale/conflicting/out-of-scope cases surface the expected state and never become unsupported factual claims or implicit approval.

- [ ] **XUNC-02 — Calibrate confidence against validation data where quantitative scores are shown.**  
  **Source:** line 217 | Section: Uncertainty and Abstention | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement the uncertainty policy needed to calibrate confidence against validation data where quantitative scores are shown; encode states/reasons in schema, workflow transitions, model instructions, verification, and UI.  
  **Done when / evidence:** Seeded missing/stale/conflicting/out-of-scope cases surface the expected state and never become unsupported factual claims or implicit approval.

- [ ] **XUNC-03 — Surface missing context instead of filling gaps silently.**  
  **Source:** line 218 | Section: Uncertainty and Abstention | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement the uncertainty policy needed to surface missing context instead of filling gaps silently; encode states/reasons in schema, workflow transitions, model instructions, verification, and UI.  
  **Done when / evidence:** Seeded missing/stale/conflicting/out-of-scope cases surface the expected state and never become unsupported factual claims or implicit approval.

- [ ] **XUNC-04 — Define stop/abstain thresholds.**  
  **Source:** line 219 | Section: Uncertainty and Abstention | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement the uncertainty policy needed to define stop/abstain thresholds; encode states/reasons in schema, workflow transitions, model instructions, verification, and UI.  
  **Done when / evidence:** Seeded missing/stale/conflicting/out-of-scope cases surface the expected state and never become unsupported factual claims or implicit approval.

- [ ] **XUNC-05 — Route high-impact or ambiguous cases to human review.**  
  **Source:** line 220 | Section: Uncertainty and Abstention | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement the uncertainty policy needed to route high-impact or ambiguous cases to human review; encode states/reasons in schema, workflow transitions, model instructions, verification, and UI.  
  **Done when / evidence:** Seeded missing/stale/conflicting/out-of-scope cases surface the expected state and never become unsupported factual claims or implicit approval.

- [ ] **XUNC-06 — Never present unsupported assumptions as facts.**  
  **Source:** line 221 | Section: Uncertainty and Abstention | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement the uncertainty policy needed to never present unsupported assumptions as facts; encode states/reasons in schema, workflow transitions, model instructions, verification, and UI.  
  **Done when / evidence:** Seeded missing/stale/conflicting/out-of-scope cases surface the expected state and never become unsupported factual claims or implicit approval.

### P8 — Trade-offs, diagrams, and interactive steering

- [ ] **PAPER-CAP-04 — Compare trade-offs explicitly.**  
  **Source:** line 19 | Section: Paper-Stated Capability Requirements | Source ID: `PAPER-CAP-04`  
  **Priority:** Required  
  **Implement:** Define a structured comparison artifact that evaluates candidate differences, benefits, costs, risks, constraint impacts, uncertainty, and evidence.  
  **Done when / evidence:** Trade-off claims are source-linked or labeled inference and the comparison exposes unresolved/missing information.

- [ ] **PAPER-CAP-05 — Ask clarifying questions when missing information materially affects the design.**  
  **Source:** line 20 | Section: Paper-Stated Capability Requirements | Source ID: `PAPER-CAP-05`  
  **Priority:** Required  
  **Implement:** Implement a missing-information detector and a clarifying-question state that pauses design progression when missing context materially changes feasible options.  
  **Done when / evidence:** Test cases show material gaps trigger questions/abstention, while nonmaterial gaps remain labeled without blocking unnecessarily.

- [ ] **PAPER-GRD-04 — Must not produce a one-shot unsteerable design.**  
  **Source:** line 28 | Section: Paper-Stated Constraints and Guardrails | Source ID: `PAPER-GRD-04`  
  **Priority:** Blocker  
  **Implement:** Keep design sessions iterative and steerable through persistent state plus controls to edit goals/constraints, add evidence, narrow scope, modify/discard options, and rerun.  
  **Done when / evidence:** A user can change design inputs after an initial proposal and receive a provenance-preserving revised candidate set.

- [ ] **COMP-06 — Trade-off model**  
  **Source:** line 49 | Section: Required System Components | Source ID: `COMP-06`  
  **Priority:** Required  
  **Implement:** Implement a trade-off model that compares candidates across source-derived decision criteria, constraints, risks, uncertainties, and unresolved questions.  
  **Done when / evidence:** Every material comparison statement points to evidence or is labeled inference; missing criteria remain visible.

- [ ] **COMP-07 — Interactive steering UI**  
  **Source:** line 50 | Section: Required System Components | Source ID: `COMP-07`  
  **Priority:** Required  
  **Implement:** Implement the steering UI for inspect, compare, ask, edit goals/constraints, narrow scope, request more evidence, modify/discard options, and rerun.  
  **Done when / evidence:** A reviewer can steer an existing design session without losing history or triggering unauthorized side effects.

- [ ] **COMP-09 — Diagram generator**  
  **Source:** line 52 | Section: Required System Components | Source ID: `COMP-09`  
  **Priority:** Required  
  **Implement:** Implement diagram generation from the canonical candidate model, with deterministic mapping where feasible and provenance back to candidate elements.  
  **Done when / evidence:** Rendered diagrams round-trip to the candidate model or have a verifiable mapping; diagram elements retain stable IDs.

### P9 — Human review, decision recording, and approval

- [ ] **PAPER-CAP-06 — Track why options were introduced, modified, or discarded.**  
  **Source:** line 21 | Section: Paper-Stated Capability Requirements | Source ID: `PAPER-CAP-06`  
  **Priority:** Required  
  **Implement:** Record option lifecycle events—introduced, modified, forked, compared, discarded—with actor, rationale, evidence, and preceding state.  
  **Done when / evidence:** The UI and audit trail can explain the full evolution of every option across iterations.

- [ ] **PAPER-GRD-01 — Must not settle the final architecture decision.**  
  **Source:** line 25 | Section: Paper-Stated Constraints and Guardrails | Source ID: `PAPER-GRD-01`  
  **Priority:** Blocker  
  **Implement:** Make final architecture selection/approval a human-only transition; prohibit model/tool principals from setting the final-decision state.  
  **Done when / evidence:** Authorization and adversarial tests prove model output cannot fabricate or trigger final approval.

- [ ] **COMP-08 — Decision/rationale recorder**  
  **Source:** line 51 | Section: Required System Components | Source ID: `COMP-08`  
  **Priority:** Required  
  **Implement:** Implement an append-only decision/rationale recorder for option introduced/modified/discarded events and human review decisions.  
  **Done when / evidence:** Each lifecycle event records actor, time, prior/new state, rationale, evidence, and run/artifact IDs.

- [ ] **ARCH-09 — Human review and approval interface**  
  **Source:** line 65 | Section: Required Reference Architecture | Source ID: `ARCH-09`  
  **Priority:** Required  
  **Implement:** Implement the review/approval interface with evidence inspection, scope visibility, uncertainty, verification results, and explicit human actions.  
  **Done when / evidence:** Approval is attributable to an authenticated human principal and cannot be synthesized from model output.

- [ ] **IMPL-08 — Provide a human review surface that exposes evidence, rationale, changed artifacts, uncertainty, and approval controls.**  
  **Source:** line 77 | Section: Additional Implementation Requirements | Source ID: `IMPL-08`  
  **Priority:** Required  
  **Implement:** Build the review surface to display candidate changes, source evidence, rationale, uncertainty, scope, verification outcomes, and explicit review controls.  
  **Done when / evidence:** Review usability tests confirm a human can inspect evidence and approve/reject/narrow/request-more-evidence without hidden side effects.

- [ ] **WF-09 — Expose evidence, uncertainty, scope, and verification results to the human reviewer.**  
  **Source:** line 91 | Section: Core Workflow | Source ID: `WF-09`  
  **Priority:** Required  
  **Implement:** Build a review package containing scope, evidence, candidate artifact, rationale, assumptions, uncertainty, verification results, and excluded/failed analyses.  
  **Done when / evidence:** The reviewer sees the information needed to understand both what was considered and what was not.

- [ ] **WF-10 — Require the paper-specified human decision/approval before any subsequent state change.**  
  **Source:** line 92 | Section: Core Workflow | Source ID: `WF-10`  
  **Priority:** Required  
  **Implement:** Gate every subsequent state-changing transition on a trusted human review decision matching the exact scope/run/artifact/action.  
  **Done when / evidence:** Missing, forged, stale, or mismatched approval leaves the workflow in review/blocked state with no side effect.

- [ ] **HUMAN-01 — Reviewer can inspect original evidence.**  
  **Source:** line 149 | Section: Human Review Requirements | Source ID: `HUMAN-01`  
  **Priority:** Required  
  **Implement:** Provide evidence drill-down from candidate/trade-off statements to original authorized source artifact and pinned revision/location.  
  **Done when / evidence:** A reviewer can open supporting evidence for sampled material claims without leaving the review workflow.

- [ ] **HUMAN-02 — Reviewer can see exactly what the system did and did not analyze.**  
  **Source:** line 150 | Section: Human Review Requirements | Source ID: `HUMAN-02`  
  **Priority:** Required  
  **Implement:** Display analyzed sources/scopes and explicit exclusions, failures, unsupported formats, stale items, skipped checks, and unresolved questions.  
  **Done when / evidence:** Reviewers can distinguish analyzed from un-analyzed context before deciding.

- [ ] **HUMAN-03 — Reviewer can narrow scope and rerun.**  
  **Source:** line 151 | Section: Human Review Requirements | Source ID: `HUMAN-03`  
  **Priority:** Required  
  **Implement:** Implement scope editing/narrowing that creates a new scoped iteration while preserving prior state/provenance and re-runs only permitted stages.  
  **Done when / evidence:** Narrow-scope reruns retain prior history, use the new authority contract, and do not leak excluded evidence.

- [ ] **HUMAN-04 — Reviewer can reject without side effects.**  
  **Source:** line 152 | Section: Human Review Requirements | Source ID: `HUMAN-04`  
  **Priority:** Required  
  **Implement:** Make rejection a non-state-changing decision for external systems; record rejection and keep drafts isolated from execution paths.  
  **Done when / evidence:** Reject tests show no write/deploy/commit/communication side effect and preserve a complete review record.

- [ ] **HUMAN-05 — Reviewer can require additional evidence.**  
  **Source:** line 153 | Section: Human Review Requirements | Source ID: `HUMAN-05`  
  **Priority:** Required  
  **Implement:** Implement request-more-evidence action that identifies needed evidence, pauses approval, allows authorized retrieval/attachment, and resumes analysis.  
  **Done when / evidence:** The workflow cannot progress to approval while required evidence requests remain unresolved unless policy explicitly allows it.

- [ ] **HUMAN-06 — Approval identity, timestamp, and approved scope are recorded.**  
  **Source:** line 154 | Section: Human Review Requirements | Source ID: `HUMAN-06`  
  **Priority:** Blocker  
  **Implement:** Capture authenticated approver identity, timestamp, approved scope, artifact/run IDs, decision, and policy version in a trusted review record.  
  **Done when / evidence:** Approval records are attributable, immutable, scope-bound, and independently verifiable.

- [ ] **HUMAN-07 — Final accountability is never represented as belonging to the AI.**  
  **Source:** line 155 | Section: Human Review Requirements | Source ID: `HUMAN-07`  
  **Priority:** Blocker  
  **Implement:** Use UI, API, generated artifacts, and audit language that attributes recommendations to the system but final accountability/approval to the human role.  
  **Done when / evidence:** Content/UI tests find no representation that the AI owns final architecture accountability.

- [ ] **XHITL-01 — Provide preview before state-changing actions.**  
  **Source:** line 224 | Section: Human-in-the-Loop Control | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement trusted review workflow controls to provide preview before state-changing actions; enforce them in UI, API, state-machine guards, and audit records.  
  **Done when / evidence:** Automated and manual review tests prove the human can take the allowed action and the model cannot impersonate, bypass, or self-approve it.

- [ ] **XHITL-02 — Require explicit approval at the paper-specified human gates.**  
  **Source:** line 225 | Section: Human-in-the-Loop Control | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement trusted review workflow controls to require explicit approval at the paper-specified human gates; enforce them in UI, API, state-machine guards, and audit records.  
  **Done when / evidence:** Automated and manual review tests prove the human can take the allowed action and the model cannot impersonate, bypass, or self-approve it.

- [ ] **XHITL-03 — Support approve, reject, edit, narrow scope, and request-more-evidence operations.**  
  **Source:** line 226 | Section: Human-in-the-Loop Control | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement trusted review workflow controls to support approve, reject, edit, narrow scope, and request-more-evidence operations; enforce them in UI, API, state-machine guards, and audit records.  
  **Done when / evidence:** Automated and manual review tests prove the human can take the allowed action and the model cannot impersonate, bypass, or self-approve it.

- [ ] **XHITL-04 — Keep final accountability visible in the UI and audit record.**  
  **Source:** line 227 | Section: Human-in-the-Loop Control | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement trusted review workflow controls to keep final accountability visible in the ui and audit record; enforce them in UI, API, state-machine guards, and audit records.  
  **Done when / evidence:** Automated and manual review tests prove the human can take the allowed action and the model cannot impersonate, bypass, or self-approve it.

- [ ] **XHITL-05 — Prevent the AI from approving or attesting to its own work where prohibited.**  
  **Source:** line 228 | Section: Human-in-the-Loop Control | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement trusted review workflow controls to prevent the ai from approving or attesting to its own work where prohibited; enforce them in UI, API, state-machine guards, and audit records.  
  **Done when / evidence:** Automated and manual review tests prove the human can take the allowed action and the model cannot impersonate, bypass, or self-approve it.

### P10 — Security, privacy, isolation, and fail-closed enforcement

- [ ] **SEC-01 — Prompt injection from repository/docs/tickets/logs is treated as untrusted input.**  
  **Source:** line 128 | Section: Threat Model Requirements | Source ID: `SEC-01`  
  **Priority:** Blocker  
  **Implement:** Treat content from repositories, documents, tickets, logs, diagrams, and catalogs as untrusted data; isolate instructions from system/policy control channels.  
  **Done when / evidence:** Prompt-injection fixtures cannot alter authority, workflow rules, hidden prompts, tool permissions, or approval state.

- [ ] **SEC-02 — Tool-call argument validation blocks command/path/scope injection.**  
  **Source:** line 129 | Section: Threat Model Requirements | Source ID: `SEC-02`  
  **Priority:** Blocker  
  **Implement:** Validate and canonicalize every tool argument against schema and policy; constrain commands, paths, URLs, identifiers, scopes, and resource limits.  
  **Done when / evidence:** Command/path/scope injection payloads are rejected before tool execution and logged as denials.

- [ ] **SEC-03 — Secrets are never copied into model context unless explicitly required and protected.**  
  **Source:** line 130 | Section: Threat Model Requirements | Source ID: `SEC-03`  
  **Priority:** Blocker  
  **Implement:** Implement secret classification and exclusion/redaction; use secret references or brokered credentials instead of copying secret values into model context.  
  **Done when / evidence:** Secret-seeding tests find no raw secret in prompts, model inputs/outputs, logs, artifacts, or exports unless an explicitly approved protected path applies.

- [ ] **SEC-04 — Cross-project/tenant data leakage tests exist.**  
  **Source:** line 131 | Section: Threat Model Requirements | Source ID: `SEC-04`  
  **Priority:** Blocker  
  **Implement:** Build cross-project/tenant isolation tests across storage, retrieval, caches, embeddings/indexes, logs, exports, and model context assembly.  
  **Done when / evidence:** Canary data from one project/tenant is never returned to another under authorized and adversarial queries.

- [ ] **SEC-05 — Unauthorized write attempts fail closed.**  
  **Source:** line 132 | Section: Threat Model Requirements | Source ID: `SEC-05`  
  **Priority:** Blocker  
  **Implement:** Place write authorization outside model control and deny writes unless the workflow state, scope, actor, target, and approval token all validate.  
  **Done when / evidence:** Unauthorized and ambiguous write attempts produce no side effect and generate a denial audit event.

- [ ] **SEC-06 — Sensitive generated output is classified before display/export.**  
  **Source:** line 133 | Section: Threat Model Requirements | Source ID: `SEC-06`  
  **Priority:** Blocker  
  **Implement:** Classify generated output before display/export using the same data policy taxonomy as source content; redact/block according to destination policy.  
  **Done when / evidence:** Sensitive-output fixtures are correctly blocked/redacted and classification decisions are auditable.

- [ ] **SEC-07 — Human approval tokens cannot be fabricated by model output.**  
  **Source:** line 134 | Section: Threat Model Requirements | Source ID: `SEC-07`  
  **Priority:** Blocker  
  **Implement:** Issue human approval tokens only from trusted authenticated review services; bind them to approver, scope, run/artifact, action, expiry, and nonce.  
  **Done when / evidence:** Forged, replayed, altered, expired, or model-authored approval tokens are rejected.

- [ ] **SEC-08 — Audit records cannot be modified by the model.**  
  **Source:** line 135 | Section: Threat Model Requirements | Source ID: `SEC-08`  
  **Priority:** Blocker  
  **Implement:** Remove model write access to audit storage; use append-only/tamper-evident service boundaries with independent credentials and integrity checks.  
  **Done when / evidence:** Adversarial tool/model paths cannot edit or delete audit records and tamper tests are detected.

- [ ] **XSEC-01 — Classify data before model/tool access.**  
  **Source:** line 238 | Section: Security and Privacy | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement security/privacy controls to classify data before model/tool access; enforce them outside model prompts and cover storage, retrieval, model context, tools, logs, UI, and export.  
  **Done when / evidence:** Threat-model tests show the protected condition holds under normal and adversarial paths, with fail-closed behavior and auditable denials.

- [ ] **XSEC-02 — Redact or exclude sensitive data where not required.**  
  **Source:** line 239 | Section: Security and Privacy | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement security/privacy controls to redact or exclude sensitive data where not required; enforce them outside model prompts and cover storage, retrieval, model context, tools, logs, UI, and export.  
  **Done when / evidence:** Threat-model tests show the protected condition holds under normal and adversarial paths, with fail-closed behavior and auditable denials.

- [ ] **XSEC-03 — Prevent cross-tenant/project leakage.**  
  **Source:** line 240 | Section: Security and Privacy | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement security/privacy controls to prevent cross-tenant/project leakage; enforce them outside model prompts and cover storage, retrieval, model context, tools, logs, UI, and export.  
  **Done when / evidence:** Threat-model tests show the protected condition holds under normal and adversarial paths, with fail-closed behavior and auditable denials.

- [ ] **XSEC-04 — Encrypt data in transit and at rest.**  
  **Source:** line 241 | Section: Security and Privacy | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement security/privacy controls to encrypt data in transit and at rest; enforce them outside model prompts and cover storage, retrieval, model context, tools, logs, UI, and export.  
  **Done when / evidence:** Threat-model tests show the protected condition holds under normal and adversarial paths, with fail-closed behavior and auditable denials.

- [ ] **XSEC-05 — Keep secrets out of prompts, logs, generated artifacts, and model context.**  
  **Source:** line 242 | Section: Security and Privacy | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement security/privacy controls to keep secrets out of prompts, logs, generated artifacts, and model context; enforce them outside model prompts and cover storage, retrieval, model context, tools, logs, UI, and export.  
  **Done when / evidence:** Threat-model tests show the protected condition holds under normal and adversarial paths, with fail-closed behavior and auditable denials.

- [ ] **XSEC-06 — Maintain configurable retention and deletion policies.**  
  **Source:** line 243 | Section: Security and Privacy | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement security/privacy controls to maintain configurable retention and deletion policies; enforce them outside model prompts and cover storage, retrieval, model context, tools, logs, UI, and export.  
  **Done when / evidence:** Threat-model tests show the protected condition holds under normal and adversarial paths, with fail-closed behavior and auditable denials.

- [ ] **XSEC-07 — Threat-model prompt injection and malicious repository/artifact content.**  
  **Source:** line 244 | Section: Security and Privacy | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement security/privacy controls to threat-model prompt injection and malicious repository/artifact content; enforce them outside model prompts and cover storage, retrieval, model context, tools, logs, UI, and export.  
  **Done when / evidence:** Threat-model tests show the protected condition holds under normal and adversarial paths, with fail-closed behavior and auditable denials.

- [ ] **XTOOL-03 — Sandbox code execution and untrusted artifact processing.**  
  **Source:** line 249 | Section: Model and Tooling Controls | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement orchestration/tool controls to sandbox code execution and untrusted artifact processing; define the deterministic boundary, schema/policy checks, sandbox/resource limits, fallback behavior, and version capture as applicable.  
  **Done when / evidence:** Integration/adversarial tests prove the control operates independently of model cooperation and produces typed, observable failure behavior.

### P11 — Observability, resilience, and operations

- [ ] **ARCH-10 — Observability/evaluation subsystem**  
  **Source:** line 66 | Section: Required Reference Architecture | Source ID: `ARCH-10`  
  **Priority:** Required  
  **Implement:** Implement observability/evaluation instrumentation spanning connectors, retrieval, analyzers, model calls, state transitions, review actions, policy denials, latency, and cost.  
  **Done when / evidence:** A run-level trace explains execution end to end and feeds operational/evaluation metrics without leaking protected data.

- [ ] **IMPL-09 — Implement audit logging for retrievals, model/tool calls, generated artifacts, approvals, overrides, and denied actions.**  
  **Source:** line 78 | Section: Additional Implementation Requirements | Source ID: `IMPL-09`  
  **Priority:** Required  
  **Implement:** Emit tamper-resistant audit events for retrieval, normalization, tool/model calls, generated artifacts, policy decisions, approvals, overrides, exports, and denied actions.  
  **Done when / evidence:** Audit events include actor/run/artifact IDs and timestamps and cannot be altered through model-accessible interfaces.

- [ ] **WF-12 — Rollback/abort cleanly if scope, evidence, authorization, or verification conditions fail.**  
  **Source:** line 94 | Section: Core Workflow | Source ID: `WF-12`  
  **Priority:** Required  
  **Implement:** Define rollback/abort handlers for authorization loss, scope mismatch, evidence failure, connector/tool/model failure, verification failure, and revoked approval.  
  **Done when / evidence:** Fault-injection tests leave external systems consistent, preserve audit evidence, and terminate in an explicit safe state.

- [ ] **XTOOL-07 — Provide fallback behavior when a model or connector fails.**  
  **Source:** line 253 | Section: Model and Tooling Controls | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Implement orchestration/tool controls to provide fallback behavior when a model or connector fails; define the deterministic boundary, schema/policy checks, sandbox/resource limits, fallback behavior, and version capture as applicable.  
  **Done when / evidence:** Integration/adversarial tests prove the control operates independently of model cooperation and produces typed, observable failure behavior.

- [ ] **XOBS-01 — Emit structured logs for workflow state transitions.**  
  **Source:** line 256 | Section: Observability and Operations | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Instrument the platform to emit structured logs for workflow state transitions; define event/metric schema, dimensions, privacy filtering, dashboards, alerts, and run correlation.  
  **Done when / evidence:** Operational tests produce queryable run-level telemetry with no secret leakage; alerts/metrics have documented owners and thresholds.

- [ ] **XOBS-02 — Measure latency, cost, tool failures, abstention, approval, and override rates.**  
  **Source:** line 257 | Section: Observability and Operations | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Instrument the platform to measure latency, cost, tool failures, abstention, approval, and override rates; define event/metric schema, dimensions, privacy filtering, dashboards, alerts, and run correlation.  
  **Done when / evidence:** Operational tests produce queryable run-level telemetry with no secret leakage; alerts/metrics have documented owners and thresholds.

- [ ] **XOBS-03 — Track false-positive/false-negative rates where ground truth exists.**  
  **Source:** line 258 | Section: Observability and Operations | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Instrument the platform to track false-positive/false-negative rates where ground truth exists; define event/metric schema, dimensions, privacy filtering, dashboards, alerts, and run correlation.  
  **Done when / evidence:** Operational tests produce queryable run-level telemetry with no secret leakage; alerts/metrics have documented owners and thresholds.

- [ ] **XOBS-04 — Alert on abnormal permission use or unexpected write attempts.**  
  **Source:** line 259 | Section: Observability and Operations | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Instrument the platform to alert on abnormal permission use or unexpected write attempts; define event/metric schema, dimensions, privacy filtering, dashboards, alerts, and run correlation.  
  **Done when / evidence:** Operational tests produce queryable run-level telemetry with no secret leakage; alerts/metrics have documented owners and thresholds.

- [ ] **XOBS-05 — Provide run-level tracing across retrieval, tools, model calls, and approvals.**  
  **Source:** line 260 | Section: Observability and Operations | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Instrument the platform to provide run-level tracing across retrieval, tools, model calls, and approvals; define event/metric schema, dimensions, privacy filtering, dashboards, alerts, and run correlation.  
  **Done when / evidence:** Operational tests produce queryable run-level telemetry with no secret leakage; alerts/metrics have documented owners and thresholds.

### P12 — Verification, testing, benchmark, and evaluation

- [ ] **IMPL-10 — Define an offline benchmark and regression suite before enabling production use.**  
  **Source:** line 79 | Section: Additional Implementation Requirements | Source ID: `IMPL-10`  
  **Priority:** Required  
  **Implement:** Create a versioned offline benchmark corpus plus regression runner covering grounding, provenance, distinctness, constraint adherence, uncertainty, guardrail bypass, and workflow outcomes.  
  **Done when / evidence:** A release produces a reproducible benchmark report against documented pass/fail thresholds before production enablement.

- [ ] **WF-08 — Verify the output using independent tools or checks.**  
  **Source:** line 90 | Section: Core Workflow | Source ID: `WF-08`  
  **Priority:** Required  
  **Implement:** Run independent schema, grounding, constraint, distinctness, provenance, security, and policy checks over generated outputs.  
  **Done when / evidence:** Verification results are recorded separately from generation and failures block advancement according to policy.

- [ ] **VERIFY-01 — Each option traces to requirements and constraints**  
  **Source:** line 98 | Section: Verification Requirements | Source ID: `VERIFY-01`  
  **Priority:** Required  
  **Implement:** Implement a traceability verifier that walks each candidate component/relationship/decision to requirement and constraint IDs and records coverage gaps.  
  **Done when / evidence:** Verification report shows complete supported links or explicit gaps; no material option element is presented as grounded without a resolvable source path.

- [ ] **VERIFY-02 — Options are materially distinct**  
  **Source:** line 99 | Section: Verification Requirements | Source ID: `VERIFY-02`  
  **Priority:** Required  
  **Implement:** Define approved material-distinctness criteria and implement an independent candidate similarity/diversity check over structure, deployment choices, trade-offs, and constraints.  
  **Done when / evidence:** Near-duplicate candidates are rejected/regenerated or labeled; regression fixtures cover both distinct and superficially renamed options.

- [ ] **VERIFY-03 — Unsupported assumptions are labeled**  
  **Source:** line 100 | Section: Verification Requirements | Source ID: `VERIFY-03`  
  **Priority:** Required  
  **Implement:** Verify every assertion lacking direct evidence is tagged as inferred, uncertain, proposed, or unsupported and appears in the assumption registry.  
  **Done when / evidence:** A seeded unsupported assertion is detected before review; no unlabeled assumption passes the gate.

- [ ] **VERIFY-04 — Trade-offs cite source context**  
  **Source:** line 101 | Section: Verification Requirements | Source ID: `VERIFY-04`  
  **Priority:** Required  
  **Implement:** Verify every material trade-off statement carries source/provenance references or an explicit inference marker.  
  **Done when / evidence:** Comparison artifacts fail validation when material trade-off claims lack evidence links.

- [ ] **VERIFY-05 — Final decision remains explicitly human-owned**  
  **Source:** line 102 | Section: Verification Requirements | Source ID: `VERIFY-05`  
  **Priority:** Required  
  **Implement:** Verify final decision state, UI labels, API authorization, audit events, and generated text preserve explicit human ownership.  
  **Done when / evidence:** No model/tool identity can author a final approval; the approved record names the authenticated human principal.

- [ ] **VERIFY-06 — Design-state history is preserved across iterations**  
  **Source:** line 103 | Section: Verification Requirements | Source ID: `VERIFY-06`  
  **Priority:** Required  
  **Implement:** Verify design-state snapshots/events survive reruns, candidate edits, rejection, scope narrowing, interruption, and resume.  
  **Done when / evidence:** History reconstruction tests reproduce each iteration and show no destructive overwrite of prior design state.

- [ ] **TEST-UNIT-01 — Parsers, schema validators, policy checks, scoring logic, provenance links, and state transitions.**  
  **Source:** line 160 | Section: Unit Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create fast isolated unit-test suites for parsers, schema validators, policy checks, scoring logic, provenance links, and state transitions; include valid, invalid, boundary, and failure cases and run them in CI.  
  **Done when / evidence:** Unit-test jobs are deterministic, exercise negative paths, and fail CI on regression with coverage of every listed control family.

- [ ] **TEST-INT-01 — Connectors, retrieval, deterministic analyzers, model orchestration, review UI, and audit storage.**  
  **Source:** line 163 | Section: Integration Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create integration suites spanning connectors, retrieval, deterministic analyzers, model orchestration, review ui, and audit storage; use representative authorized fixtures and realistic persistence/service boundaries.  
  **Done when / evidence:** Integration runs prove contract compatibility, data/provenance continuity, authorization enforcement, and failure handling across component boundaries.

- [ ] **TEST-ADV-01 — Malicious repository/document instructions.**  
  **Source:** line 166 | Section: Adversarial Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create adversarial fixtures and attack-path tests for: Malicious repository/document instructions. Exercise both model-mediated and direct API/tool paths.  
  **Done when / evidence:** The attack produces no unauthorized side effect or silent trust escalation; expected denial/abstention is recorded and asserted.

- [ ] **TEST-ADV-02 — Missing/stale/conflicting evidence.**  
  **Source:** line 167 | Section: Adversarial Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create adversarial fixtures and attack-path tests for: Missing/stale/conflicting evidence. Exercise both model-mediated and direct API/tool paths.  
  **Done when / evidence:** The attack produces no unauthorized side effect or silent trust escalation; expected denial/abstention is recorded and asserted.

- [ ] **TEST-ADV-03 — Oversized scope requests.**  
  **Source:** line 168 | Section: Adversarial Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create adversarial fixtures and attack-path tests for: Oversized scope requests. Exercise both model-mediated and direct API/tool paths.  
  **Done when / evidence:** The attack produces no unauthorized side effect or silent trust escalation; expected denial/abstention is recorded and asserted.

- [ ] **TEST-ADV-04 — Unauthorized write/tool calls.**  
  **Source:** line 169 | Section: Adversarial Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create adversarial fixtures and attack-path tests for: Unauthorized write/tool calls. Exercise both model-mediated and direct API/tool paths.  
  **Done when / evidence:** The attack produces no unauthorized side effect or silent trust escalation; expected denial/abstention is recorded and asserted.

- [ ] **TEST-ADV-05 — Sensitive-data leakage.**  
  **Source:** line 170 | Section: Adversarial Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create adversarial fixtures and attack-path tests for: Sensitive-data leakage. Exercise both model-mediated and direct API/tool paths.  
  **Done when / evidence:** The attack produces no unauthorized side effect or silent trust escalation; expected denial/abstention is recorded and asserted.

- [ ] **TEST-ADV-06 — Hallucinated provenance.**  
  **Source:** line 171 | Section: Adversarial Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create adversarial fixtures and attack-path tests for: Hallucinated provenance. Exercise both model-mediated and direct API/tool paths.  
  **Done when / evidence:** The attack produces no unauthorized side effect or silent trust escalation; expected denial/abstention is recorded and asserted.

- [ ] **TEST-ADV-07 — False human-approval claims.**  
  **Source:** line 172 | Section: Adversarial Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create adversarial fixtures and attack-path tests for: False human-approval claims. Exercise both model-mediated and direct API/tool paths.  
  **Done when / evidence:** The attack produces no unauthorized side effect or silent trust escalation; expected denial/abstention is recorded and asserted.

- [ ] **TEST-E2E-01 — Golden-path scenario.**  
  **Source:** line 175 | Section: End-to-End Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build a fully automated end-to-end scenario for: Golden-path scenario. Drive the real workflow state machine through connectors, analysis, model orchestration, review, persistence, and audit.  
  **Done when / evidence:** The scenario reaches only the expected legal terminal state, with complete provenance/audit evidence and deterministic assertions on side effects.

- [ ] **TEST-E2E-02 — Human rejection scenario.**  
  **Source:** line 176 | Section: End-to-End Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build a fully automated end-to-end scenario for: Human rejection scenario. Drive the real workflow state machine through connectors, analysis, model orchestration, review, persistence, and audit.  
  **Done when / evidence:** The scenario reaches only the expected legal terminal state, with complete provenance/audit evidence and deterministic assertions on side effects.

- [ ] **TEST-E2E-03 — Human scope-narrowing scenario.**  
  **Source:** line 177 | Section: End-to-End Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build a fully automated end-to-end scenario for: Human scope-narrowing scenario. Drive the real workflow state machine through connectors, analysis, model orchestration, review, persistence, and audit.  
  **Done when / evidence:** The scenario reaches only the expected legal terminal state, with complete provenance/audit evidence and deterministic assertions on side effects.

- [ ] **TEST-E2E-04 — Tool failure scenario.**  
  **Source:** line 178 | Section: End-to-End Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build a fully automated end-to-end scenario for: Tool failure scenario. Drive the real workflow state machine through connectors, analysis, model orchestration, review, persistence, and audit.  
  **Done when / evidence:** The scenario reaches only the expected legal terminal state, with complete provenance/audit evidence and deterministic assertions on side effects.

- [ ] **TEST-E2E-05 — Missing-context abstention scenario.**  
  **Source:** line 179 | Section: End-to-End Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build a fully automated end-to-end scenario for: Missing-context abstention scenario. Drive the real workflow state machine through connectors, analysis, model orchestration, review, persistence, and audit.  
  **Done when / evidence:** The scenario reaches only the expected legal terminal state, with complete provenance/audit evidence and deterministic assertions on side effects.

- [ ] **TEST-E2E-06 — Rollback/abort scenario.**  
  **Source:** line 180 | Section: End-to-End Tests | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build a fully automated end-to-end scenario for: Rollback/abort scenario. Drive the real workflow state machine through connectors, analysis, model orchestration, review, persistence, and audit.  
  **Done when / evidence:** The scenario reaches only the expected legal terminal state, with complete provenance/audit evidence and deterministic assertions on side effects.

- [ ] **XEVAL-01 — Build a representative offline evaluation corpus.**  
  **Source:** line 263 | Section: Evaluation and Acceptance | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build evaluation/acceptance machinery to build a representative offline evaluation corpus; define corpus, metrics, thresholds, regression comparison, and evidence retention.  
  **Done when / evidence:** Each release emits a reproducible evaluation report and fails qualification when the documented acceptance rule is not met.

- [ ] **XEVAL-02 — Include adversarial, ambiguous, stale, incomplete, and out-of-scope cases.**  
  **Source:** line 264 | Section: Evaluation and Acceptance | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build evaluation/acceptance machinery to include adversarial, ambiguous, stale, incomplete, and out-of-scope cases; define corpus, metrics, thresholds, regression comparison, and evidence retention.  
  **Done when / evidence:** Each release emits a reproducible evaluation report and fails qualification when the documented acceptance rule is not met.

- [ ] **XEVAL-03 — Measure grounding/provenance correctness.**  
  **Source:** line 265 | Section: Evaluation and Acceptance | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build evaluation/acceptance machinery to measure grounding/provenance correctness; define corpus, metrics, thresholds, regression comparison, and evidence retention.  
  **Done when / evidence:** Each release emits a reproducible evaluation report and fails qualification when the documented acceptance rule is not met.

- [ ] **XEVAL-04 — Measure human review burden, not only task completion.**  
  **Source:** line 266 | Section: Evaluation and Acceptance | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build evaluation/acceptance machinery to measure human review burden, not only task completion; define corpus, metrics, thresholds, regression comparison, and evidence retention.  
  **Done when / evidence:** Each release emits a reproducible evaluation report and fails qualification when the documented acceptance rule is not met.

- [ ] **XEVAL-05 — Validate that guardrails fail closed.**  
  **Source:** line 267 | Section: Evaluation and Acceptance | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build evaluation/acceptance machinery to validate that guardrails fail closed; define corpus, metrics, thresholds, regression comparison, and evidence retention.  
  **Done when / evidence:** Each release emits a reproducible evaluation report and fails qualification when the documented acceptance rule is not met.

- [ ] **XEVAL-06 — Run pilot deployment under read-only/draft-only permissions before broader rollout.**  
  **Source:** line 268 | Section: Evaluation and Acceptance | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build evaluation/acceptance machinery to run pilot deployment under read-only/draft-only permissions before broader rollout; define corpus, metrics, thresholds, regression comparison, and evidence retention.  
  **Done when / evidence:** Each release emits a reproducible evaluation report and fails qualification when the documented acceptance rule is not met.

- [ ] **XEVAL-07 — Require documented acceptance criteria and rollback procedure before production use.**  
  **Source:** line 269 | Section: Evaluation and Acceptance | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Build evaluation/acceptance machinery to require documented acceptance criteria and rollback procedure before production use; define corpus, metrics, thresholds, regression comparison, and evidence retention.  
  **Done when / evidence:** Each release emits a reproducible evaluation report and fails qualification when the documented acceptance rule is not met.

### P13 — Deployment environments, pilot, and release qualification

- [ ] **ENV-01 — Developer/local sandbox.**  
  **Source:** line 273 | Section: Minimum Deployment Environments | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Provision and document the developer/local sandbox with separate identity, configuration, secrets, data boundaries, observability, and deployment controls.  
  **Done when / evidence:** Environment smoke tests pass; privilege boundaries and promotion rules are verified; no environment silently shares production authority/data beyond policy.

- [ ] **ENV-02 — CI validation environment.**  
  **Source:** line 274 | Section: Minimum Deployment Environments | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Provision and document the ci validation environment with separate identity, configuration, secrets, data boundaries, observability, and deployment controls.  
  **Done when / evidence:** Environment smoke tests pass; privilege boundaries and promotion rules are verified; no environment silently shares production authority/data beyond policy.

- [ ] **ENV-03 — Staging/pre-production environment.**  
  **Source:** line 275 | Section: Minimum Deployment Environments | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Provision and document the staging/pre-production environment with separate identity, configuration, secrets, data boundaries, observability, and deployment controls.  
  **Done when / evidence:** Environment smoke tests pass; privilege boundaries and promotion rules are verified; no environment silently shares production authority/data beyond policy.

- [ ] **ENV-04 — Production read-only integration where applicable.**  
  **Source:** line 276 | Section: Minimum Deployment Environments | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Provision and document the production read-only integration where applicable with separate identity, configuration, secrets, data boundaries, observability, and deployment controls.  
  **Done when / evidence:** Environment smoke tests pass; privilege boundaries and promotion rules are verified; no environment silently shares production authority/data beyond policy.

- [ ] **ENV-05 — Separate privileged execution path only where explicitly authorized.**  
  **Source:** line 277 | Section: Minimum Deployment Environments | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Provision and document the separate privileged execution path only where explicitly authorized with separate identity, configuration, secrets, data boundaries, observability, and deployment controls.  
  **Done when / evidence:** Environment smoke tests pass; privilege boundaries and promotion rules are verified; no environment silently shares production authority/data beyond policy.

- [ ] **ENV-06 — Isolated test tenant/data set for privacy/security validation.**  
  **Source:** line 278 | Section: Minimum Deployment Environments | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Provision and document the isolated test tenant/data set for privacy/security validation with separate identity, configuration, secrets, data boundaries, observability, and deployment controls.  
  **Done when / evidence:** Environment smoke tests pass; privilege boundaries and promotion rules are verified; no environment silently shares production authority/data beyond policy.

### P14 — Documentation and operational handoff

- [ ] **DOC-01 — Architecture diagram.**  
  **Source:** line 282 | Section: Required Documentation | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create, version, review, and link the required artifact: Architecture diagram. Generate it from authoritative schemas/configuration where practical and assign an owner.  
  **Done when / evidence:** The artifact is current, references implementation/control IDs, is included in release evidence, and is reviewed whenever dependent architecture/policy changes.

- [ ] **DOC-02 — Data-flow and trust-boundary diagram.**  
  **Source:** line 283 | Section: Required Documentation | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create, version, review, and link the required artifact: Data-flow and trust-boundary diagram. Generate it from authoritative schemas/configuration where practical and assign an owner.  
  **Done when / evidence:** The artifact is current, references implementation/control IDs, is included in release evidence, and is reviewed whenever dependent architecture/policy changes.

- [ ] **DOC-03 — Source/connector inventory.**  
  **Source:** line 284 | Section: Required Documentation | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create, version, review, and link the required artifact: Source/connector inventory. Generate it from authoritative schemas/configuration where practical and assign an owner.  
  **Done when / evidence:** The artifact is current, references implementation/control IDs, is included in release evidence, and is reviewed whenever dependent architecture/policy changes.

- [ ] **DOC-04 — Permission matrix.**  
  **Source:** line 285 | Section: Required Documentation | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create, version, review, and link the required artifact: Permission matrix. Generate it from authoritative schemas/configuration where practical and assign an owner.  
  **Done when / evidence:** The artifact is current, references implementation/control IDs, is included in release evidence, and is reviewed whenever dependent architecture/policy changes.

- [ ] **DOC-05 — Threat model.**  
  **Source:** line 286 | Section: Required Documentation | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create, version, review, and link the required artifact: Threat model. Generate it from authoritative schemas/configuration where practical and assign an owner.  
  **Done when / evidence:** The artifact is current, references implementation/control IDs, is included in release evidence, and is reviewed whenever dependent architecture/policy changes.

- [ ] **DOC-06 — Model/tool inventory.**  
  **Source:** line 287 | Section: Required Documentation | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create, version, review, and link the required artifact: Model/tool inventory. Generate it from authoritative schemas/configuration where practical and assign an owner.  
  **Done when / evidence:** The artifact is current, references implementation/control IDs, is included in release evidence, and is reviewed whenever dependent architecture/policy changes.

- [ ] **DOC-07 — Provenance schema.**  
  **Source:** line 288 | Section: Required Documentation | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create, version, review, and link the required artifact: Provenance schema. Generate it from authoritative schemas/configuration where practical and assign an owner.  
  **Done when / evidence:** The artifact is current, references implementation/control IDs, is included in release evidence, and is reviewed whenever dependent architecture/policy changes.

- [ ] **DOC-08 — Run-state schema.**  
  **Source:** line 289 | Section: Required Documentation | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create, version, review, and link the required artifact: Run-state schema. Generate it from authoritative schemas/configuration where practical and assign an owner.  
  **Done when / evidence:** The artifact is current, references implementation/control IDs, is included in release evidence, and is reviewed whenever dependent architecture/policy changes.

- [ ] **DOC-09 — Human approval policy.**  
  **Source:** line 290 | Section: Required Documentation | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create, version, review, and link the required artifact: Human approval policy. Generate it from authoritative schemas/configuration where practical and assign an owner.  
  **Done when / evidence:** The artifact is current, references implementation/control IDs, is included in release evidence, and is reviewed whenever dependent architecture/policy changes.

- [ ] **DOC-10 — Evaluation plan and benchmark corpus description.**  
  **Source:** line 291 | Section: Required Documentation | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create, version, review, and link the required artifact: Evaluation plan and benchmark corpus description. Generate it from authoritative schemas/configuration where practical and assign an owner.  
  **Done when / evidence:** The artifact is current, references implementation/control IDs, is included in release evidence, and is reviewed whenever dependent architecture/policy changes.

- [ ] **DOC-11 — Incident/rollback runbook.**  
  **Source:** line 292 | Section: Required Documentation | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create, version, review, and link the required artifact: Incident/rollback runbook. Generate it from authoritative schemas/configuration where practical and assign an owner.  
  **Done when / evidence:** The artifact is current, references implementation/control IDs, is included in release evidence, and is reviewed whenever dependent architecture/policy changes.

- [ ] **DOC-12 — Known limitations and non-goals.**  
  **Source:** line 293 | Section: Required Documentation | Source ID: _none; audit-assigned_  
  **Priority:** Required  
  **Implement:** Create, version, review, and link the required artifact: Known limitations and non-goals. Generate it from authoritative schemas/configuration where practical and assign an owner.  
  **Done when / evidence:** The artifact is current, references implementation/control IDs, is included in release evidence, and is reviewed whenever dependent architecture/policy changes.

### P15 — Production-readiness gate

- [ ] **GATE-PROD-01 — All paper-stated guardrails are implemented as enforceable controls.**  
  **Source:** line 184 | Section: Production Readiness Gate | Source ID: _none; audit-assigned_  
  **Priority:** Blocker  
  **Implement:** Turn this readiness condition into a machine-checkable or evidence-backed release gate: All paper-stated guardrails are implemented as enforceable controls. Name the evidence owner and required artifact/test report.  
  **Done when / evidence:** Release is blocked until the gate has current, independently reviewable evidence and an explicit PASS; exceptions require a documented human risk acceptance process.

- [ ] **GATE-PROD-02 — Evaluation demonstrates acceptable grounding and false-positive behavior.**  
  **Source:** line 185 | Section: Production Readiness Gate | Source ID: _none; audit-assigned_  
  **Priority:** Blocker  
  **Implement:** Turn this readiness condition into a machine-checkable or evidence-backed release gate: Evaluation demonstrates acceptable grounding and false-positive behavior. Name the evidence owner and required artifact/test report.  
  **Done when / evidence:** Release is blocked until the gate has current, independently reviewable evidence and an explicit PASS; exceptions require a documented human risk acceptance process.

- [ ] **GATE-PROD-03 — No hidden write authority exists outside approved workflows.**  
  **Source:** line 186 | Section: Production Readiness Gate | Source ID: _none; audit-assigned_  
  **Priority:** Blocker  
  **Implement:** Turn this readiness condition into a machine-checkable or evidence-backed release gate: No hidden write authority exists outside approved workflows. Name the evidence owner and required artifact/test report.  
  **Done when / evidence:** Release is blocked until the gate has current, independently reviewable evidence and an explicit PASS; exceptions require a documented human risk acceptance process.

- [ ] **GATE-PROD-04 — Every material output is traceable to evidence.**  
  **Source:** line 187 | Section: Production Readiness Gate | Source ID: _none; audit-assigned_  
  **Priority:** Blocker  
  **Implement:** Turn this readiness condition into a machine-checkable or evidence-backed release gate: Every material output is traceable to evidence. Name the evidence owner and required artifact/test report.  
  **Done when / evidence:** Release is blocked until the gate has current, independently reviewable evidence and an explicit PASS; exceptions require a documented human risk acceptance process.

- [ ] **GATE-PROD-05 — Human approval gates have been tested for bypass resistance.**  
  **Source:** line 188 | Section: Production Readiness Gate | Source ID: _none; audit-assigned_  
  **Priority:** Blocker  
  **Implement:** Turn this readiness condition into a machine-checkable or evidence-backed release gate: Human approval gates have been tested for bypass resistance. Name the evidence owner and required artifact/test report.  
  **Done when / evidence:** Release is blocked until the gate has current, independently reviewable evidence and an explicit PASS; exceptions require a documented human risk acceptance process.

- [ ] **GATE-PROD-06 — Rollback and incident procedures are documented and exercised.**  
  **Source:** line 189 | Section: Production Readiness Gate | Source ID: _none; audit-assigned_  
  **Priority:** Blocker  
  **Implement:** Turn this readiness condition into a machine-checkable or evidence-backed release gate: Rollback and incident procedures are documented and exercised. Name the evidence owner and required artifact/test report.  
  **Done when / evidence:** Release is blocked until the gate has current, independently reviewable evidence and an explicit PASS; exceptions require a documented human risk acceptance process.

- [ ] **GATE-PROD-07 — Security/privacy review is complete.**  
  **Source:** line 190 | Section: Production Readiness Gate | Source ID: _none; audit-assigned_  
  **Priority:** Blocker  
  **Implement:** Turn this readiness condition into a machine-checkable or evidence-backed release gate: Security/privacy review is complete. Name the evidence owner and required artifact/test report.  
  **Done when / evidence:** Release is blocked until the gate has current, independently reviewable evidence and an explicit PASS; exceptions require a documented human risk acceptance process.

- [ ] **GATE-PROD-08 — Known limitations and non-goals are published.**  
  **Source:** line 191 | Section: Production Readiness Gate | Source ID: _none; audit-assigned_  
  **Priority:** Blocker  
  **Implement:** Turn this readiness condition into a machine-checkable or evidence-backed release gate: Known limitations and non-goals are published. Name the evidence owner and required artifact/test report.  
  **Done when / evidence:** Release is blocked until the gate has current, independently reviewable evidence and an explicit PASS; exceptions require a documented human risk acceptance process.

## 8. Production Go/No-Go Rule

Production is **NO-GO by default** until P15 closes. P15 may close only when every paper guardrail is enforced, every material output is evidence-traceable, human approval is bypass-resistant, security/privacy review is complete, rollback/incident procedures have been exercised, limitations are published, and the required evaluation/pilot evidence passes the approved thresholds.

A failure, unknown result, missing evidence, stale authority, unverifiable provenance, approval mismatch, or unresolved Blocker item must **not** be converted into PASS by model judgment.

## 9. Recommended Status Vocabulary

`NOT_STARTED → READY → IN_PROGRESS → IMPLEMENTED → VERIFIED → ACCEPTED`

Use `BLOCKED` as a side state with an explicit blocker ID/reason. Do not use `DONE` unless both implementation and evidence criteria are satisfied.

## 10. Recommended Next Artifact

Generate one prompt and one workflow for each normalized TODO ID, grouped by the same P0–P15 phases, with a master index that preserves source line, dependencies, inputs, outputs, acceptance tests, rollback behavior, and required evidence.