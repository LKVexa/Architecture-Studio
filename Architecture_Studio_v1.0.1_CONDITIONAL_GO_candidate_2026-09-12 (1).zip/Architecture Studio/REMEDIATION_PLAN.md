# REMEDIATION PLAN

Generated 2026-09-11T21:09:21Z. Implementer `builder:architecture-studio-audit-2026-09-11`. Verifier `null`.

This plan separates (A) defects that were fixed in the overlay from (B) prerequisites that cannot be
satisfied by the implementer. Items in (B) have handoff packages. They stay BLOCKED until real evidence
arrives. They must not be closed by editing labels.

## A. In-repository remediations (done)

| ID | Change | Verification | Residual |
|---|---|---|---|
| ISS-01 | `issued_at` now-relative | 133/133 tests | callers needing a frozen clock pass `issued_at` |
| ISS-02 | `gate_evidence.evaluate_production` used by `gates`/`status` | CLI counts match assembled evidence | `--skip-tests` fail-closes tests |
| ISS-03 | `WriteGate.attempt_bundle`; pipeline no longer `shutil.copy2`s | write-authority scan 0 hidden | AST coverage |
| ISS-04 | `confine` uses `relative_to` + reserved/NUL/length | confinement negatives | Windows not executed here |
| ISS-05 | `controls_document` maps `tests` | GATE-PROD-01 EVIDENCE_PASS | mapping ≠ review |
| ISS-14 | bundle consumes token before first byte | replay test | crash after consume burns the token (fail-closed) |
| LIM-08 | DOC-12 states remaining FAIL/NO_EVIDENCE | docs freshness current | publication still overlay-local |

## B. External / human prerequisites (open)

| # | Prerequisite | Gate/task | Handoff | Smallest concrete action |
|---|---|---|---|---|
| 1 | Independent reviews of mechanically passing gates | GATE-PROD-01,03,04,05,06,08 | `handoff/HANDOFF-INDEPENDENT-REVIEW.md` | Distinct human attaches a review record per gate naming `evidence_digest` |
| 2 | Approve (or refuse) numeric thresholds | GATE-PROD-02 | `handoff/HANDOFF-THRESHOLD-APPROVAL.md` | `ml_evaluation_owner` sets `thresholds_status=APPROVED` with signed rationale, **or** leaves FAIL |
| 3 | Security/privacy review | GATE-PROD-07 | `handoff/HANDOFF-SECURITY-PRIVACY-REVIEW.md` | Independent human produces `security_review` with `reviewer_kind=human`, `independent=true` |
| 4 | Independent verification of 226 BLOCKED records | protocol v3 | `handoff/HANDOFF-INDEPENDENT-VERIFICATION.md` | Distinct trusted principal runs the sealed checker; this pass must not |
| 5 | Bind host identity provider | XAUTH-01 | `handoff/HANDOFF-IDP-BINDING.md` | Occupies `IdentityBinding` slot; empty continues to fail closed |
| 6 | Bind host KMS | XSEC-04 | `handoff/HANDOFF-KMS-BINDING.md` | Occupies `KeyProvider` slot; install `cryptography` extra if AES-GCM/Ed25519 required |
| 7 | Provision CI/staging; decide ENV-04/05 | ENV-02..05 | `handoff/HANDOFF-ENV-PROVISIONING.md` | Create environments; human records applicability |

## C. Explicitly out of scope (do not fake)

- Binding a dummy model provider to make MODEL-01 look done.
- Setting `thresholds_status` to `APPROVED` from this process.
- Writing a `security_review` document signed by `architecture_studio`.
- Flipping 226 records from `BLOCKED` to `VERIFIED`.
- Counting `ACCEPTED_RISK` as `PASS`.
- Treating 133/133 tests, a zero exit code, or a valid archive as Production GO.

## D. Sequence after handoffs return

1. Place real review/approval/binding artifacts where the handoff specifies.
2. `python3 tests/run_all.py --json evidence/reports/run_all.json`
3. `python3 -m architecture_studio gates`
4. `python3 tools/build_evidence.py --package source` as the **implementer**, then the **verifier** runs the sealed checker.
5. Production GO only if `counts.PASS == 8` and `protocol_status.verified == 227` with `verifier` distinct from `implementer`.
