# ASFW evidence slots

One directory per item is created when a human deposits review or artifacts.
This runtime never writes `review.json` on its own behalf.

Expected (optional) layout:

```
evidence/asfw/ASFW-TODO-NNNN/review.json
```

`reviewer` must not be `architecture_studio`, `runtime`, `generator`,
`builder:architecture-studio-audit-2026-09-11`, or
`builder:architecture-studio-asfw-2026-09-11`.
`reviewer_kind` must be `human`. Missing files mean the item stays incomplete.
