# Gate review drop-box

Review records that can make a gate `PASS` are **still absent**.

What *is* here (after the 2026-09-11 chat offer) are **non-review** files:

| File | Meaning |
|---|---|
| `principal-offer.json` | Display-name offer from the implementer chat. Not a binding. |
| `roster-proposal.json` | All required roles UNSET. Consulted `research_specialist` proposed only. |
| `DEC-ASFW-0007.json` | Keep `DOD-02/04/05/08/09` undefined. Does **not** unblock GO. |
| `DEC-ASFW-0008.json` | Do not infer a ninth gate. Eight executable gates remain. Does **not** unblock GO. |

`python3 -m architecture_studio gates` ignores those record kinds. Missing
`GATE-PROD-XX.json` files still mean no review, not PASS.

| File | Meaning |
|---|---|
| `GATE-PROD-01.json` … `GATE-PROD-08.json` | Independent review of that gate |
| `GATE-PROD-07-security.json` | Security/privacy review body |
| `exceptions.json` | Documented risk acceptances (still not PASS) |
| `builder_subjects.json` | Extra implementer subjects the runtime must refuse |

A file signed by `architecture_studio`, `runtime`, `generator`,
`builder:architecture-studio-audit-2026-09-11`, or
`builder:architecture-studio-asfw-2026-09-11` is loaded and **refused**.

Do not commit invented reviews. Do not convert a chat signature into `PASS`.
