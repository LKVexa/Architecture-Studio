# Adversarial fixtures (pulled from the yard, verbatim)

| Folder | Donor | License | Used as |
|---|---|---|---|
| `bipia/` | microsoft/BIPIA (`benchmark/text_attack_test.json`, `benchmark/code_attack_test.json`) | MIT (copy in folder) | indirect-prompt-injection **attack** cases (XEVAL-02, MODEL-07, SEC-01) |
| `llmail/` | microsoft/llmail-inject-challenge (`src/agent/data/fp_tests.json`) | MIT (copy in folder) | **benign controls** for the injection false-positive rate (GATE-PROD-02, XOBS-03) |

Files are byte-identical to the donors; `architecture_studio/benchmark.py` reads them and never modifies them.
