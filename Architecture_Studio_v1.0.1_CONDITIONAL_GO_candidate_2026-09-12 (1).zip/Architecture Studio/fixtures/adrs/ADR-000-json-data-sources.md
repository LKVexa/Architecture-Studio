# ADR-000 — Use JSON files as the data source for `.jad` scripts

- Status: superseded
- Date: 2026-07-01
- Owner: repository maintainer (role)
- Superseded-by: ADR-001

## Context

The 62 `.jad` data scripts needed a machine-readable data source. JSON files were the first choice because every tool in the suite could read them.

## Decision

Each `.jad` script references its data source with `from json("<name>.json")`.

## Consequences

The referenced JSON files were never generated, so 62 data-source references pointed at files that did not exist. This was found by the cross-reference integrity diagnostic and led to ADR-001.
