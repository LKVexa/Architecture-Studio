# ADR-002 — Every workspace runs offline with the network disabled and secrets by reference

- Status: accepted
- Date: 2026-07-22
- Owner: operations owner (role)

## Context

The suites target an air-gapped installation (Air Gap Certification and Installer Plane). Workspaces declare `environment offline` and `network disabled`; `.jasec` policies deny `network.*` by default.

## Decision

No workspace may open a network connection at run time. Secrets are never embedded: a workspace names a `secret … reference "vault://…"` and the installer resolves it. Service contracts use `policy explicit_network` so any exception is declared, reviewed and visible.

## Consequences

Architecture candidates may not introduce a component that requires live network access unless the candidate labels the exception and routes it to human review. Cost and performance envelopes are bounded by the declared `resource cpu … memory …` lines because there is no elastic capacity.
