# ADR-001 — Migrate all data sources from JSON to `.dmk` files

- Status: accepted
- Date: 2026-07-23
- Owner: repository maintainer (role)
- Supersedes: ADR-000

## Context

The re-run of the cross-reference diagnostic found 62 unresolved `from json("…")` references. The corpus already had a deterministic `.dmk` emitter format with a `module` declaration and an `emit` statement per file.

## Decision

Every `.jad` script references its data source with `from dmk("…")`; each of the 62 sources becomes a real `.dmk` file with a unique `….source` namespace and the `coupling EightS_v1_0` block.

## Consequences

All 62 references resolve on disk (0 unresolved). The `.dmk` files are scaffolds whose row counts are bound at load, so populating them with real records is a separate step. Query outputs still use `emit json <catalog>` (see ADR-004).
