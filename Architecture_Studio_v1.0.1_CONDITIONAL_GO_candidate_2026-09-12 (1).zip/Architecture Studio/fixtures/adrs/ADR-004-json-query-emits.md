# ADR-004 — Migrate residual `emit json <catalog>` query outputs to `emit dmk`

- Status: proposed
- Date: 2026-07-23
- Owner: repository maintainer (role)

## Context

After ADR-001 the data sources are `.dmk`, but each `.jad` still ends with `emit json <query_catalog>`. The diagnostic recorded this as optional observation C.

## Decision

Not yet decided. The option is to migrate the query emits to `emit dmk` for a fully JSON-free pipeline.

## Consequences

Until decided, candidates that assume a JSON-free pipeline are resting on a proposed, not accepted, decision and must label that assumption.
