# ADR-003 — Five governance actors are assigned in every knowledge base

- Status: accepted
- Date: 2026-07-22
- Owner: architecture owner (role)

## Context

Every suite README assigns SOPHIA (semantic judgment and acceptance), CHARLOTTE (structural and logic validation), LANDON (repository integration and route application), Professor (reviewable explanation without silent modification) and Podium (jobs, evidence queues and completion records).

## Decision

Any new component or candidate architecture keeps the five-actor separation: judgment, validation, application, explanation and evidence are distinct services with distinct capabilities, and privileged effects require `human_approval` as the `.jasec` policies state.

## Consequences

A candidate that merges validation and application into one component violates this decision and must be flagged. Professor may explain but never modify; Podium owns the evidence queue.
