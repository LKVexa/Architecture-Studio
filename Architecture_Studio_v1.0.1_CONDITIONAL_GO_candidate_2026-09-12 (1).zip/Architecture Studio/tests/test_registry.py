"""Backlog governance: registry, IDs, metadata, ownership map, acceptance criteria, RACI
(AUDIT-ADD-01..04, AUDIT-ADD-24, AUDIT-ADD-22)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main  # noqa: E402

from architecture_studio.acceptance import acceptance_map  # noqa: E402
from architecture_studio.registry import (CONTROL_OWNERSHIP, CRITICAL_DECISIONS, ESCALATION_PATH, RACI,  # noqa: E402
                                          STATUS_VOCABULARY, acceptance_table, build_registry, control_for,
                                          parse_checkboxes, raci_document, registry_document, verify_sources)
from architecture_studio.steering import ACCESSIBILITY_CRITERIA, check_accessibility  # noqa: E402


def test_pinned_sources_match_the_lock():
    result = verify_sources()
    check(all(s["actual"] == s["expected"] for s in result["sources"]),
          f"pinned source digests do not match SOURCE_LOCK: {[s['role'] for s in result['sources'] if s['actual'] != s['expected']]}")
    check(len(result["sources"]) >= 2, "the lock must cover both pinned source documents")


def test_every_checkbox_gets_a_stable_id():
    items = parse_checkboxes()
    check(len(items) == 201, f"expected 201 parsed source items (189 checkboxes + 12 workflow steps), got {len(items)}")
    reqs = build_registry()
    check_eq(len(reqs), 227, "registry size")
    ids = [r.requirement_id for r in reqs]
    check_eq(len(set(ids)), len(ids), "requirement IDs must be unique")
    check(all(r.source_file and (r.source_line or r.source_section or r.audited_todo_line) for r in reqs),
          "every requirement retains its source line/section provenance")
    doc = registry_document(reqs)
    check_eq(doc["anonymous_checkboxes_assigned"], 97, "the source's 97 unnumbered checklist requirements")
    check_eq(doc["workflow_steps_assigned"], 12, "workflow steps assigned IDs")


def test_requirement_metadata_is_complete():
    for r in build_registry():
        for field in ("owner_role", "priority", "status", "phase", "dependencies", "implementation_artifact",
                      "test_or_evidence", "risk", "change_history", "target_phase"):
            check(hasattr(r, field), f"{r.requirement_id} lacks metadata field {field}")
        check(r.status in STATUS_VOCABULARY, f"{r.requirement_id} has status {r.status!r} outside the vocabulary")
        check(bool(r.owner_role), f"{r.requirement_id} has no accountable owner role")


def test_each_alias_resolves_to_exactly_one_owning_control():
    seen: dict[str, str] = {}
    for family, control in CONTROL_OWNERSHIP.items():
        for alias in control["aliases"]:
            check(alias not in seen, f"{alias} is claimed by both {seen.get(alias)} and {family}")
            seen[alias] = family
        check(control["tests"].startswith("tests/"), f"{family} names no test file")
        check(bool(control["owner"]), f"{family} names no owning implementation")
    for alias in ("XAUTH-01", "SEC-07", "MODEL-01", "XPROV-01", "AUDIT-ADD-26"):
        check(control_for(alias) is not None, f"{alias} resolves to no owning control")


def test_acceptance_criteria_are_testable():
    reqs = build_registry()
    table = acceptance_table(reqs, acceptance_map(reqs))
    check(len(table) == 227, f"acceptance table must cover every requirement, got {len(table)}")
    kinds = {row["kind"] for row in table}
    check(kinds <= {"test", "inspection", "human_evidence", "external_measurement"}, f"unexpected criterion kinds: {kinds}")
    narrative = [row for row in table if not row.get("done_when") or not row.get("evidence_artifact") or row["narrative_only"]]
    check(not narrative, f"{len(narrative)} requirement(s) could be marked done by narrative alone")


def test_raci_and_escalation_name_roles_not_people():
    doc = raci_document()
    check(doc["raci"], "no RACI activities declared")
    check(doc["roles_are_names"] is False, "the RACI must declare that it names roles, not people")
    for name, entry in RACI.items():
        check(isinstance(entry["accountable"], str) and entry["accountable"],
              f"activity {name} must name exactly one accountable role")
    check(len(ESCALATION_PATH) >= 3, "escalation path must have at least three steps")
    check(len(CRITICAL_DECISIONS) >= 3, "critical decisions must be enumerated")
    roles = {entry["accountable"] for entry in RACI.values()} | {r for e in RACI.values() for r in e.get("consulted", [])}
    people = [r for r in roles if "@" in r]
    check(not people, f"RACI binds people rather than roles: {people}")


def test_accessibility_criteria_are_declared_and_checked():
    check(len(ACCESSIBILITY_CRITERIA) >= 6, "AUDIT-ADD-22 needs enumerated accessibility criteria")
    human = [c for c in ACCESSIBILITY_CRITERIA if c.get("check") == "human"]
    check(human, "at least one accessibility criterion must be honestly marked human-verified")
    page = ("<main><h1>Review</h1><h2>Evidence</h2><p>Statement</p>"
            "<button type=\"button\">Approve</button></main>")
    report = check_accessibility(page)
    check(report["criteria"] and report["results"], "accessibility check returned no criteria")
    check(report["results"]["A11Y-06"]["pass"] is None, "a human-verified criterion must never self-report a mechanical verdict")
    check_eq(report["human_checks_pending"], ["A11Y-06"], "human-verified criteria must be reported as pending")
    check(report["results"]["A11Y-01"]["pass"] is True, "native controls should satisfy the keyboard criterion")


if __name__ == "__main__":
    import test_registry
    raise SystemExit(main(test_registry))
