"""Model orchestration, candidate generation, distinctness, trade-offs and diagrams
(MODEL-01..07, ARCH-06, WF-06, WF-07, PAPER-CAP-03, COMP-04, XTOOL-07, VERIFY-02, VERIFY-04)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.assumptions import AssumptionRegistry  # noqa: E402
from architecture_studio.diagrams import diagram_from_candidate, render_mermaid, round_trip  # noqa: E402
from architecture_studio.distinctness import DistinctnessRule, assess_distinctness, similarity  # noqa: E402
from architecture_studio.fixtures import make_index, make_operator, make_scope  # noqa: E402
from architecture_studio.generator import (SYSTEM_PROMPTS, Generator, ProviderError, ProviderSlot,  # noqa: E402
                                           RecordedProvider, prompt_digest)
from architecture_studio.ledger import Ledger  # noqa: E402
from architecture_studio.retrieval import RetrievalIndex  # noqa: E402
from architecture_studio.schemas import validate  # noqa: E402
from architecture_studio.tradeoffs import TAXONOMY, compare, uncited_material_claims  # noqa: E402

_SCOPE = make_scope("RUN-G", classes=("requirement", "api_operation", "service", "security_constraint", "deployment_standard"))
_INDEX, _, _ = make_index(_SCOPE)
_GOALS = ({"text": "consolidate the governance services", "derivation": "human"},)


def _generator(ledger=None, slot=None):
    retrieval = RetrievalIndex()
    retrieval.add_index(_INDEX)
    return Generator(scope=_SCOPE, index=_INDEX, retrieval=retrieval, assumptions=AssumptionRegistry("RUN-G"),
                     slot=slot or ProviderSlot(), ledger=ledger)


def test_no_provider_is_bound_by_default_and_binding_is_a_human_act():
    slot = ProviderSlot()
    check(not slot.bound, "no model provider may be bound by default (MODEL-01)")
    check("MODEL-01" in slot.describe()["blocker"], "the empty slot must name its blocker")
    provider = RecordedProvider({"*": {"schema": "as.model_output/1", "payload": {"strategies": []}}})
    _, human = make_operator()
    check_raises(ProviderError, lambda: slot.bind(provider, principal=None, binding_ref="B"),
                 "binding requires an authenticated human principal")
    unpinned = RecordedProvider({"*": {}}, identity={"provider": "x", "model_id": "", "model_version": ""})
    check_raises(ProviderError, lambda: slot.bind(unpinned, principal=human, binding_ref="B"),
                 "an unpinned model must not be bindable")
    binding = slot.bind(provider, principal=human, binding_ref="AUTH-1")
    check_eq(binding["bound_by"], human.subject, "the binding records who bound it")
    check(slot.bound, "binding succeeds for a human with a pinned provider")


def test_prompts_are_versioned_data_and_do_not_enforce_anything():
    for prompt_id, prompt in SYSTEM_PROMPTS.items():
        check(prompt["version"], f"{prompt_id} has no version")
        check(prompt_digest(prompt_id), f"{prompt_id} has no digest")
        text = prompt["text"].lower()
        check("evidence" in text or "cite" in text or "gap" in text, f"{prompt_id} does not mention evidence")
        check("assum" in text or "abstention" in text or "label" in text, f"{prompt_id} does not state its uncertainty rule")
    generation = SYSTEM_PROMPTS["as.candidate_generation"]["text"].lower()
    for expectation in ("scope", "evidence", "abstention", "provenance"):
        check(expectation in generation, f"the generation prompt does not state the {expectation} rule")
    check("human" in SYSTEM_PROMPTS["as.candidate_generation"]["text"].lower(),
          "the generation prompt must state human ownership")


def test_the_deterministic_generator_produces_distinct_evidence_derived_candidates():
    result = _generator().generate(run_id="RUN-G1", iteration=1, goals=_GOALS, constraints=[], session_ref="S1")
    check_eq(result.mode, "deterministic", "with no provider bound the run must be deterministic")
    check(len(result.candidates) >= 2, f"expected several candidates, got {len(result.candidates)}")
    for candidate in result.candidates:
        validate("as.candidate/1", dict(candidate))
        check(candidate["evidence_refs"], f"{candidate['name']} cites no evidence")
        check_eq(candidate["generator"]["model"], None, "a deterministic candidate must not claim a model")
        for element in candidate["components"]:
            check(element["derivation"] in ("source", "deterministic_analyzer", "model_inference"),
                  f"unlabelled derivation on {element['element_id']}")
    check(result.distinctness["all_distinct"], f"generated candidates must be distinct: {result.distinctness}")
    check(result.context.manifest_digest, "the exact context manifest must be recorded")


def test_provider_failure_becomes_a_typed_fallback_not_a_crash():
    _, human = make_operator()
    slot = ProviderSlot()
    failing = RecordedProvider({"*": {}}, fail=True)
    slot.bind(failing, principal=human, binding_ref="AUTH-1")
    with tempdir() as root:
        ledger = Ledger(root / "ledger.jsonl", "RUN-G2")
        result = _generator(ledger=ledger, slot=slot).generate(run_id="RUN-G2", iteration=1, goals=_GOALS,
                                                               constraints=[], session_ref="S2")
        check(result.fallback_used, "a provider failure must be recorded as a fallback")
        check_eq(result.mode, "deterministic", "the fallback is the deterministic generator, not a generic design")
        check(result.diagnostics, "the fallback must say why")
        events = [e["event"]["event_type"] for e in ledger.events()]
        check("model.fallback" in events, f"the fallback must be recorded in the ledger: {events}")


def test_malformed_model_output_is_rejected_before_anything_downstream():
    _, human = make_operator()
    slot = ProviderSlot()
    slot.bind(RecordedProvider({"*": {"schema": "as.model_output/1", "payload": {"strategies": "not a list"}}}),
              principal=human, binding_ref="AUTH-1")
    result = _generator(slot=slot).generate(run_id="RUN-G3", iteration=1, goals=_GOALS, constraints=[], session_ref="S3")
    check(result.fallback_used or result.mode == "deterministic",
          "structurally invalid model output must not become candidates")


def test_superficially_renamed_options_are_rejected():
    result = _generator().generate(run_id="RUN-G4", iteration=1, goals=_GOALS, constraints=[], session_ref="S4")
    original = result.candidates[0]
    renamed = dict(original)
    renamed["candidate_id"] = original["candidate_id"][:-4] + "beef"
    renamed["name"] = original["name"] + " (renamed)"
    renamed["components"] = [{**c, "name": c["name"] + " Prime"} for c in original["components"]]
    verdict = assess_distinctness([original, renamed], DistinctnessRule())
    check(not verdict["all_distinct"], "renaming must not make an option distinct")
    check(verdict["labels_only_differences_detected"], "the report must say the differences were labels only")
    check(similarity(original, renamed) > 0.85, "a renamed structure must score as similar")
    rule = DistinctnessRule()
    check_eq(rule.status, "PROPOSED", "the distinctness threshold is PROPOSED")


def test_trade_offs_cover_the_taxonomy_and_cite_their_claims():
    result = _generator().generate(run_id="RUN-G5", iteration=1, goals=_GOALS, constraints=[], session_ref="S5")
    comparison = compare(run_id="RUN-G5", candidates=result.candidates, index=_INDEX,
                         constraint_checks=result.constraint_checks, grounding=result.grounding)
    validate("as.comparison/1", dict(comparison))
    dimensions = {cell["dimension"] for cell in comparison["cells"]}
    check(dimensions <= set(TAXONOMY), f"cells outside the taxonomy: {dimensions - set(TAXONOMY)}")
    check(len(dimensions) >= 5, f"the comparison should span the taxonomy, got {len(dimensions)}")
    check_eq(uncited_material_claims(comparison), [], "every material trade-off claim must cite evidence or be marked inferred")
    check_raises(ValueError, lambda: compare(run_id="RUN-G5", candidates=result.candidates, index=_INDEX,
                                             constraint_checks=result.constraint_checks, grounding=result.grounding,
                                             weights={"cost": 1.0}),
                 "weights must not be accepted without a human authority reference")
    check_raises(ValueError, lambda: compare(run_id="RUN-G5", candidates=result.candidates[:1], index=_INDEX,
                                             constraint_checks=result.constraint_checks, grounding=result.grounding),
                 "a comparison needs at least two candidates")


def test_diagrams_round_trip_without_inventing_elements():
    result = _generator().generate(run_id="RUN-G6", iteration=1, goals=_GOALS, constraints=[], session_ref="S6")
    candidate = result.candidates[0]
    diagram = diagram_from_candidate(candidate)
    validate("as.diagram/1", dict(diagram))
    text = render_mermaid(diagram)
    check(text.strip().startswith("flowchart") or text.strip().startswith("graph"), "the diagram must render as mermaid")
    report = round_trip(diagram)
    check(report["elements_preserved"], f"the diagram must round-trip to the same elements: {report}")
    check(report["relations_preserved"], f"the diagram must round-trip to the same relations: {report}")
    element_ids = {e["element_id"] for e in diagram["elements"]}
    candidate_ids = {c["element_id"] for c in candidate["components"]}
    check(element_ids <= candidate_ids, f"the diagram invented elements: {sorted(element_ids - candidate_ids)}")


if __name__ == "__main__":
    import test_generator
    raise SystemExit(main(test_generator))
