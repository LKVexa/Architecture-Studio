"""End-to-end workflow scenarios and corpus integrity
(WF-01..WF-12, TEST-E2E-01..06, TEST-INT-01, TEST-ADV-01..07, XPROV-07, AUDIT-ADD-23)."""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.casefile import REQUIRED_PARTS, inspect_case_file  # noqa: E402
from architecture_studio.corpus import EXPECTED_DIGEST, EXPECTED_FILES, iter_corpus_files  # noqa: E402
from architecture_studio.fixtures import CORPUS_ROOT, OVERLAY_ROOT  # noqa: E402
from architecture_studio.pipeline import SCENARIOS, scenarios  # noqa: E402
from architecture_studio.workflow import SAFE_TERMINALS, WorkflowState  # noqa: E402

_RESULTS: dict = {}
#: SHA-256 over "<relative posix path>\0<file sha256>\n" for all 612 corpus files, sorted by path.
#: Verified byte-identical to the untouched input repository at build time. (The work order records
#: the same baseline under the yard's own manifest formula, which hashes different bytes.)
CORPUS_DIGEST = EXPECTED_DIGEST


def _run(names=None):
    key = tuple(sorted(names or SCENARIOS))
    if key not in _RESULTS:
        _RESULTS[key] = scenarios(only=names)
    return _RESULTS[key]


def _corpus_files():
    return list(iter_corpus_files(CORPUS_ROOT))


def test_the_generic_corpus_is_untouched():
    files = _corpus_files()
    check_eq(len(files), EXPECTED_FILES, f"the corpus baseline is {EXPECTED_FILES} files, found {len(files)}")
    digest = hashlib.sha256()
    for rel, sha in files:
        digest.update(f"{rel}\0{sha}\n".encode("utf-8"))
    check_eq(digest.hexdigest(), CORPUS_DIGEST, "the corpus digest changed: the overlay must never modify the corpus")


def test_the_overlay_writes_nothing_outside_itself():
    check(OVERLAY_ROOT.name == "Architecture Studio", "the overlay lives in one directory")
    evidence = OVERLAY_ROOT / "evidence"
    check(evidence.is_dir(), "the evidence root exists inside the overlay")


def test_the_golden_path_completes_and_exports_an_inspectable_case_file():
    result = _run(["golden_path"])["scenarios"]["golden_path"]
    check(result["passed"], f"the golden path must complete: {result}")
    check_eq(result["state"], WorkflowState.COMPLETED, "the golden path ends COMPLETED")
    check(result["ledger_ok"], "the run ledger must verify")
    check(result["verification_passed"], "verification must pass before review")
    check_eq(result["decision"], "approve", "the run was approved by a human")
    check(result["case_file_ok"], f"the exported case file must inspect clean: {result['case_file_problems']}")
    inspection = inspect_case_file(Path(result["export_dir"]))
    check_eq(inspection["problems"], [], "an independent inspection must find no problems")
    for part in REQUIRED_PARTS:
        check(part in inspection["parts"], f"the case file lacks the required part {part}")
    check(inspection["ledger"]["ok"], "the exported ledger must re-verify from the export alone")
    check(inspection["lineage"]["cited"] > 0, "the case file must carry cited evidence")
    check_eq(inspection["lineage"]["unresolved"], [], "every cited reference must resolve to a pinned source")
    check_eq(inspection["derivation_separation"]["unlabelled"], 0, "every element must carry a derivation label")
    check(result["design_versions"] >= 3, "the design state must be versioned through the run")


def test_every_fault_path_lands_in_an_explicit_safe_terminal():
    report = _run()
    for name, result in report["scenarios"].items():
        check(result.get("passed"), f"scenario {name} failed: {result.get('error') or result}")
    scenarios_map = report["scenarios"]
    check_eq(scenarios_map["rejection"]["state"], WorkflowState.REJECTED, "a rejection ends REJECTED")
    check_eq(scenarios_map["scope_narrowing"]["state"], WorkflowState.SCOPE_NARROWED, "narrowing ends SCOPE_NARROWED")
    check(scenarios_map["scope_narrowing"]["widening_refused"], "narrowing must refuse to widen")
    check(scenarios_map["tool_failure"]["state"] in SAFE_TERMINALS, "a tool failure ends in a safe terminal")
    check_eq(scenarios_map["abstention"]["state"], WorkflowState.ABSTAINED, "an evidence-free run abstains")
    check_eq(scenarios_map["kill_switch_mid_run"]["state"], WorkflowState.DENIED, "the kill switch denies mid-run")
    check_eq(scenarios_map["kill_switch_mid_run"]["candidates"], 0, "nothing is produced after the stop")
    check_eq(scenarios_map["unauthenticated_start"]["state"], WorkflowState.DENIED, "an unauthenticated start is denied")
    check(not scenarios_map["unauthenticated_start"]["source_access_before_denial"],
          "no source may be read before authorization succeeds")
    for result in scenarios_map.values():
        check(result["ledger_ok"], f"evidence must be preserved in every scenario: {result.get('run_id')}")


def test_a_forged_or_foreign_approval_produces_no_side_effect():
    result = _run()["scenarios"]["forged_approval"]
    check(result["refused_forged"], "a forged signature must be refused")
    check(result["refused_service"], "a service principal must be refused")
    check(result["refused_other_principal"], "another human's token must be refused")
    check(result["export_refused"], "no export may happen without a valid approval")
    check_eq(result["state"], WorkflowState.AWAITING_REVIEW, "the run stays in review, with no state change")


def test_export_failure_rolls_back_without_leaving_external_files():
    result = _run()["scenarios"]["rollback_on_export_failure"]
    check_eq(result["state"], WorkflowState.ROLLED_BACK, "an export failure rolls back")
    check_eq(result["external_files_written"], 0, "a rolled-back export must leave no external file")
    check(result["ledger_ok"], "the audit trail survives the rollback")


if __name__ == "__main__":
    import test_e2e
    raise SystemExit(main(test_e2e))
