"""Connectors, pinning, normalization and indexing (DATA-01..09, IMPL-05, WF-02, WF-03, WF-04, XTOOL-02)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.connectors.base import contract_test, pin_source_set, verify_pins  # noqa: E402
from architecture_studio.connectors.normalize import Normalizer  # noqa: E402
from architecture_studio.connectors.typed import REGISTRY, connector_for_class  # noqa: E402
from architecture_studio.fixtures import CORPUS_ROOT, FIXTURES_ROOT, make_index, make_scope  # noqa: E402
from architecture_studio.graph import build_graph  # noqa: E402
from architecture_studio.ledger import Ledger  # noqa: E402

_ALL = tuple(REGISTRY)


def _connectors(scope, classes=_ALL, ledger=None):
    return [connector_for_class(c, corpus_root=CORPUS_ROOT, tenant=scope.tenant, project=scope.project,
                                fixtures_root=FIXTURES_ROOT, ledger=ledger, sleep=lambda s: None) for c in classes]


def test_nine_data_classes_have_read_only_connectors():
    check_eq(len(REGISTRY), 9, "DATA-01..09 needs nine typed connectors")
    scope = make_scope("RUN-C1", classes=_ALL)
    for connector in _connectors(scope):
        caps = connector.capabilities
        check(caps.read and not caps.write, f"{caps.source_system} must be read-only")
        check_eq(caps.revision_semantics, "content-hash", f"{caps.source_system} revision semantics")
        report = contract_test(connector, scope)
        check(report["passed"], f"{caps.source_system} failed its connector contract test: {report}")


def test_the_index_only_contains_authorized_scoped_records():
    scope = make_scope("RUN-C2", classes=("requirement", "service"))
    index, _, _ = make_index(scope)
    check(index.records, "the corpus must yield records")
    classes = {r["data_class"] for r in index.records.values()}
    check(classes <= {"requirement", "service"}, f"records outside the contract entered the index: {classes}")
    systems = {r["source_system"] for r in index.records.values()}
    check(systems <= set(scope.source_set), f"sources outside the source set entered the index: {systems}")
    for record in list(index.records.values())[:50]:
        ref = index.evidence[record["provenance_ref_id"]]
        check(ref.source_hash and ref.revision, f"{record['record_id']} lacks provenance metadata")


def test_pins_are_reproducible_and_detect_drift():
    with tempdir() as root:
        scope = make_scope("RUN-C3", classes=("adr",))
        connectors = _connectors(scope, ("adr",))
        pins = pin_source_set("RUN-C3", connectors, scope)
        again = pin_source_set("RUN-C3", _connectors(scope, ("adr",)), scope)
        check_eq(pins.digest, again.digest, "pinning the same tree twice must give the same digest")
        drift = verify_pins(pins, _connectors(scope, ("adr",)), scope)
        check(drift["reproducible"], f"an unchanged tree must not report drift: {drift}")
        empty = verify_pins(pins, _connectors(scope, ("service",)), scope)
        check(not empty["reproducible"], "a source system outside the pinned set must be reported, not ignored")


def test_malformed_input_is_quarantined_not_indexed():
    with tempdir() as root:
        fixtures = root / "fixtures"
        (fixtures / "adrs").mkdir(parents=True)
        (fixtures / "adrs" / "ADR-999-broken.md").write_text("this is not a MADR document at all\n", encoding="utf-8")
        scope = make_scope("RUN-C4", classes=("adr",))
        connector = connector_for_class("adr", corpus_root=CORPUS_ROOT, tenant=scope.tenant, project=scope.project,
                                        fixtures_root=fixtures, sleep=lambda s: None)
        result = connector.read(scope)
        index = Normalizer().ingest([result])
        broken = [q for q in index.quarantine if "999" in str(q)]
        indexed = [r for r in index.records.values() if "999" in r["record_id"]]
        check(not indexed or broken, "a malformed document must be quarantined rather than silently indexed")


def test_connector_failure_is_typed_and_bounded():
    scope = make_scope("RUN-C5", classes=("adr",))
    ledger_dir = None
    connector = _connectors(scope, ("adr",))[0]
    locators = connector._discover(scope)
    check(locators, "the adr connector must discover something")
    for locator in locators:
        connector.simulate_unavailable(locator)
    result = connector.read(scope)
    check(result.status in ("failed", "unavailable", "partial"), f"an unavailable source must be typed, got {result.status}")
    check(not result.artifacts, "a failed read must not present artifacts")
    check(result.diagnostics, "a failed read must say why")


def test_denials_are_logged_and_nothing_outside_scope_is_read():
    with tempdir() as root:
        ledger = Ledger(root / "ledger.jsonl", "RUN-C6")
        scope = make_scope("RUN-C6", classes=("requirement",))
        connector = connector_for_class("service", corpus_root=CORPUS_ROOT, tenant=scope.tenant, project=scope.project,
                                        fixtures_root=FIXTURES_ROOT, ledger=ledger, sleep=lambda s: None)
        result = connector.read(scope)
        check_eq(result.status, "denied", "a connector outside the contract must be denied")
        check(not result.artifacts, "a denied connector returns no artifacts")
        events = [e["event"]["event_type"] for e in ledger.events()]
        check(any(e.startswith("connector") for e in events), f"the denial must be recorded: {events}")


def test_stale_marking_propagates_to_the_index():
    scope = make_scope("RUN-C7", classes=("requirement",))
    index, _, _ = make_index(scope)
    artifact_ids = sorted({r["artifact_id"] for r in list(index.records.values())[:3]})
    changed = index.mark_stale(artifact_ids)
    check(changed > 0, "marking artifacts stale must change records")
    stale = [r for r in index.records.values() if r["freshness"] == "STALE"]
    check(stale, "stale records must be visible in the index")


def test_the_requirement_graph_is_built_from_indexed_records_only():
    scope = make_scope("RUN-C8", classes=("requirement", "service", "api_operation"))
    index, _, _ = make_index(scope)
    graph = build_graph(index)
    stats = graph.stats()
    check(stats["nodes"] > 100, f"the corpus should produce a substantial graph, got {stats}")
    check(stats["edges"] > 100, "the graph should carry edges")
    for edge in graph.as_document()["edges"][:200] if hasattr(graph, "as_document") else []:
        check(edge["source"] in graph.nodes and edge["target"] in graph.nodes, "every edge must connect known nodes")


if __name__ == "__main__":
    import test_connectors
    raise SystemExit(main(test_connectors))
