"""ASGO 150-item Production GO register: pin, classification, fail-closed GO."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.asgo import (  # noqa: E402
    EXPECTED_ITEM_COUNT, EXPECTED_PACKAGE_SHA256, IMPLEMENTER_PASS, INCOMPLETE_STATUSES,
    AsgoAuthorityError, AsgoError, build_register, claim_done, export_register,
    freeze_intake, gate_count_contract, load_items, overlay_tree_report, package_pin,
    production_go_from_asgo, register_summary, scan_referenced_paths, scan_release_hygiene,
    test_count_contract as asgo_test_count_contract, write_item_evidence,
)
from architecture_studio.corpus import (  # noqa: E402
    EXPECTED_DIGEST, EXPECTED_FILES, PRODUCT_KIND, iter_corpus_files, preflight, product_contract,
)
from architecture_studio.fixtures import CORPUS_ROOT, make_scope  # noqa: E402
from architecture_studio.policy import Verdict, evaluate  # noqa: E402


def test_package_pin_matches_received_baseline():
    pin = package_pin()
    check_eq(pin["sha256"], EXPECTED_PACKAGE_SHA256, "ASGO package pin")
    check(pin["immutable"], "pin must be immutable")
    check_eq(pin["item_count_declared"], 150, "declared item count")
    check_eq(pin["bytes"], 1302221, "package byte size")


def test_register_contains_exactly_150_unique_source_preserving_items():
    items = load_items()
    check_eq(len(items), EXPECTED_ITEM_COUNT, "item count")
    ids = [i["item_id"] for i in items]
    check_eq(len(set(ids)), 150, "unique item ids")
    check_eq(ids[0], "ASGO-0.1", "first id")
    check_eq(ids[-1], "ASGO-10.12", "last id")
    check("Freeze the input candidate archive" in items[0]["source_text"], "0.1 title")
    check("automatically return to `NO_GO`" in items[-1]["source_text"]
          or "automatically return to NO_GO" in items[-1]["source_text"].replace("`", ""),
          "10.12 title keeps NO_GO rollback")
    waves = {}
    for item in items:
        waves[item["wave"]] = waves.get(item["wave"], 0) + 1
    check_eq(waves, {0: 15, 1: 14, 2: 20, 3: 14, 4: 12, 5: 12, 6: 12, 7: 14, 8: 12, 9: 13, 10: 12},
             "wave occupancy")


def test_index_csv_absence_and_self_contained_packaging_stay_blocked():
    document = build_register()
    by_id = {item["item_id"]: item for item in document["items"]}
    check_eq(by_id["ASGO-0.8"]["status"], "BLOCKED", "INDEX.csv must stay BLOCKED")
    check("INDEX.csv" in (by_id["ASGO-0.8"]["block_reason"] or ""), "name the missing artifact")
    check_eq(by_id["ASGO-0.4"]["status"], "BLOCKED", "self-contained packaging is N/A")
    check("NOT_APPLICABLE" in (by_id["ASGO-0.4"]["block_reason"] or ""), "0.4 is N/A pending overlay decision")
    check_eq(by_id["ASGO-1.1"]["status"], "BLOCKED", "recover INDEX.csv is BLOCKED")
    for iid in ("ASGO-1.3", "ASGO-1.4", "ASGO-1.5", "ASGO-1.6", "ASGO-1.7", "ASGO-1.9"):
        check_eq(by_id[iid]["status"], "BLOCKED", f"{iid} source recovery stays BLOCKED")
    for iid in ("ASGO-3.11", "ASGO-3.12", "ASGO-3.13", "ASGO-3.14"):
        check_eq(by_id[iid]["status"], "BLOCKED", f"{iid} human/security decision stays BLOCKED")
    check_eq(document["product_contract"]["product_kind"], "overlay_only", "product kind")
    check_eq(document["product_contract"]["status"], "PROPOSED", "unsigned overlay decision")
    check(document["product_contract"]["unblocks_go"] is False, "unsigned contract is not GO")


def test_in_repo_wave0_is_implemented_not_done():
    document = build_register()
    by_id = {item["item_id"]: item for item in document["items"]}
    for iid in ("ASGO-0.1", "ASGO-0.2", "ASGO-0.3", "ASGO-0.5", "ASGO-0.6", "ASGO-0.7",
                "ASGO-0.9", "ASGO-0.10", "ASGO-0.12", "ASGO-0.14", "ASGO-0.15"):
        check_eq(by_id[iid]["status"], "IMPLEMENTED", f"{iid} should be implemented this pass")
        check(by_id[iid]["completion"]["complete"] is False, f"{iid} still needs review")
        check(by_id[iid]["review"] is None, f"{iid} has no independent review")
    check_eq(by_id["ASGO-4.3"]["status"], "IMPLEMENTED", "Russell refusal is encoded")
    check_eq(by_id["ASGO-7.11"]["status"], "IMPLEMENTED", "self-review exclusion encoded")
    check_eq(by_id["ASGO-10.12"]["status"], "IMPLEMENTED", "post-fail NO_GO encoded")
    for item in document["items"]:
        check(item["status"] != "VERIFIED", f"{item['item_id']} was self-verified")
        check(item["status"] != "DONE", f"{item['item_id']} was marked DONE")
        check(item["assignment"]["independent_reviewer_person"] == "UNSET", "do not invent reviewers")
        check(item["completion"]["complete"] is False, "nothing is complete this pass")


def test_runtime_cannot_self_done_or_claim_go():
    check_raises(AsgoAuthorityError, lambda: claim_done("ASGO-0.1", actor=IMPLEMENTER_PASS),
                 "implementer marked an item DONE")
    go = production_go_from_asgo()
    check_eq(go["verdict"], "NO_GO", "ASGO GO")
    check_eq(go["done"], 0, "nothing DONE")
    check(go["blocking_count"] >= 150, "every incomplete item blocks GO")
    summary = register_summary()
    check_eq(summary["production_go"], "NO_GO", "summary GO")
    check_eq(summary["verified"], 0, "verified count")
    check_eq(summary["done"], 0, "done count")
    check_eq(summary["complete"], 0, "complete count")
    check_eq(summary["product_kind"], PRODUCT_KIND, "overlay-only")


def test_preflight_passes_with_sibling_corpus_and_fails_closed_when_absent():
    ok = preflight(CORPUS_ROOT)
    check(ok["ok"], f"sibling corpus must preflight: {ok}")
    check_eq(ok["code"], "ok", "preflight code")
    check_eq(ok["files"], EXPECTED_FILES, "612 files")
    check_eq(ok["digest"], EXPECTED_DIGEST, "corpus digest")
    with tempdir() as root:
        missing = preflight(root / "no-such")
        check(not missing["ok"], "absent corpus must fail")
        check_eq(missing["code"], "corpus_absent", "absent code")
        empty = root / "empty"
        empty.mkdir()
        empty_flight = preflight(empty)
        check(not empty_flight["ok"], "empty dir is corpus_absent")
        check_eq(empty_flight["code"], "corpus_absent", "empty code")
        wrong = root / "wrong"
        wrong.mkdir()
        (wrong / "README.md").write_text("not the corpus\n", encoding="utf-8")
        mismatch = preflight(wrong)
        check(not mismatch["ok"], "one-file tree is not the corpus")
        check(mismatch["code"] in {"wrong_root_or_layout", "digest_mismatch"}, mismatch["code"])


def test_archive_wrappers_are_not_corpus_members():
    with tempdir() as root:
        (root / "Action Cards").mkdir()
        (root / "Action Cards" / "README.md").write_text("suite\n", encoding="utf-8")
        (root / "Architecture Studio").mkdir()
        (root / "Architecture Studio" / "overlay.txt").write_text("overlay\n", encoding="utf-8")
        (root / "_archive").mkdir()
        (root / "_archive" / "SHA256SUMS.txt").write_text("deadbeef  x\n", encoding="utf-8")
        (root / "SHA256SUMS.txt").write_text("outer wrapper\n", encoding="utf-8")
        (root / "CANDIDATE_README.md").write_text("wrapper\n", encoding="utf-8")
        nested = root / "Anthology"
        nested.mkdir()
        (nested / "SHA256SUMS.txt").write_text("nested corpus member\n", encoding="utf-8")
        members = list(iter_corpus_files(root))
        paths = [p for p, _ in members]
        check("Action Cards/README.md" in paths, "suite file counted")
        check("Anthology/SHA256SUMS.txt" in paths, "nested SHA256SUMS remains corpus")
        check("SHA256SUMS.txt" not in paths, "top-level SHA256SUMS is a wrapper")
        check("CANDIDATE_README.md" not in paths, "candidate readme is a wrapper")
        check(not any(p.startswith("Architecture Studio/") for p in paths), "overlay skipped")
        check(not any(p.startswith("_archive/") for p in paths), "_archive skipped")


def test_export_and_evidence_never_claim_go_or_write_gate_reviews():
    document = build_register()
    with tempdir() as root:
        result = export_register(root, register=document)
        check_eq(result["production_go"], "NO_GO", "export must not claim GO")
        check((root / "ASGO_REGISTER.json").is_file(), "register json")
        check((root / "ASGO_SUMMARY.json").is_file(), "summary json")
        check((root / "PACKAGE_PIN.json").is_file(), "pin")
        summary = json.loads((root / "ASGO_SUMMARY.json").read_text(encoding="utf-8"))
        check_eq(summary["summary"]["production_go"], "NO_GO", "summary file GO")
        check_eq(summary["production_go_from_asgo"]["verdict"], "NO_GO", "go payload")
        notes = write_item_evidence(root / "notes", register=document)
        check_eq(notes["production_go"], "NO_GO", "evidence export GO")
        check(notes["reviewer"] is None, "implementer notes have no reviewer")
        check((root / "notes" / "ASGO-0.8.json").is_file(), "blocked item still gets a note")
        check(not (root / "notes" / "GATE-PROD-01.json").is_file(), "must not write gate reviews")
        note = json.loads((root / "notes" / "ASGO-0.1.json").read_text(encoding="utf-8"))
        check_eq(note["record_kind"], "asgo_implementer_note", "kind")
        check(note["review"] is None and note["complete"] is False, "incomplete")


def test_mutated_package_is_refused():
    with tempdir() as root:
        fake = root / "Architecture_Studio_Production_GO_Prompts_and_Workflows_2026-09-12.md"
        fake.write_text("not the baseline\n", encoding="utf-8")
        check_raises(AsgoError, lambda: package_pin(fake), "mutated package accepted")


def test_policy_denies_self_attested_asgo_go_and_invented_index():
    scope = make_scope("RUN-asgo")
    denied = evaluate({"kind": "approve", "permission": "approve", "actor_kind": "human",
                       "claimed_production_go": True, "asgo_all_verified": False}, scope)
    check_eq(denied.verdict, Verdict.DENY, "claimed GO must be denied")
    invented = evaluate({"kind": "draft", "permission": "draft", "actor_kind": "human",
                         "invented_index_csv": True}, scope)
    check_eq(invented.verdict, Verdict.DENY, "invented INDEX.csv must be denied")
    ninth = evaluate({"kind": "draft", "permission": "draft", "actor_kind": "human",
                      "inferred_ninth_gate": True}, scope)
    check_eq(ninth.verdict, Verdict.DENY, "inferred ninth gate must be denied")
    selfv = evaluate({"kind": "analyze", "permission": "analyze", "actor_kind": "service",
                      "self_verified_asgo": True}, scope)
    check_eq(selfv.verdict, Verdict.DENY, "self-verified ASGO must be denied")
    incomplete = evaluate({"kind": "deploy", "permission": "deploy", "actor_kind": "human",
                           "asgo_status": "IMPLEMENTED"}, scope)
    check_eq(incomplete.verdict, Verdict.DENY, "IMPLEMENTED cannot authorize deploy")


def test_count_and_gate_contracts_are_honest():
    counts = asgo_test_count_contract()
    check("150/150" in counts["historical_claims"], "record the 150/150 claim")
    check("120/150" in counts["historical_claims"], "record the archive-without-corpus drop")
    check(counts["skipping_corpus_tests_forbidden"], "do not skip corpus tests")
    gates = gate_count_contract()
    check_eq(gates["executable_gates"], 8, "still eight executable gates")
    check_eq(gates["resolution"], "UNRESOLVED", "do not invent GATE-PROD-09")
    check(gates["ninth_gate_invented"] is False, "ninth gate not invented")
    intake = freeze_intake()
    check(intake["reviewer"] is None, "intake is not a review")
    check(intake["complete"] is False, "intake incomplete")
    check("/workspace/" not in intake["asgo_package"]["path"], "intake pin path must be portable")
    check(intake["asfw_package"]["verified_here"], "ASGO-0.7 asfw digest must match")
    check_eq(product_contract()["product_kind"], "overlay_only", "contract")
    check("overlay_root" not in product_contract(), "product contract must not embed a sandbox abs root")
    check_eq(len(INCOMPLETE_STATUSES), 4, "incomplete vocabulary")
    pin = package_pin()
    check(not pin["path"].startswith("/"), f"package pin path should be overlay-relative, got {pin['path']}")


def test_hygiene_scan_flags_pycache_and_accepts_a_clean_tree():
    with tempdir() as root:
        cache = root / "architecture_studio" / "__pycache__"
        cache.mkdir(parents=True)
        (cache / "x.cpython-310.pyc").write_bytes(b"\0")
        dirty = scan_release_hygiene(root)
        check(not dirty["ok"], "pycache must fail hygiene")
        check(any("__pycache__" in p for p in dirty["pycache"]), "pycache path recorded")
        (root / "asgo").mkdir()
        (root / "asgo" / "PACKAGE_PIN.json").write_text('{"path":"/workspace/secret"}\n', encoding="utf-8")
        dirty2 = scan_release_hygiene(root)
        check("asgo/PACKAGE_PIN.json" in dirty2["environment_specific_absolute_paths_in_current_artifacts"],
              "sandbox abs path in current pin must be named")
    live = scan_release_hygiene()
    check("pycache" in live and "ok" in live, "hygiene report shape")
    # Worktree bytecode appears as soon as tests import the package; the release zip strips it.
    tree = overlay_tree_report()
    check(tree["root_portable"], "overlay tree root is portable")
    check(tree["digest"].startswith("sha256:"), "tree digest prefix")
    check(tree["root"] == "Architecture Studio" or not tree["root"].startswith("/"),
          f"tree root must not be an abs sandbox path: {tree['root']}")


def test_declared_evidence_paths_are_written_and_are_not_reviews():
    document = build_register()
    with tempdir() as root:
        (root / "evidence" / "asgo").mkdir(parents=True)
        result = write_item_evidence(root / "notes", register=document, also_declared_under=root)
        check_eq(result["production_go"], "NO_GO", "declared evidence is not GO")
        check(result["reviewer"] is None, "no reviewer")
        package_note = root / "evidence" / "reports" / "package" / "ASGO-0.1.json"
        check(package_note.is_file(), "ASGO-0.1 must land at the declared package path")
        payload = json.loads(package_note.read_text(encoding="utf-8"))
        check_eq(payload["record_kind"], "asgo_implementer_note", "kind")
        check(payload["review"] is None and payload["complete"] is False, "incomplete")
        check(payload["decision"] is None, "no self-decision")
        check(not (root / "evidence" / "reviews" / "GATE-PROD-01.json").is_file(),
              "must not write GATE-PROD review files")
        blocked = root / "evidence" / "reports" / "package" / "ASGO-0.8.json"
        check(blocked.is_file(), "blocked INDEX.csv item still gets a declared note")
        release_note = root / "evidence" / "release" / "ASGO-10.12.json"
        check(release_note.is_file(), "W10 declared path is written")
        check_eq(json.loads(release_note.read_text(encoding="utf-8"))["status"], "IMPLEMENTED",
                 "10.12 fail-closed encoding")
    required = scan_referenced_paths(register=document)
    check(not required["invented_index_csv"], "INDEX.csv must not appear as invented")
    check(required["hard_dependency_on_workspace_attachments"] is False, "no /workspace/attachments hard dep")
    check("INDEX.csv" in {row["path"] for row in required["known_absent"]}, "INDEX.csv recorded absent")


if __name__ == "__main__":
    import test_asgo
    raise SystemExit(main(test_asgo))
