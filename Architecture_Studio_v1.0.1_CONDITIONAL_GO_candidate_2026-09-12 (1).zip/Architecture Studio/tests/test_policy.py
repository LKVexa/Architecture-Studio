"""Guardrail enforcement: paper guardrails as executable controls and stop conditions
(IMPL-06, ARCH-07, PAPER-GRD-01..04, MODEL-05, MODEL-06, AUDIT-ADD-26, XAUTH-03)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.authority import IdentityProvider  # noqa: E402
from architecture_studio.fixtures import make_scope  # noqa: E402
from architecture_studio.incident import FlagStore  # noqa: E402
from architecture_studio.ledger import Ledger  # noqa: E402
from architecture_studio.policy import (ACTION_KINDS, CONTROLS, POLICY_VERSION, PolicyViolation, STOP_CONDITIONS,  # noqa: E402
                                        Verdict, controls_document, enforce, evaluate)


def _human():
    idp = IdentityProvider()
    idp.enroll("operator@example.test", "human", "operator-secret")
    return idp.authenticate("operator@example.test", "operator-secret")


def test_every_paper_guardrail_has_an_enforceable_control_with_tests():
    doc = controls_document()
    check_eq(doc["policy_version"], POLICY_VERSION, "policy version")
    requirement_ids = {c["requirement_id"] for c in doc["controls"]}
    for required in ("PAPER-GRD-01", "PAPER-GRD-02", "PAPER-GRD-03", "PAPER-GRD-04", "MODEL-05", "MODEL-06",
                     "XAUTH-03", "AUDIT-ADD-26", "WF-08"):
        check(required in requirement_ids, f"{required} has no enforceable control")
    check(doc["guardrails_implemented"], "the controls document must state guardrail coverage")
    check(len(STOP_CONDITIONS) >= 5, "stop conditions must be enumerated")
    for stop in STOP_CONDITIONS:
        check(stop["stop_id"] and stop["condition"] and stop["requirement_id"], "each stop condition names its requirement")
    unmapped = [c["control_id"] for c in doc["controls"] if not c.get("tests")]
    check(not unmapped, f"GATE-PROD-01: every control must name its tests, unmapped={unmapped}")


def test_unknown_action_kinds_are_denied():
    scope = make_scope("RUN-P1")
    decision = evaluate({"kind": "teleport"}, scope)
    check_eq(decision.verdict, Verdict.DENY, "an unknown action kind must be denied")
    check(all(k in ACTION_KINDS for k in ("draft", "model_call", "tool_call", "approve", "export")),
          "the declared action kinds are incomplete")


def test_the_model_may_not_approve_or_hold_permissions():
    scope = make_scope("RUN-P2")
    decision = evaluate({"kind": "approve", "permission": "approve", "actor_kind": "service", "material_output": True}, scope)
    check_eq(decision.verdict, Verdict.DENY, "a service principal must not pass the approval control")
    check_raises(PolicyViolation, lambda: enforce(
        {"kind": "approve", "permission": "approve", "actor_kind": "service", "material_output": True}, scope),
        "enforce must raise on DENY")
    reasons = " ".join(r["reason"] for r in decision.reasons)
    check("human" in reasons.lower(), f"the denial must name human ownership, got: {reasons}")


def test_ungrounded_material_output_is_not_allowed_silently():
    scope = make_scope("RUN-P3")
    grounded = evaluate({"kind": "draft", "permission": "draft", "actor_kind": "service", "material_output": True,
                         "evidence_refs": ["EV-1", "EV-2"], "grounding_coverage": 1.0, "grounding_minimum": 0.75,
                         "generic_fallback_elements": [], "unlabelled_assertions": 0, "session_ref": "S1"}, scope)
    check(grounded.verdict != Verdict.DENY, f"a grounded draft should not be denied: {grounded.reasons}")
    ungrounded = evaluate({"kind": "draft", "permission": "draft", "actor_kind": "service", "material_output": True,
                           "evidence_refs": [], "grounding_coverage": 0.0, "grounding_minimum": 0.75,
                           "generic_fallback_elements": [{"element_id": "g1"}], "unlabelled_assertions": 3,
                           "session_ref": "S1"}, scope)
    check(ungrounded.verdict in (Verdict.DENY, Verdict.REVIEW), "an ungrounded generic draft must not be allowed outright")


def test_permissions_are_checked_against_the_contract_not_the_request():
    scope = make_scope("RUN-P4")
    decision = evaluate({"kind": "tool_call", "permission": "modify", "actor_kind": "human", "tool": "write_file"}, scope)
    check_eq(decision.verdict, Verdict.DENY, "a permission the contract does not grant must be denied for anyone")


def test_the_rollout_switch_is_a_stop_condition():
    scope = make_scope("RUN-P5")
    human = _human()
    with tempdir() as root:
        ledger = Ledger(root / "ledger.jsonl", "RUN-P5")
        flags = FlagStore(root / "flags.json", ledger=ledger)
        action = {"kind": "draft", "permission": "draft", "actor_kind": "service", "material_output": False, "rollout": flags}
        check(evaluate(action, scope).allowed, "an enabled switch permits the action")
        flags.emergency_disable(actor=human, reason="test")
        denied = evaluate(action, scope)
        check_eq(denied.verdict, Verdict.DENY, "a disabled switch must deny")
        model_action = {**action, "kind": "model_call", "permission": "analyze"}
        check_eq(evaluate(model_action, scope).verdict, Verdict.DENY, "model reasoning is off by default and denied when disabled")
        # A missing/unreadable flag store denies rather than defaulting to on.
        (root / "flags.json").write_text("{ not json", encoding="utf-8")
        broken = FlagStore(root / "flags.json", ledger=ledger)
        check(not broken.ok, "an unreadable flag store must not report ok")
        check_eq(evaluate({**action, "rollout": broken}, scope).verdict, Verdict.DENY, "an unusable switch denies everything")


def test_decisions_are_recorded_with_their_reasons():
    scope = make_scope("RUN-P6")
    with tempdir() as root:
        ledger = Ledger(root / "ledger.jsonl", "RUN-P6")
        try:
            enforce({"kind": "approve", "permission": "approve", "actor_kind": "service", "material_output": True},
                    scope, ledger=ledger, actor="architecture_studio", actor_kind="service")
        except PolicyViolation:
            pass
        events = [e["event"] for e in ledger.events()]
        decisions = [e for e in events if e["event_type"] == "policy.decision"]
        check(decisions, "a denied decision must still be recorded")
        check_eq(decisions[-1]["outcome"], "denied", "the recorded outcome must say denied")
        ok, reason = ledger.verify()
        check(ok, f"the ledger must stay verifiable after denials: {reason}")


if __name__ == "__main__":
    import test_policy
    raise SystemExit(main(test_policy))
