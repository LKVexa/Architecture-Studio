"""Generated documentation, freshness, production gates and the program verdict
(DOC-01..12, GATE-PROD-01..08, AUDIT-ADD-18)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.docs import DOCUMENTS, KNOWN_LIMITATIONS, freshness_report, render_all  # noqa: E402
from architecture_studio.gates import GATES, evaluate_gates, production_verdict  # noqa: E402

_DOCS = OVERLAY = Path(__file__).resolve().parent.parent / "docs"


def test_twelve_documents_are_generated_from_authoritative_configuration():
    check_eq(len(DOCUMENTS), 12, "DOC-01..12 needs twelve documents")
    with tempdir() as root:
        result = render_all(root)
        check_eq(len(result["documents"]), 12, "every document must be rendered")
        for doc in DOCUMENTS:
            path = root / doc["file"]
            check(path.exists(), f"{doc['doc_id']} was not written")
            text = path.read_text(encoding="utf-8")
            check(doc["title"] in text, f"{doc['doc_id']} does not carry its title")
            check(f"owner role: `{doc['owner_role']}`" in text, f"{doc['doc_id']} names no owner role")
            for covered in doc["covers"]:
                check(covered in text, f"{doc['doc_id']} does not reference {covered}")
            check("sources_digest=" in text.splitlines()[0], f"{doc['doc_id']} carries no freshness digest")
        check((root / "INDEX.md").exists(), "an index must be written")


def test_freshness_is_detected_not_asserted():
    with tempdir() as root:
        render_all(root)
        fresh = freshness_report(root)
        check(fresh["all_current"], f"freshly rendered docs must be current: {[d['doc_id'] for d in fresh['documents'] if not d['current']]}")
        target = root / DOCUMENTS[0]["file"]
        lines = target.read_text(encoding="utf-8").splitlines()
        lines[0] = lines[0].replace("sources_digest=", "sources_digest=stale-")
        target.write_text("\n".join(lines), encoding="utf-8")
        stale = freshness_report(root)
        check(not stale["all_current"], "a stale document must be detected")
        check(not next(d for d in stale["documents"] if d["doc_id"] == DOCUMENTS[0]["doc_id"])["current"],
              "the stale document must be named")
    with tempdir() as empty:
        missing = freshness_report(empty)
        check(not missing["all_current"], "missing documents must not report as current")
        check(all(not d["exists"] for d in missing["documents"]), "absence must be reported")


def test_the_checked_in_documents_match_the_runtime():
    if not _DOCS.is_dir():
        return
    report = freshness_report(_DOCS)
    stale = [d["doc_id"] for d in report["documents"] if not d["current"]]
    check(not stale, f"checked-in documentation has drifted from the runtime: {stale}")


def test_known_limitations_state_the_blockers_rather_than_hiding_them():
    ids = {limit["id"] for limit in KNOWN_LIMITATIONS}
    check(len(ids) == len(KNOWN_LIMITATIONS), "limitation ids must be unique")
    text = " ".join(limit["statement"] for limit in KNOWN_LIMITATIONS).lower()
    for blocker in ("model provider", "proposed", "provisioned", "identity", "verified", "review"):
        check(blocker in text, f"the known limitations do not mention {blocker}")
    check(any("no task record is verified" in limit["statement"].lower() for limit in KNOWN_LIMITATIONS),
          "the limitations must state that nothing is verified by this pass")


def test_every_gate_needs_evidence_and_an_independent_human_review():
    check_eq(len(GATES), 8, "GATE-PROD-01..08 needs eight gates")
    for gate in GATES:
        check(gate.evidence_owner_role and gate.review_role, f"{gate.gate_id} names no owner/reviewer role")
        check(gate.required_artifacts, f"{gate.gate_id} names no required artifacts")
        check(gate.review_role != gate.evidence_owner_role or "independent" in gate.review_role,
              f"{gate.gate_id} does not require an independent reviewer")

    empty = evaluate_gates({})
    check_eq(empty["counts"]["NO_EVIDENCE"], 8, "with no evidence every gate must report NO_EVIDENCE")
    check(not empty["all_pass"], "no gate passes without evidence")
    check_eq(production_verdict(empty)["verdict"], "NO_GO", "the production verdict must be NO_GO")

    evidence = {
        "tests": {"all_passed": True, "passed": 90, "total": 90},
        "controls": {"controls": [{"control_id": "CTRL-A", "tests": "tests/test_policy.py"}]},
        "benchmark": {"thresholds_status": "APPROVED", "suite_passed": True, "all_guardrail_cases_pass": True, "failed_cases": []},
        "verification": {"checks": [{"check_id": "VERIFY-01", "result": "PASS", "summary": "all elements traced"}]},
        "write_authority_scan": {"hidden_write_paths": [], "write_sites": 1},
        "incident_drill": {"passed": True}, "recovery_exercise": {"passed": True},
        "security_review": {"reviewer_kind": "human", "independent": True, "review_ref": "SEC-REVIEW-1"},
        "docs": {"documents": [{"doc_id": "DOC-11", "current": True}, {"doc_id": "DOC-12", "current": True,
                                                                      "published_ref": "docs/DOC-12-known-limitations.md"}]},
    }
    unreviewed = evaluate_gates(evidence)
    check_eq(unreviewed["counts"]["AWAITING_INDEPENDENT_REVIEW"], 8,
             f"passing evidence alone must await review: {unreviewed['counts']}")
    check_eq(production_verdict(unreviewed)["verdict"], "NO_GO", "evidence without review is still NO_GO")

    self_review = {g.gate_id: {"reviewer_kind": "human", "reviewer_subject": "architecture_studio", "decision": "PASS",
                               "evidence_digest": "sha256:x", "review_ref": "R"} for g in GATES}
    check_eq(evaluate_gates(evidence, reviews=self_review)["counts"]["AWAITING_INDEPENDENT_REVIEW"], 8,
             "the runtime must not be able to review its own gates")

    builder_review = {g.gate_id: {"reviewer_kind": "human", "reviewer_subject": "builder@example.test", "decision": "PASS",
                                  "evidence_digest": "sha256:x", "review_ref": "R"} for g in GATES}
    check_eq(evaluate_gates(evidence, reviews=builder_review, builder_subjects=["builder@example.test"])["counts"]["AWAITING_INDEPENDENT_REVIEW"], 8,
             "the builder must not be able to review their own evidence")

    good_review = {g.gate_id: {"reviewer_kind": "human", "reviewer_subject": "reviewer@example.test", "decision": "PASS",
                               "evidence_digest": "sha256:x", "review_ref": "R"} for g in GATES}
    passed = evaluate_gates(evidence, reviews=good_review, builder_subjects=["builder@example.test"])
    check(passed["all_pass"], f"evidence plus independent review passes: {[g['gate_id'] for g in passed['gates'] if g['status'] != 'PASS']}")
    check_eq(production_verdict(passed)["verdict"], "GO", "only then may the verdict be GO")


def test_a_risk_acceptance_never_becomes_a_pass():
    evidence = {"benchmark": {"thresholds_status": "PROPOSED", "suite_passed": True}}
    exceptions = {"GATE-PROD-02": {"gate_id": "GATE-PROD-02", "accepted_by": "owner@example.test", "accepter_kind": "human",
                                   "expires_at": "2026-12-31T00:00:00Z", "compensating_control": "manual review",
                                   "rationale": "pilot only"}}
    report = evaluate_gates(evidence, exceptions=exceptions)
    row = next(g for g in report["gates"] if g["gate_id"] == "GATE-PROD-02")
    check_eq(row["status"], "ACCEPTED_RISK", "a documented risk acceptance is recorded as such")
    check(not report["all_pass"], "an accepted risk is not a pass")
    check("GATE-PROD-02" in production_verdict(report)["blocking_gates"], "an accepted risk still blocks the verdict")

    incomplete = {"GATE-PROD-02": {"gate_id": "GATE-PROD-02", "accepted_by": "owner@example.test"}}
    row2 = next(g for g in evaluate_gates(evidence, exceptions=incomplete)["gates"] if g["gate_id"] == "GATE-PROD-02")
    check_eq(row2["status"], "FAIL", "an incomplete risk acceptance is ignored")


def test_mechanical_evidence_is_assembled_and_does_not_invent_a_review():
    from architecture_studio.gate_evidence import collect_gate_evidence
    from architecture_studio.write_scan import scan_write_authority
    scan = scan_write_authority()
    check_eq(scan["verdict"], "PASS", f"write-authority scan must be clean: {scan['hidden_write_paths']}")
    evidence = collect_gate_evidence(
        tests={"all_passed": True, "passed": 129, "total": 129},
        benchmark={"thresholds_status": "PROPOSED", "suite_passed": True, "all_guardrail_cases_pass": True,
                   "failed_cases": []},
        run_benchmark=False, run_operational=True)
    for key in ("tests", "controls", "docs", "write_authority_scan", "verification", "incident_drill",
                "recovery_exercise", "benchmark"):
        check(key in evidence, f"mechanical evidence is missing {key}")
    check("security_review" not in evidence, "the runtime must not invent a security/privacy review")
    report = evaluate_gates(evidence)
    by_id = {g["gate_id"]: g for g in report["gates"]}
    check_eq(by_id["GATE-PROD-01"]["mechanical"], "EVIDENCE_PASS",
             f"GATE-PROD-01 must map every control to tests: {by_id['GATE-PROD-01']}")
    check_eq(by_id["GATE-PROD-01"]["status"], "AWAITING_INDEPENDENT_REVIEW",
             "GATE-PROD-01 must not PASS without an independent human review")
    check_eq(by_id["GATE-PROD-03"]["mechanical"], "EVIDENCE_PASS",
             f"GATE-PROD-03 must have a write scan: {by_id['GATE-PROD-03']}")
    check_eq(by_id["GATE-PROD-07"]["status"], "NO_EVIDENCE",
             "GATE-PROD-07 must stay NO_EVIDENCE without an independent human review")
    check_eq(by_id["GATE-PROD-02"]["status"], "FAIL",
             "GATE-PROD-02 must FAIL while thresholds remain PROPOSED")
    check(production_verdict(report)["verdict"] == "NO_GO", "assembled evidence without review is still NO_GO")
    check_eq(report["counts"]["PASS"], 0, "no gate may PASS without an independent human review")


def test_on_disk_reviews_are_loaded_and_self_reviews_are_still_refused():
    import json
    from architecture_studio.gate_evidence import IMPLEMENTER_SUBJECTS, load_external_authority
    with tempdir() as root:
        reviews_dir = root / "evidence" / "reviews"
        reviews_dir.mkdir(parents=True)
        empty = load_external_authority(root)
        check_eq(empty["reviews"], {}, "missing review files must not invent reviews")
        check(empty["security_review"] is None, "missing security review must stay absent")
        (reviews_dir / "GATE-PROD-08.json").write_text(json.dumps({
            "gate_id": "GATE-PROD-08", "reviewer_kind": "human",
            "reviewer_subject": "reviewer@example.test", "decision": "PASS",
            "evidence_digest": "sha256:x", "review_ref": "R-08",
        }), encoding="utf-8")
        (reviews_dir / "GATE-PROD-01.json").write_text(json.dumps({
            "gate_id": "GATE-PROD-01", "reviewer_kind": "human",
            "reviewer_subject": IMPLEMENTER_SUBJECTS[-1], "decision": "PASS",
            "evidence_digest": "sha256:x", "review_ref": "R-self",
        }), encoding="utf-8")
        loaded = load_external_authority(root)
        check("GATE-PROD-08" in loaded["reviews"], "an independent review file must be loaded")
        evidence = {
            "tests": {"all_passed": True, "passed": 1, "total": 1},
            "controls": {"controls": [{"control_id": "CTRL-A", "tests": "t"}]},
            "benchmark": {"thresholds_status": "PROPOSED", "suite_passed": True,
                          "all_guardrail_cases_pass": True, "failed_cases": []},
            "verification": {"checks": [{"check_id": "VERIFY-01", "result": "PASS", "summary": "ok"}]},
            "write_authority_scan": {"hidden_write_paths": [], "write_sites": 1},
            "incident_drill": {"passed": True}, "recovery_exercise": {"passed": True},
            "docs": {"documents": [{"doc_id": "DOC-11", "current": True},
                                   {"doc_id": "DOC-12", "current": True, "published_ref": "docs/DOC-12"}]},
        }
        report = evaluate_gates(evidence, reviews=loaded["reviews"],
                                builder_subjects=loaded["builder_subjects"])
        by_id = {g["gate_id"]: g for g in report["gates"]}
        check_eq(by_id["GATE-PROD-08"]["status"], "PASS",
                 "a distinct human review of passing evidence is PASS")
        check_eq(by_id["GATE-PROD-01"]["status"], "AWAITING_INDEPENDENT_REVIEW",
                 "a review file signed by the implementer must still be refused")
        check_eq(production_verdict(report)["verdict"], "NO_GO",
                 "one gate PASS is not production GO")


if __name__ == "__main__":
    import test_docs_gates
    raise SystemExit(main(test_docs_gates))
