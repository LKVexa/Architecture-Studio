"""Canonical schemas, contracts and identity (IMPL-02, API-01..08, ARCH-02)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio import VERSIONS, version_manifest  # noqa: E402
from architecture_studio.canonical import canonical_bytes, canonical_json, digest_of, merkle_root, sha256_of  # noqa: E402
from architecture_studio.evidence_io import EvidenceError, confine, loads_strict, parse_ref  # noqa: E402
from architecture_studio.ids import deterministic_id, is_valid_id  # noqa: E402
from architecture_studio.schemas import (DATA_CLASSES, DERIVATIONS, PERMISSIONS, SchemaError, export_schemas,  # noqa: E402
                                         schema_versions, validate)


def test_canonical_form_is_stable_and_ascii():
    a = {"b": 1, "a": [3, {"z": None, "y": "ü"}]}
    b = {"a": [3, {"y": "ü", "z": None}], "b": 1}
    check_eq(canonical_json(a), canonical_json(b), "key order must not change the canonical form")
    check(canonical_bytes(a).endswith(b"\n"), "canonical bytes end with a newline")
    canonical_bytes(a).decode("ascii")  # must not raise: ensure_ascii
    check_raises(ValueError, lambda: canonical_json({"x": float("nan")}), "NaN must be refused")
    check_eq(digest_of(a), digest_of(b), "digests follow the canonical form")
    check_eq(merkle_root(["a", "b"]), merkle_root(["b", "a"]), "the merkle root sorts its leaves")
    check(merkle_root(["a", "b"]) != merkle_root(["a", "c"]), "different leaves give a different root")


def test_strict_evidence_reader_refuses_ambiguity():
    check_raises(EvidenceError, lambda: loads_strict(b'{"a":1,"a":2}'), "duplicate keys must be refused")
    check_raises(EvidenceError, lambda: loads_strict(b'{"a":NaN}'), "non-finite numbers must be refused")
    check_raises(EvidenceError, lambda: loads_strict(b'\xff\xfe{}'), "invalid UTF-8 must be refused")
    check_eq(loads_strict(b'{"a":1}'), {"a": 1}, "well-formed JSON still loads")


def test_every_registered_schema_round_trips_and_is_versioned():
    exported = export_schemas()
    check(len(exported["schemas"]) >= 20, "the contract registry is smaller than the declared API surface")
    for schema_id, schema in exported["schemas"].items():
        check(schema["version"], f"{schema_id} carries no version")
        check(schema["description"], f"{schema_id} carries no description")
        check(schema["fields"], f"{schema_id} declares no fields")
    check_eq(schema_versions()["as.candidate/1"], "1.0.0", "candidate contract version")


def test_validation_rejects_unknown_fields_and_wrong_types():
    good = {"schema_id": "as.evidence_ref/1", "artifact_id": "ART-1", "source_system": "requirements", "revision": "r1",
            "source_hash": "sha256:" + "a" * 64, "observed_at": "2026-09-07T00:00:00Z", "derivation": "source",
            "evidence_status": "current", "location": None, "span": None, "retrieval_event": None,
            "transformation_chain": [], "analyzer": None}
    validate("as.evidence_ref/1", dict(good))
    check_raises(SchemaError, lambda: validate("as.evidence_ref/1", {**good, "surprise": 1}), "unknown field must be refused")
    check_raises(SchemaError, lambda: validate("as.evidence_ref/1", {**good, "derivation": "vibes"}), "unknown enum must be refused")
    check_raises(SchemaError, lambda: validate("as.evidence_ref/1", {**good, "artifact_id": 7}), "wrong type must be refused")
    check_raises(SchemaError, lambda: validate("as.nonexistent/1", {}), "unknown schema must be refused")


def test_identifiers_are_deterministic_and_typed():
    a = deterministic_id("candidate", run_id="R1", name="x", iteration=1)
    b = deterministic_id("candidate", iteration=1, name="x", run_id="R1")
    check_eq(a, b, "the same fields must produce the same id")
    check(a != deterministic_id("candidate", run_id="R1", name="y", iteration=1), "different fields must differ")
    check(is_valid_id(a), "generated ids must satisfy the id format")
    check(not is_valid_id("not an id"), "arbitrary text is not an id")


def test_vocabularies_and_versions_are_declared():
    check_eq(DERIVATIONS, ("source", "deterministic_analyzer", "model_inference", "human"), "derivation vocabulary")
    check(len(DATA_CLASSES) == 10, f"expected 10 data classes, got {len(DATA_CLASSES)}")
    check("write_evidence" in PERMISSIONS and "approve" in PERMISSIONS, "permission vocabulary is incomplete")
    manifest = version_manifest()
    check_eq(manifest, dict(sorted(VERSIONS.items())), "the version manifest is the sorted version table")
    check(manifest["package_applied"] == "ASRTD/1.4.0", "the applied package version must be recorded")


def test_artifact_references_and_paths_are_confined():
    ref = parse_ref("sha256:" + "a" * 64)
    check_eq(ref.algorithm, "sha256", "only sha256 references are accepted")
    for bad in ("md5:" + "a" * 32, "sha256:" + "A" * 64, "sha256:short", "../escape", 7):
        check_raises(Exception, lambda bad=bad: parse_ref(bad), f"{bad!r} must be refused")
    with tempdir() as root:
        (root / "ok.txt").write_text("x", encoding="utf-8")
        check_eq(confine(root, "ok.txt").name, "ok.txt", "a path inside the root resolves")
        for escape in ("../outside", "/etc/passwd", "a/../../b"):
            check_raises(Exception, lambda e=escape: confine(root, e), f"{escape!r} must not escape the root")
        check_raises(Exception, lambda: confine(root, "CON"), "a Windows reserved device name must be refused")
        check_raises(Exception, lambda: confine(root, "x" * 300), "an over-long relative path must be refused")
        check_raises(Exception, lambda: confine(root, "ok\x00.txt"), "a NUL in a path must be refused")


if __name__ == "__main__":
    import test_schemas_contracts
    raise SystemExit(main(test_schemas_contracts))
