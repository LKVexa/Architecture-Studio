"""ASFW 545-item register: governance, identifier preservation, fail-closed GO."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.asfw import (  # noqa: E402
    EXPECTED_ITEM_COUNT, EXPECTED_PACKAGE_SHA256, EXECUTABLE_GATE_IDS, INCOMPLETE_STATUSES,
    IMPLEMENTER_PASS, MISSING_DOD_IDS, AsfwAuthorityError, AsfwError, apply_review, build_register,
    claim_verified, export_register, load_items, package_pin, preserved_identifiers,
    production_go_from_asfw, register_summary,
)
from architecture_studio.gates import GATES  # noqa: E402
from architecture_studio.fixtures import make_scope  # noqa: E402
from architecture_studio.policy import Verdict, evaluate  # noqa: E402


def test_package_pin_matches_received_baseline_and_source_index_is_absent():
    pin = package_pin()
    check_eq(pin["sha256"], EXPECTED_PACKAGE_SHA256, "package pin")
    check(pin["immutable"], "pin must be immutable")
    check_eq(pin["item_count_declared"], 545, "declared item count")
    check_eq(pin["source_index_csv"]["status"], "ABSENT", "INDEX.csv was not in the attachment set")
    check(pin["source_index_csv"]["path"] is None, "do not invent a source INDEX.csv path")


def test_register_contains_exactly_545_unique_source_preserving_items():
    items = load_items()
    check_eq(len(items), EXPECTED_ITEM_COUNT, "item count")
    ids = [i["item_id"] for i in items]
    check_eq(len(set(ids)), 545, "unique item ids")
    check_eq(ids[0], "ASFW-TODO-0001", "first id")
    check_eq(ids[-1], "ASFW-TODO-0545", "last id")
    check_eq(items[0]["source_text"], (
        "Assign an owner, implementer, independent reviewer, target environment, due date, "
        "and evidence location to every checkbox."
    ), "0001 source text must be exact")
    check("DOD-02" in items[6]["source_text"] and "DOD-09" in items[6]["source_text"],
          "0007 must keep the missing DOD ids in source text")
    check("GATE-PROD-01-09" in items[7]["source_text"] and "eight or nine" in items[7]["source_text"],
          "0008 source text must keep the 8-vs-9 question")
    check(items[6]["source_line"] >= 1 and items[0]["source_line"] >= 1, "source lines recorded")


def test_every_item_has_assignment_unique_impl_id_and_evidence_location():
    document = build_register()
    seen_impl = set()
    for item in document["items"]:
        assignment = item["assignment"]
        for key in ("owner_role", "implementer_role", "independent_reviewer_role",
                    "environment", "due_date", "evidence_location"):
            check(assignment[key], f"{item['item_id']} missing {key}")
        check_eq(assignment["owner_person"], "UNSET", "do not invent named owners")
        check_eq(assignment["independent_reviewer_person"], "UNSET", "do not invent reviewers")
        check_eq(assignment["due_date"], "UNSET", "do not invent due dates")
        check(assignment["owner_role"] != assignment["independent_reviewer_role"],
              f"{item['item_id']} owner and reviewer roles must be distinct")
        check(item["implementation_id"].startswith("ASFW-IMPL-"), "unique impl id prefix")
        check(item["implementation_id"] not in seen_impl, f"duplicate impl id {item['implementation_id']}")
        seen_impl.add(item["implementation_id"])
        check(item["evidence"]["evidence_location"].startswith("evidence/asfw/"), "evidence location")
        check(item["evidence"]["complete"] is False, "evidence links are incomplete without review")
        check(item["review"] is None or item["review"].get("refused"),
              "no independent review is on file")
        check(item["completion"]["complete"] is False, "nothing is complete this pass")
    check_eq(len(seen_impl), 545, "545 unique implementation ids")


def test_source_identifiers_are_preserved_exactly():
    found = set()
    for raw in load_items():
        found.update(raw["source_identifiers"])
    for required in ("BLK-GOV-01", "DEC-01", "P15", "FLOW-01", "DOD-01", "DOD-02", "GATE-PROD-01-09"):
        check(required in found, f"identifier {required} was dropped")
    # reconstruction from source text must not rewrite the token
    sample = preserved_identifiers("Preserve `BLK-GOV-01` and `DEC-10` and `P15` and `FLOW-12` and `DOD-07`.")
    check_eq(sample, ["BLK-GOV-01", "DEC-10", "P15", "FLOW-12", "DOD-07"], "exact token preservation")


def test_incomplete_statuses_cannot_complete_without_human_review():
    document = build_register()
    for item in document["items"]:
        if item["status"] in INCOMPLETE_STATUSES:
            check(item["completion"]["complete"] is False,
                  f"{item['item_id']} {item['status']} must stay incomplete")
        check(item["status"] != "VERIFIED", f"{item['item_id']} was self-verified")
        check(item["status"] != "DONE", "DONE is not an ASFW status this runtime may set")


def test_source_ambiguity_is_blocked_and_not_inferred():
    document = build_register()
    by_id = {item["item_id"]: item for item in document["items"]}
    for item_id in ("ASFW-TODO-0007", "ASFW-TODO-0008", "ASFW-TODO-0311", "ASFW-TODO-0437",
                    "ASFW-TODO-0451", "ASFW-TODO-0456", "ASFW-TODO-0477", "ASFW-TODO-0478",
                    "ASFW-TODO-0481", "ASFW-TODO-0507"):
        item = by_id[item_id]
        check_eq(item["status"], "BLOCKED", f"{item_id} must be BLOCKED")
        check_eq(item["execution_class"], "source_ambiguity", f"{item_id} class")
        check("infer" in (item["block_reason"] or "").lower() or "ambiguity" in (item["block_reason"] or "").lower(),
              f"{item_id} must name the ambiguity")
    check_eq(document["dod_resolution"], "UNRESOLVED", "do not invent missing DOD definitions")
    check_eq(document["gate_count_resolution"], "UNRESOLVED", "do not invent a ninth gate")
    for missing in MISSING_DOD_IDS:
        check(missing in document["missing_dod_ids"], f"{missing} must remain listed as missing")
        check(missing not in document["visible_dod_ids"], f"{missing} must not be treated as visible")
    check_eq(list(EXECUTABLE_GATE_IDS), [g.gate_id for g in GATES],
             "executable registry is eight gates; do not add a ninth")
    check_eq(len(GATES), 8, "still eight executable gates")
    check_eq(document["pdf_gate_range_claim"], "GATE-PROD-01-09", "keep the PDF claim as a claim")


def test_governance_0001_to_0006_are_implemented_but_not_verified():
    document = build_register()
    for item in document["items"][:6]:
        check_eq(item["status"], "IMPLEMENTED", f"{item['item_id']} should be implemented this pass")
        check(item["completion"]["complete"] is False, f"{item['item_id']} still needs review")
        check_eq(item["execution_class"], "governance_machinery", item["item_id"])


def test_runtime_cannot_self_verify_or_claim_go():
    check_raises(AsfwAuthorityError, lambda: claim_verified("ASFW-TODO-0001", actor=IMPLEMENTER_PASS),
                 "implementer verified an item")
    check_raises(AsfwAuthorityError, lambda: apply_review("ASFW-TODO-0001", {
        "reviewer": IMPLEMENTER_PASS, "reviewer_kind": "human", "decision": "PASS",
    }), "self-review accepted")
    check_raises(AsfwAuthorityError, lambda: apply_review("ASFW-TODO-0001", {
        "reviewer": "architecture_studio", "reviewer_kind": "human", "decision": "PASS",
    }), "runtime review accepted")
    go = production_go_from_asfw()
    check_eq(go["verdict"], "NO_GO", "ASFW GO")
    check(go["verified"] == 0 and go["complete"] == 0, "nothing verified")
    check(go["blocking_count"] >= 545, "every unverified item blocks GO")
    summary = register_summary()
    check_eq(summary["production_go"], "NO_GO", "summary GO")
    check_eq(summary["verified"], 0, "verified count")
    check("INDEX.CSV-ABSENT" in go["blocking_preview"] or go["blocking_count"] > 545,
          "absent INDEX.csv is a GO blocker")


def test_export_writes_derived_index_not_source_index():
    document = build_register()
    with tempdir() as root:
        result = export_register(root, register=document)
        check_eq(result["production_go"], "NO_GO", "export must not claim GO")
        check((root / "ASFW_REGISTER.json").is_file(), "register json")
        check((root / "ASFW_SUMMARY.json").is_file(), "summary json")
        check((root / "PACKAGE_PIN.json").is_file(), "pin")
        check((root / "INDEX.derived.csv").is_file(), "derived csv")
        check(not (root / "INDEX.csv").is_file(), "must not pretend to be the source INDEX.csv")
        csv_text = (root / "INDEX.derived.csv").read_text(encoding="utf-8")
        check(csv_text.startswith("# DERIVED"), "derived banner")
        check("ASFW-TODO-0001" in csv_text and "ASFW-TODO-0545" in csv_text, "csv coverage")
        payload = json.loads((root / "ASFW_SUMMARY.json").read_text(encoding="utf-8"))
        check_eq(payload["summary"]["production_go"], "NO_GO", "summary file GO")
        check_eq(payload["gate_count_resolution"], "UNRESOLVED", "exported gate resolution")


def test_mutated_package_is_refused_as_a_new_unsigned_baseline():
    with tempdir() as root:
        fake = root / "MASTER_PROMPT_WORKFLOW_PACKAGE.md"
        fake.write_text("not the baseline\n", encoding="utf-8")
        check_raises(AsfwError, lambda: package_pin(fake), "mutated package accepted")


def test_policy_denies_self_attested_go_and_inferred_source_gaps():
    scope = make_scope("RUN-asfw")
    denied = evaluate({"kind": "approve", "permission": "approve", "actor_kind": "human",
                       "claimed_production_go": True, "asfw_all_verified": False}, scope)
    check_eq(denied.verdict, Verdict.DENY, "claimed GO must be denied")
    inferred = evaluate({"kind": "draft", "permission": "draft", "actor_kind": "human",
                         "inferred_missing_dod": True}, scope)
    check_eq(inferred.verdict, Verdict.DENY, "inferred DOD must be denied")
    ninth = evaluate({"kind": "draft", "permission": "draft", "actor_kind": "human",
                      "inferred_ninth_gate": True}, scope)
    check_eq(ninth.verdict, Verdict.DENY, "inferred ninth gate must be denied")
    selfv = evaluate({"kind": "analyze", "permission": "analyze", "actor_kind": "service",
                      "self_verified_asfw": True}, scope)
    check_eq(selfv.verdict, Verdict.DENY, "self-verified ASFW must be denied")
    incomplete = evaluate({"kind": "deploy", "permission": "deploy", "actor_kind": "human",
                           "asfw_status": "IMPLEMENTED"}, scope)
    check_eq(incomplete.verdict, Verdict.DENY, "IMPLEMENTED cannot authorize deploy")


if __name__ == "__main__":
    import test_asfw
    raise SystemExit(main(test_asfw))
