"""Human review, approval tokens and the fail-closed truth table
(HUMAN-01..07, SEC-07, SEC-08, WF-09, WF-10, XHITL-01..05, VERIFY-05, XEVAL-04)."""
from __future__ import annotations

import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.approvals import (ApprovalError, ApprovalService, ed25519_available,  # noqa: E402
                                           load_or_create_key)
from architecture_studio.authority import AuthorityError, IdentityProvider, Principal  # noqa: E402
from architecture_studio.fixtures import make_scope  # noqa: E402
from architecture_studio.ledger import Ledger  # noqa: E402
from architecture_studio.review import (ACCOUNTABILITY, ApprovalGate, DecisionRecorder, ReviewError,  # noqa: E402
                                        accountability_violations, build_review_package)

_SCOPE = make_scope("RUN-AP")
_KEY = b"a-test-approval-key-32-bytes-long"
_SUBJECT = "sha256:" + "1" * 64
_ARTIFACTS = ["CND-1", "CND-2"]


def _service(ledger=None):
    return ApprovalService(key=_KEY, issuer="as.test", key_id="test", ledger=ledger)


def _people():
    idp = IdentityProvider()
    idp.enroll("approver@example.test", "human", "approver-secret")
    idp.enroll("other@example.test", "human", "other-secret")
    idp.enroll("svc-runner", "service", "svc-secret")
    return (idp, idp.authenticate("approver@example.test", "approver-secret"),
            idp.authenticate("other@example.test", "other-secret"), idp.authenticate("svc-runner", "svc-secret"))


def _issue(service, approver, **kw):
    args = {"run_id": "RUN-AP", "gate": "final_selection", "artifact_ids": _ARTIFACTS, "action": "approve",
            "scope_digest": _SCOPE.scope_digest, "subject_digest": _SUBJECT}
    args.update(kw)
    return service.issue(approver=approver, **args)


def _verify(service, token, **kw):
    args = {"run_id": "RUN-AP", "gate": "final_selection", "artifact_ids": _ARTIFACTS, "action": "approve",
            "scope_digest": _SCOPE.scope_digest, "subject_digest": _SUBJECT}
    args.update(kw)
    return service.verify(token, **args)


def test_a_genuine_approval_verifies_once():
    service = _service()
    _, approver, _, _ = _people()
    token = _issue(service, approver)
    result = _verify(service, token)
    check(result.valid, f"a genuine approval must verify: {result.code}: {result.reason}")
    check_eq(token["approver"]["subject"], approver.subject, "the token names its approver")
    check(token["expires_at"] > token["issued_at"], "a token must expire")
    check(token["nonce"], "a token must carry a nonce")


def test_the_single_omission_truth_table():
    """Each row changes exactly one element of a genuine approval; every row must be refused."""
    _, approver, other, service_principal = _people()
    rows: list[tuple[str, str]] = []

    def refuse(name: str, expected_code: str, mutate_token=None, **verify_overrides):
        service = _service()
        token = _issue(service, approver)
        if mutate_token:
            token = mutate_token(dict(token))
        result = _verify(service, token, **verify_overrides)
        check(not result.valid, f"row {name!r} must be refused but verified")
        check_eq(result.code, expected_code, f"row {name!r} refusal code")
        rows.append((name, result.code))

    def flip(sig: str) -> str:
        algorithm, _, hexsig = sig.partition(":")
        return f"{algorithm}:{('0' if hexsig[0] != '0' else '1')}{hexsig[1:]}"
    refuse("forged signature", "approval.signature_invalid", lambda t: {**t, "signature": flip(t["signature"])})
    refuse("different issuer", "approval.issuer_mismatch", lambda t: {**t, "issuer": "as.evil"})
    refuse("wrong run", "approval.run_mismatch", run_id="RUN-OTHER")
    refuse("wrong gate", "approval.gate_mismatch", gate="some_other_gate")
    refuse("wrong action", "approval.action_mismatch", action="write")
    refuse("different artifacts", "approval.artifact_mismatch", artifact_ids=["CND-9"])
    refuse("changed scope", "approval.scope_changed", scope_digest="sha256:" + "9" * 64)
    refuse("changed subject", "approval.subject_changed", subject_digest="sha256:" + "2" * 64)
    # Expiry and validity windows are inside the signed payload, so they are tested by moving the clock,
    # not by editing the token (editing it is caught earlier, as the forged-signature row shows).
    service = _service()
    token = _issue(service, approver, seconds=60)
    expired = _verify(service, token, now=datetime.now(timezone.utc) + timedelta(hours=2))
    check(not expired.valid and expired.code == "approval.expired", f"an expired token must be refused, got {expired.code}")
    rows.append(("expired", expired.code))
    early = _verify(_service(), _issue(_service(), approver), now=datetime.now(timezone.utc) - timedelta(hours=2))
    check(not early.valid, "a token used before its validity window must be refused")
    rows.append(("not yet valid", early.code))
    refuse("malformed", "approval.malformed", lambda t: {k: v for k, v in t.items() if k != "nonce"})
    refuse("wrong algorithm", "approval.signature_algorithm_mismatch",
           lambda t: {**t, "algorithm": "ed25519", "signature": "ed25519:" + "0" * 128})

    # Replay: the same genuine token twice.
    service = _service()
    token = _issue(service, approver)
    check(_verify(service, token).valid, "the first use of a token is valid")
    replay = _verify(service, token)
    check(not replay.valid and replay.code == "approval.replayed", f"a replayed token must be refused, got {replay.code}")
    rows.append(("replayed", replay.code))

    # A service principal cannot be issued a token at all.
    check_raises((ApprovalError, AuthorityError), lambda: _issue(_service(), service_principal),
                 "a service principal must not receive an approval token")
    rows.append(("service approver", "refused at issue"))
    check(len(rows) == 14, f"the truth table must cover every single-omission row, got {len(rows)}")


def test_tokens_are_bound_to_an_interactive_human_channel():
    service = _service()
    _, approver, _, _ = _people()
    check_raises(ApprovalError, lambda: _issue(service, approver, channel="automated"),
                 "a token must not be issued over a non-interactive channel")
    check_raises(ApprovalError, lambda: _issue(service, approver, seconds=60 * 60 * 48),
                 "a token lifetime beyond the cap must be refused")
    check_raises(ApprovalError, lambda: _issue(service, "approver@example.test"),
                 "a token is issued to a Principal, not to a name")


def test_ed25519_is_used_when_available_and_never_silently_downgraded():
    if not ed25519_available():
        return
    import secrets
    service = ApprovalService(key=secrets.token_bytes(32), issuer="as.test", key_id="ed", algorithm="ed25519")
    _, approver, _, _ = _people()
    token = _issue(service, approver)
    check_eq(token["algorithm"], "ed25519", "the token must name its algorithm")
    check(_verify(service, token).valid, "an ed25519 token must verify")
    hmac_service = _service()
    cross = _verify(hmac_service, _issue(service, approver))
    check(not cross.valid, "a token signed with one algorithm must not verify under another")


def test_the_review_package_shows_what_was_and_was_not_considered():
    _, approver, _, _ = _people()
    package = build_review_package(
        run_id="RUN-AP", gate="final_selection", scope=_SCOPE, pinned_digest="sha256:" + "3" * 64,
        analyzed={"analyzers": ["schema_check"], "records": 10}, not_analyzed={"classes_outside_scope": ["diagram"], "quarantined": 2},
        candidates=[{"candidate_id": "CND-1", "name": "A", "components": [], "relationships": [], "rationale": [],
                     "evidence_refs": [], "uncertainty": {}, "assumptions": [], "risks": []}],
        comparison=None, evidence={}, uncertainty={}, verification={"passed": False, "checks": []},
        questions=[], excluded_or_failed=[{"kind": "distinctness_rejected", "candidate_id": "CND-2"}],
        policy_decision={"verdict": "REVIEW", "reasons": []})
    doc = package.as_document()
    check(doc["not_analyzed"]["classes_outside_scope"], "the package must show what was not analyzed")
    check(doc["excluded_or_failed"], "the package must show excluded/failed analyses")
    check_eq(doc["accountability"], ACCOUNTABILITY, "the accountability statement must be present")
    check(doc["burden"]["burden_score"] >= 0, "review burden must be measured")
    check(package.subject_digest.startswith("sha256:"), "the package must have a stable subject digest")


def test_accountability_language_is_enforced():
    check(accountability_violations("The system approved the final architecture."), "an AI-approval claim must be caught")
    check(accountability_violations("This option was auto-approved."), "auto-approval language must be caught")
    check_eq(accountability_violations("The reviewer approved option A after reading the evidence."), [],
             "a human-approval sentence must not be flagged")


def test_the_gate_refuses_every_path_that_is_not_a_human_with_a_token():
    with tempdir() as root:
        ledger = Ledger(root / "ledger.jsonl", "RUN-AP")
        service = _service(ledger=ledger)
        recorder = DecisionRecorder(ledger=ledger)
        gate = ApprovalGate(service, recorder, ledger=ledger)
        _, approver, other, service_principal = _people()
        package = build_review_package(
            run_id="RUN-AP", gate="final_selection", scope=_SCOPE, pinned_digest="sha256:" + "3" * 64,
            analyzed={}, not_analyzed={}, candidates=[{"candidate_id": "CND-1", "name": "A", "components": [],
                                                       "relationships": [], "rationale": [], "evidence_refs": [],
                                                       "uncertainty": {}, "assumptions": [], "risks": []}],
            comparison=None, evidence={}, uncertainty={}, verification={"passed": True, "checks": []}, questions=[],
            excluded_or_failed=[], policy_decision={"verdict": "ALLOW", "reasons": []})
        args = {"package": package, "scope": _SCOPE, "policy_version": "1.0.0", "rationale": "reviewed"}
        check_raises(ReviewError, lambda: gate.decide(principal=approver, decision="approve", token=None, **args),
                     "approve without a token must be refused")
        check_raises((ReviewError, AuthorityError), lambda: gate.decide(principal=service_principal, decision="approve",
                                                                        token=None, **args),
                     "a service principal must never approve")
        token = service.issue(approver=approver, run_id="RUN-AP", gate="final_selection", artifact_ids=["CND-1"],
                              action="approve", scope_digest=_SCOPE.scope_digest, subject_digest=package.subject_digest)
        check_raises(ReviewError, lambda: gate.decide(principal=other, decision="approve", token=token, **args),
                     "a token issued to one human must not authorize another")
        decision = gate.decide(principal=approver, decision="approve", token=token, **args)
        check_eq(decision["decision"], "approve", "a genuine approval is recorded")
        check_eq(decision["approver_identity"]["kind"], "human", "the record names the human approver")
        ok, reason = gate.authorizes(decision, package, _SCOPE)
        check(ok, f"the recorded decision must authorize this exact package: {reason}")
        superseded = recorder.record(principal=approver, run_id="RUN-AP", gate="final_selection", decision="reject",
                                     package=package, scope=_SCOPE, policy_version="1.0.0", rationale="changed my mind")
        check(recorder.is_superseded(decision["decision_id"]), "a later decision must supersede the earlier one")
        ok2, _ = gate.authorizes(decision, package, _SCOPE)
        check(not ok2, "a superseded approval must no longer authorize")
        ok3, why = gate.authorizes(superseded, package, _SCOPE)
        check(not ok3, f"a rejection never authorizes: {why}")


if __name__ == "__main__":
    import test_approvals_review
    raise SystemExit(main(test_approvals_review))
