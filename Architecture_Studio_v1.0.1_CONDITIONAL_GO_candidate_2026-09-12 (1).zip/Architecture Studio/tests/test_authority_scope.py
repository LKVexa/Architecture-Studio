"""Identity, scope contracts, least privilege and narrowing (XAUTH-01..07, IMPL-01, ARCH-04)."""
from __future__ import annotations

import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main  # noqa: E402

from architecture_studio.authority import (AuthenticationError, AuthorityError, IdentityBinding, IdentityProvider,  # noqa: E402
                                           MAX_LEASE_SECONDS, Principal, assert_not_self_attested)
from architecture_studio.fixtures import make_scope, scope_document  # noqa: E402
from architecture_studio.schemas import SchemaError  # noqa: E402
from architecture_studio.scope import (EnvironmentConflict, MUTATING, ScopeContract, ScopeDenied, ScopeError,  # noqa: E402
                                       effective_permissions, mode_admits, reconcile_environment)


def _now():
    return datetime.now(timezone.utc)


def test_authentication_is_required_and_constant_time():
    idp = IdentityProvider()
    idp.enroll("architect@example.test", "human", "secret-value")
    principal = idp.authenticate("architect@example.test", "secret-value")
    check_eq(principal.kind, "human", "principal kind")
    check(principal.can_hold_accountability, "a human principal can hold accountability")
    check_raises(AuthenticationError, lambda: idp.authenticate("architect@example.test", "wrong"), "wrong secret must fail")
    check_raises(AuthenticationError, lambda: idp.authenticate("nobody@example.test", "secret-value"), "unknown subject must fail")
    idp.revoke_subject("architect@example.test")
    check_raises(AuthenticationError, lambda: idp.authenticate("architect@example.test", "secret-value"),
                 "a revoked identity must not authenticate")


def test_placeholder_identities_are_refused():
    for subject in ("REPLACE_WITH_PRINCIPAL", " padded", "", "with\x00null"):
        check_raises(AuthenticationError, lambda s=subject: Principal(s, "human", "as.local", "shared_secret", _now()),
                     f"{subject!r} must be refused as a principal subject")
    check_raises(AuthenticationError, lambda: Principal("x", "model", "as.local", "shared_secret", _now()),
                 "a model principal kind must not exist")


def test_service_principals_cannot_attest_or_approve():
    check_raises(AuthorityError, lambda: assert_not_self_attested("service", "final_selection"), "service approval refused")
    assert_not_self_attested("human", "final_selection")


def test_identity_binding_fails_closed_when_empty():
    binding = IdentityBinding()
    check(not binding.bound, "the host identity slot starts empty")
    check_raises(AuthenticationError, lambda: binding.authenticate("anyone", "any-secret"),
                 "an empty identity binding must fail closed (XAUTH-01 blocker)")
    check("XAUTH-01" in binding.describe()["blocker"], "the empty slot must name its blocker")


def test_credential_leases_are_short_lived_and_scoped():
    idp = IdentityProvider()
    idp.enroll("svc@example.test", "service", "svc-secret")
    principal = idp.authenticate("svc@example.test", "svc-secret")
    lease = idp.issue_lease(principal, ["read"], seconds=60)
    check((lease.expires_at - lease.issued_at).total_seconds() <= MAX_LEASE_SECONDS, "leases must be bounded")
    check_raises(AuthorityError, lambda: idp.issue_lease(principal, ["read"], seconds=MAX_LEASE_SECONDS + 1),
                 "an over-long lease must be refused")
    check(lease.authorizes("read"), "the lease grants what it was issued for")
    check(not lease.authorizes("modify"), "the lease grants nothing else")
    expired = idp.issue_lease(principal, ["read"], seconds=60, now=_now() - timedelta(hours=2))
    check(not expired.is_valid(_now()), "an expired lease is not valid")


def test_scope_contract_separates_permissions_and_defaults_read_only():
    scope = make_scope("RUN-1")
    for permission in ("read", "analyze", "draft"):
        check(scope.allows(permission), f"{permission} should be granted")
    for permission in sorted(MUTATING):
        check(not scope.allows(permission), f"{permission} must not be granted by a draft-only contract")
    check_raises(ScopeDenied, lambda: scope.check("modify"), "modify must be denied")
    read_only = make_scope("RUN-2", mode="read_only", actions=("read", "analyze"), write_authority="none")
    check(not read_only.allows("draft"), "read-only mode must not grant draft")
    ok, _ = mode_admits("read_only", ["read", "analyze"])
    check(ok, "a read-only contract with read/analyze is admissible")
    bad, reason = mode_admits("read_only", ["read", "draft"])
    check(not bad, f"read_only + draft must be refused, got {reason}")


def test_malformed_or_expired_contracts_are_refused():
    doc = scope_document("RUN-3")
    check_raises(ScopeError, lambda: ScopeContract.from_document(
        {**doc, "write_authority": "none", "allowed_actions": sorted(set(doc["allowed_actions"]) | {"modify"}), "mode": "modify"}),
        "write_authority none cannot coexist with a mutating permission")
    check_raises(ScopeError, lambda: ScopeContract.from_document(
        {**doc, "allowed_actions": sorted(set(doc["allowed_actions"]) | {"modify"}), "mode": "modify"}),
        "write_authority draft cannot grant modify")
    check_raises((ScopeError, SchemaError), lambda: ScopeContract.from_document({**doc, "allowed_artifact_classes": ["unicorn"]}),
                 "unknown artifact class must be refused")
    check_raises(ScopeError, lambda: ScopeContract.from_document({**doc, "expires_at": doc["issued_at"]}),
                 "a contract must expire after it is issued")
    check_raises(ScopeError, lambda: ScopeContract.from_document({**doc, "revision_bounds": {"unknown_system": "r1"}}),
                 "a revision bound outside the source set must be refused")
    expired = make_scope("RUN-4", issued_at=datetime(2020, 1, 1, tzinfo=timezone.utc))
    check(not expired.is_current(_now()), "an expired contract is not current")


def test_default_fixtures_are_issued_now_not_on_a_hardcoded_date():
    """A frozen issue date plus a 24h window is a time bomb: after it elapses every
    fixture fails closed as expired. Defaults must be current at call time, and a
    contract issued on 2026-09-07 for 24 hours must still be refused today."""
    scope = make_scope("RUN-NOW")
    check(scope.is_current(_now()), "the default fixture contract must be in force at call time")
    check((_now() - scope.issued_at) < timedelta(minutes=5), "default issued_at must be approximately now")
    frozen = make_scope("RUN-FROZEN", issued_at=datetime(2026, 9, 7, tzinfo=timezone.utc), hours=24)
    check(not frozen.is_current(_now()), "a 24h contract issued 2026-09-07 must be expired after that window")


def test_paths_and_sources_are_authorized_independently():
    scope = make_scope("RUN-5", classes=("requirement",))
    check_raises(ScopeDenied, lambda: scope.check_path("/etc/passwd", permission="read"), "an absolute foreign path is denied")
    check_raises(ScopeDenied, lambda: scope.check("read", source_system="api_catalog"),
                 "a source outside the source set is denied even with the read permission")
    check_raises(ScopeDenied, lambda: scope.check("read", artifact_class="diagram"),
                 "an artifact class outside the contract is denied")
    check_raises(ScopeDenied, lambda: scope.check("read", external_system="https://example.test"),
                 "an external system is denied when none is listed")


def test_narrowing_is_one_way():
    scope = make_scope("RUN-6")
    narrowed = scope.narrowed(artifact_classes=["requirement"], permissions=["read", "analyze"])
    check_eq(sorted(narrowed.allowed_artifact_classes), ["requirement"], "narrowed classes")
    check(not narrowed.allows("draft"), "narrowing drops the draft permission")
    check(narrowed.scope_digest != scope.scope_digest, "a narrowed contract is a different contract")
    check_raises(ScopeError, lambda: scope.narrowed(permissions=["read", "modify"]), "narrowing cannot add a permission")
    check_raises(ScopeError, lambda: scope.narrowed(artifact_classes=["diagram"]), "narrowing cannot add a class")


def test_composition_only_narrows_across_authorities():
    scope = make_scope("RUN-7")
    eff = effective_permissions(scope=scope, environment_ceiling=["read", "analyze"], environment_mode="read_only")
    check(not eff.allows("draft"), "the environment ceiling and mode both narrow")
    check(eff.dropped, "dropped permissions must be reported with their source")
    check_raises(ScopeError, lambda: effective_permissions(scope=scope, environment_ceiling=["read", "modify"]),
                 "an environment cannot widen the contract")


def test_environment_profiles_must_be_internally_consistent():
    ok = reconcile_environment({"id": "local", "mode_ceiling": "draft_only", "permissions_ceiling": ["read", "analyze", "draft"]})
    check(ok["instantiable"], "a consistent profile is instantiable")
    check_raises(EnvironmentConflict, lambda: reconcile_environment(
        {"id": "bad", "mode_ceiling": "read_only", "permissions_ceiling": ["read", "modify"]}),
        "a read-only environment cannot hold a mutating permission")
    check_raises(EnvironmentConflict, lambda: reconcile_environment(
        {"id": "bad", "mode_ceiling": "sideways", "permissions_ceiling": ["read"]}), "an unknown mode must be refused")


if __name__ == "__main__":
    import test_authority_scope
    raise SystemExit(main(test_authority_scope))
