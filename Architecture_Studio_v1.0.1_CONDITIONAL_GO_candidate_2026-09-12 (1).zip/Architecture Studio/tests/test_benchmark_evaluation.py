"""Benchmark, regression comparison, review burden and pilot exit criteria
(IMPL-10, MODEL-07, XEVAL-01..07, AUDIT-ADD-25, VERIFY-01..06, WF-08)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.assumptions import AssumptionRegistry  # noqa: E402
from architecture_studio.benchmark import compare_reports, load_baseline, run_benchmark  # noqa: E402
from architecture_studio.evaluation import (BURDEN_LIMITS, PILOT_EXIT_CRITERIA, evaluate_pilot, pilot_record,  # noqa: E402
                                            review_burden_report)
from architecture_studio.fixtures import make_index, make_scope  # noqa: E402
from architecture_studio.generator import Generator, ProviderSlot  # noqa: E402
from architecture_studio.retrieval import RetrievalIndex  # noqa: E402
from architecture_studio.tradeoffs import compare  # noqa: E402
from architecture_studio.verify import gate_verdict, verify_outputs  # noqa: E402

_REPORT: dict = {}


def _benchmark():
    if not _REPORT:
        _REPORT.update(run_benchmark(retrieval_queries=20))
    return _REPORT


def test_the_benchmark_runs_offline_and_reports_every_dimension():
    report = _benchmark()
    dimensions = set(report["by_dimension"])
    for required in ("grounding", "distinctness", "constraints", "uncertainty", "guardrail", "workflow",
                     "retrieval", "failure_mode"):
        check(required in dimensions, f"the benchmark does not cover {required}")
    check(report["corpus"]["records"] > 100, "the benchmark must run against the real corpus")
    check(report["corpus"]["adversarial_attacks"] > 100, "the adversarial corpus must be loaded")
    check(report["corpus"]["benign_controls"] > 100, "benign controls must be loaded")
    check(report["report_digest"], "the report must be digestible for release evidence")


def test_failure_modes_are_reported_separately_and_all_detected():
    report = _benchmark()
    modes = report["failure_modes"]
    for required in ("FM-HALLUCINATED-EVIDENCE", "FM-FABRICATED-REQUIREMENT", "FM-GENERIC-FALLBACK",
                     "FM-FABRICATED-PROVENANCE", "FM-STALE-CONTEXT", "FM-CONFLICTING-EVIDENCE", "FM-OVERREACH"):
        check(required in modes, f"{required} is not reported")
        check_eq(modes[required], "PASS", f"{required} was not detected by the runtime")


def test_guardrail_bypass_cases_pass_and_a_bypass_would_fail_the_suite():
    report = _benchmark()
    check(report["all_guardrail_cases_pass"], "every guardrail/workflow bypass case must be refused")
    guardrails = [c for c in report["cases"] if c["dimension"] in ("guardrail", "workflow")]
    check(len(guardrails) >= 5, f"too few guardrail cases: {len(guardrails)}")
    check(report["suite_passed"], f"the suite must pass: {report['failed_cases']}")


def test_measurements_never_become_a_pass_under_proposed_thresholds():
    report = _benchmark()
    check_eq(report["thresholds_status"], "PROPOSED", "benchmark thresholds are PROPOSED")
    check_eq(report["targets"]["verdict"], "NO_APPROVED_TARGETS", "no target may be approved by this pass")
    for row in report["targets"]["rows"]:
        check(not row["approved"], f"{row['target_id']} must not be approved")
        check(row["state"] in ("insufficient_data", "met_under_proposed_target", "not_met_under_proposed_target"),
              f"{row['target_id']} state {row['state']!r} claims more than a measurement")
    for case in report["cases"]:
        if case["dimension"] == "retrieval" or case["case_id"] in ("GUARD-INJECTION-RECALL", "GUARD-INJECTION-FP"):
            check(case["result"] in ("MEASURED", "INSUFFICIENT_DATA"),
                  f"{case['case_id']} must report a measurement, not a verdict")


def test_regression_comparison_detects_a_regression():
    report = _benchmark()
    check_eq(compare_reports(report, None)["state"], "NO_BASELINE", "no baseline is stated, not assumed")
    check_eq(compare_reports(report, report)["state"], "NO_REGRESSION", "a report never regresses against itself")
    worse = {**report, "cases": [{**c, "result": "FAIL"} if c["case_id"] == "GROUND-01" else c for c in report["cases"]],
             "measurements": {**report["measurements"],
                              "injection.recall": {"value": 0.0, "denominator": 100}}}
    diff = compare_reports(worse, report)
    check_eq(diff["state"], "REGRESSED", "a PASS->FAIL case and a dropped metric must be reported as a regression")
    check(any(r.get("case_id") == "GROUND-01" for r in diff["regressions"]), "the failing case must be named")
    check(any(r.get("metric") == "injection.recall" for r in diff["regressions"]), "the dropped metric must be named")


def test_independent_verification_blocks_advancement_on_failure():
    scope = make_scope("RUN-V", classes=("requirement", "api_operation", "service", "security_constraint", "deployment_standard"))
    index, _, _ = make_index(scope)
    retrieval = RetrievalIndex()
    retrieval.add_index(index)
    assumptions = AssumptionRegistry("RUN-V")
    generation = Generator(scope=scope, index=index, retrieval=retrieval, assumptions=assumptions,
                           slot=ProviderSlot()).generate(run_id="RUN-V", iteration=1,
                                                         goals=[{"text": "consolidate governance services"}],
                                                         constraints=[], session_ref="S1")
    comparison = compare(run_id="RUN-V", candidates=generation.candidates, index=index,
                         constraint_checks=generation.constraint_checks, grounding=generation.grounding)
    report = verify_outputs(run_id="RUN-V", iteration=1, candidates=generation.candidates, index=index,
                            assumptions=assumptions, comparison=comparison,
                            design_history=[{"version": 1, "digest": "d1"}, {"version": 2, "digest": "d2"}],
                            policy_decision=generation.policy)
    ids = {c.check_id for c in report.checks}
    for required in ("VERIFY-01", "VERIFY-02", "VERIFY-03", "VERIFY-04", "VERIFY-05", "VERIFY-06", "SCHEMA", "SECURITY", "POLICY"):
        check(required in ids, f"the verifier does not run {required}")
    check(report.passed, f"a clean run must verify: {[c.as_document() for c in report.failed]}")
    verdict, reason = gate_verdict(report)
    check_eq(verdict, "ALLOW", f"a passing verification allows advancement: {reason}")

    # Seed exactly one defect: an uncited material claim in the comparison.
    broken = {**comparison, "cells": [{**c, "evidence_refs": [], "derivation": "deterministic_analyzer"}
                                      if c["dimension"] == "evidence_coverage" else c for c in comparison["cells"]]}
    failed = verify_outputs(run_id="RUN-V", iteration=1, candidates=generation.candidates, index=index,
                            assumptions=assumptions, comparison=broken,
                            design_history=[{"version": 1, "digest": "d1"}], policy_decision=generation.policy)
    check(not failed.passed, "a seeded uncited claim must fail verification")
    check("VERIFY-04" in {c.check_id for c in failed.failed}, f"VERIFY-04 must be the failing check: {[c.check_id for c in failed.failed]}")
    blocked, why = gate_verdict(failed)
    check_eq(blocked, "DENY", f"a failed verification must block advancement: {why}")

    # Ownership: a non-human approver in a decision record must fail VERIFY-05.
    owned = verify_outputs(run_id="RUN-V", iteration=1, candidates=generation.candidates, index=index,
                           assumptions=assumptions, comparison=comparison,
                           decisions=[{"decision_id": "D1", "decision": "approve", "approver_identity": {"kind": "service"}}],
                           design_history=[{"version": 1, "digest": "d1"}], policy_decision=generation.policy)
    check("VERIFY-05" in {c.check_id for c in owned.failed}, "a non-human approver must fail the ownership check")


def test_review_burden_is_measured_against_proposed_limits():
    check_eq(review_burden_report([])["state"], "INSUFFICIENT_DATA", "no runs means no burden measurement")
    burdens = [{"statements_to_check": 20, "evidence_items": 40, "comparison_cells": 24, "unresolved_items": 1,
                "open_questions": 2, "material_open_questions": 1, "burden_score": 47} for _ in range(4)]
    report = review_burden_report(burdens)
    check_eq(report["runs"], 4, "runs counted")
    check(report["evidence_per_statement"] >= 1.0, "evidence per statement must be measured")
    check(report["within_proposed_limits"], "these burdens are inside the proposed limits")
    check_eq(BURDEN_LIMITS["status"], "PROPOSED", "burden limits are PROPOSED")
    check("measurement" in report["boundary"], "the report must say a measurement is not acceptance")
    heavy = [{**b, "statements_to_check": 500, "burden_score": 900, "material_open_questions": 20} for b in burdens]
    check(not review_burden_report(heavy)["within_proposed_limits"], "an excessive burden must be reported")


def test_pilot_exit_criteria_cannot_be_met_by_this_pass():
    check_eq(PILOT_EXIT_CRITERIA["status"], "PROPOSED", "pilot exit criteria are PROPOSED")
    check(PILOT_EXIT_CRITERIA["approval_ref"] is None, "the criteria carry no approval")
    empty = evaluate_pilot(pilot_record(runs=[], reviewers=[], calendar_days=0))
    check_eq(empty["verdict"], "INSUFFICIENT_DATA", "no pilot data means insufficient data")
    check(not empty["broader_rollout_permitted"], "rollout must not be permitted without data")

    runs = [{"run_id": f"R{i}", "effective_permissions": ["read", "analyze", "draft"], "mode": "draft_only",
             "grounding_coverage": 0.9, "verification_passed": True, "abstained": False, "overridden": False,
             "policy_evaluations": 10, "policy_denied": 0, "burden_score": 40} for i in range(40)]
    good = evaluate_pilot(pilot_record(runs=runs, reviewers=["a", "b", "c"], calendar_days=20))
    check_eq(good["verdict"], "MET_UNDER_PROPOSED_CRITERIA", f"a good pilot under proposed criteria: {good['verdict']}")
    check(not good["broader_rollout_permitted"], "proposed criteria never permit broader rollout")

    disqualified = [{**runs[0], "effective_permissions": ["read", "modify"], "mode": "modify"}] + runs[1:]
    bad = evaluate_pilot(pilot_record(runs=disqualified, reviewers=["a", "b", "c"], calendar_days=20))
    check_eq(bad["verdict"], "NOT_MET", "a run outside read-only/draft-only disqualifies the pilot")


if __name__ == "__main__":
    import test_benchmark_evaluation
    raise SystemExit(main(test_benchmark_evaluation))
