"""Audit integrity, content-addressed state, versioning and reproducibility
(STORE-01..07, XSTATE-01..05, ARCH-05, XPROV-06, AUDIT-ADD-20)."""
from __future__ import annotations

import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.backup import backup, exercise, restore  # noqa: E402
from architecture_studio.design_state import DesignStateError, DesignStateStore  # noqa: E402
from architecture_studio.ledger import Ledger, LedgerError, ReadOnlyLedger  # noqa: E402
from architecture_studio.store import ConcurrencyError, ObjectStore  # noqa: E402
from architecture_studio.workflow import (SAFE_TERMINALS, TERMINAL_STATES, TransitionError, WorkflowMachine,  # noqa: E402
                                          WorkflowState)


def _ledger(root: Path, run_id: str = "RUN-L") -> Ledger:
    return Ledger(root / "ledger.jsonl", run_id)


def test_the_ledger_is_append_only_and_hash_chained():
    with tempdir() as root:
        ledger = _ledger(root)
        for i in range(5):
            ledger.append("test.event", actor="tester", actor_kind="human", outcome="recorded", detail={"i": i})
        ok, reason = ledger.verify()
        check(ok, f"a freshly written ledger must verify: {reason}")
        check_eq(ledger.length, 5, "event count")
        check(ledger.head_digest, "the ledger must expose a head digest")
        lines = (root / "ledger.jsonl").read_text(encoding="utf-8").splitlines()
        tampered = json.loads(lines[2]); tampered["event"]["detail"] = {"i": 99}
        lines[2] = json.dumps(tampered, sort_keys=True, separators=(",", ":"))
        (root / "ledger.jsonl").write_text("\n".join(lines) + "\n", encoding="utf-8")
        ok2, reason2 = Ledger(root / "ledger.jsonl", "RUN-L").verify()
        check(not ok2, "tampering must break the chain")
        check("2" in reason2 or "chain" in reason2.lower(), f"the failure must locate itself: {reason2}")


def test_a_truncated_ledger_is_detected():
    with tempdir() as root:
        ledger = _ledger(root)
        for i in range(4):
            ledger.append("test.event", actor="t", actor_kind="human", outcome="recorded", detail={"i": i})
        lines = (root / "ledger.jsonl").read_text(encoding="utf-8").splitlines()
        (root / "ledger.jsonl").write_text("\n".join(lines[:-1]) + "\n", encoding="utf-8")
        second = Ledger(root / "ledger.jsonl", "RUN-L")
        check_eq(second.length, 3, "truncation is visible in the length")
        ok, _ = second.verify()
        check(ok, "a prefix of a chain still verifies as a prefix; the length is what changed")
        check(second.head_digest != ledger.head_digest, "the head digest must reveal the removal")


def test_the_model_cannot_write_to_the_ledger():
    with tempdir() as root:
        ledger = _ledger(root)
        check_raises(LedgerError, lambda: ledger.append("model.claim", actor="gpt", actor_kind="model",
                                                        outcome="recorded", detail={}), "a model writer must be refused")
        check_raises(LedgerError, lambda: ledger.append("x", actor="t", actor_kind="human", outcome="great", detail={}),
                     "an illegal outcome must be refused")
        reader = ReadOnlyLedger(root / "ledger.jsonl")
        check(not hasattr(reader, "append"), "the read-only view must not expose append")


def test_objects_are_content_addressed_and_refs_use_compare_and_swap():
    with tempdir() as root:
        store = ObjectStore(root / "store")
        d1 = store.put_object({"a": 1})
        d2 = store.put_object({"a": 1})
        check_eq(d1, d2, "identical payloads share one object")
        first = store.commit("runs/R/state", {"version": 1}, expected_parent=None)
        store.commit("runs/R/state", {"version": 2}, expected_parent=first.snapshot_id)
        check_raises(ConcurrencyError, lambda: store.commit("runs/R/state", {"version": 3}, expected_parent=first.snapshot_id),
                     "a stale parent must be refused")
        check_eq(len(store.history("runs/R/state")), 2, "history keeps every revision")
        check_eq(store.at_revision("runs/R/state", 0)["version"], 1, "an earlier revision is still readable")
        check(store.verify()["ok"], "the store must verify")


def test_erasure_tombstones_without_breaking_the_chain():
    with tempdir() as root:
        store = ObjectStore(root / "store")
        store.commit("runs/R/doc", {"secret": "value"}, expected_parent=None)
        store.commit("runs/R/doc", {"secret": "value2"}, expected_parent=store.head("runs/R/doc").snapshot_id)
        tomb = store.tombstone("runs/R/doc", reason="retention", erase_payload=True)
        check(tomb is not None, "tombstoning returns a snapshot")
        check_eq(store.head("runs/R/doc").lifecycle, "tombstoned", "the ref records the erasure")
        check(len(store.history("runs/R/doc")) >= 3, "the tombstone is a new revision, not a deletion of history")
        check(store.verify()["ok"], "the store still verifies after erasure")


def test_design_state_is_versioned_and_never_overwritten():
    with tempdir() as root:
        store = ObjectStore(root / "store")
        design = DesignStateStore(store, "RUN-D")
        design.initialize(scope_digest="sha256:" + "0" * 64, actor="operator@example.test")
        design.register_candidates(["CND-1"], actor="svc", actor_kind="service", expected_version=design.load().version,
                                   rationale="first iteration candidates")
        check_raises((DesignStateError, ConcurrencyError), lambda: design.register_candidates(
            ["CND-2"], actor="svc", actor_kind="service", expected_version=0, rationale="stale version write"),
            "a stale expected_version must be refused")
        check_raises(DesignStateError, lambda: design.apply("inspect", actor="svc", actor_kind="service",
                                                            expected_version=design.load().version, rationale="read op"),
                     "a read operation must not create a version")
        check_raises(DesignStateError, lambda: design.apply("teleport", actor="svc", actor_kind="service",
                                                            expected_version=design.load().version, rationale="unknown op"),
                     "an unknown steering operation must be refused")
        history = design.history()
        check(len(history) >= 2, "every version is preserved")
        versions = [h["version"] for h in history]
        check_eq(versions, sorted(versions), "versions increase monotonically")
        check_eq(design.at_version(versions[0]).version, versions[0], "an earlier version is reconstructable")


def test_the_workflow_cannot_reach_approval_without_a_human():
    machine = WorkflowMachine("RUN-W")
    for event in ("authority_established", "revisions_pinned", "collect_evidence", "evidence_indexed",
                  "analysis_complete", "candidates_generated", "verification_passed", "submit_for_review"):
        machine.fire(event, actor="svc", actor_kind="service")
    check_eq(machine.state, WorkflowState.AWAITING_REVIEW, "golden prefix state")
    check_raises(TransitionError, lambda: machine.fire("approve", actor="svc", actor_kind="service"),
                 "a service actor must not fire a human-only event")
    check_raises(TransitionError, lambda: machine.fire("approve", actor="human@example.test", actor_kind="human"),
                 "a human-only event still requires an authority reference")
    machine.fire("approve", actor="human@example.test", actor_kind="human", authority_ref="AUTH-1")
    check_eq(machine.state, WorkflowState.APPROVED, "approved after a human decision with authority")
    check(not WorkflowMachine.reachable_without("approve", WorkflowState.APPROVED), "APPROVED must be unreachable without approve")
    check(SAFE_TERMINALS <= TERMINAL_STATES, "safe terminals are terminal")


def test_state_survives_restore_and_reconstructs_from_the_ledger():
    with tempdir() as root:
        ledger = _ledger(root, "RUN-S")
        machine = WorkflowMachine("RUN-S")
        machine.fire("authority_established", actor="h", actor_kind="human", authority_ref="A", ledger=ledger)
        machine.fire("revisions_pinned", actor="svc", actor_kind="service", ledger=ledger)
        restored = WorkflowMachine.restore(machine.snapshot())
        check_eq(restored.state, machine.state, "a snapshot restores the state")
        rebuilt = WorkflowMachine.reconstruct_from_ledger("RUN-S", ledger.events())
        check_eq(rebuilt.state, machine.state, "the ledger alone reconstructs the state")


def test_backup_restore_and_recovery_exercise():
    with tempdir() as root:
        ledger = _ledger(root, "RUN-B")
        ledger.append("run.started", actor="h", actor_kind="human", outcome="recorded", detail={})
        store = ObjectStore(root / "store")
        store.commit("runs/RUN-B/state", {"version": 1}, expected_parent=None)
        result = exercise(store=store, ledger=ledger, flags_path=None, workdir=root / "dr", run_id="RUN-B")
        check(result["passed"], f"the recovery exercise must pass: {result}")
        check(result["lineage_intact"], "restored refs must match the originals")
        check(result["audit_integrity"], "the restored ledger must verify")
        manifest = backup(store=store, ledger_path=ledger.path, flags_path=None, destination=root / "b2")
        (root / "b2" / "ledger.jsonl").write_text("tampered\n", encoding="utf-8")
        check_raises(RuntimeError, lambda: restore(backup_dir=root / "b2", destination=root / "r2", run_id="RUN-B"),
                     "a tampered backup must refuse to restore")


if __name__ == "__main__":
    import test_ledger_store
    raise SystemExit(main(test_ledger_store))
