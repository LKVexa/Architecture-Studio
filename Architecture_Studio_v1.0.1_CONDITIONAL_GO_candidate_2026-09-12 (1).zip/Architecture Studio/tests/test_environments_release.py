"""Environments, boundaries, release qualification and rollback (ENV-01..06, AUDIT-ADD-21, XEVAL-07, XAUTH-04)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio import __version__  # noqa: E402
from architecture_studio.environments import (ENVIRONMENTS, boundary_report, load_descriptors, smoke_test,  # noqa: E402
                                              write_descriptors)
from architecture_studio.fixtures import OVERLAY_ROOT, make_scope  # noqa: E402
from architecture_studio.release import (ACCEPTANCE_RULE, PROMOTION_CHAIN, build_manifest, conditional_qualify,
                                         qualify, rollback_plan, tree_digest)  # noqa: E402
from architecture_studio.scope import MUTATING  # noqa: E402

_SCOPE = make_scope("RUN-ENV")


def test_six_environments_are_declared_with_separate_boundaries():
    check_eq(len(ENVIRONMENTS), 6, "ENV-01..06 needs six environment descriptors")
    report = boundary_report()
    check_eq(report["problems"], [], f"boundary problems: {report['problems']}")
    check(report["ok"], "the declared boundaries must be internally consistent")
    for env in ENVIRONMENTS:
        for field in ("identity_provider", "config_namespace", "secrets_namespace", "data_boundary",
                      "observability_sink", "deployment_control"):
            check(getattr(env, field), f"{env.environment_id} declares no {field}")
    non_production = [e for e in ENVIRONMENTS if e.environment_id in ("local", "ci", "test_tenant")]
    for env in non_production:
        check(not (set(env.permissions_ceiling) & MUTATING), f"{env.environment_id} must hold no mutating permission")
        check("production" not in env.data_boundary, f"{env.environment_id} must not touch production data")


def test_conditional_environments_stay_unresolved_until_a_human_decides():
    unresolved = set(boundary_report()["unresolved_applicability"])
    check_eq(unresolved, {"production_read_only", "privileged_execution"},
             "ENV-04 and ENV-05 are conditional in the source and must stay UNRESOLVED")
    for env_id in unresolved:
        result = smoke_test(env_id, _SCOPE)
        check_eq(result["status"], "NOT_APPLICABLE_YET", f"{env_id} must not be smoke-tested before applicability is resolved")
        check(result["reason"], "the reason must name the owner who must decide")


def test_environment_smoke_tests():
    results = {env.environment_id: smoke_test(env.environment_id, _SCOPE) for env in ENVIRONMENTS}
    check_eq(results["local"]["status"], "PASS", f"the local sandbox is this checkout: {results['local']}")
    check_eq(results["test_tenant"]["status"], "PASS", "the isolated test tenant is provisioned by the fixtures")
    for env_id in ("ci", "staging"):
        check_eq(results[env_id]["status"], "NOT_PROVISIONED",
                 f"{env_id} is declared but not provisioned by this pass, and must say so")
    for env_id, result in results.items():
        if result["status"] == "PASS":
            effective = set(result["effective"]["effective_permissions"])
            check(effective <= set(_SCOPE.permissions), f"{env_id} widened the contract")


def test_descriptors_round_trip_to_disk():
    with tempdir() as root:
        written = write_descriptors(root)
        check_eq(len(written), len(ENVIRONMENTS), "every environment must be written")
        loaded = load_descriptors(root)
        check_eq(set(loaded), {e.environment_id for e in ENVIRONMENTS}, "descriptors must round-trip")
        check((root / "INDEX.json").exists(), "an index must be written")
        for env_id, doc in loaded.items():
            check(doc["resource_ceilings"], f"{env_id} carries no resource ceilings")
            check("provisioned" in doc, f"{env_id} does not state whether it is provisioned")


def test_release_manifest_and_rollback():
    with tempdir() as root:
        manifest = build_manifest(overlay_root=OVERLAY_ROOT, corpus_digest="sha256:" + "0" * 64, reports={"tests": "r1"})
        check_eq(manifest["release"], __version__, "the manifest names the release")
        check(manifest["components"] and manifest["schemas"], "the manifest pins every versioned component")
        check(manifest["overlay_tree"]["digest"].startswith("sha256:"), "the tree digest must be recorded")
        check(manifest["manifest_digest"], "the manifest must be digestible")
        again = build_manifest(overlay_root=OVERLAY_ROOT, corpus_digest="sha256:" + "0" * 64, reports={"tests": "r1"})
        check_eq(manifest["overlay_tree"]["digest"], again["overlay_tree"]["digest"], "the tree digest must be reproducible")
        plan = rollback_plan(manifest, None)
        check(plan["no_previous_release"], "the first release has nothing to roll back to, and says so")
        check(len(plan["steps"]) >= 4, "the rollback procedure must be documented as steps")
        check("object store" in " ".join(plan["state_preserved"]).lower(), "rollback must preserve stored state")
        second = {**manifest, "release": "1.1.0"}
        plan2 = rollback_plan(second, manifest)
        check_eq(plan2["to_release"], __version__, "a rollback names the release it returns to")


def test_a_release_cannot_qualify_without_its_evidence():
    manifest = build_manifest(overlay_root=OVERLAY_ROOT, corpus_digest="sha256:" + "0" * 64, reports={})
    bare = qualify(manifest, test_report=None, benchmark_report=None, evaluation_report=None, supply_chain_report=None,
                   gate_report=None, recovery_exercise=None, target_environment="staging")
    check_eq(bare["verdict"], "NOT_QUALIFIED", "a release with no evidence must not qualify")
    check(len(bare["reasons"]) >= 5, f"every missing report must be named: {bare['reasons']}")

    full_gate = {"gates": [{"gate_id": f"GATE-PROD-{i:02d}", "status": "PASS"} for i in range(1, 9)]}
    ready = qualify(manifest, test_report={"all_passed": True}, benchmark_report={"thresholds_status": "APPROVED", "suite_passed": True},
                    evaluation_report={"verdict": "MET"}, supply_chain_report={"verdict": "PASS"}, gate_report=full_gate,
                    recovery_exercise={"passed": True}, target_environment="ci")
    check_eq(ready["verdict"], "QUALIFIED", f"a fully evidenced release qualifies for the next environment: {ready['reasons']}")

    proposed = qualify({**manifest, "environment": "staging"}, test_report={"all_passed": True},
                       benchmark_report={"thresholds_status": "PROPOSED", "suite_passed": True},
                       evaluation_report={"verdict": "MET_UNDER_PROPOSED_CRITERIA"}, supply_chain_report={"verdict": "PASS"},
                       gate_report=full_gate, recovery_exercise={"passed": True}, target_environment="production_read_only")
    check_eq(proposed["verdict"], "NOT_QUALIFIED", "production must not qualify on PROPOSED thresholds")
    check(any("PROPOSED" in r for r in proposed["reasons"]), f"the reason must name the proposed thresholds: {proposed['reasons']}")
    check(ready["promotion_is_a_human_act"], "qualification never promotes by itself")
    check_eq(ACCEPTANCE_RULE["status"], "PROPOSED", "the acceptance rule itself is PROPOSED")
    check_eq(list(PROMOTION_CHAIN)[0], "local", "the promotion chain starts at local")


def test_promotion_must_follow_the_chain():
    manifest = {**build_manifest(overlay_root=OVERLAY_ROOT, corpus_digest="sha256:" + "0" * 64, reports={}), "environment": "local"}
    full_gate = {"gates": [{"gate_id": f"GATE-PROD-{i:02d}", "status": "PASS"} for i in range(1, 9)]}
    skipped = qualify(manifest, test_report={"all_passed": True}, benchmark_report={"thresholds_status": "APPROVED", "suite_passed": True},
                      evaluation_report={"verdict": "MET"}, supply_chain_report={"verdict": "PASS"}, gate_report=full_gate,
                      recovery_exercise={"passed": True}, target_environment="staging")
    check_eq(skipped["verdict"], "NOT_QUALIFIED", "local cannot promote straight to staging")
    check(any("promotion" in r for r in skipped["reasons"]), f"the chain violation must be named: {skipped['reasons']}")


def test_conditional_go_is_bounded_and_keeps_production_no_go():
    from datetime import datetime, timezone
    from architecture_studio.gates import evaluate_gates

    evidence = {
        "tests": {"all_passed": True, "passed": 163, "total": 163},
        "controls": {"controls": [{"control_id": "CTRL-A", "tests": "tests/test_policy.py"}]},
        "benchmark": {"thresholds_status": "PROPOSED", "suite_passed": True,
                       "all_guardrail_cases_pass": True, "failed_cases": []},
        "verification": {"checks": [{"check_id": "VERIFY-01", "result": "PASS", "summary": "all elements traced"}]},
        "write_authority_scan": {"hidden_write_paths": [], "write_sites": 53, "verdict": "PASS"},
        "incident_drill": {"passed": True}, "recovery_exercise": {"passed": True},
        "docs": {"documents": [{"doc_id": "DOC-11", "current": True},
                                 {"doc_id": "DOC-12", "current": True,
                                  "published_ref": "Architecture Studio/docs/DOC-12-known-limitations.md"}]},
    }
    manifest = build_manifest(overlay_root=OVERLAY_ROOT, corpus_digest="sha256:" + "0" * 64,
                              reports={"tests": "test", "benchmark": "benchmark"}, environment="local")
    result = conditional_qualify(manifest=manifest, evidence=evidence,
                                 gate_report=evaluate_gates(evidence),
                                 now=datetime(2026, 9, 12, tzinfo=timezone.utc), validity_hours=72)
    check_eq(result["verdict"], "CONDITIONAL_GO", "the bounded local candidate should qualify")
    check_eq(result["production_verdict"], "NO_GO", "conditional qualification must not be production GO")
    check(not result["promotion_authorized"], "conditional qualification must not authorize promotion")
    check_eq(result["expires_at"], "2026-09-15T00:00:00Z", "conditional qualification must expire")
    check("GATE-PROD-02" in result["pending_independent_reviews"], "proposed thresholds remain pending")
    check(any(row["id"] == "CG-02" and row["status"] == "CONDITION" for row in result["conditions"]),
          "proposed thresholds must be an explicit condition")
    check(any(row["id"] == "CG-10" for row in result["conditions"]), "permission boundary must be explicit")


def test_conditional_go_fails_closed_outside_local_scope_or_on_failed_evidence():
    from datetime import datetime, timezone
    from architecture_studio.gates import evaluate_gates

    evidence = {"tests": {"all_passed": False, "passed": 1, "total": 2}}
    manifest = build_manifest(overlay_root=OVERLAY_ROOT, corpus_digest="sha256:" + "0" * 64,
                              reports={}, environment="local")
    result = conditional_qualify(manifest=manifest, evidence=evidence,
                                 gate_report=evaluate_gates(evidence),
                                 target_environment="staging",
                                 now=datetime(2026, 9, 12, tzinfo=timezone.utc))
    check_eq(result["verdict"], "NOT_CONDITIONALLY_QUALIFIED", "failed evidence and staging must fail closed")
    check(result["hard_blockers"], "the failed conditions must be named")


if __name__ == "__main__":
    import test_environments_release
    raise SystemExit(main(test_environments_release))
