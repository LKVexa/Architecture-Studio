"""Provenance and evidence lineage (XPROV-01..07, API-03, AUDIT-ADD-07)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main  # noqa: E402

from architecture_studio.provenance import EvidenceRef, ProvenanceError, ProvenanceGraph  # noqa: E402
from architecture_studio.schemas import SchemaError, validate  # noqa: E402


def _ref(artifact="ART-1", derivation="source", analyzer=None, status="current") -> EvidenceRef:
    return EvidenceRef(artifact_id=artifact, source_system="requirements", revision="r1",
                       source_hash="sha256:" + "a" * 64, observed_at="2026-09-07T00:00:00Z",
                       derivation=derivation, evidence_status=status, analyzer=analyzer)


def test_an_evidence_reference_carries_identity_revision_hash_and_status():
    ref = _ref()
    doc = ref.as_document()
    validate("as.evidence_ref/1", doc)
    check(ref.ref_id.startswith("EV-"), f"reference id must be typed, got {ref.ref_id}")
    check_eq(_ref().ref_id, ref.ref_id, "the same reference must produce the same id")
    check(_ref(artifact="ART-2").ref_id != ref.ref_id, "a different artifact must produce a different id")
    check_eq(ref.stale().evidence_status, "stale", "staleness is expressed on the reference")
    check(ref.stale().ref_id != ref.ref_id, "a stale reference is a different reference")


def test_derived_references_must_name_their_producer():
    check_raises(ProvenanceError, lambda: _ref(derivation="deterministic_analyzer"),
                 "an analyzer-derived reference must name its analyzer")
    check_raises(ProvenanceError, lambda: _ref(derivation="model_inference"),
                 "a model-derived reference must name its model")
    _ref(derivation="deterministic_analyzer", analyzer="schema_check")
    check_raises(ProvenanceError, lambda: _ref(derivation="vibes"), "an unknown derivation must be refused")
    check_raises(ProvenanceError, lambda: _ref(status="fresh-ish"), "an unknown evidence status must be refused")


def test_lineage_resolves_forward_and_backward():
    graph = ProvenanceGraph("RUN-PR")
    source = _ref()
    graph.add_entity("ART-1", "source", evidence=[source])
    graph.add_entity("NORM-1", "normalized_artifact", evidence=[source])
    graph.add_entity("CND-1", "candidate", evidence=[source])
    graph.add_edge("NORM-1", "ART-1", "normalized_from", evidence=[source])
    graph.add_edge("CND-1", "NORM-1", "generated_from", evidence=[source], derivation="deterministic_analyzer")
    back = graph.lineage_backward("CND-1")
    check("ART-1" in str(back), f"a candidate must trace back to its source: {back}")
    forward = graph.lineage_forward("ART-1")
    check("CND-1" in str(forward), "a source must trace forward to what it supports")
    check_raises(ProvenanceError, lambda: graph.add_entity("ART-1", "candidate"), "an entity cannot change kind")
    check_raises(ProvenanceError, lambda: graph.add_edge("ART-1", "MISSING", "derived_from", evidence=[source]),
                 "an edge to an unknown node must be refused")


def test_facts_keep_source_analyzer_and_model_claims_separate():
    graph = ProvenanceGraph("RUN-PR2")
    source = _ref()
    analyzer_ref = _ref(derivation="deterministic_analyzer", analyzer="graph_traversal")
    graph.add_entity("CND-1", "candidate", evidence=[source])
    graph.record_fact(subject="CND-1", statement="the workspace declares two services", derivation="source", evidence=[source])
    graph.record_fact(subject="CND-1", statement="the call chain is two hops deep", derivation="deterministic_analyzer",
                      evidence=[analyzer_ref], analyzer="graph_traversal")
    report = graph.separation_report()
    check_eq(report["source"], 1, "one source fact")
    check_eq(report["deterministic_analyzer"], 1, "one analyzer fact")
    check_eq(report.get("model_inference", 0), 0, "no model inference was recorded")
    check(len(graph.facts(derivation="source")) == 1, "facts are filterable by derivation")


def test_dangling_references_are_reported_not_hidden():
    graph = ProvenanceGraph("RUN-PR3")
    source = _ref()
    graph.add_entity("CND-1", "candidate", evidence=[source])
    check_eq(graph.dangling(), [], "a well-formed graph has no dangling references")
    doc = graph.as_document()
    check(doc["entities"] and doc["run_id"] == "RUN-PR3", "the graph exports its entities and run")
    check("separation" in doc or "facts" in doc, "the export must carry the derivation separation")


if __name__ == "__main__":
    import test_provenance
    raise SystemExit(main(test_provenance))
