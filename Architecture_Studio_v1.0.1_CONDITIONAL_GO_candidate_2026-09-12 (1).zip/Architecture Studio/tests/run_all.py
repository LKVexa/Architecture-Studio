#!/usr/bin/env python3
"""Run the Architecture Studio test suite, one control class at a time.

Per-class execution is the point: the owner's device runs each module in its own
invocation under a time cap, and CI runs them all. ``--json`` emits the machine
report the release/evidence tooling consumes; ``--list`` names the modules.

Usage:
    python3 tests/run_all.py                 # every module
    python3 tests/run_all.py test_policy     # one module
    python3 tests/run_all.py --json report.json
"""
from __future__ import annotations

import argparse
import importlib
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))

from harness import run_module  # noqa: E402

#: Ordered by control class; the registry's CONTROL_OWNERSHIP names these files.
MODULES = [
    "test_registry",
    "test_schemas_contracts",
    "test_authority_scope",
    "test_policy",
    "test_ledger_store",
    "test_provenance",
    "test_connectors",
    "test_analysis",
    "test_uncertainty_grounding",
    "test_generator",
    "test_approvals_review",
    "test_security",
    "test_observability_ops",
    "test_benchmark_evaluation",
    "test_environments_release",
    "test_docs_gates",
    "test_e2e",
    "test_asfw",
    "test_roster",
    "test_asgo",
]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("modules", nargs="*", help="modules to run (default: all)")
    parser.add_argument("--json", type=Path, help="write the machine-readable report here")
    parser.add_argument("--list", action="store_true", help="list the modules and exit")
    args = parser.parse_args()
    if args.list:
        print("\n".join(MODULES))
        return 0
    names = args.modules or MODULES
    unknown = [n for n in names if n not in MODULES]
    if unknown:
        print(f"unknown module(s): {unknown}", file=sys.stderr)
        return 2
    started = time.time()
    reports = []
    for name in names:
        print(f"\n== {name} ==")
        module = importlib.import_module(name)
        reports.append(run_module(module))
    total = sum(r["total"] for r in reports)
    passed = sum(r["passed"] for r in reports)
    failures = [f for r in reports for f in r["failed"]]
    report = {"suites": reports, "total": total, "passed": passed, "failed": len(failures),
              "all_passed": not failures and total > 0, "seconds": round(time.time() - started, 2),
              "modules": names}
    print(f"\n{passed}/{total} tests passed across {len(names)} module(s) in {report['seconds']}s")
    for failure in failures:
        print(f"  FAILED {failure['test']}: {failure['detail'].splitlines()[-1] if failure['detail'] else ''}")
    if args.json:
        args.json.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        print(f"report written to {args.json}")
    return 0 if report["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
