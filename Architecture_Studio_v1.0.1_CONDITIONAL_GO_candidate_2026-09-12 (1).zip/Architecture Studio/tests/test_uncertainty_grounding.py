"""Uncertainty, abstention, grounding and conflicts (XUNC-01..06, PAPER-CAP-02, PAPER-CAP-05, AUDIT-ADD-07/08)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main  # noqa: E402

from architecture_studio.assumptions import AssumptionRegistry, unlabelled_assertions  # noqa: E402
from architecture_studio.fixtures import make_index, make_scope  # noqa: E402
from architecture_studio.grounding import detect_conflicts, evaluate_grounding  # noqa: E402
from architecture_studio.questions import answer_question, detect_gaps, material_open, raise_questions  # noqa: E402
from architecture_studio.uncertainty import (ABSTENTION_CODES, Thresholds, assess, must_abstain,  # noqa: E402
                                             route_for_review)
from architecture_studio.schemas import validate  # noqa: E402

_SCOPE = make_scope("RUN-U", classes=("requirement", "service", "deployment_standard"))
_INDEX, _, _ = make_index(_SCOPE)


def _refs(data_class="requirement", n=3):
    return [r["provenance_ref_id"] for r in sorted(_INDEX.by_class(data_class), key=lambda r: r["record_id"])[:n]]


def test_no_numeric_confidence_is_invented():
    a = assess(evidence_refs=_refs())
    doc = a.as_document()
    validate("as.uncertainty/1", doc)
    check(doc["confidence"] is None or doc["calibrated"], "an uncalibrated numeric confidence must not be presented")
    check(doc["state"] in ("known", "supported", "inferred", "uncertain", "stale", "missing", "out_of_scope"),
          f"unexpected state {doc['state']!r}")
    check(a.human_sentence(), "the assessment must be expressible as a human sentence")


def test_every_abstention_has_a_typed_code_and_reason():
    cases = {
        "INSUFFICIENT_EVIDENCE": assess(evidence_refs=[]),
        "OUT_OF_SCOPE": assess(evidence_refs=_refs(), out_of_scope=True),
        "POLICY_STOP": assess(evidence_refs=_refs(), policy_stop=True),
        "PROVIDER_UNAVAILABLE": assess(evidence_refs=_refs(), provider_unavailable=True),
        "GENERIC_FALLBACK": assess(evidence_refs=_refs(), generic_fallback=True),
    }
    for expected, assessment in cases.items():
        check_eq(assessment.abstention_code, expected, f"abstention code for {expected}")
        check(assessment.abstained, f"{expected} must abstain")
        check(assessment.rationale, f"{expected} must carry a rationale")
        check(expected in ABSTENTION_CODES, f"{expected} is not a declared code")


def test_failing_closed_never_needs_approval():
    a = assess(evidence_refs=[])
    check(must_abstain(a), "an evidence-free assessment must abstain")
    check(must_abstain(a, Thresholds(min_evidence_refs=0)), "abstention already decided is not undone by a laxer threshold")


def test_thresholds_are_proposed_and_do_not_grant_passage():
    t = Thresholds()
    check_eq(t.status, "PROPOSED", "thresholds ship PROPOSED")
    check(not t.approved, "a PROPOSED threshold is not approved")
    approved = Thresholds(status="APPROVED", approval_ref="AUTH-1")
    check(approved.approved, "an approved threshold names its approval")
    check(not Thresholds(status="APPROVED").approved, "APPROVED without an approval reference is not approved")


def test_high_impact_and_uncertain_states_route_to_review():
    uncertain = assess(evidence_refs=_refs(n=1), inferred_fraction=0.9, high_impact=True)
    check(route_for_review(uncertain) or must_abstain(uncertain), "a high-impact inferred claim must escalate")


def test_grounding_counts_material_elements_and_flags_generic_fallback():
    from architecture_studio.candidates import build_candidate, component, relationship
    refs = _refs(n=2)
    grounded = build_candidate(run_id="RUN-U1", iteration=1, name="grounded", style="modular_monolith",
                               components=[component("c1", "Alpha", "service", evidence_refs=refs)],
                               relationships=[], deployment={"topology": "single", "environments": ["local"],
                                                             "standard_refs": [], "evidence_refs": _refs("deployment_standard", 1)},
                               rationale=[{"text": "cited", "derivation": "source", "evidence_refs": refs}],
                               evidence_refs=refs, uncertainty=assess(evidence_refs=refs).as_document(),
                               generator={"generator_id": "t", "generator_version": "1", "model": None}, introduced_by="t")
    report = evaluate_grounding(grounded, _INDEX)
    check_eq(report.coverage, 1.0, "a fully cited candidate must be fully grounded")
    check(report.sufficient, "a fully cited candidate is sufficient")

    generic = build_candidate(run_id="RUN-U2", iteration=1, name="generic", style="microservices",
                              components=[component("g1", "API Gateway", "service", derivation="model_inference")],
                              relationships=[], deployment={"topology": "multi", "environments": ["prod"],
                                                            "standard_refs": [], "evidence_refs": []},
                              rationale=[{"text": "standard pattern", "derivation": "model_inference", "evidence_refs": []}],
                              evidence_refs=[], uncertainty=assess(evidence_refs=[]).as_document(),
                              generator={"generator_id": "t", "generator_version": "1", "model": None}, introduced_by="t")
    gr = evaluate_grounding(generic, _INDEX)
    check(gr.generic_fallback, "an uncited generic design must be flagged as generic fallback")
    check(not gr.sufficient, "an uncited generic design is not sufficient")
    check("requirement" in gr.required_classes_missing, "a candidate citing no requirement must say so")


def test_seeded_unsupported_assertions_are_caught_before_review():
    from architecture_studio.candidates import build_candidate, component
    registry = AssumptionRegistry("RUN-U3")
    candidate = build_candidate(run_id="RUN-U3", iteration=1, name="seeded", style="modular_monolith",
                                components=[component("c1", "Invented Service", "service", derivation="model_inference")],
                                relationships=[], deployment={"topology": "single", "environments": ["local"],
                                                              "standard_refs": [], "evidence_refs": []},
                                rationale=[{"text": "the platform obviously needs a cache", "derivation": "model_inference",
                                            "evidence_refs": []}],
                                evidence_refs=[], uncertainty=assess(evidence_refs=[]).as_document(),
                                generator={"generator_id": "t", "generator_version": "1", "model": None}, introduced_by="t")
    problems = unlabelled_assertions(candidate, registry)
    check(problems, "a seeded unsupported assertion must be detected")
    registry.register("the platform obviously needs a cache", status="inferred", introduced_by="t",
                      affected_candidates=[candidate["candidate_id"]])
    registry.register("Invented Service", status="inferred", introduced_by="t", affected_candidates=[candidate["candidate_id"]])
    remaining = unlabelled_assertions(candidate, registry)
    check(len(remaining) < len(problems), "registering the assumption must reduce the unlabelled set")
    check(registry.entries(), "the registry must hold the assumption")


def test_conflicts_and_material_questions_pause_progression():
    stale = sorted({r["artifact_id"] for r in list(_INDEX.records.values())[:3]})
    conflicts = detect_conflicts("RUN-U4", _INDEX, stale_artifacts=stale)
    check(conflicts, "stale-vs-current evidence must produce conflict records")
    for conflict in conflicts[:3]:
        validate("as.conflict/1", dict(conflict))
    kinds = sorted({c["kind"] for c in conflicts})
    check("stale_revision" in kinds, f"stale evidence must be reported as a conflict, got {kinds}")
    # A gap that materially changes the feasible options must become a question a human answers.
    gaps = detect_gaps(candidates=[], conflicts=conflicts, assumptions=[{"assumption_id": "ASM-1", "status": "inferred",
                                                                        "statement": "the queue depth is unbounded",
                                                                        "affected_candidates": ["CND-1"]}],
                       constraint_checks={"CND-1": [{"result": "unknown", "family": "cost_performance",
                                                     "rule_id": "RULE-COST-ENV-01", "candidate_id": "CND-1"}]},
                       diagram_ambiguities=1)
    check(gaps, "unknown cost checks, open assumptions and diagram ambiguities are gaps")
    questions = raise_questions("RUN-U4", gaps)
    check(questions, "gaps must raise clarifying questions")
    for q in questions[:3]:
        validate("as.question/1", dict(q))
        check(q["materiality_rule"], "every question must name the rule that makes it material")
        check(q["materiality"] in ("material", "nonmaterial"), "materiality must be typed")
    material = material_open(questions)
    check(isinstance(material, list), "material questions must be enumerable")
    check_raises(PermissionError, lambda: answer_question(questions[0], answer="fine", principal=None),
                 "only a human principal may answer a clarifying question")


if __name__ == "__main__":
    import test_uncertainty_grounding
    raise SystemExit(main(test_uncertainty_grounding))
