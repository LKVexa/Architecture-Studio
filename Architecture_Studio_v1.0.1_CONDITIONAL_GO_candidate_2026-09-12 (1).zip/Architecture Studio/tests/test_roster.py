"""Roster intake: a chat signature is not a binding, review, or Production GO."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.gates import GATES, evaluate_gates, production_verdict  # noqa: E402
from architecture_studio.gate_evidence import load_external_authority  # noqa: E402
from architecture_studio.roster import (  # noqa: E402
    INDEPENDENT_ROLES, RECEIVED_CHAT_OFFER, REQUIRED_ROLES, RosterError, bind_role,
    export_roster, interpret_as_review, offer_principal, record_source_gap_decision,
    roster_document,
)


def test_chat_signature_is_an_unbound_offer_not_a_binding():
    offer = offer_principal(RECEIVED_CHAT_OFFER)
    check_eq(offer["display_name"], "RUSSELL PHILIP SMITHSON", "name preserved")
    check_eq(offer["title"], "Research Specialist", "title preserved")
    check_eq(offer["organization"], "LK/Vexa", "org preserved")
    check_eq(offer["status"], "PROPOSED_UNBOUND", "must not auto-bind")
    check_eq(offer["unblocks_go"], False, "an offer is not GO")
    check_eq(offer["independence"]["status"], "NOT_ESTABLISHED", "same-session chat is not independent")
    check(offer["independence"]["same_session_as_implementer"], "channel is the implementer session")
    check(not offer["independence"]["idp_bound"], "no IdP subject was supplied")
    check_eq(offer["eligible_roles"], ["research_specialist"], "title maps to consulted research only")
    check(not offer["bound_roles"], "no role is bound")
    for role in INDEPENDENT_ROLES:
        check(role in offer["refused_roles"], f"{role} must be refused for this title/channel")


def test_one_person_cannot_fill_the_roster_or_independent_slots():
    document = roster_document(offer=RECEIVED_CHAT_OFFER)
    check_eq(document["bound_count"], 0, "required roles stay UNSET")
    check_eq(len(document["rows"]), len(REQUIRED_ROLES), "every required role is listed")
    check(all(row["status"] == "UNSET" and row["subject"] is None for row in document["rows"]),
          "do not stamp one name onto every role")
    check_eq(document["production_go"], "NO_GO", "unbound roster is NO_GO")
    check_eq(document["consulted_proposed"][0]["role"], "research_specialist", "consulted proposal only")

    check_raises(RosterError, lambda: bind_role("independent_verifier", RECEIVED_CHAT_OFFER),
                 "chat offer cannot bind independent_verifier")
    check_raises(RosterError, lambda: bind_role("architecture_owner", RECEIVED_CHAT_OFFER),
                 "Research Specialist cannot bind architecture_owner")
    check_raises(RosterError, lambda: bind_role("release_owner", RECEIVED_CHAT_OFFER),
                 "Research Specialist cannot bind release_owner")

    idp_offer = {
        "display_name": "RUSSELL PHILIP SMITHSON",
        "title": "Research Specialist",
        "organization": "LK/Vexa",
        "idp_subject": "russell@example.test",
        "channel": "host_idp",
    }
    bound = bind_role("research_specialist", idp_offer)
    check_eq(bound["status"], "BOUND", "consulted role may bind once IdP-independent")
    check_raises(
        RosterError,
        lambda: bind_role("independent_architecture_reviewer", idp_offer, already_bound={"research_specialist": "russell@example.test"}),
        "title still cannot take an independent review role",
    )


def test_chat_signature_is_not_a_gate_or_asfw_review():
    check_raises(RosterError, lambda: interpret_as_review(RECEIVED_CHAT_OFFER, gate_id="GATE-PROD-01"),
                 "must not become GATE-PROD-01 PASS")
    check_raises(RosterError, lambda: interpret_as_review(RECEIVED_CHAT_OFFER, item_id="ASFW-TODO-0001"),
                 "must not verify ASFW-TODO-0001")


def test_source_gaps_stay_undefined_and_do_not_unblock_go():
    dod = record_source_gap_decision("DOD", "KEEP_UNDEFINED_STILL_BLOCKING", offer=RECEIVED_CHAT_OFFER)
    check_eq(dod["unblocks_go"], False, "keep-undefined does not unblock GO")
    check(dod["invented_definitions"] is False, "no DOD text invented")
    check(all(dod["definitions"][k] is None for k in dod["missing_ids"]), "definitions remain None")
    gate = record_source_gap_decision("GATE_COUNT", "DO_NOT_INFER_STILL_BLOCKING", offer=RECEIVED_CHAT_OFFER)
    check_eq(gate["executable_count"], 8, "eight executable gates")
    check_eq(len(GATES), 8, "runtime still has eight gates")
    check(gate["ninth_gate_invented"] is False, "no ninth gate")
    check(gate["ninth_gate_id"] is None, "ninth id stays None")
    check(gate["registry_and_pdf_agree"] is False, "disagreement remains")
    check_eq(gate["unblocks_go"], False, "disagreement still blocks GO")
    check_raises(RosterError, lambda: record_source_gap_decision("DOD", "INVENT_DOD_TEXT"),
                 "inventing DOD text is forbidden")
    check_raises(RosterError, lambda: record_source_gap_decision("GATE_COUNT", "ADD_NINTH_GATE"),
                 "adding a ninth gate is forbidden")
    check_raises(RosterError, lambda: record_source_gap_decision("DOD", "UNBLOCK_GO"),
                 "cannot unblock GO from a gap decision")


def test_export_does_not_create_gate_pass_files():
    with tempdir() as root:
        dod = record_source_gap_decision("DOD", "KEEP_UNDEFINED_STILL_BLOCKING", offer=RECEIVED_CHAT_OFFER)
        gate = record_source_gap_decision("GATE_COUNT", "DO_NOT_INFER_STILL_BLOCKING", offer=RECEIVED_CHAT_OFFER)
        document = roster_document(offer=RECEIVED_CHAT_OFFER, dod_decision=dod, gate_decision=gate)
        exported = export_roster(root, document=document)
        check("roster-proposal.json" in exported["written"], "proposal written")
        check("DEC-ASFW-0007.json" in exported["written"], "DOD keep-undefined written")
        check("DEC-ASFW-0008.json" in exported["written"], "gate-count keep-undefined written")
        check_eq(exported["production_go"], "NO_GO", "export is not GO")
        for gate_id in (g.gate_id for g in GATES):
            check(not (root / f"{gate_id}.json").exists(), f"must not write {gate_id}.json")
        nested = root / "evidence" / "reviews"
        nested.mkdir(parents=True)
        for name in exported["written"]:
            (nested / name).write_text((root / name).read_text(encoding="utf-8"), encoding="utf-8")
        loaded = load_external_authority(root)
        check_eq(loaded["reviews"], {}, "keep-undefined records must not load as gate reviews")
        check(loaded["security_review"] is None, "must not invent a security review")
        report = evaluate_gates({}, reviews=loaded["reviews"], builder_subjects=loaded["builder_subjects"])
        check_eq(production_verdict(report)["verdict"], "NO_GO", "still NO_GO")
        proposal = json.loads((root / "roster-proposal.json").read_text(encoding="utf-8"))
        check_eq(proposal["offer"]["display_name"], "RUSSELL PHILIP SMITHSON", "name on file")
        check_eq(proposal["bound_count"], 0, "still unbound")


if __name__ == "__main__":
    import test_roster
    raise SystemExit(main(test_roster))
