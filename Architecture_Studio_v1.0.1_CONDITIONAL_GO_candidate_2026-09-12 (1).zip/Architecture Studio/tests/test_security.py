"""Classification, secrets, injection isolation, tool-call validation, the write gate,
encryption, retention, sandboxing and supply chain (SEC-01..06, XSEC-01..07, XTOOL-01..05, COMP-*, AUDIT-ADD-14..17)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.approvals import ApprovalService  # noqa: E402
from architecture_studio.authority import IdentityProvider  # noqa: E402
from architecture_studio.crypto import (EncryptionIntegrityError, EncryptionUnavailable, EnvelopeEncryptor,  # noqa: E402
                                        LocalKeyProvider, NullKeyProvider, backend_available, status)
from architecture_studio.fixtures import FIXTURES_ROOT, make_scope  # noqa: E402
from architecture_studio.ledger import Ledger  # noqa: E402
from architecture_studio.retention import RETENTION_POLICY, anonymize, enforce, policy_for  # noqa: E402
from architecture_studio.sandbox import Sandbox, SandboxPolicy  # noqa: E402
from architecture_studio.security import (MATRIX, SecurityError, TenancyError, TenantCanary, assert_no_cross_tenant,  # noqa: E402
                                          canonicalize_argument, classify, classify_output, isolate_content,
                                          policy_decision, redact, scan_for_injection, scan_for_secrets,
                                          validate_tool_call)
from architecture_studio.store import ObjectStore  # noqa: E402
from architecture_studio.supply_chain import inventory, policy_check, sbom, third_party_runtime_imports  # noqa: E402
from architecture_studio.workflow import WorkflowMachine, WorkflowState  # noqa: E402
from architecture_studio.writes import WriteDenied, WriteGate  # noqa: E402

_SCOPE = make_scope("RUN-SEC")
_KEY = b"a-test-approval-key-32-bytes-long"
_ADVERSARIAL = FIXTURES_ROOT / "adversarial"


def _human(subject="approver@example.test"):
    idp = IdentityProvider()
    idp.enroll(subject, "human", "secret-value")
    idp.enroll("svc-runner", "service", "svc-secret")
    return idp, idp.authenticate(subject, "secret-value"), idp.authenticate("svc-runner", "svc-secret")


def test_secrets_are_detected_and_never_echoed():
    text = "token ghp_1234567890abcdefghijklmnopqrstuvwxyz1234 and AKIAIOSFODNN7EXAMPLE"
    findings = scan_for_secrets(text)
    check(findings, "obvious credentials must be detected")
    for finding in findings:
        doc = finding.as_document()
        check("excerpt_digest" in doc and "excerpt" not in doc, "a secret finding must not carry the secret itself")
    level, secrets = classify(text)
    check_eq(level, "secret", "text containing a credential classifies as secret")
    redacted, count = redact(text)
    check(count >= 1, "redaction must report what it removed")
    check("ghp_" not in redacted and "AKIA" not in redacted, "the credential must not survive redaction")


def test_the_classification_matrix_denies_before_it_redacts():
    check_eq(policy_decision("secret", "model_context"), "deny", "a secret must never reach the model")
    check_eq(policy_decision("secret", "export"), "deny", "a secret must never be exported")
    check_eq(policy_decision("public", "model_context"), "allow", "public content may reach the model")
    check_eq(policy_decision("internal", "cross_boundary"), "deny", "internal content must not cross a boundary")
    for level, destinations in MATRIX.items():
        for destination in destinations:
            decision = policy_decision(level, destination)
            check(decision in ("allow", "redact", "deny"), f"{level}->{destination} has decision {decision!r}")
    result = classify_output("here is a summary", destination="export", declared_inputs=["internal"])
    check(result["decision"] in ("allow", "redact", "deny"), "output classification must decide")


def test_retrieved_content_is_data_never_instructions():
    attacks = json.loads((_ADVERSARIAL / "bipia" / "text_attack_test.json").read_text(encoding="utf-8"))
    samples = [item for items in attacks.values() for item in items][:40]
    for text in samples:
        block = isolate_content(text, source_label="bipia")
        check_eq(block["channel"], "data", "retrieved content must land in the data channel")
        check(block["trusted"] is False, "retrieved content is never trusted")
        check("authority" in block["boundary"], "the boundary statement must say authority is not read from content")
    flagged = sum(1 for t in samples if scan_for_injection(t))
    check(flagged > 0, "the injection detector must flag at least some known attack instructions")
    benign = json.loads((_ADVERSARIAL / "llmail" / "fp_tests.json").read_text(encoding="utf-8"))["emails"][:60]
    false_positives = sum(1 for t in benign if scan_for_injection(t))
    check(false_positives == 0, f"benign controls must not be flagged, got {false_positives}")


def test_tool_arguments_are_canonicalized_and_dangerous_calls_refused():
    check_eq(canonicalize_argument("path", "a/./b", kind="path"), "a/b", "paths are canonicalized")
    for bad, kind in (("../escape", "path"), ("/absolute", "path"), ("a\x00b", "string"), ("rm -rf /; echo", "command")):
        check_raises(SecurityError, lambda b=bad, k=kind: canonicalize_argument("arg", b, kind=k),
                     f"{bad!r} must be refused as a {kind} argument")


def test_a_model_originated_mutating_call_is_refused():
    with tempdir() as root:
        ledger = Ledger(root / "ledger.jsonl", "RUN-SEC")
        call = {"schema_id": "as.tool_call/1", "tool": "write_file", "tool_version": "1.0.0", "arguments": {"path": "x"},
                "requested_permission": "modify", "requested_paths": ["x"], "requested_source_systems": [],
                "external_system": None, "actor_kind": "model", "idempotency_key": "K1"}
        check_raises(Exception, lambda: validate_tool_call(call, _SCOPE, ledger=ledger),
                     "a model-originated mutating call must be refused")
        read_call = {"schema_id": "as.tool_call/1", "tool": "read_file", "tool_version": "1.0.0",
                     "arguments": {"path": "a/b.md"}, "requested_permission": "read", "requested_paths": ["a/b.md"],
                     "requested_source_systems": ["requirements"], "external_system": None, "actor_kind": "service",
                     "idempotency_key": "K2"}
        validated = validate_tool_call(read_call, _SCOPE, argument_kinds={"path": "path"}, ledger=ledger)
        check(validated, "an in-scope read call is allowed")
        events = [e["event"]["event_type"] for e in ledger.events()]
        check(any("denied" in e or e == "tool.call" for e in events), f"tool decisions must be recorded: {events}")


def test_cross_tenant_evidence_is_refused_and_canaries_detect_leaks():
    records = [{"record_id": "R1", "tenant": "linearfinance", "project": "project"},
               {"record_id": "R2", "tenant": "other-tenant", "project": "project"}]
    check_raises(TenancyError, lambda: assert_no_cross_tenant(records, tenant="linearfinance"),
                 "a foreign tenant record must be refused")
    assert_no_cross_tenant(records[:1], tenant="linearfinance")
    canary = TenantCanary("other-tenant", "CANARY-9f3a-other-tenant")
    check(canary.leaked_into("the answer mentions CANARY-9f3a-other-tenant", tenant="linearfinance"),
          "a canary token from another tenant in output must be detected")
    check(not canary.leaked_into("a clean answer", tenant="linearfinance"), "clean output must not trip the canary")


def test_the_write_gate_truth_table():
    with tempdir() as root:
        ledger = Ledger(root / "ledger.jsonl", "RUN-SEC")
        service = ApprovalService(key=_KEY, issuer="as.test", key_id="test", ledger=ledger)
        _, human, service_principal = _human()
        machine = WorkflowMachine("RUN-SEC")
        scope = make_scope("RUN-SEC")
        output = root / "out"
        subject = "sha256:" + "4" * 64

        def gate(state_ready=True):
            m = WorkflowMachine("RUN-SEC")
            if state_ready:
                for event in ("authority_established", "revisions_pinned", "collect_evidence", "evidence_indexed",
                              "analysis_complete", "candidates_generated", "verification_passed", "submit_for_review"):
                    m.fire(event, actor="svc", actor_kind="service")
                m.fire("approve", actor=human.subject, actor_kind="human", authority_ref="AUTH-1")
            return WriteGate(service=service, scope=scope, machine=m, output_root=output, ledger=ledger,
                             permission="write_evidence")

        def token(**kw):
            args = {"run_id": "RUN-SEC", "gate": "final_selection", "artifact_ids": ["CND-1"], "action": "write",
                    "scope_digest": scope.scope_digest, "subject_digest": subject}
            args.update(kw)
            return service.issue(approver=human, **args)

        base = {"actor": human, "target": "RUN-SEC/out.json", "payload": b'{"a":1}', "artifact_ids": ["CND-1"],
                "subject_digest": subject, "run_id": "RUN-SEC", "gate": "final_selection"}

        rows = []

        def denied(name, code, **overrides):
            g = overrides.pop("gate_obj", None) or gate()
            args = {**base, "token": token(), **overrides}
            exc = check_raises(WriteDenied, lambda: g.attempt(**args), f"row {name!r} must be denied")
            check_eq(exc.code, code, f"row {name!r} denial code")
            rows.append((name, code))

        denied("no token", "write.token_missing", token=None)
        denied("unauthenticated actor", "write.actor_unauthenticated", actor="approver@example.test")
        denied("not approved yet", "write.state_not_approved", gate_obj=gate(state_ready=False))
        denied("wrong run", "write.run_mismatch", run_id="RUN-OTHER")
        denied("path escape", "write.target_unresolvable", target="../escape.json")
        denied("empty payload", "write.empty_payload", payload=b"")
        denied("wrong artifacts", "approval.artifact_mismatch", artifact_ids=["CND-9"])
        denied("changed subject", "approval.subject_changed", subject_digest="sha256:" + "5" * 64)

        # The genuine positive: everything present, exactly once.
        good = gate()
        receipt = good.attempt(**{**base, "token": token()})
        written = output / "RUN-SEC" / "out.json"
        check(written.exists(), "an approved write must actually write")
        check_eq(written.read_bytes(), b'{"a":1}', "the written bytes must match the payload")
        check(len(rows) == 8, f"the write-gate truth table must cover every omission, got {len(rows)}")

        # A preview must not write and must not burn the approval.
        preview_gate = gate()
        preview_token = token()
        preview = preview_gate.preview(**{**base, "target": "RUN-SEC/preview.json", "token": preview_token})
        check(not (output / "RUN-SEC" / "preview.json").exists(), "a preview must not write")
        check(preview, "a preview must report what would happen")
        preview_gate.attempt(**{**base, "target": "RUN-SEC/preview.json", "token": preview_token})
        check((output / "RUN-SEC" / "preview.json").exists(), "the previewed write must still be possible")


def test_the_write_gate_bundle_confines_every_file_and_rolls_back():
    with tempdir() as root:
        ledger = Ledger(root / "ledger.jsonl", "RUN-SEC")
        service = ApprovalService(key=_KEY, issuer="as.test", key_id="test", ledger=ledger)
        _, human, _ = _human()
        machine = WorkflowMachine("RUN-SEC")
        for event in ("authority_established", "revisions_pinned", "collect_evidence", "evidence_indexed",
                      "analysis_complete", "candidates_generated", "verification_passed", "submit_for_review"):
            machine.fire(event, actor="svc", actor_kind="service")
        machine.fire("approve", actor=human.subject, actor_kind="human", authority_ref="AUTH-1")
        scope = make_scope("RUN-SEC")
        gate = WriteGate(service=service, scope=scope, machine=machine, output_root=root / "out", ledger=ledger,
                         permission="write_evidence")
        subject = "sha256:" + "4" * 64
        token = service.issue(approver=human, run_id="RUN-SEC", gate="final_selection", artifact_ids=["CND-1"],
                              action="write", scope_digest=scope.scope_digest, subject_digest=subject)
        receipts = gate.attempt_bundle(actor=human, files=[("RUN-SEC/a.json", b'{"a":1}'), ("RUN-SEC/b.json", b'{"b":2}')],
                                       token=token, artifact_ids=["CND-1"], subject_digest=subject,
                                       run_id="RUN-SEC", gate="final_selection")
        check_eq(len(receipts), 2, "bundle writes every file")
        check((root / "out" / "RUN-SEC" / "a.json").is_file() and (root / "out" / "RUN-SEC" / "b.json").is_file(),
              "both bundle files must exist")
        replay = check_raises(WriteDenied, lambda: gate.attempt_bundle(
            actor=human, files=[("RUN-SEC/replay.json", b"no")],
            token=token, artifact_ids=["CND-1"], subject_digest=subject, run_id="RUN-SEC", gate="final_selection"),
            "a consumed bundle token must not write again")
        check(replay.code.startswith("token.") or "replay" in replay.code or "nonce" in replay.code
              or "consumed" in str(replay).lower() or "replay" in str(replay).lower(),
              f"replay must be a token failure, got {replay.code}: {replay}")
        check(not (root / "out" / "RUN-SEC" / "replay.json").exists(), "a replayed bundle must write nothing")
        token2 = service.issue(approver=human, run_id="RUN-SEC", gate="final_selection", artifact_ids=["CND-1"],
                               action="write", scope_digest=scope.scope_digest, subject_digest=subject)
        exc = check_raises(WriteDenied, lambda: gate.attempt_bundle(
            actor=human, files=[("RUN-SEC/c.json", b"ok"), ("../escape.json", b"no")],
            token=token2, artifact_ids=["CND-1"], subject_digest=subject, run_id="RUN-SEC", gate="final_selection"),
            "a path escape in a bundle must be refused")
        check_eq(exc.code, "write.target_unresolvable", "bundle path escape code")
        check(not (root / "out" / "RUN-SEC" / "c.json").exists(), "a refused bundle must write nothing")


def test_write_authority_scan_finds_no_hidden_paths_and_pipeline_does_not_copy():
    from architecture_studio.write_scan import scan_write_authority
    scan = scan_write_authority()
    check_eq(scan["hidden_write_paths"], [], f"hidden write paths remain: {scan['hidden_write_paths']}")
    check(scan["write_gate_sites"] >= 1, "the scan must see the write gate")
    check_eq(scan["verdict"], "PASS", "classified persist sites with no hidden paths")
    src = (Path(__file__).resolve().parent.parent / "architecture_studio" / "pipeline.py").read_text(encoding="utf-8")
    check("shutil.copy2" not in src and "shutil.copy(" not in src,
          "case-file export must not shutil-copy around the write gate")


def test_encryption_fails_closed_and_never_claims_more_than_it_does():
    null = NullKeyProvider()
    check_raises(EncryptionUnavailable, lambda: EnvelopeEncryptor(null).encrypt(b"x"),
                 "with no key provider bound, encryption must refuse rather than write plaintext")
    report = status(null)
    check(not report["at_rest"]["in_force"], "an unbound provider must not report encryption in force")
    check(report["in_transit"]["in_force"] is None, "encryption in transit must not be claimed")
    check_eq(report["in_transit"]["responsibility"], "host", "transport encryption is a host responsibility")
    if not backend_available():
        return
    with tempdir() as root:
        provider = LocalKeyProvider(root / "kek.key")
        check_eq(oct((root / "kek.key").stat().st_mode)[-3:], "600", "the key file must not be world readable")
        enc = EnvelopeEncryptor(provider)
        envelope = enc.encrypt(b"sensitive design note", aad=b"RUN-SEC")
        check(b"sensitive" not in envelope.ciphertext.encode(), "the ciphertext must not contain the plaintext")
        check_eq(enc.decrypt(envelope, aad=b"RUN-SEC"), b"sensitive design note", "round trip")
        check_raises(EncryptionIntegrityError, lambda: enc.decrypt(envelope, aad=b"RUN-OTHER"),
                     "associated data must be bound into the envelope")
        tampered = type(envelope)(**{**envelope.__dict__, "ciphertext": envelope.ciphertext[:-4] + "AAAA"})
        check_raises(EncryptionIntegrityError, lambda: enc.decrypt(tampered, aad=b"RUN-SEC"),
                     "a tampered ciphertext must fail authentication")


def test_retention_never_deletes_audit_mandatory_classes():
    with tempdir() as root:
        ledger = Ledger(root / "ledger.jsonl", "RUN-SEC")
        store = ObjectStore(root / "store")
        store.commit("runs/RUN-SEC/ledger", {"kind": "audit"}, expected_parent=None,
                     metadata={"data_class": "ledger"}, retention_days=1)
        store.commit("runs/RUN-SEC/candidates", {"kind": "draft"}, expected_parent=None,
                     metadata={"data_class": "candidates"}, retention_days=1)
        for data_class, policy in RETENTION_POLICY.items():
            check(set(policy) >= {"fate", "days", "audit_mandatory"}, f"{data_class} has no expressible retention policy")
        for mandatory in ("ledger", "provenance", "approvals", "review"):
            check(policy_for(mandatory)["audit_mandatory"], f"{mandatory} must be audit-mandatory")
            check_eq(policy_for(mandatory)["fate"], "retain", f"{mandatory} must be retained, never erased")
        _, human, _ = _human("retention@example.test")
        result = enforce(store, ledger=ledger, dry_run=True, actor=human)
        acted_on = {a.get("ref") for a in result["actions"]}
        check("runs/RUN-SEC/ledger" not in acted_on, f"retention must never act on the audit trail: {result['actions']}")
        refused = {r["ref"]: r["reason"] for r in result["refused"]}
        check("runs/RUN-SEC/ledger" in refused, "the refusal to expire the audit trail must be explicit")
        check("audit-mandatory" in refused["runs/RUN-SEC/ledger"], f"the refusal must name the reason: {refused}")
        check(result["ledger_intact_after"], "the audit trail must remain intact after enforcement")
        anonymized = anonymize({"subject": "person@example.test", "note": "kept"})
        check("person@example.test" not in json.dumps(anonymized), "anonymization must remove the identifier")
        check("note" in anonymized, "anonymization must keep non-identifying fields")


def test_the_sandbox_bounds_execution_and_reports_its_real_isolation():
    sandbox = Sandbox(SandboxPolicy(timeout_seconds=2))
    ok = sandbox.run_python("print('hello')")
    check(ok.exit_code == 0 and "hello" in ok.stdout, f"a simple program must run: {ok}")
    slow = sandbox.run_python("import time\ntime.sleep(30)")
    check(slow.timed_out, "a program past the timeout must be killed")
    report = ok.enforcement
    check_eq(report["isolation_class"], "process-level", "the sandbox must state its real isolation class")
    check(report.get("network") in (None, "not_enforced", "inherited") or "network" in report,
          "the sandbox must be explicit about network enforcement")


def test_the_runtime_needs_no_third_party_packages():
    imports = third_party_runtime_imports()
    names = {name for names in imports.values() for name in names}
    check(names <= {"cryptography"}, f"unexpected third-party runtime imports: {imports}")
    for module, names in imports.items():
        check(module in ("approvals.py", "crypto.py"), f"{module} must not import a third-party package")
    inv = inventory()
    document = sbom(inv)
    check(document["spdxVersion"].startswith("SPDX-2.3"), "the SBOM must declare its SPDX version")
    check(document["packages"], "the SBOM must list packages")
    check_eq(policy_check(inv)["verdict"], "PASS", "the supply-chain policy must pass")


if __name__ == "__main__":
    import test_security
    raise SystemExit(main(test_security))
