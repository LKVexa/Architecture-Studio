"""Observability, alerting, incident response and the kill-switch drill
(ARCH-10, XOBS-01..05, AUDIT-ADD-13/19/20/26, WF-12)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main, tempdir  # noqa: E402

from architecture_studio.assumptions import AssumptionRegistry  # noqa: E402
from architecture_studio.authority import IdentityProvider, Principal  # noqa: E402
from architecture_studio.fixtures import make_index, make_scope  # noqa: E402
from architecture_studio.generator import Generator, ProviderSlot, RecordedProvider  # noqa: E402
from architecture_studio.incident import FlagError, FlagStore, Quarantine, drill  # noqa: E402
from architecture_studio.ledger import Ledger  # noqa: E402
from architecture_studio.observability import (ALERT_RULES, INSUFFICIENT_DATA, GroundTruthScorer, Metrics, Rate,  # noqa: E402
                                               StructuredLogger, Telemetry, Tracer, evaluate_alerts)
from architecture_studio.retrieval import RetrievalIndex  # noqa: E402
from architecture_studio.slo import CEILINGS, TARGETS, effective_ceilings, evaluate_targets  # noqa: E402

_SCOPE = make_scope("RUN-OPS", classes=("requirement", "service"))


def _people():
    idp = IdentityProvider()
    idp.enroll("operator@example.test", "human", "operator-secret")
    idp.enroll("svc-runner", "service", "svc-secret")
    return idp, idp.authenticate("operator@example.test", "operator-secret")


def test_structured_logs_redact_before_emission():
    logger = StructuredLogger()
    record = logger.emit("test", api_key="super-secret", note="token ghp_1234567890abcdefghijklmnopqrstuvwxyz1234")
    check_eq(record["api_key"], "[REDACTED:field]", "a sensitive field name must be redacted wholesale")
    check("ghp_" not in record["note"], "a credential inside free text must be redacted")
    check(logger.sink and logger.sink[-1].startswith("{"), "each event must be one JSON object")


def test_rates_always_carry_their_denominator():
    metrics = Metrics()
    empty = metrics.rate("model.abstained", "model.calls")
    check(empty.value is None, "a rate over zero observations must not be 1.0 or 0.0")
    check_eq(empty.as_document()["state"], INSUFFICIENT_DATA, "an empty rate must say so")
    metrics.increment("model.calls", 4)
    metrics.increment("model.abstained", 1)
    rate = metrics.rate("model.abstained", "model.calls")
    check_eq(rate.value, 0.25, "rate value")
    check_eq(rate.as_document()["of"], 4, "the denominator travels with the rate")
    check_raises(ValueError, lambda: Rate("impossible", 5, 2, "calls"), "a numerator above its denominator is impossible")
    snapshot = metrics.snapshot()
    for name, doc in snapshot["rates"].items():
        check("of" in doc and "state" in doc, f"rate {name} lacks its denominator or state")


def test_one_span_tree_per_run_records_order():
    tracer = Tracer("RUN-OPS")
    with tracer.span("retrieval"):
        with tracer.span("analyzer.schema_check"):
            pass
    with tracer.span("model.generate"):
        pass
    doc = tracer.as_document()
    check_eq(doc["span_count"], 3, "every span must be recorded")
    check(doc["trace_digest"], "the trace must be digestible for the case file")
    check(min(tracer.order_of("analyzer")) < min(tracer.order_of("model")), "the trace preserves order")
    try:
        with tracer.span("failing"):
            raise RuntimeError("boom")
    except RuntimeError:
        pass
    failed = [s for s in tracer.spans if s.name == "failing"]
    check(failed and failed[0].status.startswith("error:"), "a failing span must record its error status")


def test_alerts_fire_on_permission_anomalies_not_only_errors():
    ids = {rule.rule_id for rule in ALERT_RULES}
    for required in ("ALERT-WRITE-01", "ALERT-PERM-01", "ALERT-EXT-01", "ALERT-SELFAPP-01", "ALERT-KILL-01"):
        check(required in ids, f"{required} is not declared")
    metrics = Metrics()
    events = [
        {"event": {"event_type": "artifact.write", "outcome": "denied", "actor_kind": "service"},
         "detail": {"permission": "modify"}},
        {"event": {"event_type": "tool.call", "outcome": "allowed", "actor_kind": "service"},
         "detail": {"permission": "network_read"}},
        {"event": {"event_type": "connector.denied", "outcome": "denied", "actor_kind": "service"},
         "detail": {"reason": "foreign tenant", "external": True}},
        {"event": {"event_type": "review.decision", "outcome": "recorded", "actor_kind": "service"}, "detail": {}},
    ]
    alerts = evaluate_alerts(events=events, metrics=metrics, baseline_permissions=["read", "analyze", "draft"])
    fired = {a["rule_id"] for a in alerts}
    for expected in ("ALERT-WRITE-01", "ALERT-PERM-01", "ALERT-EXT-01", "ALERT-SELFAPP-01"):
        check(expected in fired, f"{expected} should have fired: {fired}")
    metrics.increment("policy.evaluations", 10)
    metrics.increment("policy.denied", 5)
    check("ALERT-DENY-01" in {a["rule_id"] for a in evaluate_alerts(events=[], metrics=metrics)},
          "a high denial rate must alert")


def test_ground_truth_scoring_reports_both_error_directions():
    scorer = GroundTruthScorer()
    check_eq(scorer.scores()["state"], INSUFFICIENT_DATA, "no observations means no scores")
    for predicted, actual in ((True, True), (True, False), (False, True), (False, False)):
        scorer.add(predicted=predicted, actual=actual)
    scores = scorer.scores()
    check_eq(scores["false_positive_rate"], 0.5, "false positive rate")
    check_eq(scores["false_negative_rate"], 0.5, "false negative rate")
    check_eq(scores["precision"], 0.5, "precision")


def test_the_flag_store_fails_closed_and_only_a_human_enables_reasoning():
    with tempdir() as root:
        idp, human = _people()
        service = idp.authenticate("svc-runner", "svc-secret")
        ledger = Ledger(root / "ledger.jsonl", "RUN-OPS")
        flags = FlagStore(root / "flags.json", ledger=ledger)
        check(not flags.model_reasoning, "model reasoning must be off by default")
        check_raises(FlagError, lambda: flags.set("as.model_reasoning", True, actor=service, reason="try"),
                     "a service principal must not enable model reasoning")
        check_raises(FlagError, lambda: flags.set("as.enabled", True, actor="operator@example.test", reason="name only"),
                     "a flag change requires an authenticated Principal")
        flags.set("as.model_reasoning", True, actor=human, reason="approved experiment")
        check(flags.model_reasoning, "a human may enable model reasoning")
        (root / "flags.json").write_text("{ broken", encoding="utf-8")
        broken = FlagStore(root / "flags.json", ledger=ledger)
        check(not broken.ok and not broken.enabled, "an unreadable flag store must fail closed")
        check(broken.reason, "the failure must be explained")


def test_the_kill_switch_stops_the_execution_path_with_zero_provider_calls():
    with tempdir() as root:
        idp, human = _people()
        ledger = Ledger(root / "ledger.jsonl", "RUN-OPS")
        flags = FlagStore(root / "flags.json", ledger=ledger)
        index, _, _ = make_index(_SCOPE, ledger=None)
        retrieval = RetrievalIndex()
        retrieval.add_index(index)
        provider = RecordedProvider({"*": {"schema": "as.model_output/1", "payload": {"strategies": []}}})
        slot = ProviderSlot()
        slot.bind(provider, principal=human, binding_ref="AUTH-1")
        generator = Generator(scope=_SCOPE, index=index, retrieval=retrieval, assumptions=AssumptionRegistry("RUN-OPS"),
                              slot=slot, ledger=ledger, rollout=flags)

        def probe():
            before = provider.calls
            result = generator.generate(run_id="RUN-OPS", iteration=1, goals=[{"text": "consolidate services"}],
                                        constraints=[], session_ref="S1")
            return {"provider_calls": provider.calls - before, "persisted": len(result.candidates), "outcome": result.mode}

        before_stop = probe()
        check(before_stop["provider_calls"] >= 0, "the probe must exercise the execution path")
        report = drill(flags=flags, identity_provider=idp, ledger=ledger, operator=human, run_probe=probe,
                       revoke_subject="svc-runner", revoke_secret="svc-secret")
        check(report["switch_disabled"], "the drill must disable the switch")
        check_eq(report["provider_calls_after_stop"], 0, "no provider call may happen after the stop")
        check_eq(report["candidates_persisted_after_stop"], 0, "nothing may be persisted after the stop")
        check(not report["revoked_identity_reusable"], "a revoked identity must not reauthenticate")
        check(report["evidence_preserved"], "the evidence must survive the stop")
        check(report["passed"], f"the incident drill must pass: {report}")


def test_quarantine_preserves_artifacts_for_forensics():
    with tempdir() as root:
        _, human = _people()
        ledger = Ledger(root / "ledger.jsonl", "RUN-OPS")
        quarantine = Quarantine(root / "q", ledger=ledger)
        quarantine.disable_connector("api_catalog", actor=human, reason="suspected poisoning")
        check(quarantine.connector_disabled("api_catalog"), "a disabled connector must stay disabled")
        check(not quarantine.connector_disabled("requirements"), "other connectors are unaffected")
        target = quarantine.quarantine_run("RUN-BAD", actor=human, reason="incident", artifacts={"note.txt": b"evidence"})
        check((Path(target) / "note.txt").exists(), "quarantined artifacts must be preserved, not deleted")
        events = [e["event"]["event_type"] for e in ledger.events()]
        check(any("quarantine" in e or "connector" in e for e in events), f"quarantine actions must be logged: {events}")


def test_targets_are_proposed_and_ceilings_only_narrow():
    for target in TARGETS:
        check_eq(target.status, "PROPOSED", f"{target.target_id} must ship PROPOSED")
        check(not target.approved, f"{target.target_id} must not count as approved")
        check(target.owner_role, f"{target.target_id} names no owner role")
    report = evaluate_targets({"run.duration_seconds.p95": {"value": 3.0, "denominator": 10}})
    check_eq(report["verdict"], "NO_APPROVED_TARGETS", "with nothing approved the verdict must say so")
    row = next(r for r in report["rows"] if r["target_id"] == "SLO-RUN-LATENCY-01")
    check(row["state"].endswith("_under_proposed_target"), f"a met measurement must be labelled, got {row['state']}")
    zero = evaluate_targets({"run.duration_seconds.p95": {"value": 3.0, "denominator": 0}})
    check_eq(next(r for r in zero["rows"] if r["target_id"] == "SLO-RUN-LATENCY-01")["state"], "insufficient_data",
             "a zero denominator is insufficient data, never a pass")
    ceilings = effective_ceilings("local", {"max_run_seconds": 99999, "max_parallel": 1})
    check_eq(ceilings["ceilings"]["max_run_seconds"], CEILINGS["local"]["max_run_seconds"], "a request above the ceiling is clamped")
    check_eq(ceilings["ceilings"]["max_parallel"], 1, "a request below the ceiling narrows")
    check(ceilings["requests_clamped"], "clamped requests must be reported")


if __name__ == "__main__":
    import test_observability_ops
    raise SystemExit(main(test_observability_ops))
