"""Deterministic analysis, constraint rules and retrieval (WF-05, IMPL-07, COMP-*, AUDIT-ADD-12, ARCH-09)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import check, check_eq, check_raises, main  # noqa: E402

from architecture_studio.analysis import ANALYZERS, RULES, ConstraintChecker, run_analyzers  # noqa: E402
from architecture_studio.fixtures import make_index, make_scope  # noqa: E402
from architecture_studio.generator import DeterministicEvidenceGenerator  # noqa: E402
from architecture_studio.observability import Tracer  # noqa: E402
from architecture_studio.retrieval import RetrievalIndex  # noqa: E402
from architecture_studio.schemas import validate  # noqa: E402

_SCOPE = make_scope("RUN-A", classes=("requirement", "api_operation", "service", "security_constraint", "deployment_standard"))
_INDEX, _, _ = make_index(_SCOPE)


def test_analyzers_run_in_a_fixed_order_and_are_inspectable():
    tracer = Tracer("RUN-A")
    results = run_analyzers(_INDEX, trace=tracer)
    check(len(results) == len(ANALYZERS), f"every analyzer must run, got {len(results)}")
    for result in results:
        doc = result.as_document()
        check_eq(doc["derivation"], "deterministic_analyzer", "analyzer output must be labelled as such")
        check(doc["version"], f"{doc['analyzer']} carries no version")
        check(doc["result"] in ("pass", "fail", "unknown"), f"{doc['analyzer']} returned {doc['result']!r}")
    again = run_analyzers(_INDEX)
    check_eq([r.analyzer for r in results], [r.analyzer for r in again], "analyzer order must be fixed")
    check_eq([r.result for r in results], [r.result for r in again], "analyzers must be deterministic")


def test_deterministic_analysis_precedes_synthesis_in_the_trace():
    tracer = Tracer("RUN-A2")
    with tracer.span("analyzers"):
        run_analyzers(_INDEX, trace=tracer)
    with tracer.span("model.generate"):
        pass
    analyzer_spans = tracer.order_of("analyzers")
    model_spans = tracer.order_of("model.generate")
    check(analyzer_spans and model_spans, "both phases must appear in the trace")
    check(max(analyzer_spans) < min(model_spans), "deterministic results must precede model reasoning in the run trace")


def test_every_constraint_rule_produces_a_typed_check_with_evidence():
    checker = ConstraintChecker(_INDEX)
    strategies = DeterministicEvidenceGenerator().strategies(_INDEX, [{"text": "consolidate governance services"}])
    check(strategies, "the corpus must yield at least one evidence-derived strategy")
    from architecture_studio.candidates import build_candidate
    from architecture_studio.uncertainty import assess
    strategy = strategies[0]
    candidate = build_candidate(run_id="RUN-A3", iteration=1, name=strategy["name"], style=strategy["style"],
                                components=strategy["components"], relationships=strategy["relationships"],
                                deployment=strategy["deployment"], rationale=strategy["rationale"],
                                evidence_refs=strategy["evidence_refs"],
                                uncertainty=assess(evidence_refs=strategy["evidence_refs"]).as_document(),
                                generator={"generator_id": "test", "generator_version": "1.0.0", "model": None},
                                introduced_by="test")
    checks = checker.check(candidate)
    check_eq(len(checks), len(RULES), "every rule must produce a check")
    seen = set()
    for entry in checks:
        validate("as.constraint_check/1", dict(entry))
        check(entry["result"] in ("pass", "fail", "unknown"), f"{entry['rule_id']} returned {entry['result']!r}")
        check(entry["message"], f"{entry['rule_id']} produced no message")
        if entry["result"] in ("pass", "fail"):
            check(entry["evidence_refs"], f"{entry['rule_id']} decided without citing evidence")
        seen.add(entry["rule_id"])
    check_eq(len(seen), len(RULES), "rule ids must be unique")


def test_retrieval_is_deterministic_scope_filtered_and_demotes_stale():
    index, _, _ = make_index(_SCOPE)
    retrieval = RetrievalIndex()
    retrieval.add_index(index)
    first = retrieval.search("governance service", scope=_SCOPE, limit=10)
    second = retrieval.search("governance service", scope=_SCOPE, limit=10)
    check_eq([c.chunk_id for c in first.chunks], [c.chunk_id for c in second.chunks], "retrieval must be deterministic")
    check(first.chunks, "the query should retrieve something from the corpus")
    for chunk in first.chunks:
        check(chunk.data_class in _SCOPE.allowed_artifact_classes, f"{chunk.data_class} is outside the contract")
        check(chunk.evidence_ref_id, "every chunk must carry its evidence reference")
    doc = first.as_document()
    check(doc["context_manifest_digest"], "a retrieval result must produce a context manifest digest")
    labelled = first.labelled_context()
    check("data_class" in labelled or "source" in labelled.lower(), "context blocks must be source-labelled")

    narrow = _SCOPE.narrowed(artifact_classes=["service"])
    filtered = retrieval.search("governance service", scope=narrow, limit=10)
    check(all(c.data_class == "service" for c in filtered.chunks), "a narrowed scope must filter retrieval at query time")

    stale_ids = sorted({c.artifact_id for c in first.chunks[:2]})
    retrieval.mark_stale(stale_ids)
    after = retrieval.search("governance service", scope=_SCOPE, limit=10)
    positions = {c.chunk_id: i for i, c in enumerate(after.chunks)}
    stale = [c for c in after.chunks if c.freshness == "STALE"]
    current = [c for c in after.chunks if c.freshness != "STALE"]
    for s in stale:
        for c in current:
            check(positions[s.chunk_id] > positions[c.chunk_id], "a stale chunk must never outrank a current one")


def test_token_budget_and_scope_exclusions_are_reported():
    retrieval = RetrievalIndex()
    retrieval.add_index(_INDEX)
    result = retrieval.search("service", scope=_SCOPE, limit=50, token_budget=200)
    check(result.tokens_used <= 200 or result.truncated, "the token budget must bound or report truncation")
    narrow = _SCOPE.narrowed(artifact_classes=["service"])
    filtered = retrieval.search("service", scope=narrow, limit=50)
    check(filtered.excluded_by_scope >= 0, "scope exclusions must be counted, not hidden")


if __name__ == "__main__":
    import test_analysis
    raise SystemExit(main(test_analysis))
