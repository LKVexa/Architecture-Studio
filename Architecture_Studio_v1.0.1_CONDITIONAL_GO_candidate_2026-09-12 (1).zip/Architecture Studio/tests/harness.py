"""Minimal stdlib test harness (no third-party test runner; the package has zero required deps).

Each test module defines module-level ``test_*`` callables. ``run_module`` executes
them in definition order and returns a machine-readable result so ``run_all.py`` can
run one class at a time (the device runs under a per-invocation time cap).
"""
from __future__ import annotations

import contextlib
import io
import shutil
import sys
import tempfile
import time
import traceback
from pathlib import Path
from types import ModuleType
from typing import Any, Callable

OVERLAY = Path(__file__).resolve().parent.parent
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))


class Failure(AssertionError):
    pass


def check(condition: Any, message: str) -> None:
    if not condition:
        raise Failure(message)


def check_eq(actual: Any, expected: Any, message: str = "") -> None:
    if actual != expected:
        raise Failure(f"{message or 'values differ'}: expected {expected!r}, got {actual!r}")


def check_raises(exception: type[BaseException] | tuple[type[BaseException], ...], fn: Callable[[], Any], message: str = "",
                 *, code: str | None = None) -> BaseException:
    try:
        fn()
    except exception as exc:
        if code is not None and getattr(exc, "code", None) != code:
            raise Failure(f"{message}: expected code {code!r}, got {getattr(exc, 'code', None)!r}") from None
        return exc
    raise Failure(message or f"expected {exception} to be raised")


@contextlib.contextmanager
def tempdir(prefix: str = "as-test-"):
    path = Path(tempfile.mkdtemp(prefix=prefix))
    try:
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)


def run_module(module: ModuleType, *, verbose: bool = True) -> dict[str, Any]:
    names = [n for n in vars(module) if n.startswith("test_") and callable(getattr(module, n))]
    names.sort(key=lambda n: getattr(module, n).__code__.co_firstlineno)
    results = []
    for name in names:
        started = time.perf_counter()
        buffer = io.StringIO()
        try:
            with contextlib.redirect_stdout(buffer):
                getattr(module, name)()
            outcome, detail = "PASS", ""
        except Failure as exc:
            outcome, detail = "FAIL", str(exc)
        except Exception:
            outcome, detail = "ERROR", traceback.format_exc(limit=6)
        elapsed = round((time.perf_counter() - started) * 1000, 1)
        results.append({"test": name, "result": outcome, "ms": elapsed, "detail": detail})
        if verbose:
            print(f"  {outcome:5} {name} ({elapsed} ms)" + (f"\n        {detail.splitlines()[-1]}" if detail else ""))
    passed = sum(1 for r in results if r["result"] == "PASS")
    return {"module": module.__name__, "total": len(results), "passed": passed,
            "failed": [r for r in results if r["result"] != "PASS"], "results": results,
            "all_passed": passed == len(results) and bool(results)}


def main(module: ModuleType) -> int:
    report = run_module(module)
    print(f"{report['module']}: {report['passed']}/{report['total']} passed")
    return 0 if report["all_passed"] else 1
