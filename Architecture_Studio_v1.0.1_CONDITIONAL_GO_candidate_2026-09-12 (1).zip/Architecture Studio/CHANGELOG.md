# Changelog

All notable changes to this overlay. The format follows Keep a Changelog; versions follow SemVer.
Application code, schemas, policies, prompts, analyzers, the benchmark corpus and documentation are
versioned **together** (AUDIT-ADD-21) — `architecture_studio.version_manifest()` is what a run records.

## [1.0.0] — 2026-09-12 (ASGO declared-path evidence and portable inventory; production verdict remains NO_GO)

Applied remaining W0 package requirements after ingesting the 150-item ASGO series.
This pass is still the implementer. Nothing below is a verification or a Production GO.

### Added / corrected

- **Declared evidence paths** — implementer notes now land at the package-declared
  locations (`evidence/reports/package/ASGO-0.1.json`, …). Filenames
  `evidence/reviews/GATE-PROD-*.json` are reserved for independent reviewers and
  are not written by this runtime.
- **Portable pins (ASGO-0.9 / 0.10)** — package pins, product contract, and
  overlay tree digest no longer embed sandbox absolute paths. Package lookup
  prefers overlay-relative source pins; `/workspace/attachments` is not a hard
  dependency.
- **Hygiene scan** — `__pycache__` is gitignored and stripped from the release
  tree. Historical `evidence/*/SUITE.json` stdout tails remain forensic.
- **ASGO-0.7** — `MASTER_PROMPT_WORKFLOW_PACKAGE.md` digest verified at
  `asfw/source/`. `INDEX.csv` remains ABSENT.

### Deliberately still not done

- Production verdict remains **NO_GO**.
- ASGO `verified=0`, `done=0`, `complete=0`.
- Waves 1 and 4–10 (except encoded fail-closed items) remain BLOCKED.

## [1.0.0] — 2026-09-12 (ASGO 150-item register; production verdict remains NO_GO)


Ingested `Architecture_Studio_Production_GO_Prompts_and_Workflows_2026-09-12.md`
(150 items, sha256 `41209097b7b6d7fdaf905a7d52776be8557214049741ad4df5c89bf1982971b9`).
This pass is the implementer. Nothing below is a verification, an approval, or a
Production GO.

### Added

- **Overlay-only product contract** (`architecture_studio.corpus`) — the 612-file
  corpus is a sibling of the overlay (`overlay.parent`), never packaged inside
  the overlay zip. Preflight fails closed with `corpus_absent` /
  `wrong_root_or_layout` / `digest_mismatch`.
- **Archive layout skip (ASGO-0.5)** — `_archive/` and top-level `SHA256SUMS.txt`
  / `CANDIDATE_README.md` are not corpus members. Nested `Anthology/SHA256SUMS.txt`
  remains a corpus file.
- **ASGO register** (`architecture_studio.asgo`) — 150 unique IDs, wave occupancy
  15/14/20/14/12/12/12/14/12/13/12. `IMPLEMENTED` is not `DONE`. `claim_done` raises.
  `production_go_from_asgo` is `NO_GO`.
- **CLI** `architecture-studio asgo` and `architecture-studio preflight`.
- **CTRL-ASGO-01 / STOP-ASGO / LIM-14** — self-attested GO, invented `INDEX.csv`,
  invented ninth gate, and implementer-DONE are denied.
- Source pins copied into `asgo/source/` and `asfw/source/`.
- `.gitignore` for `__pycache__` (ASGO-0.9). Python 3.12 classifier declared
  (ASGO-0.11; 3.11/3.12 not executed here).

### Honest counts (ASGO-0.12 / 0.13)

- `150/150` was the post-ASFW suite **with** the sibling corpus present. It is
  not evidence that an overlay-only zip is self-contained.
- `120/150` is the overlay-only archive **without** the corpus; corpus-dependent
  tests fail closed. Do not skip them.
- `6/1/1` vs `5/2/1` gate snapshots differ by evidence assembly / missing corpus,
  not by a new PASS. Production still requires eight gates PASS.

### Deliberately still not done

- Production verdict remains **NO_GO**.
- ASGO `verified=0`, `done=0`, `complete=0`.
- Source `INDEX.csv` still absent. DOD definitions and gate count still
  `UNRESOLVED`. Product contract status is `PROPOSED` (unsigned).
- Named humans, IdP, KMS, environments, threshold approvals, gate reviews,
  and independent verification remain external handoffs.

## [1.0.0] — 2026-09-11 (ASFW 545-item register; production verdict remains NO_GO)


Ingested the Architecture Studio & Full-Loop Design Workbench master prompt/workflow
package (545 items). This pass is the implementer. Nothing below is a verification,
an approval, or a Production GO.

### Added

- **ASFW register** (`architecture_studio.asfw`) — parses and pins
  `MASTER_PROMPT_WORKFLOW_PACKAGE.md` by SHA-256
  (`c94ed9bd6f41bd034cc0136183010f9f7ddb1823fcdb25c55a7c138a026048d2`).
  Source `INDEX.csv` is recorded **ABSENT**; a derived index is labelled derived
  and is not a substitute source of truth.
- **ASFW-TODO-0001..0006 governance machinery** — every item has owner /
  implementer / independent-reviewer *roles*, environment, due date slot, unique
  `ASFW-IMPL-NNNN` id, and an evidence-link schema. Persons and calendar dates
  remain `UNSET` until the roster is filled.
- **ASFW-TODO-0002** — source identifiers `BLK-*`, `DEC-*`, `P*`, `FLOW-*`,
  `DOD-*` (and related) are extracted exactly and must round-trip.
- **ASFW-TODO-0005** — `PROPOSED` / `IMPLEMENTED` / `AWAITING_CONFIRMATION` /
  `ACCEPTED_RISK` are incomplete until independent review. `CTRL-ASFW-01` and
  `STOP-ASFW` deny self-attested GO, inferred missing DOD, and an inferred
  ninth gate.
- **ASFW-TODO-0007 / 0008** — missing `DOD-02/04/05/08/09` and the
  `GATE-PROD-01-09` vs eight executable gates question are `BLOCKED`
  source-ambiguity records. They were not inferred. Handoff:
  `handoff/HANDOFF-ASFW-0007-0008-SOURCE-AMBIGUITY.md`.
- **ASFW-TODO-0545** — any unverified ASFW item is an automatic `NO_GO`.
- CLI: `architecture-studio asfw`.

### Tests

- 145 tests across 18 control classes (was 134). Eleven ASFW tests cover pin
  integrity, 545 unique IDs, assignment slots, identifier preservation,
  ambiguity non-inference, self-review refusal, and derived-vs-source index.

### Deliberately still not done

- Production verdict remains **NO_GO**.
- ASFW `verified=0`, `complete=0`. `IMPLEMENTED` is not `VERIFIED`.
- Source `INDEX.csv` still absent. DOD definitions and gate count still
  `UNRESOLVED`.
- Named humans, IdP, KMS, environments, threshold approvals, gate reviews,
  and independent verification remain external handoffs.

## [1.0.0] — 2026-09-11 (audit remediations; production verdict remains NO_GO)


Audit remediations applied on top of the 2026-09-07 first application. Runtime identity stays `1.0.0`
(ASRTD/1.4.0). Nothing in this section is a verification, an approval, or a Production GO.

### 2026-09-12 — Conditional GO qualification boundary

- Added a fail-closed `conditional-go` CLI command and `as.conditional_go/1`
  record for a time-bounded local/synthetic test-tenant evaluation scope.
- The new path requires passing mechanical evidence for the complete test
  suite, write-authority scan, real-run VERIFY-01, incident/recovery exercises,
  current operational docs, controls, provenance, and bypass resistance.
- Proposed thresholds, missing independent reviews, absent host bindings, and
  the lack of a model provider remain explicit conditions. The record always
  preserves `production_verdict=NO_GO` and `promotion_authorized=false`.

### Fixed

- **Expired fixture contracts** — default `issued_at` is now `datetime.now(timezone.utc)` instead of the
  hardcoded 2026-09-07 stamp that expired after 24 hours and made 29 tests fail closed as `contract has expired`.
- **Path confinement** — `confine()` refuses NULs, control characters, absolute paths, `..` segments,
  Windows reserved device names, and over-long paths, and uses `Path.relative_to` rather than a prefix match.
- **Write-gate bundle** — case-file export no longer `shutil.copy2`s leftover files after a single-file
  preview. `WriteGate.attempt_bundle` confines every path, consumes the token once (fail-closed, before the
  first byte), writes, and rolls back on failure.
- **Write-authority scan** — AST persist-site scan for GATE-PROD-03. Unreviewed persist sites are hidden
  write authority. Current scan: 42 sites, 0 hidden, mechanical PASS.
- **Gate evidence assembly** — `cli gates` / `status` previously passed only the docs freshness report, so
  four gates reported `NO_EVIDENCE` even though the runtime could produce the artifacts. `gate_evidence`
  now assembles tests, controls, docs, write scan, benchmark, verification, incident drill, and recovery.
  It never invents a `security_review`.
- **Control-to-test mapping** — `controls_document()` maps every enforceable control to its
  `CONTROL_OWNERSHIP` test module so GATE-PROD-01 no longer fails as "controls without tests".
- **Atomic write portability** — `os.replace` in the destination directory; fsync best-effort on hosts
  that refuse it.
- **Sandbox honesty** — `SandboxPolicy.isolation_class = "process-level"`.
- **On-disk review loader** — `evidence/reviews/*.json` is loaded if a human
  places it; signatures by the implementer / runtime are still refused. Missing
  files remain not-PASS.
- **Production GO to-do** — `PRODUCTION_GO_TODO.md` sequences Waves 1–8
  (roster, IdP/KMS, environments, thresholds, security review, gate reviews,
  227-task verification, qualify+promote).
- **ASFW 545-item register** — immutable package pin, derived index (source
  `INDEX.csv` ABSENT), governance 0001–0006, source-ambiguity 0007/0008 not inferred.
- **Chat-signature intake** — `RUSSELL PHILIP SMITHSON` recorded as a
  `PROPOSED_UNBOUND` research-specialist offer. Same-session chat is not
  independent. One person cannot fill every review slot. Keep-undefined
  source-gap records still block GO. No gate PASS files written.

### Tests

- 150 tests across 19 control classes (was 134). Added ASFW register tests and
  roster intake tests (chat signature ≠ review; one person ≠ full roster).

### Deliberately still not done

- Production verdict remains **NO_GO**.
- GATE-PROD-02 FAILs: every numeric threshold is `PROPOSED`.
- GATE-PROD-07 has `NO_EVIDENCE`: the runtime cannot review itself.
- Remaining mechanically passing gates are `AWAITING_INDEPENDENT_REVIEW`.
- 1 task `IMPLEMENTED`, 226 `BLOCKED`, 0 `VERIFIED`, verifier `null`.
- No model provider, host IdP, or KMS is bound; CI/staging/production-read-only/privileged are not provisioned.

See `AUDIT_NO_GO_REPORT.md` and `handoff/`.

## [1.0.0] — 2026-09-07

First application of the ASRTD v1.4.0 prompt/workflow package (227 tasks, 16 phases, evidence protocol
`ASRTD/*/3`) to the generic project repository, as an additive overlay.

### Added

- **Foundations** — requirement registry over the two pinned source documents (227 requirements: 92 original,
  97 anonymous checkboxes and 12 workflow steps given stable IDs, 26 audit additions), canonical control
  ownership (19 families, every alias resolving to exactly one owner), measurable acceptance criteria for
  every requirement, RACI and escalation naming roles rather than people.
- **Authority** — machine-readable scope contracts, separated permissions, short-lived credential leases,
  composition that may only narrow, and an identity-provider slot that fails closed.
- **Policy** — paper guardrails as executable controls with typed stop conditions, including a rollout kill
  switch consulted on the execution path.
- **Evidence** — nine typed read-only connectors over the corpus and fixtures, content-hash revision
  pinning, normalization with quarantine, a requirement graph, and deterministic BM25 retrieval that demotes
  stale evidence and filters by scope at query time.
- **Analysis and synthesis** — four analyzers and nine constraint rules that run before any synthesis; a
  deterministic evidence generator behind an empty model-provider slot; distinctness, trade-off and diagram
  layers that cite or label every material claim.
- **Verification and review** — an independent verification pass (VERIFY-01..06 plus schema, security and
  policy re-checks) recorded separately from generation; review packages that show what was *not* analyzed;
  approval tokens bound to approver, run, gate, artifacts, action, scope, subject, expiry and nonce.
- **Side effects** — one fail-closed write gate with preview; auditable case-file export that an outside
  party can inspect without the runtime.
- **Operations** — hash-chained ledger, content-addressed store with compare-and-swap, envelope encryption
  behind a key-provider boundary, retention that refuses to erase audit-mandatory classes, process-level
  sandbox, structured logging, metrics with denominators, span trees, permission-anomaly alerts, incident
  drill, backup/restore exercise.
- **Programme** — offline benchmark with verbatim BIPIA/llmail adversarial corpora and separately reported
  MODEL-07 failure modes; review-burden and pilot-exit machinery; six environment descriptors; release
  manifest, qualification rule and rollback plan; twelve documents generated from the runtime with freshness
  digests; eight production gates; 129 tests across 17 control classes; a CLI.
- **Evidence records** — `tools/build_evidence.py` writes one protocol-v3 `EXECUTION_REPORT` per task from
  checks that actually ran, plus `PROGRAM_STATE.json`.

### Deliberately not done

- Nothing is verified or accepted. 1 record `IMPLEMENTED`, 226 `BLOCKED`, verifier `null` everywhere,
  production verdict `NO_GO`. See `README.md` and `docs/DOC-12-known-limitations.md`.
- No threshold is approved; no model provider, identity provider or KMS is bound; CI, staging and the
  conditional environments are declared, not provisioned.

### Unchanged

- The 612-file generic project corpus. Digest
  `16b9800f326777dcd5f6e4d58aeb97cc99ceb3a972abbbce37b0d48f1289d4e2`, asserted by `tools/verify_corpus.py`
  and by the test suite.
