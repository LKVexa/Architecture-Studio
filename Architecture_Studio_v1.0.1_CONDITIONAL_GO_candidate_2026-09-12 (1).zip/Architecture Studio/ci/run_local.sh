#!/usr/bin/env sh
# The same checks CI runs, locally, in order. Stops at the first failure.
set -eu
cd "$(dirname "$0")/.."
echo "== supply chain"
python3 -c "import sys;sys.path.insert(0,'.');from architecture_studio.supply_chain import inventory,policy_check;import json;r=policy_check(inventory());print(r['verdict']);raise SystemExit(0 if r['verdict']=='PASS' else 1)"
echo "== corpus untouched"
python3 tools/verify_corpus.py >/dev/null && echo untouched
echo "== documentation current"
python3 -m architecture_studio docs --check >/dev/null && echo current
echo "== tests"
python3 tests/run_all.py "$@"
echo "== benchmark"
python3 -m architecture_studio benchmark >/dev/null && echo "benchmark suite passed"
echo "== gates"
python3 -m architecture_studio gates | python3 -c "import json,sys;d=json.load(sys.stdin);print(d['verdict'], d['counts'])"
